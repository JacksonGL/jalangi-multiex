jalangiLabel7:
    while (true) {
        try {
            J$.Se(1653, '../tests/multiex/algorithms/Prim_jalangi_.js');
            J$.N(1657, 'Edge', Edge, false);
            J$.N(1661, 'Graph', Graph, false);
            J$.N(1669, 'Prim', J$.T(1665, Prim, 12), false);
            J$.N(1673, 'g', g, false);
            J$.N(1677, 'nodes', nodes, false);
            J$.N(1681, 'edges', edges, false);
            J$.N(1685, 'i', i, false);
            J$.N(1689, 'edge', edge, false);
            J$.N(1693, 'index1', index1, false);
            J$.N(1697, 'index2', index2, false);
            J$.N(1701, 'result', result, false);
            var Edge = J$.W(65, 'Edge', J$.T(61, function (source, sink, capacity) {
                    jalangiLabel0:
                        while (true) {
                            try {
                                J$.Fe(41, arguments.callee, this);
                                arguments = J$.N(45, 'arguments', arguments, true);
                                source = J$.N(49, 'source', source, true);
                                sink = J$.N(53, 'sink', sink, true);
                                capacity = J$.N(57, 'capacity', capacity, true);
                                J$.P(13, J$.R(5, 'this', this, false), 'source', J$.R(9, 'source', source, false));
                                J$.P(25, J$.R(17, 'this', this, false), 'sink', J$.R(21, 'sink', sink, false));
                                J$.P(37, J$.R(29, 'this', this, false), 'capacity', J$.R(33, 'capacity', capacity, false));
                            } catch (J$e) {
                                J$.Ex(1705, J$e);
                            } finally {
                                if (J$.Fr(1709))
                                    continue jalangiLabel0;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12), Edge);
            var Graph = J$.W(541, 'Graph', J$.T(537, function () {
                    jalangiLabel4:
                        while (true) {
                            try {
                                J$.Fe(529, arguments.callee, this);
                                arguments = J$.N(533, 'arguments', arguments, true);
                                J$.P(77, J$.R(69, 'this', this, false), 'edges', J$.T(73, {}, 11));
                                J$.P(89, J$.R(81, 'this', this, false), 'nodes', J$.T(85, [], 10));
                                J$.P(101, J$.R(93, 'this', this, false), 'nodeMap', J$.T(97, {}, 11));
                                J$.P(205, J$.R(105, 'this', this, false), 'addNode', J$.T(201, function (node) {
                                    jalangiLabel1:
                                        while (true) {
                                            try {
                                                J$.Fe(189, arguments.callee, this);
                                                arguments = J$.N(193, 'arguments', arguments, true);
                                                node = J$.N(197, 'node', node, true);
                                                J$.P(133, J$.G(113, J$.R(109, 'this', this, false), 'nodes'), J$.G(125, J$.G(121, J$.R(117, 'this', this, false), 'nodes'), 'length'), J$.R(129, 'node', node, false));
                                                J$.P(165, J$.G(141, J$.R(137, 'this', this, false), 'nodeMap'), J$.R(145, 'node', node, false), J$.B(6, '-', J$.G(157, J$.G(153, J$.R(149, 'this', this, false), 'nodes'), 'length'), J$.T(161, 1, 22)));
                                                J$.P(185, J$.G(173, J$.R(169, 'this', this, false), 'edges'), J$.R(177, 'node', node, false), J$.T(181, [], 10));
                                            } catch (J$e) {
                                                J$.Ex(1713, J$e);
                                            } finally {
                                                if (J$.Fr(1717))
                                                    continue jalangiLabel1;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12));
                                J$.P(365, J$.R(209, 'this', this, false), 'addEdge', J$.T(361, function (source, sink, capacity) {
                                    jalangiLabel2:
                                        while (true) {
                                            try {
                                                J$.Fe(341, arguments.callee, this);
                                                arguments = J$.N(345, 'arguments', arguments, true);
                                                source = J$.N(349, 'source', source, true);
                                                sink = J$.N(353, 'sink', sink, true);
                                                capacity = J$.N(357, 'capacity', capacity, true);
                                                J$.P(273, J$.G(225, J$.G(217, J$.R(213, 'this', this, false), 'edges'), J$.R(221, 'source', source, false)), J$.G(245, J$.G(241, J$.G(233, J$.R(229, 'this', this, false), 'edges'), J$.R(237, 'source', source, false)), 'length'), J$.T(269, J$.F(265, J$.R(249, 'Edge', Edge, false), true)(J$.R(253, 'source', source, false), J$.R(257, 'sink', sink, false), J$.R(261, 'capacity', capacity, false)), 11));
                                                J$.P(337, J$.G(289, J$.G(281, J$.R(277, 'this', this, false), 'edges'), J$.R(285, 'sink', sink, false)), J$.G(309, J$.G(305, J$.G(297, J$.R(293, 'this', this, false), 'edges'), J$.R(301, 'sink', sink, false)), 'length'), J$.T(333, J$.F(329, J$.R(313, 'Edge', Edge, false), true)(J$.R(317, 'sink', sink, false), J$.R(321, 'source', source, false), J$.R(325, 'capacity', capacity, false)), 11));
                                            } catch (J$e) {
                                                J$.Ex(1721, J$e);
                                            } finally {
                                                if (J$.Fr(1725))
                                                    continue jalangiLabel2;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12));
                                J$.P(525, J$.R(369, 'this', this, false), 'edgeExists', J$.T(521, function (source, sink) {
                                    jalangiLabel3:
                                        while (true) {
                                            try {
                                                J$.Fe(501, arguments.callee, this);
                                                arguments = J$.N(505, 'arguments', arguments, true);
                                                source = J$.N(509, 'source', source, true);
                                                sink = J$.N(513, 'sink', sink, true);
                                                J$.N(517, 'i', i, false);
                                                if (J$.C(12, J$.B(10, '!==', J$.G(385, J$.G(377, J$.R(373, 'this', this, false), 'edges'), J$.R(381, 'source', source, false)), J$.T(389, undefined, 24))))
                                                    for (var i = J$.W(397, 'i', J$.T(393, 0, 22), i); J$.C(8, J$.B(14, '<', J$.R(401, 'i', i, false), J$.G(421, J$.G(417, J$.G(409, J$.R(405, 'this', this, false), 'edges'), J$.R(413, 'source', source, false)), 'length'))); J$.B(26, '-', i = J$.W(429, 'i', J$.B(22, '+', J$.U(18, '+', J$.R(425, 'i', i, false)), 1), i), 1))
                                                        if (J$.C(4, J$.B(30, '==', J$.G(457, J$.G(453, J$.G(445, J$.G(437, J$.R(433, 'this', this, false), 'edges'), J$.R(441, 'source', source, false)), J$.R(449, 'i', i, false)), 'sink'), J$.R(461, 'sink', sink, false))))
                                                            return J$.Rt(489, J$.G(485, J$.G(477, J$.G(469, J$.R(465, 'this', this, false), 'edges'), J$.R(473, 'source', source, false)), J$.R(481, 'i', i, false)));
                                                return J$.Rt(497, J$.T(493, null, 25));
                                            } catch (J$e) {
                                                J$.Ex(1729, J$e);
                                            } finally {
                                                if (J$.Fr(1733))
                                                    continue jalangiLabel3;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12));
                            } catch (J$e) {
                                J$.Ex(1737, J$e);
                            } finally {
                                if (J$.Fr(1741))
                                    continue jalangiLabel4;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12), Graph);
            function Prim(graph) {
                jalangiLabel6:
                    while (true) {
                        try {
                            J$.Fe(1037, arguments.callee, this);
                            arguments = J$.N(1041, 'arguments', arguments, true);
                            graph = J$.N(1045, 'graph', graph, true);
                            J$.N(1049, 'result', result, false);
                            J$.N(1053, 'usedNodes', usedNodes, false);
                            J$.N(1061, 'findMin', J$.T(1057, findMin, 12), false);
                            J$.N(1065, 'node', node, false);
                            J$.N(1069, 'min', min, false);
                            var result = J$.W(549, 'result', J$.T(545, [], 10), result);
                            var usedNodes = J$.W(557, 'usedNodes', J$.T(553, {}, 11), usedNodes);
                            function findMin(g) {
                                jalangiLabel5:
                                    while (true) {
                                        try {
                                            J$.Fe(845, arguments.callee, this);
                                            arguments = J$.N(849, 'arguments', arguments, true);
                                            g = J$.N(853, 'g', g, true);
                                            J$.N(857, 'min', min, false);
                                            J$.N(861, 'i', i, false);
                                            J$.N(865, 'n', n, false);
                                            var min = J$.W(573, 'min', J$.T(569, [
                                                    J$.T(561, 999999, 22),
                                                    J$.T(565, null, 25)
                                                ], 10), min);
                                            for (var i = J$.W(581, 'i', J$.T(577, 0, 22), i); J$.C(28, J$.B(34, '<', J$.R(585, 'i', i, false), J$.G(593, J$.R(589, 'result', result, false), 'length'))); J$.B(46, '-', i = J$.W(601, 'i', J$.B(42, '+', J$.U(38, '+', J$.R(597, 'i', i, false)), 1), i), 1))
                                                for (var n = J$.W(609, 'n', J$.T(605, 0, 22), n); J$.C(24, J$.B(50, '<', J$.R(613, 'n', n, false), J$.G(641, J$.G(637, J$.G(621, J$.R(617, 'g', g, false), 'edges'), J$.G(633, J$.R(625, 'result', result, false), J$.R(629, 'i', i, false))), 'length'))); J$.B(62, '-', n = J$.W(649, 'n', J$.B(58, '+', J$.U(54, '+', J$.R(645, 'n', n, false)), 1), n), 1))
                                                    if (J$.C(20, J$.C(16, J$.B(66, '<', J$.G(685, J$.G(681, J$.G(673, J$.G(657, J$.R(653, 'g', g, false), 'edges'), J$.G(669, J$.R(661, 'result', result, false), J$.R(665, 'i', i, false))), J$.R(677, 'n', n, false)), 'capacity'), J$.G(697, J$.R(689, 'min', min, false), J$.T(693, 0, 22)))) ? J$.B(70, '===', J$.G(741, J$.R(701, 'usedNodes', usedNodes, false), J$.G(737, J$.G(733, J$.G(725, J$.G(709, J$.R(705, 'g', g, false), 'edges'), J$.G(721, J$.R(713, 'result', result, false), J$.R(717, 'i', i, false))), J$.R(729, 'n', n, false)), 'sink')), J$.T(745, undefined, 24)) : J$._()))
                                                        min = J$.W(825, 'min', J$.T(821, [
                                                            J$.G(781, J$.G(777, J$.G(769, J$.G(753, J$.R(749, 'g', g, false), 'edges'), J$.G(765, J$.R(757, 'result', result, false), J$.R(761, 'i', i, false))), J$.R(773, 'n', n, false)), 'capacity'),
                                                            J$.G(817, J$.G(813, J$.G(805, J$.G(789, J$.R(785, 'g', g, false), 'edges'), J$.G(801, J$.R(793, 'result', result, false), J$.R(797, 'i', i, false))), J$.R(809, 'n', n, false)), 'sink')
                                                        ], 10), min);
                                            return J$.Rt(841, J$.G(837, J$.R(829, 'min', min, false), J$.T(833, 1, 22)));
                                        } catch (J$e) {
                                            J$.Ex(1745, J$e);
                                        } finally {
                                            if (J$.Fr(1749))
                                                continue jalangiLabel5;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            var node = J$.W(913, 'node', J$.G(909, J$.G(873, J$.R(869, 'g', g, false), 'nodes'), J$.M(905, J$.I(typeof Math === 'undefined' ? Math = J$.R(877, 'Math', undefined, true) : Math = J$.R(877, 'Math', Math, true)), 'round', false)(J$.B(78, '*', J$.M(885, J$.I(typeof Math === 'undefined' ? Math = J$.R(881, 'Math', undefined, true) : Math = J$.R(881, 'Math', Math, true)), 'random', false)(), J$.B(74, '-', J$.G(897, J$.G(893, J$.R(889, 'g', g, false), 'nodes'), 'length'), J$.T(901, 1, 22))))), node);
                            J$.P(933, J$.R(917, 'result', result, false), J$.G(925, J$.R(921, 'result', result, false), 'length'), J$.R(929, 'node', node, false));
                            J$.P(949, J$.R(937, 'usedNodes', usedNodes, false), J$.R(941, 'node', node, false), J$.T(945, true, 23));
                            var min = J$.W(965, 'min', J$.F(961, J$.R(953, 'findMin', findMin, false), false)(J$.R(957, 'g', g, false)), min);
                            while (J$.C(32, J$.B(82, '!=', J$.R(969, 'min', min, false), J$.T(973, null, 25)))) {
                                J$.P(993, J$.R(977, 'result', result, false), J$.G(985, J$.R(981, 'result', result, false), 'length'), J$.R(989, 'min', min, false));
                                J$.P(1009, J$.R(997, 'usedNodes', usedNodes, false), J$.R(1001, 'min', min, false), J$.T(1005, true, 23));
                                min = J$.W(1025, 'min', J$.F(1021, J$.R(1013, 'findMin', findMin, false), false)(J$.R(1017, 'g', g, false)), min);
                            }
                            return J$.Rt(1033, J$.R(1029, 'result', result, false));
                        } catch (J$e) {
                            J$.Ex(1753, J$e);
                        } finally {
                            if (J$.Fr(1757))
                                continue jalangiLabel6;
                            else
                                return J$.Ra();
                        }
                    }
            }
            ;
            var g = J$.W(1085, 'g', J$.T(1081, J$.F(1077, J$.R(1073, 'Graph', Graph, false), true)(), 11), g);
            var nodes = J$.W(1117, 'nodes', J$.T(1113, [
                    J$.T(1089, 'a', 21),
                    J$.T(1093, 'b', 21),
                    J$.T(1097, 'c', 21),
                    J$.T(1101, 'd', 21),
                    J$.T(1105, 'e', 21),
                    J$.T(1109, 'f', 21)
                ], 10), nodes);
            var edges = J$.W(1125, 'edges', J$.T(1121, [], 10), edges);
            for (var i = J$.W(1133, 'i', J$.T(1129, 0, 22), i); J$.C(44, J$.B(86, '<', J$.R(1137, 'i', i, false), J$.T(1141, 12, 22))); J$.B(98, '-', i = J$.W(1149, 'i', J$.B(94, '+', J$.U(90, '+', J$.R(1145, 'i', i, false)), 1), i), 1)) {
                var edge = J$.W(1157, 'edge', J$.T(1153, [], 10), edge);
                var index1 = J$.W(1169, 'index1', J$.M(1165, J$, 'readInput', false)(J$.T(1161, 1, 22)), index1);
                if (J$.C(36, J$.B(102, '>=', J$.R(1173, 'index1', index1, false), J$.G(1181, J$.R(1177, 'nodes', nodes, false), 'length')))) {
                    index1 = J$.W(1197, 'index1', J$.B(106, '%', J$.R(1185, 'index1', index1, false), J$.G(1193, J$.R(1189, 'nodes', nodes, false), 'length')), index1);
                }
                var index2 = J$.W(1209, 'index2', J$.M(1205, J$, 'readInput', false)(J$.T(1201, 2, 22)), index2);
                if (J$.C(40, J$.B(110, '>=', J$.R(1213, 'index2', index2, false), J$.G(1221, J$.R(1217, 'nodes', nodes, false), 'length')))) {
                    index2 = J$.W(1237, 'index2', J$.B(114, '%', J$.R(1225, 'index2', index2, false), J$.G(1233, J$.R(1229, 'nodes', nodes, false), 'length')), index2);
                }
                J$.P(1261, J$.R(1241, 'edge', edge, false), J$.T(1245, 0, 22), J$.G(1257, J$.R(1249, 'nodes', nodes, false), J$.R(1253, 'index1', index1, false)));
                J$.P(1285, J$.R(1265, 'edge', edge, false), J$.T(1269, 1, 22), J$.G(1281, J$.R(1273, 'nodes', nodes, false), J$.R(1277, 'index2', index2, false)));
                J$.P(1305, J$.R(1289, 'edge', edge, false), J$.T(1293, 2, 22), J$.M(1301, J$, 'readInput', false)(J$.T(1297, 3, 22)));
                J$.M(1349, J$.R(1309, 'g', g, false), 'addEdge', false)(J$.G(1321, J$.R(1313, 'edge', edge, false), J$.T(1317, 0, 22)), J$.G(1333, J$.R(1325, 'edge', edge, false), J$.T(1329, 1, 22)), J$.G(1345, J$.R(1337, 'edge', edge, false), J$.T(1341, 2, 22)));
            }
            J$.M(1361, J$.R(1353, 'g', g, false), 'addNode', false)(J$.T(1357, 'a', 21));
            J$.M(1373, J$.R(1365, 'g', g, false), 'addNode', false)(J$.T(1369, 'b', 21));
            J$.M(1385, J$.R(1377, 'g', g, false), 'addNode', false)(J$.T(1381, 'c', 21));
            J$.M(1397, J$.R(1389, 'g', g, false), 'addNode', false)(J$.T(1393, 'd', 21));
            J$.M(1409, J$.R(1401, 'g', g, false), 'addNode', false)(J$.T(1405, 'e', 21));
            J$.M(1421, J$.R(1413, 'g', g, false), 'addNode', false)(J$.T(1417, 'f', 21));
            J$.M(1441, J$.R(1425, 'g', g, false), 'addEdge', false)(J$.T(1429, 'a', 21), J$.T(1433, 'b', 21), J$.T(1437, 1, 22));
            J$.M(1461, J$.R(1445, 'g', g, false), 'addEdge', false)(J$.T(1449, 'b', 21), J$.T(1453, 'c', 21), J$.T(1457, 3, 22));
            J$.M(1481, J$.R(1465, 'g', g, false), 'addEdge', false)(J$.T(1469, 'a', 21), J$.T(1473, 'd', 21), J$.T(1477, 3, 22));
            J$.M(1501, J$.R(1485, 'g', g, false), 'addEdge', false)(J$.T(1489, 'b', 21), J$.T(1493, 'd', 21), J$.T(1497, 2, 22));
            J$.M(1521, J$.R(1505, 'g', g, false), 'addEdge', false)(J$.T(1509, 'd', 21), J$.T(1513, 'e', 21), J$.T(1517, 3, 22));
            J$.M(1541, J$.R(1525, 'g', g, false), 'addEdge', false)(J$.T(1529, 'b', 21), J$.T(1533, 'e', 21), J$.T(1537, 6, 22));
            J$.M(1561, J$.R(1545, 'g', g, false), 'addEdge', false)(J$.T(1549, 'b', 21), J$.T(1553, 'f', 21), J$.T(1557, 5, 22));
            J$.M(1581, J$.R(1565, 'g', g, false), 'addEdge', false)(J$.T(1569, 'c', 21), J$.T(1573, 'e', 21), J$.T(1577, 4, 22));
            J$.M(1601, J$.R(1585, 'g', g, false), 'addEdge', false)(J$.T(1589, 'e', 21), J$.T(1593, 'f', 21), J$.T(1597, 2, 22));
            J$.M(1621, J$.R(1605, 'g', g, false), 'addEdge', false)(J$.T(1609, 'c', 21), J$.T(1613, 'f', 21), J$.T(1617, 4, 22));
            var result = J$.W(1637, 'result', J$.F(1633, J$.R(1625, 'Prim', Prim, false), false)(J$.R(1629, 'g', g, false)), result);
            J$.M(1649, J$.I(typeof console === 'undefined' ? console = J$.R(1641, 'console', undefined, true) : console = J$.R(1641, 'console', console, true)), 'log', false)(J$.R(1645, 'result', result, false));
        } catch (J$e) {
            J$.Ex(1761, J$e);
        } finally {
            if (J$.Sr(1765))
                continue jalangiLabel7;
            else
                break jalangiLabel7;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=Prim_jalangi_.js.map