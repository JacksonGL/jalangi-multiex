jalangiLabel3:
    while (true) {
        try {
            J$.Se(609, '../tests/multiex/algorithms/bfs_jalangi_.js');
            J$.N(617, 'visit', J$.T(613, visit, 12), false);
            J$.N(625, 'bfs', J$.T(621, bfs, 12), false);
            J$.N(629, 'graph', graph, false);
            J$.N(633, 'list', list, false);
            J$.N(637, 'i', i, false);
            J$.N(641, 'edge', edge, false);
            J$.N(645, 'visited', visited, false);
            function visit(frontier, graph, fn) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(189, arguments.callee, this);
                            arguments = J$.N(193, 'arguments', arguments, true);
                            frontier = J$.N(197, 'frontier', frontier, true);
                            graph = J$.N(201, 'graph', graph, true);
                            fn = J$.N(205, 'fn', fn, true);
                            J$.N(209, 'level', level, false);
                            J$.N(213, 'levels', levels, false);
                            J$.N(217, 'next', next, false);
                            J$.N(221, 'i', i, false);
                            J$.N(225, 'node', node, false);
                            J$.N(229, 'adj', adj, false);
                            var level = J$.W(9, 'level', J$.T(5, 0, 22), level);
                            var levels = J$.W(17, 'levels', J$.T(13, {}, 11), levels);
                            while (J$.C(12, J$.B(6, '<', J$.T(21, 0, 22), J$.G(29, J$.R(25, 'frontier', frontier, false), 'length')))) {
                                var next = J$.W(37, 'next', J$.T(33, [], 10), next);
                                for (var i = J$.W(45, 'i', J$.T(41, 0, 22), i); J$.C(8, J$.B(10, '<', J$.R(49, 'i', i, false), J$.G(57, J$.R(53, 'frontier', frontier, false), 'length'))); J$.B(22, '-', i = J$.W(65, 'i', J$.B(18, '+', J$.U(14, '+', J$.R(61, 'i', i, false)), 1), i), 1)) {
                                    var node = J$.W(81, 'node', J$.G(77, J$.R(69, 'frontier', frontier, false), J$.R(73, 'i', i, false)), node);
                                    J$.F(93, J$.R(85, 'fn', fn, false), false)(J$.R(89, 'node', node, false));
                                    J$.P(109, J$.R(97, 'levels', levels, false), J$.R(101, 'node', node, false), J$.R(105, 'level', level, false));
                                    for (var adj in J$.H(161, J$.G(121, J$.R(113, 'graph', graph, false), J$.R(117, 'node', node, false)))) {
                                        J$.N(165, 'adj', adj, false);
                                        {
                                            {
                                                if (J$.C(4, J$.B(30, '===', J$.U(26, 'typeof', J$.G(133, J$.R(125, 'levels', levels, false), J$.R(129, 'adj', adj, false))), J$.T(137, 'undefined', 21)))) {
                                                    J$.P(157, J$.R(141, 'next', next, false), J$.G(149, J$.R(145, 'next', next, false), 'length'), J$.R(153, 'adj', adj, false));
                                                }
                                            }
                                        }
                                    }
                                }
                                frontier = J$.W(173, 'frontier', J$.R(169, 'next', next, false), frontier);
                                level = J$.W(185, 'level', J$.B(34, '+', J$.R(181, 'level', level, false), J$.T(177, 1, 22)), level);
                            }
                        } catch (J$e) {
                            J$.Ex(649, J$e);
                        } finally {
                            if (J$.Fr(653))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function bfs(node, graph, fn) {
                jalangiLabel1:
                    while (true) {
                        try {
                            J$.Fe(257, arguments.callee, this);
                            arguments = J$.N(261, 'arguments', arguments, true);
                            node = J$.N(265, 'node', node, true);
                            graph = J$.N(269, 'graph', graph, true);
                            fn = J$.N(273, 'fn', fn, true);
                            J$.F(253, J$.R(233, 'visit', visit, false), false)(J$.T(241, [J$.R(237, 'node', node, false)], 10), J$.R(245, 'graph', graph, false), J$.R(249, 'fn', fn, false));
                        } catch (J$e) {
                            J$.Ex(657, J$e);
                        } finally {
                            if (J$.Fr(661))
                                continue jalangiLabel1;
                            else
                                return J$.Ra();
                        }
                    }
            }
            var graph = J$.W(329, 'graph', J$.T(325, {
                    '1': J$.T(277, {}, 11),
                    '2': J$.T(281, {}, 11),
                    '3': J$.T(285, {}, 11),
                    '4': J$.T(289, {}, 11),
                    '5': J$.T(293, {}, 11),
                    '6': J$.T(297, {}, 11),
                    '7': J$.T(301, {}, 11),
                    '8': J$.T(305, {}, 11),
                    '9': J$.T(309, {}, 11),
                    '10': J$.T(313, {}, 11),
                    '11': J$.T(317, {}, 11),
                    '12': J$.T(321, {}, 11)
                }, 11), graph);
            var list = J$.W(337, 'list', J$.T(333, [], 10), list);
            for (var i = J$.W(345, 'i', J$.T(341, 0, 22), i); J$.C(16, J$.B(38, '<', J$.R(349, 'i', i, false), J$.T(353, 10, 22))); J$.B(50, '-', i = J$.W(361, 'i', J$.B(46, '+', J$.U(42, '+', J$.R(357, 'i', i, false)), 1), i), 1)) {
                J$.P(397, J$.R(365, 'list', list, false), J$.G(373, J$.R(369, 'list', list, false), 'length'), J$.T(393, [
                    J$.M(381, J$, 'readInput', false)(J$.T(377, 1, 22)),
                    J$.M(389, J$, 'readInput', false)(J$.T(385, 2, 22))
                ], 10));
                var edge = J$.W(421, 'edge', J$.G(417, J$.R(401, 'list', list, false), J$.B(54, '-', J$.G(409, J$.R(405, 'list', list, false), 'length'), J$.T(413, 1, 22))), edge);
                J$.P(477, J$.G(441, J$.R(425, 'graph', graph, false), J$.G(437, J$.R(429, 'edge', edge, false), J$.T(433, 0, 22))), J$.G(453, J$.R(445, 'edge', edge, false), J$.T(449, 1, 22)), J$.G(473, J$.R(457, 'graph', graph, false), J$.G(469, J$.R(461, 'edge', edge, false), J$.T(465, 1, 22))));
                J$.P(533, J$.G(497, J$.R(481, 'graph', graph, false), J$.G(493, J$.R(485, 'edge', edge, false), J$.T(489, 1, 22))), J$.G(509, J$.R(501, 'edge', edge, false), J$.T(505, 0, 22)), J$.G(529, J$.R(513, 'graph', graph, false), J$.G(525, J$.R(517, 'edge', edge, false), J$.T(521, 0, 22))));
            }
            var visited = J$.W(541, 'visited', J$.T(537, [], 10), visited);
            J$.F(593, J$.R(545, 'bfs', bfs, false), false)(J$.T(549, 1, 22), J$.R(553, 'graph', graph, false), J$.T(589, function (n) {
                jalangiLabel2:
                    while (true) {
                        try {
                            J$.Fe(577, arguments.callee, this);
                            arguments = J$.N(581, 'arguments', arguments, true);
                            n = J$.N(585, 'n', n, true);
                            J$.P(573, J$.R(557, 'visited', visited, false), J$.G(565, J$.R(561, 'visited', visited, false), 'length'), J$.R(569, 'n', n, false));
                        } catch (J$e) {
                            J$.Ex(665, J$e);
                        } finally {
                            if (J$.Fr(669))
                                continue jalangiLabel2;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.M(605, J$.I(typeof console === 'undefined' ? console = J$.R(597, 'console', undefined, true) : console = J$.R(597, 'console', console, true)), 'log', false)(J$.R(601, 'visited', visited, false));
        } catch (J$e) {
            J$.Ex(673, J$e);
        } finally {
            if (J$.Sr(677))
                continue jalangiLabel3;
            else
                break jalangiLabel3;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=bfs_jalangi_.js.map