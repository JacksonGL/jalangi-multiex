jalangiLabel4:
    while (true) {
        try {
            J$.Se(745, '../tests/multiex/algorithms/mergeSort_jalangi_.js');
            J$.N(749, 'Mergesort', Mergesort, false);
            J$.N(753, 'N', N, false);
            J$.N(757, 'i', i, false);
            J$.N(761, 'array', array, false);
            var Mergesort = J$.W(645, 'Mergesort', J$.F(641, J$.T(637, function () {
                    jalangiLabel3:
                        while (true) {
                            try {
                                J$.Fe(605, arguments.callee, this);
                                arguments = J$.N(609, 'arguments', arguments, true);
                                J$.N(617, 'sort', J$.T(613, sort, 12), false);
                                J$.N(625, 'merge', J$.T(621, merge, 12), false);
                                J$.N(633, 'shiftArray', J$.T(629, shiftArray, 12), false);
                                function sort(array) {
                                    jalangiLabel0:
                                        while (true) {
                                            try {
                                                J$.Fe(209, arguments.callee, this);
                                                arguments = J$.N(213, 'arguments', arguments, true);
                                                array = J$.N(217, 'array', array, true);
                                                J$.N(221, 'length', length, false);
                                                J$.N(225, 'mid', mid, false);
                                                J$.N(229, 'left', left, false);
                                                J$.N(233, 'right', right, false);
                                                J$.N(237, 'i', i, false);
                                                var length = J$.W(37, 'length', J$.G(9, J$.R(5, 'array', array, false), 'length'), length), mid = J$.W(41, 'mid', J$.M(25, J$.I(typeof Math === 'undefined' ? Math = J$.R(13, 'Math', undefined, true) : Math = J$.R(13, 'Math', Math, true)), 'floor', false)(J$.B(6, '*', J$.R(17, 'length', length, false), J$.T(21, 0.5, 22))), mid), left = J$.W(45, 'left', J$.T(29, [], 10), left), right = J$.W(49, 'right', J$.T(33, [], 10), right);
                                                for (var i = J$.W(57, 'i', J$.T(53, 0, 22), i); J$.C(4, J$.B(10, '<', J$.R(61, 'i', i, false), J$.R(65, 'mid', mid, false))); J$.B(22, '-', i = J$.W(73, 'i', J$.B(18, '+', J$.U(14, '+', J$.R(69, 'i', i, false)), 1), i), 1)) {
                                                    J$.P(97, J$.R(77, 'left', left, false), J$.R(81, 'i', i, false), J$.G(93, J$.R(85, 'array', array, false), J$.R(89, 'i', i, false)));
                                                }
                                                for (var i = J$.W(105, 'i', J$.R(101, 'mid', mid, false), i); J$.C(8, J$.B(26, '<', J$.R(109, 'i', i, false), J$.G(117, J$.R(113, 'array', array, false), 'length'))); J$.B(38, '-', i = J$.W(125, 'i', J$.B(34, '+', J$.U(30, '+', J$.R(121, 'i', i, false)), 1), i), 1)) {
                                                    J$.P(153, J$.R(129, 'right', right, false), J$.B(42, '-', J$.R(133, 'i', i, false), J$.R(137, 'mid', mid, false)), J$.G(149, J$.R(141, 'array', array, false), J$.R(145, 'i', i, false)));
                                                }
                                                if (J$.C(12, J$.B(46, '===', J$.R(157, 'length', length, false), J$.T(161, 1, 22)))) {
                                                    return J$.Rt(169, J$.R(165, 'array', array, false));
                                                }
                                                return J$.Rt(205, J$.F(201, J$.R(173, 'merge', merge, false), false)(J$.F(185, J$.R(177, 'sort', sort, false), false)(J$.R(181, 'left', left, false)), J$.F(197, J$.R(189, 'sort', sort, false), false)(J$.R(193, 'right', right, false))));
                                            } catch (J$e) {
                                                J$.Ex(765, J$e);
                                            } finally {
                                                if (J$.Fr(769))
                                                    continue jalangiLabel0;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }
                                function merge(left, right) {
                                    jalangiLabel1:
                                        while (true) {
                                            try {
                                                J$.Fe(433, arguments.callee, this);
                                                arguments = J$.N(437, 'arguments', arguments, true);
                                                left = J$.N(441, 'left', left, true);
                                                right = J$.N(445, 'right', right, true);
                                                J$.N(449, 'result', result, false);
                                                var result = J$.W(245, 'result', J$.T(241, [], 10), result);
                                                while (J$.C(36, J$.C(16, J$.G(253, J$.R(249, 'left', left, false), 'length')) ? J$._() : J$.G(261, J$.R(257, 'right', right, false), 'length'))) {
                                                    if (J$.C(32, J$.C(20, J$.G(269, J$.R(265, 'left', left, false), 'length')) ? J$.G(277, J$.R(273, 'right', right, false), 'length') : J$._())) {
                                                        if (J$.C(24, J$.B(50, '<', J$.G(289, J$.R(281, 'left', left, false), J$.T(285, 0, 22)), J$.G(301, J$.R(293, 'right', right, false), J$.T(297, 0, 22))))) {
                                                            J$.P(329, J$.R(305, 'result', result, false), J$.G(313, J$.R(309, 'result', result, false), 'length'), J$.F(325, J$.R(317, 'shiftArray', shiftArray, false), false)(J$.R(321, 'left', left, false)));
                                                        } else {
                                                            J$.P(357, J$.R(333, 'result', result, false), J$.G(341, J$.R(337, 'result', result, false), 'length'), J$.F(353, J$.R(345, 'shiftArray', shiftArray, false), false)(J$.R(349, 'right', right, false)));
                                                        }
                                                    } else if (J$.C(28, J$.G(365, J$.R(361, 'left', left, false), 'length'))) {
                                                        J$.P(393, J$.R(369, 'result', result, false), J$.G(377, J$.R(373, 'result', result, false), 'length'), J$.F(389, J$.R(381, 'shiftArray', shiftArray, false), false)(J$.R(385, 'left', left, false)));
                                                    } else {
                                                        J$.P(421, J$.R(397, 'result', result, false), J$.G(405, J$.R(401, 'result', result, false), 'length'), J$.F(417, J$.R(409, 'shiftArray', shiftArray, false), false)(J$.R(413, 'right', right, false)));
                                                    }
                                                }
                                                return J$.Rt(429, J$.R(425, 'result', result, false));
                                            } catch (J$e) {
                                                J$.Ex(773, J$e);
                                            } finally {
                                                if (J$.Fr(777))
                                                    continue jalangiLabel1;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }
                                function shiftArray(array) {
                                    jalangiLabel2:
                                        while (true) {
                                            try {
                                                J$.Fe(573, arguments.callee, this);
                                                arguments = J$.N(577, 'arguments', arguments, true);
                                                array = J$.N(581, 'array', array, true);
                                                J$.N(585, 'result', result, false);
                                                J$.N(589, 'i', i, false);
                                                var result = J$.W(457, 'result', J$.T(453, undefined, 24), result);
                                                if (J$.C(44, J$.B(54, '>', J$.G(465, J$.R(461, 'array', array, false), 'length'), J$.T(469, 0, 22)))) {
                                                    result = J$.W(485, 'result', J$.G(481, J$.R(473, 'array', array, false), J$.T(477, 0, 22)), result);
                                                    for (var i = J$.W(493, 'i', J$.T(489, 1, 22), i); J$.C(40, J$.B(58, '<', J$.R(497, 'i', i, false), J$.G(505, J$.R(501, 'array', array, false), 'length'))); J$.B(70, '-', i = J$.W(513, 'i', J$.B(66, '+', J$.U(62, '+', J$.R(509, 'i', i, false)), 1), i), 1)) {
                                                        J$.P(541, J$.R(517, 'array', array, false), J$.B(74, '-', J$.R(521, 'i', i, false), J$.T(525, 1, 22)), J$.G(537, J$.R(529, 'array', array, false), J$.R(533, 'i', i, false)));
                                                    }
                                                    J$.P(561, J$.R(545, 'array', array, false), 'length', J$.B(78, '-', J$.G(553, J$.R(549, 'array', array, false), 'length'), J$.T(557, 1, 22)));
                                                }
                                                return J$.Rt(569, J$.R(565, 'result', result, false));
                                            } catch (J$e) {
                                                J$.Ex(781, J$e);
                                            } finally {
                                                if (J$.Fr(785))
                                                    continue jalangiLabel2;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }
                                return J$.Rt(601, J$.T(597, { sort: J$.R(593, 'sort', sort, false) }, 11));
                            } catch (J$e) {
                                J$.Ex(789, J$e);
                            } finally {
                                if (J$.Fr(793))
                                    continue jalangiLabel3;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12), false)(), Mergesort);
            var N = J$.W(653, 'N', J$.T(649, 4, 22), N), i;
            var array = J$.W(661, 'array', J$.T(657, [], 10), array);
            for (i = J$.W(669, 'i', J$.T(665, 0, 22), i); J$.C(48, J$.B(82, '<', J$.R(673, 'i', i, false), J$.R(677, 'N', N, false))); J$.B(94, '-', i = J$.W(685, 'i', J$.B(90, '+', J$.U(86, '+', J$.R(681, 'i', i, false)), 1), i), 1)) {
                J$.P(705, J$.R(689, 'array', array, false), J$.R(693, 'i', i, false), J$.M(701, J$, 'readInput', false)(J$.T(697, 1, 22)));
            }
            var array = J$.W(721, 'array', J$.M(717, J$.R(709, 'Mergesort', Mergesort, false), 'sort', false)(J$.R(713, 'array', array, false)), array);
            J$.M(741, J$.I(typeof console === 'undefined' ? console = J$.R(725, 'console', undefined, true) : console = J$.R(725, 'console', console, true)), 'log', false)(J$.M(737, J$.I(typeof JSON === 'undefined' ? JSON = J$.R(729, 'JSON', undefined, true) : JSON = J$.R(729, 'JSON', JSON, true)), 'stringify', false)(J$.R(733, 'array', array, false)));
        } catch (J$e) {
            J$.Ex(797, J$e);
        } finally {
            if (J$.Sr(801))
                continue jalangiLabel4;
            else
                break jalangiLabel4;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=mergeSort_jalangi_.js.map