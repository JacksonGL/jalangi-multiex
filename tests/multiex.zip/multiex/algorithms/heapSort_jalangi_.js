J$.noInstrEval = false;
jalangiLabel5:
    while (true) {
        try {
            J$.Se(1633, '../tests/multiex/algorithms/heapSort_jalangi_.js');
            function max(a, b) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(57, arguments.callee, this, arguments);
                            arguments = J$.N(65, 'arguments', arguments, true, false);
                            a = J$.N(73, 'a', a, true, false);
                            b = J$.N(81, 'b', b, true, false);
                            if (J$.C(8, J$.B(10, '<', J$.R(9, 'a', a, false, false), J$.R(17, 'b', b, false, false)))) {
                                return J$.Rt(33, J$.R(25, 'b', b, false, false));
                            } else {
                                return J$.Rt(49, J$.R(41, 'a', a, false, false));
                            }
                        } catch (J$e) {
                            J$.Ex(1737, J$e);
                        } finally {
                            if (J$.Fr(1745))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function chunk(list) {
                jalangiLabel1:
                    while (true) {
                        try {
                            J$.Fe(425, arguments.callee, this, arguments);
                            arguments = J$.N(433, 'arguments', arguments, true, false);
                            list = J$.N(441, 'list', list, true, false);
                            J$.N(449, 'chunks', chunks, false, false);
                            J$.N(457, 'i', i, false, false);
                            var chunks = J$.W(97, 'chunks', J$.T(89, [], 10, false), chunks, false, false);
                            for (var i = J$.W(113, 'i', J$.T(105, 0, 22, false), i, false, false); J$.C(40, J$.B(18, '<', J$.R(121, 'i', i, false, false), J$.G(137, J$.R(129, 'list', list, false, false), 'length'))); J$.B(42, '-', i = J$.W(153, 'i', J$.B(34, '+', J$.U(26, '+', J$.R(145, 'i', i, false, false)), 1), i, false, false), 1)) {
                                if (J$.C(32, J$.C(16, J$.B(58, '==', J$.B(50, '%', J$.G(169, J$.R(161, 'list', list, false, false), 'length'), J$.T(177, 2, 22, false)), J$.T(185, 1, 22, false))) ? J$.B(74, '==', J$.B(66, '+', J$.R(193, 'i', i, false, false), J$.T(201, 1, 22, false)), J$.G(217, J$.R(209, 'list', list, false, false), 'length')) : J$._())) {
                                    J$.P(273, J$.R(225, 'chunks', chunks, false, false), J$.G(241, J$.R(233, 'chunks', chunks, false, false), 'length'), J$.G(265, J$.R(249, 'list', list, false, false), J$.R(257, 'i', i, false, false)));
                                } else {
                                    if (J$.C(24, J$.B(90, '==', J$.B(82, '%', J$.R(281, 'i', i, false, false), J$.T(289, 2, 22, false)), J$.T(297, 0, 22, false)))) {
                                        J$.P(401, J$.R(305, 'chunks', chunks, false, false), J$.G(321, J$.R(313, 'chunks', chunks, false, false), 'length'), J$.F(393, J$.R(329, 'max', max, false, true), false)(J$.G(353, J$.R(337, 'list', list, false, false), J$.R(345, 'i', i, false, false)), J$.G(385, J$.R(361, 'list', list, false, false), J$.B(98, '+', J$.R(369, 'i', i, false, false), J$.T(377, 1, 22, false)))));
                                    }
                                }
                            }
                            return J$.Rt(417, J$.R(409, 'chunks', chunks, false, false));
                        } catch (J$e) {
                            J$.Ex(1753, J$e);
                        } finally {
                            if (J$.Fr(1761))
                                continue jalangiLabel1;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function bubble(list) {
                jalangiLabel2:
                    while (true) {
                        try {
                            J$.Fe(673, arguments.callee, this, arguments);
                            arguments = J$.N(681, 'arguments', arguments, true, false);
                            list = J$.N(689, 'list', list, true, false);
                            J$.N(697, 'remainder', remainder, false, false);
                            J$.N(705, 'heap', heap, false, false);
                            var remainder = J$.W(505, 'remainder', J$.F(481, J$.R(465, 'chunk', chunk, false, true), false)(J$.R(473, 'list', list, false, false)), remainder, false, false), heap = J$.W(513, 'heap', J$.T(497, [J$.R(489, 'list', list, false, false)], 10, false), heap, false, false);
                            J$.P(553, J$.R(521, 'heap', heap, false, false), J$.G(537, J$.R(529, 'heap', heap, false, false), 'length'), J$.R(545, 'remainder', remainder, false, false));
                            while (J$.C(48, J$.B(106, '!=', J$.G(569, J$.R(561, 'remainder', remainder, false, false), 'length'), J$.T(577, 1, 22, false)))) {
                                remainder = J$.W(609, 'remainder', J$.F(601, J$.R(585, 'chunk', chunk, false, true), false)(J$.R(593, 'remainder', remainder, false, false)), remainder, false, false);
                                J$.P(649, J$.R(617, 'heap', heap, false, false), J$.G(633, J$.R(625, 'heap', heap, false, false), 'length'), J$.R(641, 'remainder', remainder, false, false));
                            }
                            return J$.Rt(665, J$.R(657, 'heap', heap, false, false));
                        } catch (J$e) {
                            J$.Ex(1769, J$e);
                        } finally {
                            if (J$.Fr(1777))
                                continue jalangiLabel2;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function getTopIndex(thing) {
                jalangiLabel3:
                    while (true) {
                        try {
                            J$.Fe(1105, arguments.callee, this, arguments);
                            arguments = J$.N(1113, 'arguments', arguments, true, false);
                            thing = J$.N(1121, 'thing', thing, true, false);
                            J$.N(1129, 'currentIndex', currentIndex, false, false);
                            J$.N(1137, 'value', value, false, false);
                            J$.N(1145, 'i', i, false, false);
                            var currentIndex = J$.W(801, 'currentIndex', J$.T(713, 0, 22, false), currentIndex, false, false), value = J$.W(809, 'value', J$.G(769, J$.G(753, J$.R(721, 'thing', thing, false, false), J$.B(114, '-', J$.G(737, J$.R(729, 'thing', thing, false, false), 'length'), J$.T(745, 1, 22, false))), J$.T(761, 0, 22, false)), value, false, false), i = J$.W(817, 'i', J$.B(122, '-', J$.G(785, J$.R(777, 'thing', thing, false, false), 'length'), J$.T(793, 2, 22, false)), i, false, false);
                            while (J$.C(104, J$.B(138, '!=', J$.R(825, 'i', i, false, false), J$.U(130, '-', J$.T(833, 1, 22, false))))) {
                                if (J$.C(64, J$.C(56, J$.B(154, '%', J$.U(146, '!', J$.G(865, J$.G(857, J$.R(841, 'thing', thing, false, false), J$.R(849, 'i', i, false, false)), 'length')), J$.T(873, 2, 22, false))) ? J$.B(162, '>', J$.R(881, 'currentIndex', currentIndex, false, false), J$.T(889, 0, 22, false)) : J$._())) {
                                    J$.B(186, '+', currentIndex = J$.W(905, 'currentIndex', J$.B(178, '-', J$.U(170, '+', J$.R(897, 'currentIndex', currentIndex, false, false)), 1), currentIndex, false, false), 1);
                                }
                                if (J$.C(96, J$.B(202, '==', J$.G(953, J$.G(929, J$.R(913, 'thing', thing, false, false), J$.R(921, 'i', i, false, false)), J$.B(194, '+', J$.R(937, 'currentIndex', currentIndex, false, false), J$.T(945, 1, 22, false))), J$.R(961, 'value', value, false, false)))) {
                                    J$.B(226, '-', currentIndex = J$.W(977, 'currentIndex', J$.B(218, '+', J$.U(210, '+', J$.R(969, 'currentIndex', currentIndex, false, false)), 1), currentIndex, false, false), 1);
                                    currentIndex = J$.W(1017, 'currentIndex', J$.C(72, J$.R(985, 'i', i, false, false)) ? J$.B(234, '<<', J$.R(993, 'currentIndex', currentIndex, false, false), J$.T(1001, 1, 22, false)) : J$.R(1009, 'currentIndex', currentIndex, false, false), currentIndex, false, false);
                                } else if (J$.C(88, J$.R(1025, 'currentIndex', currentIndex, false, false))) {
                                    currentIndex = J$.W(1065, 'currentIndex', J$.C(80, J$.R(1033, 'i', i, false, false)) ? J$.B(242, '<<', J$.R(1041, 'currentIndex', currentIndex, false, false), J$.T(1049, 1, 22, false)) : J$.R(1057, 'currentIndex', currentIndex, false, false), currentIndex, false, false);
                                }
                                J$.B(266, '+', i = J$.W(1081, 'i', J$.B(258, '-', J$.U(250, '+', J$.R(1073, 'i', i, false, false)), 1), i, false, false), 1);
                            }
                            return J$.Rt(1097, J$.R(1089, 'currentIndex', currentIndex, false, false));
                        } catch (J$e) {
                            J$.Ex(1785, J$e);
                        } finally {
                            if (J$.Fr(1793))
                                continue jalangiLabel3;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function heapSort(list) {
                jalangiLabel4:
                    while (true) {
                        try {
                            J$.Fe(1433, arguments.callee, this, arguments);
                            arguments = J$.N(1441, 'arguments', arguments, true, false);
                            list = J$.N(1449, 'list', list, true, false);
                            J$.N(1457, 'sortedList', sortedList, false, false);
                            J$.N(1465, 'listCopy', listCopy, false, false);
                            J$.N(1473, 'heap', heap, false, false);
                            J$.N(1481, 'targetLength', targetLength, false, false);
                            var sortedList = J$.W(1177, 'sortedList', J$.T(1153, [], 10, false), sortedList, false, false), listCopy = J$.W(1185, 'listCopy', J$.R(1161, 'list', list, false, false), listCopy, false, false), heap = J$.W(1193, 'heap', J$.T(1169, [], 10, false), heap, false, false);
                            var targetLength = J$.W(1217, 'targetLength', J$.G(1209, J$.R(1201, 'list', list, false, false), 'length'), targetLength, false, false);
                            while (J$.C(112, J$.B(274, '!=', J$.G(1233, J$.R(1225, 'sortedList', sortedList, false, false), 'length'), J$.R(1241, 'targetLength', targetLength, false, false)))) {
                                heap = J$.W(1273, 'heap', J$.F(1265, J$.R(1249, 'bubble', bubble, false, true), false)(J$.R(1257, 'listCopy', listCopy, false, false)), heap, false, false);
                                J$.P(1361, J$.R(1281, 'sortedList', sortedList, false, false), J$.G(1297, J$.R(1289, 'sortedList', sortedList, false, false), 'length'), J$.G(1353, J$.G(1337, J$.R(1305, 'heap', heap, false, false), J$.B(282, '-', J$.G(1321, J$.R(1313, 'heap', heap, false, false), 'length'), J$.T(1329, 1, 22, false))), J$.T(1345, 0, 22, false)));
                                J$.M(1409, J$.R(1369, 'listCopy', listCopy, false, false), 'splice', false)(J$.F(1393, J$.R(1377, 'getTopIndex', getTopIndex, false, true), false)(J$.R(1385, 'heap', heap, false, false)), J$.T(1401, 1, 22, false));
                            }
                            return J$.Rt(1425, J$.R(1417, 'sortedList', sortedList, false, false));
                        } catch (J$e) {
                            J$.Ex(1801, J$e);
                        } finally {
                            if (J$.Fr(1809))
                                continue jalangiLabel4;
                            else
                                return J$.Ra();
                        }
                    }
            }
            max = J$.N(1649, 'max', J$.T(1641, max, 12, false), true, false);
            chunk = J$.N(1665, 'chunk', J$.T(1657, chunk, 12, false), true, false);
            bubble = J$.N(1681, 'bubble', J$.T(1673, bubble, 12, false), true, false);
            getTopIndex = J$.N(1697, 'getTopIndex', J$.T(1689, getTopIndex, 12, false), true, false);
            heapSort = J$.N(1713, 'heapSort', J$.T(1705, heapSort, 12, false), true, false);
            J$.N(1721, 'list', list, false, false);
            J$.N(1729, 'i', i, false, false);
            var list = J$.W(1497, 'list', J$.T(1489, [], 10, false), list, false, true);
            for (var i = J$.W(1513, 'i', J$.T(1505, 0, 22, false), i, false, true); J$.C(120, J$.B(290, '<', J$.R(1521, 'i', i, false, true), J$.T(1529, 4, 22, false))); J$.B(314, '-', i = J$.W(1545, 'i', J$.B(306, '+', J$.U(298, '+', J$.R(1537, 'i', i, false, true)), 1), i, false, true), 1)) {
                J$.P(1585, J$.R(1553, 'list', list, false, true), J$.R(1561, 'i', i, false, true), J$.M(1577, J$, 'readInput', false)(J$.T(1569, 1, 22, false)));
            }
            J$.M(1625, J$.I(typeof console === 'undefined' ? console = J$.R(1593, 'console', undefined, true, true) : console = J$.R(1593, 'console', console, true, true)), 'log', false)(J$.F(1617, J$.R(1601, 'heapSort', heapSort, false, true), false)(J$.R(1609, 'list', list, false, true)));
        } catch (J$e) {
            J$.Ex(1817, J$e);
        } finally {
            if (J$.Sr(1825))
                continue jalangiLabel5;
            else
                break jalangiLabel5;
        }
    }
// JALANGI DO NOT INSTRUMENT

