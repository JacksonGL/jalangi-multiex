jalangiLabel9:
    while (true) {
        try {
            J$.Se(2757, '../tests/multiex/algorithms/dynamicProgramming_jalangi_.js');
            J$.N(2765, 'nameMatch', J$.T(2761, nameMatch, 12), false);
            function nameMatch(pNameSource, pDebug, pDebugOutputArea) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(237, arguments.callee, this);
                            arguments = J$.N(241, 'arguments', arguments, true);
                            pNameSource = J$.N(245, 'pNameSource', pNameSource, true);
                            pDebug = J$.N(249, 'pDebug', pDebug, true);
                            pDebugOutputArea = J$.N(253, 'pDebugOutputArea', pDebugOutputArea, true);
                            J$.N(257, 'tNameSource', tNameSource, false);
                            J$.N(261, 'tIndex', tIndex, false);
                            J$.N(265, 'tFirst', tFirst, false);
                            J$.N(269, 'tLast', tLast, false);
                            var tNameSource = J$.W(13, 'tNameSource', J$.C(4, J$.R(5, 'pNameSource', pNameSource, false)) ? J$._() : J$.T(9, '', 21), tNameSource);
                            if (J$.C(12, J$.R(17, 'tNameSource', tNameSource, false))) {
                                if (J$.C(8, J$.B(6, '>', J$.M(29, J$.R(21, 'tNameSource', tNameSource, false), 'indexOf', false)(J$.T(25, ',', 21)), J$.T(33, 0, 22)))) {
                                    var tIndex = J$.W(81, 'tIndex', J$.M(45, J$.R(37, 'tNameSource', tNameSource, false), 'indexOf', false)(J$.T(41, ',', 21)), tIndex), tFirst = J$.W(85, 'tFirst', J$.M(61, J$.R(49, 'tNameSource', tNameSource, false), 'slice', false)(J$.B(10, '+', J$.R(53, 'tIndex', tIndex, false), J$.T(57, 1, 22))), tFirst), tLast = J$.W(89, 'tLast', J$.M(77, J$.R(65, 'tNameSource', tNameSource, false), 'slice', false)(J$.T(69, 0, 22), J$.R(73, 'tIndex', tIndex, false)), tLast);
                                    tNameSource = J$.W(105, 'tNameSource', J$.B(18, '+', J$.B(14, '+', J$.R(93, 'tFirst', tFirst, false), J$.T(97, ' ', 21)), J$.R(101, 'tLast', tLast, false)), tNameSource);
                                }
                                tNameSource = J$.W(117, 'tNameSource', J$.M(113, J$.R(109, 'tNameSource', tNameSource, false), 'toLowerCase', false)(), tNameSource);
                                tNameSource = J$.W(137, 'tNameSource', J$.M(133, J$.R(121, 'tNameSource', tNameSource, false), 'replace', false)(J$.T(125, /[.'"]/gi, 14), J$.T(129, ' ', 21)), tNameSource);
                                tNameSource = J$.W(157, 'tNameSource', J$.M(153, J$.R(141, 'tNameSource', tNameSource, false), 'replace', false)(J$.T(145, /\s{2,}/g, 14), J$.T(149, ' ', 21)), tNameSource);
                            }
                            J$.P(173, J$.R(161, 'this', this, false), 'DEBUG', J$.C(16, J$.R(165, 'pDebug', pDebug, false)) ? J$._() : J$.T(169, false, 23));
                            J$.P(185, J$.R(177, 'this', this, false), 'DEBUG_AREA', J$.R(181, 'pDebugOutputArea', pDebugOutputArea, false));
                            J$.P(197, J$.R(189, 'this', this, false), 'nameSource', J$.M(193, J$, 'readInput', false)());
                            J$.P(213, J$.R(201, 'this', this, false), 'nameSourceLength', J$.B(22, '+', J$.M(205, J$, 'readInput', false)(), J$.T(209, 1, 22)));
                            J$.P(225, J$.R(217, 'this', this, false), 'nameSourceScore', J$.T(221, 0, 22));
                            J$.M(233, J$.R(229, 'this', this, false), '_reset', false)();
                        } catch (J$e) {
                            J$.Ex(2769, J$e);
                        } finally {
                            if (J$.Fr(2773))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.P(2729, J$.R(273, 'nameMatch', nameMatch, false), 'prototype', J$.T(2725, {
                _reset: J$.T(457, function (pNameTarget) {
                    jalangiLabel1:
                        while (true) {
                            try {
                                J$.Fe(441, arguments.callee, this);
                                arguments = J$.N(445, 'arguments', arguments, true);
                                pNameTarget = J$.N(449, 'pNameTarget', pNameTarget, true);
                                J$.N(453, 'tNameTarget', tNameTarget, false);
                                var tNameTarget = J$.W(285, 'tNameTarget', J$.C(20, J$.R(277, 'pNameTarget', pNameTarget, false)) ? J$._() : J$.T(281, '', 21), tNameTarget);
                                if (J$.C(24, J$.R(289, 'tNameTarget', tNameTarget, false))) {
                                    tNameTarget = J$.W(301, 'tNameTarget', J$.M(297, J$.R(293, 'tNameTarget', tNameTarget, false), 'toLowerCase', false)(), tNameTarget);
                                    tNameTarget = J$.W(321, 'tNameTarget', J$.M(317, J$.R(305, 'tNameTarget', tNameTarget, false), 'replace', false)(J$.T(309, /[.,'"]/gi, 14), J$.T(313, '', 21)), tNameTarget);
                                    tNameTarget = J$.W(341, 'tNameTarget', J$.M(337, J$.R(325, 'tNameTarget', tNameTarget, false), 'replace', false)(J$.T(329, /\s{2,}/g, 14), J$.T(333, ' ', 21)), tNameTarget);
                                }
                                J$.P(353, J$.R(345, 'this', this, false), 'nameTarget', J$.R(349, 'tNameTarget', tNameTarget, false));
                                J$.P(377, J$.R(357, 'this', this, false), 'nameTargetLength', J$.B(26, '+', J$.G(369, J$.G(365, J$.R(361, 'this', this, false), 'nameTarget'), 'length'), J$.T(373, 1, 22)));
                                J$.P(389, J$.R(381, 'this', this, false), 'nameTargetScore', J$.T(385, 0, 22));
                                J$.P(401, J$.R(393, 'this', this, false), 'dynamicMatrix', J$.T(397, [], 10));
                                J$.P(413, J$.R(405, 'this', this, false), 'maxMatrixValue', J$.T(409, 0, 22));
                                J$.P(425, J$.R(417, 'this', this, false), 'overallScore', J$.T(421, 0, 22));
                                J$.P(437, J$.R(429, 'this', this, false), 'finalScore', J$.T(433, 0, 22));
                            } catch (J$e) {
                                J$.Ex(2777, J$e);
                            } finally {
                                if (J$.Fr(2781))
                                    continue jalangiLabel1;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12),
                characterMatrix: J$.T(605, [
                    J$.T(461, 'a0004000000000400000000000', 21),
                    J$.T(465, '0a000000000000000000000000', 21),
                    J$.T(469, '00a00000004000002000000000', 21),
                    J$.T(473, '000a0000000000000002000000', 21),
                    J$.T(477, '4000a000000000000000000020', 21),
                    J$.T(481, '00000a00000000020000020000', 21),
                    J$.T(485, '000000a0000000000000000000', 21),
                    J$.T(489, '0000000a040000000000000000', 21),
                    J$.T(493, '00000000a20400000000000020', 21),
                    J$.T(497, '000000042a0000000000000040', 21),
                    J$.T(501, '0040000000a000002000000000', 21),
                    J$.T(505, '00000000400a00000000000000', 21),
                    J$.T(509, '000000000000a4000000000000', 21),
                    J$.T(513, '0000000000004a000000000000', 21),
                    J$.T(517, '40000000000000a00000000000', 21),
                    J$.T(521, '000002000000000a0000000000', 21),
                    J$.T(525, '0020000000200000a000000000', 21),
                    J$.T(529, '00000000000000000a00000000', 21),
                    J$.T(533, '000000000000000000a0000000', 21),
                    J$.T(537, '0002000000000000000a000000', 21),
                    J$.T(541, '00000000000000000000a00000', 21),
                    J$.T(545, '000002000000000000000a4000', 21),
                    J$.T(549, '0000000000000000000004a000', 21),
                    J$.T(553, '00000000000000000000000a00', 21),
                    J$.T(557, '000020002400000000000000a0', 21),
                    J$.T(561, '0000000000000000002000000a', 21),
                    J$.T(565, '00000000000000400000000000', 21),
                    J$.T(569, '00000000400400000000000000', 21),
                    J$.T(573, '00000000000000000100000002', 21),
                    J$.T(577, '00002000000000000000000001', 21),
                    J$.T(581, '20000002000000000000000000', 21),
                    J$.T(585, '00000000000000000020000000', 21),
                    J$.T(589, '01000010000000000000000000', 21),
                    J$.T(593, '00000000100100000002000000', 21),
                    J$.T(597, '01000000000000000000000000', 21),
                    J$.T(601, '00000020000000000000000000', 21)
                ], 10),
                charMatrixDictionary: J$.T(753, {
                    a: J$.T(609, 0, 22),
                    b: J$.T(613, 1, 22),
                    c: J$.T(617, 2, 22),
                    d: J$.T(621, 3, 22),
                    e: J$.T(625, 4, 22),
                    f: J$.T(629, 5, 22),
                    g: J$.T(633, 6, 22),
                    h: J$.T(637, 7, 22),
                    i: J$.T(641, 8, 22),
                    j: J$.T(645, 9, 22),
                    k: J$.T(649, 10, 22),
                    l: J$.T(653, 11, 22),
                    m: J$.T(657, 12, 22),
                    n: J$.T(661, 13, 22),
                    o: J$.T(665, 14, 22),
                    p: J$.T(669, 15, 22),
                    q: J$.T(673, 16, 22),
                    r: J$.T(677, 17, 22),
                    s: J$.T(681, 18, 22),
                    t: J$.T(685, 19, 22),
                    u: J$.T(689, 20, 22),
                    v: J$.T(693, 21, 22),
                    w: J$.T(697, 22, 22),
                    x: J$.T(701, 23, 22),
                    y: J$.T(705, 24, 22),
                    z: J$.T(709, 25, 22),
                    0: J$.T(713, 26, 22),
                    1: J$.T(717, 27, 22),
                    2: J$.T(721, 28, 22),
                    3: J$.T(725, 29, 22),
                    4: J$.T(729, 30, 22),
                    5: J$.T(733, 31, 22),
                    6: J$.T(737, 32, 22),
                    7: J$.T(741, 33, 22),
                    8: J$.T(745, 34, 22),
                    9: J$.T(749, 35, 22)
                }, 11),
                _characterScore: J$.T(1021, function (pCharA, pCharB) {
                    jalangiLabel2:
                        while (true) {
                            try {
                                J$.Fe(981, arguments.callee, this);
                                arguments = J$.N(985, 'arguments', arguments, true);
                                pCharA = J$.N(989, 'pCharA', pCharA, true);
                                pCharB = J$.N(993, 'pCharB', pCharB, true);
                                J$.N(997, 'matchScore', matchScore, false);
                                J$.N(1001, 'mismatchScore', mismatchScore, false);
                                J$.N(1005, 'mismatchPenalty', mismatchPenalty, false);
                                J$.N(1009, 'charIndexA', charIndexA, false);
                                J$.N(1013, 'charIndexB', charIndexB, false);
                                J$.N(1017, 'refValue', refValue, false);
                                pCharA = J$.W(761, 'pCharA', J$.M(757, J$, 'readInput', false)(), pCharA);
                                pCharB = J$.W(769, 'pCharB', J$.M(765, J$, 'readInput', false)(), pCharB);
                                var matchScore = J$.W(797, 'matchScore', J$.T(773, 1, 22), matchScore), mismatchScore = J$.W(801, 'mismatchScore', J$.T(777, 0, 22), mismatchScore), mismatchPenalty = J$.W(805, 'mismatchPenalty', J$.U(30, '-', J$.T(781, 0.4, 22)), mismatchPenalty), charIndexA = J$.W(809, 'charIndexA', J$.T(785, 0, 22), charIndexA), charIndexB = J$.W(813, 'charIndexB', J$.T(789, 0, 22), charIndexB), refValue = J$.W(817, 'refValue', J$.T(793, 0, 22), refValue);
                                if (J$.C(48, J$.C(28, J$.R(821, 'pCharA', pCharA, false)) ? J$.R(825, 'pCharB', pCharB, false) : J$._())) {
                                    if (J$.C(44, J$.B(34, '==', J$.R(829, 'pCharA', pCharA, false), J$.R(833, 'pCharB', pCharB, false)))) {
                                        return J$.Rt(841, J$.R(837, 'matchScore', matchScore, false));
                                    } else {
                                        charIndexA = J$.W(861, 'charIndexA', J$.G(857, J$.G(849, J$.R(845, 'this', this, false), 'charMatrixDictionary'), J$.R(853, 'pCharA', pCharA, false)), charIndexA);
                                        charIndexB = J$.W(881, 'charIndexB', J$.G(877, J$.G(869, J$.R(865, 'this', this, false), 'charMatrixDictionary'), J$.R(873, 'pCharB', pCharB, false)), charIndexB);
                                        if (J$.C(40, J$.C(32, J$.R(885, 'charIndexA', charIndexA, false)) ? J$.R(889, 'charIndexB', charIndexB, false) : J$._())) {
                                            mismatchScore = J$.W(917, 'mismatchScore', J$.G(913, J$.G(905, J$.G(897, J$.R(893, 'this', this, false), 'characterMatrix'), J$.R(901, 'charIndexA', charIndexA, false)), J$.R(909, 'charIndexB', charIndexB, false)), mismatchScore);
                                            refValue = J$.W(941, 'refValue', J$.B(38, '/', J$.F(933, J$.I(typeof parseInt === 'undefined' ? parseInt = J$.R(921, 'parseInt', undefined, true) : parseInt = J$.R(921, 'parseInt', parseInt, true)), false)(J$.R(925, 'mismatchScore', mismatchScore, false), J$.T(929, 16, 22)), J$.T(937, 10, 22)), refValue);
                                            if (J$.C(36, J$.R(945, 'refValue', refValue, false))) {
                                                return J$.Rt(953, J$.R(949, 'refValue', refValue, false));
                                            } else {
                                                return J$.Rt(961, J$.R(957, 'mismatchPenalty', mismatchPenalty, false));
                                            }
                                        } else {
                                            return J$.Rt(969, J$.R(965, 'mismatchPenalty', mismatchPenalty, false));
                                        }
                                    }
                                } else {
                                    return J$.Rt(977, J$.R(973, 'mismatchPenalty', mismatchPenalty, false));
                                }
                            } catch (J$e) {
                                J$.Ex(2785, J$e);
                            } finally {
                                if (J$.Fr(2789))
                                    continue jalangiLabel2;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12),
                _gappedScore: J$.T(1113, function (pCharA, pCharB) {
                    jalangiLabel3:
                        while (true) {
                            try {
                                J$.Fe(1089, arguments.callee, this);
                                arguments = J$.N(1093, 'arguments', arguments, true);
                                pCharA = J$.N(1097, 'pCharA', pCharA, true);
                                pCharB = J$.N(1101, 'pCharB', pCharB, true);
                                J$.N(1105, 'gapPenalty', gapPenalty, false);
                                J$.N(1109, 'mismatchPenalty', mismatchPenalty, false);
                                pCharA = J$.W(1029, 'pCharA', J$.M(1025, J$, 'readInput', false)(), pCharA);
                                pCharB = J$.W(1037, 'pCharB', J$.M(1033, J$, 'readInput', false)(), pCharB);
                                var gapPenalty = J$.W(1049, 'gapPenalty', J$.U(42, '-', J$.T(1041, 0.3, 22)), gapPenalty), mismatchPenalty = J$.W(1053, 'mismatchPenalty', J$.U(46, '-', J$.T(1045, 0.4, 22)), mismatchPenalty);
                                if (J$.C(56, J$.C(52, J$.B(50, '==', J$.R(1057, 'pCharA', pCharA, false), J$.T(1061, ' ', 21))) ? J$._() : J$.B(54, '==', J$.R(1065, 'pCharB', pCharB, false), J$.T(1069, ' ', 21)))) {
                                    return J$.Rt(1077, J$.R(1073, 'gapPenalty', gapPenalty, false));
                                } else {
                                    return J$.Rt(1085, J$.R(1081, 'mismatchPenalty', mismatchPenalty, false));
                                }
                            } catch (J$e) {
                                J$.Ex(2793, J$e);
                            } finally {
                                if (J$.Fr(2797))
                                    continue jalangiLabel3;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12),
                _transposedScore: J$.T(1153, function (pCharA, pCharB) {
                    jalangiLabel4:
                        while (true) {
                            try {
                                J$.Fe(1133, arguments.callee, this);
                                arguments = J$.N(1137, 'arguments', arguments, true);
                                pCharA = J$.N(1141, 'pCharA', pCharA, true);
                                pCharB = J$.N(1145, 'pCharB', pCharB, true);
                                J$.N(1149, 'transposePenalty', transposePenalty, false);
                                var transposePenalty = J$.W(1121, 'transposePenalty', J$.U(58, '-', J$.T(1117, 0.2, 22)), transposePenalty);
                                return J$.Rt(1129, J$.R(1125, 'transposePenalty', transposePenalty, false));
                            } catch (J$e) {
                                J$.Ex(2801, J$e);
                            } finally {
                                if (J$.Fr(2805))
                                    continue jalangiLabel4;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12),
                _buildMatrix: J$.T(1889, function () {
                    jalangiLabel5:
                        while (true) {
                            try {
                                J$.Fe(1861, arguments.callee, this);
                                arguments = J$.N(1865, 'arguments', arguments, true);
                                J$.N(1869, 'tmpArray', tmpArray, false);
                                J$.N(1873, 'tCharA', tCharA, false);
                                J$.N(1877, 'tCharB', tCharB, false);
                                J$.N(1881, 'ix', ix, false);
                                J$.N(1885, 'iy', iy, false);
                                var tmpArray = J$.W(1169, 'tmpArray', J$.T(1157, [], 10), tmpArray), tCharA = J$.W(1173, 'tCharA', J$.T(1161, '', 21), tCharA), tCharB = J$.W(1177, 'tCharB', J$.T(1165, '', 21), tCharB);
                                for (var ix = J$.W(1185, 'ix', J$.T(1181, 0, 22), ix); J$.C(60, J$.B(62, '<', J$.R(1189, 'ix', ix, false), J$.G(1197, J$.R(1193, 'this', this, false), 'nameTargetLength'))); J$.B(74, '-', ix = J$.W(1205, 'ix', J$.B(70, '+', J$.U(66, '+', J$.R(1201, 'ix', ix, false)), 1), ix), 1)) {
                                    J$.M(1217, J$.R(1209, 'tmpArray', tmpArray, false), 'push', false)(J$.T(1213, 0, 22));
                                }
                                for (var iy = J$.W(1225, 'iy', J$.T(1221, 0, 22), iy); J$.C(64, J$.B(78, '<', J$.R(1229, 'iy', iy, false), J$.G(1237, J$.R(1233, 'this', this, false), 'nameSourceLength'))); J$.B(90, '-', iy = J$.W(1245, 'iy', J$.B(86, '+', J$.U(82, '+', J$.R(1241, 'iy', iy, false)), 1), iy), 1)) {
                                    J$.M(1261, J$.G(1253, J$.R(1249, 'this', this, false), 'dynamicMatrix'), 'push', false)(J$.M(1257, J$, 'readInput', false)());
                                }
                                for (var iy = J$.W(1269, 'iy', J$.T(1265, 1, 22), iy); J$.C(80, J$.B(94, '<', J$.R(1273, 'iy', iy, false), J$.G(1281, J$.R(1277, 'this', this, false), 'nameSourceLength'))); J$.B(106, '-', iy = J$.W(1289, 'iy', J$.B(102, '+', J$.U(98, '+', J$.R(1285, 'iy', iy, false)), 1), iy), 1)) {
                                    for (var ix = J$.W(1297, 'ix', J$.T(1293, 1, 22), ix); J$.C(76, J$.B(110, '<', J$.R(1301, 'ix', ix, false), J$.G(1309, J$.R(1305, 'this', this, false), 'nameTargetLength'))); J$.B(122, '-', ix = J$.W(1317, 'ix', J$.B(118, '+', J$.U(114, '+', J$.R(1313, 'ix', ix, false)), 1), ix), 1)) {
                                        tCharA = J$.W(1341, 'tCharA', J$.G(1337, J$.G(1325, J$.R(1321, 'this', this, false), 'nameSource'), J$.B(126, '-', J$.R(1329, 'iy', iy, false), J$.T(1333, 1, 22))), tCharA);
                                        tCharB = J$.W(1365, 'tCharB', J$.G(1361, J$.G(1349, J$.R(1345, 'this', this, false), 'nameTarget'), J$.B(130, '-', J$.R(1353, 'ix', ix, false), J$.T(1357, 1, 22))), tCharB);
                                        J$.P(1537, J$.G(1381, J$.G(1373, J$.R(1369, 'this', this, false), 'dynamicMatrix'), J$.R(1377, 'iy', iy, false)), J$.R(1385, 'ix', ix, false), J$.M(1533, J$.I(typeof Math === 'undefined' ? Math = J$.R(1389, 'Math', undefined, true) : Math = J$.R(1389, 'Math', Math, true)), 'max', false)(J$.B(142, '+', J$.G(1421, J$.G(1409, J$.G(1397, J$.R(1393, 'this', this, false), 'dynamicMatrix'), J$.B(134, '-', J$.R(1401, 'iy', iy, false), J$.T(1405, 1, 22))), J$.B(138, '-', J$.R(1413, 'ix', ix, false), J$.T(1417, 1, 22))), J$.M(1437, J$.R(1425, 'this', this, false), '_characterScore', false)(J$.R(1429, 'tCharA', tCharA, false), J$.R(1433, 'tCharB', tCharB, false))), J$.T(1441, 0, 22), J$.B(150, '+', J$.G(1469, J$.G(1461, J$.G(1449, J$.R(1445, 'this', this, false), 'dynamicMatrix'), J$.B(146, '-', J$.R(1453, 'iy', iy, false), J$.T(1457, 1, 22))), J$.R(1465, 'ix', ix, false)), J$.M(1485, J$.R(1473, 'this', this, false), '_gappedScore', false)(J$.R(1477, 'tCharA', tCharA, false), J$.R(1481, 'tCharB', tCharB, false))), J$.B(158, '+', J$.G(1513, J$.G(1501, J$.G(1493, J$.R(1489, 'this', this, false), 'dynamicMatrix'), J$.R(1497, 'iy', iy, false)), J$.B(154, '-', J$.R(1505, 'ix', ix, false), J$.T(1509, 1, 22))), J$.M(1529, J$.R(1517, 'this', this, false), '_gappedScore', false)(J$.R(1521, 'tCharA', tCharA, false), J$.R(1525, 'tCharB', tCharB, false)))));
                                        if (J$.C(72, J$.C(68, J$.B(174, '>', J$.G(1565, J$.G(1557, J$.G(1545, J$.R(1541, 'this', this, false), 'dynamicMatrix'), J$.B(162, '-', J$.R(1549, 'iy', iy, false), J$.T(1553, 1, 22))), J$.R(1561, 'ix', ix, false)), J$.G(1597, J$.G(1585, J$.G(1573, J$.R(1569, 'this', this, false), 'dynamicMatrix'), J$.B(166, '-', J$.R(1577, 'iy', iy, false), J$.T(1581, 1, 22))), J$.B(170, '-', J$.R(1589, 'ix', ix, false), J$.T(1593, 1, 22))))) ? J$.B(190, '>', J$.G(1625, J$.G(1613, J$.G(1605, J$.R(1601, 'this', this, false), 'dynamicMatrix'), J$.R(1609, 'iy', iy, false)), J$.B(178, '-', J$.R(1617, 'ix', ix, false), J$.T(1621, 1, 22))), J$.G(1657, J$.G(1645, J$.G(1633, J$.R(1629, 'this', this, false), 'dynamicMatrix'), J$.B(182, '-', J$.R(1637, 'iy', iy, false), J$.T(1641, 1, 22))), J$.B(186, '-', J$.R(1649, 'ix', ix, false), J$.T(1653, 1, 22)))) : J$._())) {
                                            J$.P(1753, J$.G(1677, J$.G(1665, J$.R(1661, 'this', this, false), 'dynamicMatrix'), J$.B(194, '-', J$.R(1669, 'iy', iy, false), J$.T(1673, 1, 22))), J$.B(198, '-', J$.R(1681, 'ix', ix, false), J$.T(1685, 1, 22)), J$.M(1749, J$.I(typeof Math === 'undefined' ? Math = J$.R(1689, 'Math', undefined, true) : Math = J$.R(1689, 'Math', Math, true)), 'max', false)(J$.G(1717, J$.G(1709, J$.G(1697, J$.R(1693, 'this', this, false), 'dynamicMatrix'), J$.B(202, '-', J$.R(1701, 'iy', iy, false), J$.T(1705, 1, 22))), J$.R(1713, 'ix', ix, false)), J$.G(1745, J$.G(1733, J$.G(1725, J$.R(1721, 'this', this, false), 'dynamicMatrix'), J$.R(1729, 'iy', iy, false)), J$.B(206, '-', J$.R(1737, 'ix', ix, false), J$.T(1741, 1, 22)))));
                                            J$.P(1857, J$.G(1769, J$.G(1761, J$.R(1757, 'this', this, false), 'dynamicMatrix'), J$.R(1765, 'iy', iy, false)), J$.R(1773, 'ix', ix, false), J$.M(1853, J$.I(typeof Math === 'undefined' ? Math = J$.R(1777, 'Math', undefined, true) : Math = J$.R(1777, 'Math', Math, true)), 'max', false)(J$.B(218, '+', J$.G(1809, J$.G(1797, J$.G(1785, J$.R(1781, 'this', this, false), 'dynamicMatrix'), J$.B(210, '-', J$.R(1789, 'iy', iy, false), J$.T(1793, 1, 22))), J$.B(214, '-', J$.R(1801, 'ix', ix, false), J$.T(1805, 1, 22))), J$.M(1825, J$.R(1813, 'this', this, false), '_transposedScore', false)(J$.R(1817, 'tCharA', tCharA, false), J$.R(1821, 'tCharB', tCharB, false))), J$.G(1849, J$.G(1841, J$.G(1833, J$.R(1829, 'this', this, false), 'dynamicMatrix'), J$.R(1837, 'iy', iy, false)), J$.R(1845, 'ix', ix, false))));
                                        }
                                    }
                                }
                            } catch (J$e) {
                                J$.Ex(2809, J$e);
                            } finally {
                                if (J$.Fr(2813))
                                    continue jalangiLabel5;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12),
                _backtrack: J$.T(2565, function () {
                    jalangiLabel6:
                        while (true) {
                            try {
                                J$.Fe(2521, arguments.callee, this);
                                arguments = J$.N(2525, 'arguments', arguments, true);
                                J$.N(2529, 'tmaxi', tmaxi, false);
                                J$.N(2533, 'maxix', maxix, false);
                                J$.N(2537, 'ix', ix, false);
                                J$.N(2541, 'iy', iy, false);
                                J$.N(2545, 'ixLast', ixLast, false);
                                J$.N(2549, 'iyLast', iyLast, false);
                                J$.N(2553, 'diagonal', diagonal, false);
                                J$.N(2557, 'above', above, false);
                                J$.N(2561, 'left', left, false);
                                var tmaxi = J$.W(1901, 'tmaxi', J$.T(1893, 0, 22), tmaxi), maxix = J$.W(1905, 'maxix', J$.T(1897, 0, 22), maxix);
                                for (var ix = J$.W(1921, 'ix', J$.B(222, '-', J$.G(1913, J$.R(1909, 'this', this, false), 'nameTargetLength'), J$.T(1917, 1, 22)), ix); J$.C(96, J$.B(226, '>', J$.R(1925, 'ix', ix, false), J$.T(1929, 0, 22))); J$.B(238, '+', ix = J$.W(1937, 'ix', J$.B(234, '-', J$.U(230, '+', J$.R(1933, 'ix', ix, false)), 1), ix), 1)) {
                                    if (J$.C(84, J$.B(246, '>', J$.G(1969, J$.G(1961, J$.G(1945, J$.R(1941, 'this', this, false), 'dynamicMatrix'), J$.B(242, '-', J$.G(1953, J$.R(1949, 'this', this, false), 'nameSourceLength'), J$.T(1957, 1, 22))), J$.R(1965, 'ix', ix, false)), J$.R(1973, 'tmaxi', tmaxi, false)))) {
                                        tmaxi = J$.W(2009, 'tmaxi', J$.G(2005, J$.G(1997, J$.G(1981, J$.R(1977, 'this', this, false), 'dynamicMatrix'), J$.B(250, '-', J$.G(1989, J$.R(1985, 'this', this, false), 'nameSourceLength'), J$.T(1993, 1, 22))), J$.R(2001, 'ix', ix, false)), tmaxi);
                                        maxix = J$.W(2017, 'maxix', J$.R(2013, 'ix', ix, false), maxix);
                                    }
                                    if (J$.C(92, J$.C(88, J$.B(254, '>', J$.R(2021, 'tmaxi', tmaxi, false), J$.T(2025, 0, 22))) ? J$.B(266, '==', J$.G(2061, J$.G(2049, J$.G(2033, J$.R(2029, 'this', this, false), 'dynamicMatrix'), J$.B(258, '-', J$.G(2041, J$.R(2037, 'this', this, false), 'nameSourceLength'), J$.T(2045, 1, 22))), J$.B(262, '+', J$.R(2053, 'ix', ix, false), J$.T(2057, 1, 22))), J$.T(2065, 0, 22)) : J$._())) {
                                        break;
                                    }
                                }
                                if (J$.C(100, J$.B(270, '<=', J$.R(2069, 'tmaxi', tmaxi, false), J$.T(2073, 0, 22)))) {
                                    return J$.Rt(2081, J$.T(2077, false, 23));
                                }
                                var ix = J$.W(2121, 'ix', J$.R(2085, 'maxix', maxix, false), ix), iy = J$.W(2125, 'iy', J$.B(274, '-', J$.G(2093, J$.R(2089, 'this', this, false), 'nameSourceLength'), J$.T(2097, 1, 22)), iy), ixLast = J$.W(2129, 'ixLast', J$.T(2101, 0, 22), ixLast), iyLast = J$.W(2133, 'iyLast', J$.T(2105, 0, 22), iyLast), diagonal = J$.W(2137, 'diagonal', J$.T(2109, 0, 22), diagonal), above = J$.W(2141, 'above', J$.T(2113, 0, 22), above), left = J$.W(2145, 'left', J$.T(2117, 0, 22), left);
                                while (J$.C(152, J$.C(104, J$.B(278, '>', J$.R(2149, 'iy', iy, false), J$.T(2153, 0, 22))) ? J$.B(282, '>', J$.R(2157, 'ix', ix, false), J$.T(2161, 0, 22)) : J$._())) {
                                    if (J$.C(108, J$.B(286, '>', J$.G(2185, J$.G(2177, J$.G(2169, J$.R(2165, 'this', this, false), 'dynamicMatrix'), J$.R(2173, 'iy', iy, false)), J$.R(2181, 'ix', ix, false)), J$.G(2193, J$.R(2189, 'this', this, false), 'maxMatrixValue')))) {
                                        J$.P(2225, J$.R(2197, 'this', this, false), 'maxMatrixValue', J$.G(2221, J$.G(2213, J$.G(2205, J$.R(2201, 'this', this, false), 'dynamicMatrix'), J$.R(2209, 'iy', iy, false)), J$.R(2217, 'ix', ix, false)));
                                    }
                                    if (J$.C(112, J$.G(2233, J$.R(2229, 'this', this, false), 'DEBUG'))) {
                                        J$.M(2289, J$.F(2277, J$.I(typeof $ === 'undefined' ? $ = J$.R(2237, '$', undefined, true) : $ = J$.R(2237, '$', $, true)), false)(J$.B(314, '+', J$.B(306, '+', J$.B(302, '+', J$.B(294, '+', J$.B(290, '+', J$.T(2241, '#', 21), J$.G(2249, J$.R(2245, 'this', this, false), 'DEBUG_AC')), J$.T(2253, '-', 21)), J$.B(298, '+', J$.R(2257, 'iy', iy, false), J$.T(2261, 1, 22))), J$.T(2265, '-', 21)), J$.B(310, '+', J$.R(2269, 'ix', ix, false), J$.T(2273, 1, 22)))), 'css', false)(J$.T(2281, 'background-color', 21), J$.T(2285, '#ccc', 21));
                                    }
                                    diagonal = J$.W(2325, 'diagonal', J$.G(2321, J$.G(2309, J$.G(2297, J$.R(2293, 'this', this, false), 'dynamicMatrix'), J$.B(318, '-', J$.R(2301, 'iy', iy, false), J$.T(2305, 1, 22))), J$.B(322, '-', J$.R(2313, 'ix', ix, false), J$.T(2317, 1, 22))), diagonal);
                                    above = J$.W(2357, 'above', J$.G(2353, J$.G(2341, J$.G(2333, J$.R(2329, 'this', this, false), 'dynamicMatrix'), J$.R(2337, 'iy', iy, false)), J$.B(326, '-', J$.R(2345, 'ix', ix, false), J$.T(2349, 1, 22))), above);
                                    left = J$.W(2389, 'left', J$.G(2385, J$.G(2377, J$.G(2365, J$.R(2361, 'this', this, false), 'dynamicMatrix'), J$.B(330, '-', J$.R(2369, 'iy', iy, false), J$.T(2373, 1, 22))), J$.R(2381, 'ix', ix, false)), left);
                                    if (J$.C(136, J$.C(116, J$.B(334, '>=', J$.R(2393, 'diagonal', diagonal, false), J$.R(2397, 'above', above, false))) ? J$.B(338, '>=', J$.R(2401, 'diagonal', diagonal, false), J$.R(2405, 'left', left, false)) : J$._())) {
                                        J$.B(350, '+', iy = J$.W(2413, 'iy', J$.B(346, '-', J$.U(342, '+', J$.R(2409, 'iy', iy, false)), 1), iy), 1);
                                        J$.B(362, '+', ix = J$.W(2421, 'ix', J$.B(358, '-', J$.U(354, '+', J$.R(2417, 'ix', ix, false)), 1), ix), 1);
                                    } else if (J$.C(132, J$.C(120, J$.B(366, '>=', J$.R(2425, 'above', above, false), J$.R(2429, 'diagonal', diagonal, false))) ? J$.B(370, '>=', J$.R(2433, 'above', above, false), J$.R(2437, 'left', left, false)) : J$._())) {
                                        J$.B(382, '+', ix = J$.W(2445, 'ix', J$.B(378, '-', J$.U(374, '+', J$.R(2441, 'ix', ix, false)), 1), ix), 1);
                                    } else if (J$.C(128, J$.C(124, J$.B(386, '>=', J$.R(2449, 'left', left, false), J$.R(2453, 'diagonal', diagonal, false))) ? J$.B(390, '>=', J$.R(2457, 'left', left, false), J$.R(2461, 'above', above, false)) : J$._())) {
                                        J$.B(402, '+', iy = J$.W(2469, 'iy', J$.B(398, '-', J$.U(394, '+', J$.R(2465, 'iy', iy, false)), 1), iy), 1);
                                    }
                                    if (J$.C(148, J$.C(144, J$.C(140, J$.B(406, '==', J$.R(2473, 'diagonal', diagonal, false), J$.T(2477, 0, 22))) ? J$.B(410, '==', J$.R(2481, 'above', above, false), J$.T(2485, 0, 22)) : J$._()) ? J$.B(414, '==', J$.R(2489, 'left', left, false), J$.T(2493, 0, 22)) : J$._())) {
                                        iy = J$.W(2501, 'iy', J$.T(2497, 0, 22), iy);
                                        ix = J$.W(2509, 'ix', J$.T(2505, 0, 22), ix);
                                    }
                                }
                                return J$.Rt(2517, J$.T(2513, true, 23));
                            } catch (J$e) {
                                J$.Ex(2817, J$e);
                            } finally {
                                if (J$.Fr(2821))
                                    continue jalangiLabel6;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12),
                _finalMatchScore: J$.T(2657, function (pStringScores, pStringWeights) {
                    jalangiLabel7:
                        while (true) {
                            try {
                                J$.Fe(2637, arguments.callee, this);
                                arguments = J$.N(2641, 'arguments', arguments, true);
                                pStringScores = J$.N(2645, 'pStringScores', pStringScores, true);
                                pStringWeights = J$.N(2649, 'pStringWeights', pStringWeights, true);
                                J$.N(2653, 'averageNameLength', averageNameLength, false);
                                var averageNameLength = J$.W(2589, 'averageNameLength', J$.B(422, '/', J$.B(418, '+', J$.G(2573, J$.R(2569, 'this', this, false), 'nameSourceLength'), J$.G(2581, J$.R(2577, 'this', this, false), 'nameTargetLength')), J$.T(2585, 2, 22)), averageNameLength);
                                J$.P(2613, J$.R(2593, 'this', this, false), 'overallScore', J$.B(430, '/', J$.B(426, '*', J$.T(2597, 2, 22), J$.G(2605, J$.R(2601, 'this', this, false), 'maxMatrixValue')), J$.R(2609, 'averageNameLength', averageNameLength, false)));
                                J$.P(2633, J$.R(2617, 'this', this, false), 'finalScore', J$.B(434, '*', J$.G(2625, J$.R(2621, 'this', this, false), 'overallScore'), J$.T(2629, 10, 22)));
                            } catch (J$e) {
                                J$.Ex(2825, J$e);
                            } finally {
                                if (J$.Fr(2829))
                                    continue jalangiLabel7;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12),
                score: J$.T(2721, function (pNameTarget) {
                    jalangiLabel8:
                        while (true) {
                            try {
                                J$.Fe(2709, arguments.callee, this);
                                arguments = J$.N(2713, 'arguments', arguments, true);
                                pNameTarget = J$.N(2717, 'pNameTarget', pNameTarget, true);
                                J$.M(2669, J$.R(2661, 'this', this, false), '_reset', false)(J$.R(2665, 'pNameTarget', pNameTarget, false));
                                J$.M(2677, J$.R(2673, 'this', this, false), '_buildMatrix', false)();
                                J$.M(2685, J$.R(2681, 'this', this, false), '_backtrack', false)();
                                J$.M(2693, J$.R(2689, 'this', this, false), '_finalMatchScore', false)();
                                return J$.Rt(2705, J$.G(2701, J$.R(2697, 'this', this, false), 'finalScore'));
                            } catch (J$e) {
                                J$.Ex(2833, J$e);
                            } finally {
                                if (J$.Fr(2837))
                                    continue jalangiLabel8;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12)
            }, 11));
            nm = J$.W(2745, 'nm', J$.T(2741, J$.F(2737, J$.R(2733, 'nameMatch', nameMatch, false), true)(), 11), J$.I(typeof nm === 'undefined' ? undefined : nm));
            J$.M(2753, J$.I(typeof nm === 'undefined' ? nm = J$.R(2749, 'nm', undefined, true) : nm = J$.R(2749, 'nm', nm, true)), 'score', false)();
        } catch (J$e) {
            J$.Ex(2841, J$e);
        } finally {
            if (J$.Sr(2845))
                continue jalangiLabel9;
            else
                break jalangiLabel9;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=dynamicProgramming_jalangi_.js.map