jalangiLabel1:
    while (true) {
        try {
            J$.Se(185, '../tests/multiex/loop_jalangi_.js');
            J$.N(193, 'foo', J$.T(189, foo, 12), false);
            J$.N(197, 'input', input, false);
            J$.N(201, 'i', i, false);
            function foo(array) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(97, arguments.callee, this);
                            arguments = J$.N(101, 'arguments', arguments, true);
                            array = J$.N(105, 'array', array, true);
                            J$.N(109, 'max', max, false);
                            J$.N(113, 'maxIndex', maxIndex, false);
                            J$.N(117, 'i', i, false);
                            var max = J$.W(9, 'max', J$.T(5, 0, 22), max);
                            var maxIndex = J$.W(17, 'maxIndex', J$.U(6, '-', J$.T(13, 1, 22)), maxIndex);
                            for (var i = J$.W(25, 'i', J$.T(21, 0, 22), i); J$.C(8, J$.B(10, '<', J$.R(29, 'i', i, false), J$.G(37, J$.R(33, 'array', array, false), 'length'))); J$.B(22, '-', i = J$.W(45, 'i', J$.B(18, '+', J$.U(14, '+', J$.R(41, 'i', i, false)), 1), i), 1)) {
                                if (J$.C(4, J$.B(26, '<', J$.R(49, 'max', max, false), J$.G(61, J$.R(53, 'array', array, false), J$.R(57, 'i', i, false))))) {
                                    max = J$.W(77, 'max', J$.G(73, J$.R(65, 'array', array, false), J$.R(69, 'i', i, false)), max);
                                    maxIndex = J$.W(85, 'maxIndex', J$.R(81, 'i', i, false), maxIndex);
                                }
                            }
                            return J$.Rt(93, J$.R(89, 'maxIndex', maxIndex, false));
                        } catch (J$e) {
                            J$.Ex(205, J$e);
                        } finally {
                            if (J$.Fr(209))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            var input = J$.W(125, 'input', J$.T(121, [], 10), input);
            for (var i = J$.W(133, 'i', J$.T(129, 0, 22), i); J$.C(12, J$.B(30, '<', J$.R(137, 'i', i, false), J$.T(141, 4, 22))); J$.B(42, '-', i = J$.W(149, 'i', J$.B(38, '+', J$.U(34, '+', J$.R(145, 'i', i, false)), 1), i), 1)) {
                J$.P(169, J$.R(153, 'input', input, false), J$.R(157, 'i', i, false), J$.M(165, J$, 'readInput', false)(J$.T(161, 0, 22)));
            }
            J$.F(181, J$.R(173, 'foo', foo, false), false)(J$.R(177, 'input', input, false));
        } catch (J$e) {
            J$.Ex(213, J$e);
        } finally {
            if (J$.Sr(217))
                continue jalangiLabel1;
            else
                break jalangiLabel1;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=loop_jalangi_.js.map