jalangiLabel0:
    while (true) {
        try {
            J$.Se(49, '../tests/multiex/patch/typeof/typeof_test4_jalangi_.js');
            J$.N(53, 'input', input, false);
            var input = J$.W(13, 'input', J$.M(9, J$, 'readInput', false)(J$.T(5, '', 21)), input);
            if (J$.C(4, J$.B(10, '!==', J$.U(6, 'typeof', J$.R(17, 'input', input, false)), J$.T(21, 'string', 21)))) {
                J$.M(33, J$.I(typeof console === 'undefined' ? console = J$.R(25, 'console', undefined, true) : console = J$.R(25, 'console', console, true)), 'log', false)(J$.T(29, 'then branch', 21));
            } else {
                J$.M(45, J$.I(typeof console === 'undefined' ? console = J$.R(37, 'console', undefined, true) : console = J$.R(37, 'console', console, true)), 'log', false)(J$.T(41, 'else branch', 21));
            }
        } catch (J$e) {
            J$.Ex(57, J$e);
        } finally {
            if (J$.Sr(61))
                continue jalangiLabel0;
            else
                break jalangiLabel0;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=typeof_test4_jalangi_.js.map