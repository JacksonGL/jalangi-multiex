var input = J$.readInput(true);
if(typeof input === 'object') {
    1;
    if(typeof input !== 'object'){ // <- single2 throw an exception and only generate one testcase
        2;
    } else {
        3;
    }
} else {
    4;
}