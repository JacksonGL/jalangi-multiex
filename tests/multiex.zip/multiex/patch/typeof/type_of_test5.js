var input = J$.readInput(true);
var input2 = J$.readInput(false);
if(typeof input === 'object') {
    console.log('```````````````');

    if(typeof input2 !== 'string'){
        1
    } else {
        2;
    }
} else {
    console.log('```````````````""""""""""""""""""');
}