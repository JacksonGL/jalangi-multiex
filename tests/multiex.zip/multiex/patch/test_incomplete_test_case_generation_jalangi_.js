jalangiLabel0:
    while (true) {
        try {
            J$.Se(33, '../tests/multiex/patch/test_incomplete_test_case_generation_jalangi_.js');
            J$.N(37, 'y', y, false);
            var y = J$.W(13, 'y', J$.M(9, J$, 'readInput', false)(J$.T(5, 0, 22)), y);
            if (J$.C(4, J$.B(6, '>', J$.R(17, 'y', y, false), J$.T(21, 0, 22)))) {
                J$.T(25, 1, 22);
            } else {
                J$.T(29, 2, 22);
            }
        } catch (J$e) {
            J$.Ex(41, J$e);
        } finally {
            if (J$.Sr(45))
                continue jalangiLabel0;
            else
                break jalangiLabel0;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=test_incomplete_test_case_generation_jalangi_.js.map