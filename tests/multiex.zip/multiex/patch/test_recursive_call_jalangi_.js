jalangiLabel1:
    while (true) {
        try {
            J$.Se(69, '../tests/multiex/patch/test_recursive_call_jalangi_.js');
            J$.N(77, 'foo', J$.T(73, foo, 12), false);
            function foo(x) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(41, arguments.callee, this);
                            arguments = J$.N(45, 'arguments', arguments, true);
                            x = J$.N(49, 'x', x, true);
                            if (J$.C(4, J$.B(6, '>', J$.R(5, 'x', x, false), J$.T(9, 0, 22)))) {
                                return J$.Rt(29, J$.F(25, J$.R(13, 'foo', foo, false), false)(J$.B(10, '-', J$.R(17, 'x', x, false), J$.T(21, 1, 22))));
                            } else {
                                return J$.Rt(37, J$.U(14, '-', J$.T(33, 1, 22)));
                            }
                        } catch (J$e) {
                            J$.Ex(81, J$e);
                        } finally {
                            if (J$.Fr(85))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.F(65, J$.R(53, 'foo', foo, false), false)(J$.M(61, J$, 'readInput', false)(J$.T(57, 0, 22)));
        } catch (J$e) {
            J$.Ex(89, J$e);
        } finally {
            if (J$.Sr(93))
                continue jalangiLabel1;
            else
                break jalangiLabel1;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=test_recursive_call_jalangi_.js.map