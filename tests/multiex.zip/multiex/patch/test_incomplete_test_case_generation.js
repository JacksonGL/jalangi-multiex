var y = J$.readInput(0);

if(y>0){
    1;
} else {
    2;
}