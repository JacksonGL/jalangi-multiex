

function foo(a) {
    var len = a.length;
    if (len > 1) {
        return -1;
    }
    return 1;
}

foo();