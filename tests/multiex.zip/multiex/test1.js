function foo(x){
    var r = 9.1;
    if(x>100.01){
        r = 0.3;
    } else {
        r = 1;
    }
}

foo();