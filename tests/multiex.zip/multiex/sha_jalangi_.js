jalangiLabel11:
    while (true) {
        try {
            J$.Se(2081, '../tests/multiex/sha_jalangi_.js');
            J$.N(2085, 'Sha1', Sha1, false);
            J$.N(2089, 'Utf8', Utf8, false);
            J$.N(2097, 'foo', J$.T(2093, foo, 12), false);
            var Sha1 = J$.W(9, 'Sha1', J$.T(5, {}, 11), Sha1);
            J$.P(1241, J$.R(13, 'Sha1', Sha1, false), 'hash', J$.T(1237, function (msg, utf8encode) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(1141, arguments.callee, this);
                            arguments = J$.N(1145, 'arguments', arguments, true);
                            msg = J$.N(1149, 'msg', msg, true);
                            utf8encode = J$.N(1153, 'utf8encode', utf8encode, true);
                            J$.N(1157, 'K', K, false);
                            J$.N(1161, 'l', l, false);
                            J$.N(1165, 'N', N, false);
                            J$.N(1169, 'M', M, false);
                            J$.N(1173, 'i', i, false);
                            J$.N(1177, 'j', j, false);
                            J$.N(1181, 'H0', H0, false);
                            J$.N(1185, 'H1', H1, false);
                            J$.N(1189, 'H2', H2, false);
                            J$.N(1193, 'H3', H3, false);
                            J$.N(1197, 'H4', H4, false);
                            J$.N(1201, 'W', W, false);
                            J$.N(1205, 'a', a, false);
                            J$.N(1209, 'b', b, false);
                            J$.N(1213, 'c', c, false);
                            J$.N(1217, 'd', d, false);
                            J$.N(1221, 'e', e, false);
                            J$.N(1225, 't', t, false);
                            J$.N(1229, 's', s, false);
                            J$.N(1233, 'T', T, false);
                            utf8encode = J$.W(33, 'utf8encode', J$.C(4, J$.B(10, '==', J$.U(6, 'typeof', J$.R(17, 'utf8encode', utf8encode, false)), J$.T(21, 'undefined', 21))) ? J$.T(25, true, 23) : J$.R(29, 'utf8encode', utf8encode, false), utf8encode);
                            if (J$.C(8, J$.R(37, 'utf8encode', utf8encode, false)))
                                msg = J$.W(53, 'msg', J$.M(49, J$.R(41, 'Utf8', Utf8, false), 'encode', false)(J$.R(45, 'msg', msg, false)), msg);
                            var K = J$.W(77, 'K', J$.T(73, [
                                    J$.T(57, 1518500249, 22),
                                    J$.T(61, 1859775393, 22),
                                    J$.T(65, 2400959708, 22),
                                    J$.T(69, 3395469782, 22)
                                ], 10), K);
                            msg = J$.W(97, 'msg', J$.B(14, '+', J$.R(93, 'msg', msg, false), J$.M(89, J$.I(typeof String === 'undefined' ? String = J$.R(81, 'String', undefined, true) : String = J$.R(81, 'String', String, true)), 'fromCharCode', false)(J$.T(85, 128, 22))), msg);
                            var l = J$.W(117, 'l', J$.B(22, '+', J$.B(18, '/', J$.G(105, J$.R(101, 'msg', msg, false), 'length'), J$.T(109, 4, 22)), J$.T(113, 2, 22)), l);
                            var N = J$.W(137, 'N', J$.M(133, J$.I(typeof Math === 'undefined' ? Math = J$.R(121, 'Math', undefined, true) : Math = J$.R(121, 'Math', Math, true)), 'ceil', false)(J$.B(26, '/', J$.R(125, 'l', l, false), J$.T(129, 16, 22))), N);
                            var M = J$.W(157, 'M', J$.T(153, J$.F(149, J$.I(typeof Array === 'undefined' ? Array = J$.R(141, 'Array', undefined, true) : Array = J$.R(141, 'Array', Array, true)), true)(J$.R(145, 'N', N, false)), 11), M);
                            for (var i = J$.W(165, 'i', J$.T(161, 0, 22), i); J$.C(16, J$.B(30, '<', J$.R(169, 'i', i, false), J$.R(173, 'N', N, false))); J$.B(42, '-', i = J$.W(181, 'i', J$.B(38, '+', J$.U(34, '+', J$.R(177, 'i', i, false)), 1), i), 1)) {
                                J$.P(209, J$.R(185, 'M', M, false), J$.R(189, 'i', i, false), J$.T(205, J$.F(201, J$.I(typeof Array === 'undefined' ? Array = J$.R(193, 'Array', undefined, true) : Array = J$.R(193, 'Array', Array, true)), true)(J$.T(197, 16, 22)), 11));
                                for (var j = J$.W(217, 'j', J$.T(213, 0, 22), j); J$.C(12, J$.B(46, '<', J$.R(221, 'j', j, false), J$.T(225, 16, 22))); J$.B(58, '-', j = J$.W(233, 'j', J$.B(54, '+', J$.U(50, '+', J$.R(229, 'j', j, false)), 1), j), 1)) {
                                    J$.P(373, J$.G(245, J$.R(237, 'M', M, false), J$.R(241, 'i', i, false)), J$.R(249, 'j', j, false), J$.B(142, '|', J$.B(122, '|', J$.B(98, '|', J$.B(74, '<<', J$.M(273, J$.R(253, 'msg', msg, false), 'charCodeAt', false)(J$.B(70, '+', J$.B(62, '*', J$.R(257, 'i', i, false), J$.T(261, 64, 22)), J$.B(66, '*', J$.R(265, 'j', j, false), J$.T(269, 4, 22)))), J$.T(277, 24, 22)), J$.B(94, '<<', J$.M(305, J$.R(281, 'msg', msg, false), 'charCodeAt', false)(J$.B(90, '+', J$.B(86, '+', J$.B(78, '*', J$.R(285, 'i', i, false), J$.T(289, 64, 22)), J$.B(82, '*', J$.R(293, 'j', j, false), J$.T(297, 4, 22))), J$.T(301, 1, 22))), J$.T(309, 16, 22))), J$.B(118, '<<', J$.M(337, J$.R(313, 'msg', msg, false), 'charCodeAt', false)(J$.B(114, '+', J$.B(110, '+', J$.B(102, '*', J$.R(317, 'i', i, false), J$.T(321, 64, 22)), J$.B(106, '*', J$.R(325, 'j', j, false), J$.T(329, 4, 22))), J$.T(333, 2, 22))), J$.T(341, 8, 22))), J$.M(369, J$.R(345, 'msg', msg, false), 'charCodeAt', false)(J$.B(138, '+', J$.B(134, '+', J$.B(126, '*', J$.R(349, 'i', i, false), J$.T(353, 64, 22)), J$.B(130, '*', J$.R(357, 'j', j, false), J$.T(361, 4, 22))), J$.T(365, 3, 22)))));
                                }
                            }
                            J$.P(429, J$.G(389, J$.R(377, 'M', M, false), J$.B(146, '-', J$.R(381, 'N', N, false), J$.T(385, 1, 22))), J$.T(393, 14, 22), J$.B(158, '/', J$.B(154, '*', J$.B(150, '-', J$.G(401, J$.R(397, 'msg', msg, false), 'length'), J$.T(405, 1, 22)), J$.T(409, 8, 22)), J$.M(425, J$.I(typeof Math === 'undefined' ? Math = J$.R(413, 'Math', undefined, true) : Math = J$.R(413, 'Math', Math, true)), 'pow', false)(J$.T(417, 2, 22), J$.T(421, 32, 22))));
                            J$.P(485, J$.G(445, J$.R(433, 'M', M, false), J$.B(162, '-', J$.R(437, 'N', N, false), J$.T(441, 1, 22))), J$.T(449, 14, 22), J$.M(481, J$.I(typeof Math === 'undefined' ? Math = J$.R(453, 'Math', undefined, true) : Math = J$.R(453, 'Math', Math, true)), 'floor', false)(J$.G(477, J$.G(469, J$.R(457, 'M', M, false), J$.B(166, '-', J$.R(461, 'N', N, false), J$.T(465, 1, 22))), J$.T(473, 14, 22))));
                            J$.P(529, J$.G(501, J$.R(489, 'M', M, false), J$.B(170, '-', J$.R(493, 'N', N, false), J$.T(497, 1, 22))), J$.T(505, 15, 22), J$.B(182, '&', J$.B(178, '*', J$.B(174, '-', J$.G(513, J$.R(509, 'msg', msg, false), 'length'), J$.T(517, 1, 22)), J$.T(521, 8, 22)), J$.T(525, 4294967295, 22)));
                            var H0 = J$.W(537, 'H0', J$.T(533, 1732584193, 22), H0);
                            var H1 = J$.W(545, 'H1', J$.T(541, 4023233417, 22), H1);
                            var H2 = J$.W(553, 'H2', J$.T(549, 2562383102, 22), H2);
                            var H3 = J$.W(561, 'H3', J$.T(557, 271733878, 22), H3);
                            var H4 = J$.W(569, 'H4', J$.T(565, 3285377520, 22), H4);
                            var W = J$.W(589, 'W', J$.T(585, J$.F(581, J$.I(typeof Array === 'undefined' ? Array = J$.R(573, 'Array', undefined, true) : Array = J$.R(573, 'Array', Array, true)), true)(J$.T(577, 80, 22)), 11), W);
                            var a, b, c, d, e;
                            for (var i = J$.W(597, 'i', J$.T(593, 0, 22), i); J$.C(32, J$.B(186, '<', J$.R(601, 'i', i, false), J$.R(605, 'N', N, false))); J$.B(198, '-', i = J$.W(613, 'i', J$.B(194, '+', J$.U(190, '+', J$.R(609, 'i', i, false)), 1), i), 1)) {
                                for (var t = J$.W(621, 't', J$.T(617, 0, 22), t); J$.C(20, J$.B(202, '<', J$.R(625, 't', t, false), J$.T(629, 16, 22))); J$.B(214, '-', t = J$.W(637, 't', J$.B(210, '+', J$.U(206, '+', J$.R(633, 't', t, false)), 1), t), 1))
                                    J$.P(669, J$.R(641, 'W', W, false), J$.R(645, 't', t, false), J$.G(665, J$.G(657, J$.R(649, 'M', M, false), J$.R(653, 'i', i, false)), J$.R(661, 't', t, false)));
                                for (var t = J$.W(677, 't', J$.T(673, 16, 22), t); J$.C(24, J$.B(218, '<', J$.R(681, 't', t, false), J$.T(685, 80, 22))); J$.B(230, '-', t = J$.W(693, 't', J$.B(226, '+', J$.U(222, '+', J$.R(689, 't', t, false)), 1), t), 1))
                                    J$.P(781, J$.R(697, 'W', W, false), J$.R(701, 't', t, false), J$.M(777, J$.R(705, 'Sha1', Sha1, false), 'ROTL', false)(J$.B(258, '^', J$.B(250, '^', J$.B(242, '^', J$.G(721, J$.R(709, 'W', W, false), J$.B(234, '-', J$.R(713, 't', t, false), J$.T(717, 3, 22))), J$.G(737, J$.R(725, 'W', W, false), J$.B(238, '-', J$.R(729, 't', t, false), J$.T(733, 8, 22)))), J$.G(753, J$.R(741, 'W', W, false), J$.B(246, '-', J$.R(745, 't', t, false), J$.T(749, 14, 22)))), J$.G(769, J$.R(757, 'W', W, false), J$.B(254, '-', J$.R(761, 't', t, false), J$.T(765, 16, 22)))), J$.T(773, 1, 22)));
                                a = J$.W(789, 'a', J$.R(785, 'H0', H0, false), a);
                                b = J$.W(797, 'b', J$.R(793, 'H1', H1, false), b);
                                c = J$.W(805, 'c', J$.R(801, 'H2', H2, false), c);
                                d = J$.W(813, 'd', J$.R(809, 'H3', H3, false), d);
                                e = J$.W(821, 'e', J$.R(817, 'H4', H4, false), e);
                                for (var t = J$.W(829, 't', J$.T(825, 0, 22), t); J$.C(28, J$.B(262, '<', J$.R(833, 't', t, false), J$.T(837, 80, 22))); J$.B(274, '-', t = J$.W(845, 't', J$.B(270, '+', J$.U(266, '+', J$.R(841, 't', t, false)), 1), t), 1)) {
                                    var s = J$.W(865, 's', J$.M(861, J$.I(typeof Math === 'undefined' ? Math = J$.R(849, 'Math', undefined, true) : Math = J$.R(849, 'Math', Math, true)), 'floor', false)(J$.B(278, '/', J$.R(853, 't', t, false), J$.T(857, 20, 22))), s);
                                    var T = J$.W(941, 'T', J$.B(298, '&', J$.B(294, '+', J$.B(290, '+', J$.B(286, '+', J$.B(282, '+', J$.M(881, J$.R(869, 'Sha1', Sha1, false), 'ROTL', false)(J$.R(873, 'a', a, false), J$.T(877, 5, 22)), J$.M(905, J$.R(885, 'Sha1', Sha1, false), 'f', false)(J$.R(889, 's', s, false), J$.R(893, 'b', b, false), J$.R(897, 'c', c, false), J$.R(901, 'd', d, false))), J$.R(909, 'e', e, false)), J$.G(921, J$.R(913, 'K', K, false), J$.R(917, 's', s, false))), J$.G(933, J$.R(925, 'W', W, false), J$.R(929, 't', t, false))), J$.T(937, 4294967295, 22)), T);
                                    e = J$.W(949, 'e', J$.R(945, 'd', d, false), e);
                                    d = J$.W(957, 'd', J$.R(953, 'c', c, false), d);
                                    c = J$.W(977, 'c', J$.M(973, J$.R(961, 'Sha1', Sha1, false), 'ROTL', false)(J$.R(965, 'b', b, false), J$.T(969, 30, 22)), c);
                                    b = J$.W(985, 'b', J$.R(981, 'a', a, false), b);
                                    a = J$.W(993, 'a', J$.R(989, 'T', T, false), a);
                                }
                                H0 = J$.W(1009, 'H0', J$.B(306, '&', J$.B(302, '+', J$.R(997, 'H0', H0, false), J$.R(1001, 'a', a, false)), J$.T(1005, 4294967295, 22)), H0);
                                H1 = J$.W(1025, 'H1', J$.B(314, '&', J$.B(310, '+', J$.R(1013, 'H1', H1, false), J$.R(1017, 'b', b, false)), J$.T(1021, 4294967295, 22)), H1);
                                H2 = J$.W(1041, 'H2', J$.B(322, '&', J$.B(318, '+', J$.R(1029, 'H2', H2, false), J$.R(1033, 'c', c, false)), J$.T(1037, 4294967295, 22)), H2);
                                H3 = J$.W(1057, 'H3', J$.B(330, '&', J$.B(326, '+', J$.R(1045, 'H3', H3, false), J$.R(1049, 'd', d, false)), J$.T(1053, 4294967295, 22)), H3);
                                H4 = J$.W(1073, 'H4', J$.B(338, '&', J$.B(334, '+', J$.R(1061, 'H4', H4, false), J$.R(1065, 'e', e, false)), J$.T(1069, 4294967295, 22)), H4);
                            }
                            return J$.Rt(1137, J$.B(354, '+', J$.B(350, '+', J$.B(346, '+', J$.B(342, '+', J$.M(1085, J$.R(1077, 'Sha1', Sha1, false), 'toHexStr', false)(J$.R(1081, 'H0', H0, false)), J$.M(1097, J$.R(1089, 'Sha1', Sha1, false), 'toHexStr', false)(J$.R(1093, 'H1', H1, false))), J$.M(1109, J$.R(1101, 'Sha1', Sha1, false), 'toHexStr', false)(J$.R(1105, 'H2', H2, false))), J$.M(1121, J$.R(1113, 'Sha1', Sha1, false), 'toHexStr', false)(J$.R(1117, 'H3', H3, false))), J$.M(1133, J$.R(1125, 'Sha1', Sha1, false), 'toHexStr', false)(J$.R(1129, 'H4', H4, false))));
                        } catch (J$e) {
                            J$.Ex(2101, J$e);
                        } finally {
                            if (J$.Fr(2105))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1377, J$.R(1245, 'Sha1', Sha1, false), 'f', J$.T(1373, function (s, x, y, z) {
                jalangiLabel1:
                    while (true) {
                        try {
                            J$.Fe(1349, arguments.callee, this);
                            arguments = J$.N(1353, 'arguments', arguments, true);
                            s = J$.N(1357, 's', s, true);
                            x = J$.N(1361, 'x', x, true);
                            y = J$.N(1365, 'y', y, true);
                            z = J$.N(1369, 'z', z, true);
                            switch (J$.C1(36, J$.R(1249, 's', s, false))) {
                            case J$.C2(40, J$.T(1273, 0, 22)):
                                return J$.Rt(1269, J$.B(370, '^', J$.B(358, '&', J$.R(1253, 'x', x, false), J$.R(1257, 'y', y, false)), J$.B(366, '&', J$.U(362, '~', J$.R(1261, 'x', x, false)), J$.R(1265, 'z', z, false))));
                            case J$.C2(44, J$.T(1293, 1, 22)):
                                return J$.Rt(1289, J$.B(378, '^', J$.B(374, '^', J$.R(1277, 'x', x, false), J$.R(1281, 'y', y, false)), J$.R(1285, 'z', z, false)));
                            case J$.C2(48, J$.T(1325, 2, 22)):
                                return J$.Rt(1321, J$.B(398, '^', J$.B(390, '^', J$.B(382, '&', J$.R(1297, 'x', x, false), J$.R(1301, 'y', y, false)), J$.B(386, '&', J$.R(1305, 'x', x, false), J$.R(1309, 'z', z, false))), J$.B(394, '&', J$.R(1313, 'y', y, false), J$.R(1317, 'z', z, false))));
                            case J$.C2(52, J$.T(1345, 3, 22)):
                                return J$.Rt(1341, J$.B(406, '^', J$.B(402, '^', J$.R(1329, 'x', x, false), J$.R(1333, 'y', y, false)), J$.R(1337, 'z', z, false)));
                            }
                        } catch (J$e) {
                            J$.Ex(2109, J$e);
                        } finally {
                            if (J$.Fr(2113))
                                continue jalangiLabel1;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1429, J$.R(1381, 'Sha1', Sha1, false), 'ROTL', J$.T(1425, function (x, n) {
                jalangiLabel2:
                    while (true) {
                        try {
                            J$.Fe(1409, arguments.callee, this);
                            arguments = J$.N(1413, 'arguments', arguments, true);
                            x = J$.N(1417, 'x', x, true);
                            n = J$.N(1421, 'n', n, true);
                            return J$.Rt(1405, J$.B(422, '|', J$.B(410, '<<', J$.R(1385, 'x', x, false), J$.R(1389, 'n', n, false)), J$.B(418, '>>>', J$.R(1393, 'x', x, false), J$.B(414, '-', J$.T(1397, 32, 22), J$.R(1401, 'n', n, false)))));
                        } catch (J$e) {
                            J$.Ex(2117, J$e);
                        } finally {
                            if (J$.Fr(2121))
                                continue jalangiLabel2;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1545, J$.R(1433, 'Sha1', Sha1, false), 'toHexStr', J$.T(1541, function (n) {
                jalangiLabel3:
                    while (true) {
                        try {
                            J$.Fe(1517, arguments.callee, this);
                            arguments = J$.N(1521, 'arguments', arguments, true);
                            n = J$.N(1525, 'n', n, true);
                            J$.N(1529, 's', s, false);
                            J$.N(1533, 'v', v, false);
                            J$.N(1537, 'i', i, false);
                            var s = J$.W(1441, 's', J$.T(1437, '', 21), s), v;
                            for (var i = J$.W(1449, 'i', J$.T(1445, 7, 22), i); J$.C(56, J$.B(426, '>=', J$.R(1453, 'i', i, false), J$.T(1457, 0, 22))); J$.B(438, '+', i = J$.W(1465, 'i', J$.B(434, '-', J$.U(430, '+', J$.R(1461, 'i', i, false)), 1), i), 1)) {
                                v = J$.W(1485, 'v', J$.B(450, '&', J$.B(446, '>>>', J$.R(1469, 'n', n, false), J$.B(442, '*', J$.R(1473, 'i', i, false), J$.T(1477, 4, 22))), J$.T(1481, 15, 22)), v);
                                s = J$.W(1505, 's', J$.B(454, '+', J$.R(1501, 's', s, false), J$.M(1497, J$.R(1489, 'v', v, false), 'toString', false)(J$.T(1493, 16, 22))), s);
                            }
                            return J$.Rt(1513, J$.R(1509, 's', s, false));
                        } catch (J$e) {
                            J$.Ex(2125, J$e);
                        } finally {
                            if (J$.Fr(2129))
                                continue jalangiLabel3;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            var Utf8 = J$.W(1553, 'Utf8', J$.T(1549, {}, 11), Utf8);
            J$.P(1781, J$.R(1557, 'Utf8', Utf8, false), 'encode', J$.T(1777, function (strUni) {
                jalangiLabel6:
                    while (true) {
                        try {
                            J$.Fe(1761, arguments.callee, this);
                            arguments = J$.N(1765, 'arguments', arguments, true);
                            strUni = J$.N(1769, 'strUni', strUni, true);
                            J$.N(1773, 'strUtf', strUtf, false);
                            var strUtf = J$.W(1645, 'strUtf', J$.M(1641, J$.R(1561, 'strUni', strUni, false), 'replace', false)(J$.T(1565, /[\u0080-\u07ff]/g, 14), J$.T(1637, function (c) {
                                    jalangiLabel4:
                                        while (true) {
                                            try {
                                                J$.Fe(1621, arguments.callee, this);
                                                arguments = J$.N(1625, 'arguments', arguments, true);
                                                c = J$.N(1629, 'c', c, true);
                                                J$.N(1633, 'cc', cc, false);
                                                var cc = J$.W(1581, 'cc', J$.M(1577, J$.R(1569, 'c', c, false), 'charCodeAt', false)(J$.T(1573, 0, 22)), cc);
                                                return J$.Rt(1617, J$.M(1613, J$.I(typeof String === 'undefined' ? String = J$.R(1585, 'String', undefined, true) : String = J$.R(1585, 'String', String, true)), 'fromCharCode', false)(J$.B(462, '|', J$.T(1589, 192, 22), J$.B(458, '>>', J$.R(1593, 'cc', cc, false), J$.T(1597, 6, 22))), J$.B(470, '|', J$.T(1601, 128, 22), J$.B(466, '&', J$.R(1605, 'cc', cc, false), J$.T(1609, 63, 22)))));
                                            } catch (J$e) {
                                                J$.Ex(2133, J$e);
                                            } finally {
                                                if (J$.Fr(2137))
                                                    continue jalangiLabel4;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12)), strUtf);
                            strUtf = J$.W(1749, 'strUtf', J$.M(1745, J$.R(1649, 'strUtf', strUtf, false), 'replace', false)(J$.T(1653, /[\u0800-\uffff]/g, 14), J$.T(1741, function (c) {
                                jalangiLabel5:
                                    while (true) {
                                        try {
                                            J$.Fe(1725, arguments.callee, this);
                                            arguments = J$.N(1729, 'arguments', arguments, true);
                                            c = J$.N(1733, 'c', c, true);
                                            J$.N(1737, 'cc', cc, false);
                                            var cc = J$.W(1669, 'cc', J$.M(1665, J$.R(1657, 'c', c, false), 'charCodeAt', false)(J$.T(1661, 0, 22)), cc);
                                            return J$.Rt(1721, J$.M(1717, J$.I(typeof String === 'undefined' ? String = J$.R(1673, 'String', undefined, true) : String = J$.R(1673, 'String', String, true)), 'fromCharCode', false)(J$.B(478, '|', J$.T(1677, 224, 22), J$.B(474, '>>', J$.R(1681, 'cc', cc, false), J$.T(1685, 12, 22))), J$.B(490, '|', J$.T(1689, 128, 22), J$.B(486, '&', J$.B(482, '>>', J$.R(1693, 'cc', cc, false), J$.T(1697, 6, 22)), J$.T(1701, 63, 22))), J$.B(498, '|', J$.T(1705, 128, 22), J$.B(494, '&', J$.R(1709, 'cc', cc, false), J$.T(1713, 63, 22)))));
                                        } catch (J$e) {
                                            J$.Ex(2141, J$e);
                                        } finally {
                                            if (J$.Fr(2145))
                                                continue jalangiLabel5;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12)), strUtf);
                            return J$.Rt(1757, J$.R(1753, 'strUtf', strUtf, false));
                        } catch (J$e) {
                            J$.Ex(2149, J$e);
                        } finally {
                            if (J$.Fr(2153))
                                continue jalangiLabel6;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(2021, J$.R(1785, 'Utf8', Utf8, false), 'decode', J$.T(2017, function (strUtf) {
                jalangiLabel9:
                    while (true) {
                        try {
                            J$.Fe(2001, arguments.callee, this);
                            arguments = J$.N(2005, 'arguments', arguments, true);
                            strUtf = J$.N(2009, 'strUtf', strUtf, true);
                            J$.N(2013, 'strUni', strUni, false);
                            var strUni = J$.W(1897, 'strUni', J$.M(1893, J$.R(1789, 'strUtf', strUtf, false), 'replace', false)(J$.T(1793, /[\u00e0-\u00ef][\u0080-\u00bf][\u0080-\u00bf]/g, 14), J$.T(1889, function (c) {
                                    jalangiLabel7:
                                        while (true) {
                                            try {
                                                J$.Fe(1873, arguments.callee, this);
                                                arguments = J$.N(1877, 'arguments', arguments, true);
                                                c = J$.N(1881, 'c', c, true);
                                                J$.N(1885, 'cc', cc, false);
                                                var cc = J$.W(1853, 'cc', J$.B(526, '|', J$.B(518, '|', J$.B(506, '<<', J$.B(502, '&', J$.M(1805, J$.R(1797, 'c', c, false), 'charCodeAt', false)(J$.T(1801, 0, 22)), J$.T(1809, 15, 22)), J$.T(1813, 12, 22)), J$.B(514, '<<', J$.B(510, '&', J$.M(1825, J$.R(1817, 'c', c, false), 'charCodeAt', false)(J$.T(1821, 1, 22)), J$.T(1829, 63, 22)), J$.T(1833, 6, 22))), J$.B(522, '&', J$.M(1845, J$.R(1837, 'c', c, false), 'charCodeAt', false)(J$.T(1841, 2, 22)), J$.T(1849, 63, 22))), cc);
                                                return J$.Rt(1869, J$.M(1865, J$.I(typeof String === 'undefined' ? String = J$.R(1857, 'String', undefined, true) : String = J$.R(1857, 'String', String, true)), 'fromCharCode', false)(J$.R(1861, 'cc', cc, false)));
                                            } catch (J$e) {
                                                J$.Ex(2157, J$e);
                                            } finally {
                                                if (J$.Fr(2161))
                                                    continue jalangiLabel7;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12)), strUni);
                            strUni = J$.W(1989, 'strUni', J$.M(1985, J$.R(1901, 'strUni', strUni, false), 'replace', false)(J$.T(1905, /[\u00c0-\u00df][\u0080-\u00bf]/g, 14), J$.T(1981, function (c) {
                                jalangiLabel8:
                                    while (true) {
                                        try {
                                            J$.Fe(1965, arguments.callee, this);
                                            arguments = J$.N(1969, 'arguments', arguments, true);
                                            c = J$.N(1973, 'c', c, true);
                                            J$.N(1977, 'cc', cc, false);
                                            var cc = J$.W(1945, 'cc', J$.B(542, '|', J$.B(534, '<<', J$.B(530, '&', J$.M(1917, J$.R(1909, 'c', c, false), 'charCodeAt', false)(J$.T(1913, 0, 22)), J$.T(1921, 31, 22)), J$.T(1925, 6, 22)), J$.B(538, '&', J$.M(1937, J$.R(1929, 'c', c, false), 'charCodeAt', false)(J$.T(1933, 1, 22)), J$.T(1941, 63, 22))), cc);
                                            return J$.Rt(1961, J$.M(1957, J$.I(typeof String === 'undefined' ? String = J$.R(1949, 'String', undefined, true) : String = J$.R(1949, 'String', String, true)), 'fromCharCode', false)(J$.R(1953, 'cc', cc, false)));
                                        } catch (J$e) {
                                            J$.Ex(2165, J$e);
                                        } finally {
                                            if (J$.Fr(2169))
                                                continue jalangiLabel8;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12)), strUni);
                            return J$.Rt(1997, J$.R(1993, 'strUni', strUni, false));
                        } catch (J$e) {
                            J$.Ex(2173, J$e);
                        } finally {
                            if (J$.Fr(2177))
                                continue jalangiLabel9;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            function foo(x) {
                jalangiLabel10:
                    while (true) {
                        try {
                            J$.Fe(2057, arguments.callee, this);
                            arguments = J$.N(2061, 'arguments', arguments, true);
                            x = J$.N(2065, 'x', x, true);
                            J$.N(2069, 'output', output, false);
                            var output = J$.W(2041, 'output', J$.M(2037, J$.R(2025, 'Sha1', Sha1, false), 'hash', false)(J$.R(2029, 'x', x, false), J$.T(2033, {}, 11)), output);
                            J$.M(2053, J$.I(typeof console === 'undefined' ? console = J$.R(2045, 'console', undefined, true) : console = J$.R(2045, 'console', console, true)), 'log', false)(J$.R(2049, 'output', output, false));
                        } catch (J$e) {
                            J$.Ex(2181, J$e);
                        } finally {
                            if (J$.Fr(2185))
                                continue jalangiLabel10;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.F(2077, J$.R(2073, 'foo', foo, false), false)();
        } catch (J$e) {
            J$.Ex(2189, J$e);
        } finally {
            if (J$.Sr(2193))
                continue jalangiLabel11;
            else
                break jalangiLabel11;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=sha_jalangi_.js.map