jalangiLabel1:
    while (true) {
        try {
            J$.Se(37, '../tests/multiex/simple_jalangi_.js');
            J$.N(45, 'f', J$.T(41, f, 12), false);
            function f(a, b) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(21, arguments.callee, this);
                            arguments = J$.N(25, 'arguments', arguments, true);
                            a = J$.N(29, 'a', a, true);
                            b = J$.N(33, 'b', b, true);
                            if (J$.C(8, J$.B(6, '>', J$.R(5, 'a', a, false), J$.T(9, 0, 22)))) {
                            } else {
                                if (J$.C(4, J$.B(10, '>', J$.R(13, 'b', b, false), J$.T(17, 0, 22)))) {
                                }
                            }
                        } catch (J$e) {
                            J$.Ex(49, J$e);
                        } finally {
                            if (J$.Fr(53))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
        } catch (J$e) {
            J$.Ex(57, J$e);
        } finally {
            if (J$.Sr(61))
                continue jalangiLabel1;
            else
                break jalangiLabel1;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=simple_jalangi_.js.map