jalangiLabel1:
    while (true) {
        try {
            J$.Se(101, '../tests/multiex/examples/example4_jalangi_.js');
            J$.N(105, 'x', x, false);
            J$.N(109, 'p', p, false);
            J$.N(117, 'foo', J$.T(113, foo, 12), false);
            var x, p;
            p = J$.W(17, 'p', J$.T(13, {
                f: J$.T(5, 1, 22),
                g: J$.T(9, 2, 22)
            }, 11), p);
            x = J$.W(29, 'x', J$.M(25, J$, 'readInput', false)(J$.T(21, 1, 22)), x);
            function foo() {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(61, arguments.callee, this);
                            arguments = J$.N(65, 'arguments', arguments, true);
                            if (J$.C(8, J$.B(6, '>', J$.R(33, 'x', x, false), J$.T(37, 100, 22)))) {
                                if (J$.C(4, J$.B(10, '==', J$.R(41, 'x', x, false), J$.T(45, 200, 22)))) {
                                    p = J$.W(57, 'p', J$.T(53, { f: J$.T(49, 2, 22) }, 11), p);
                                }
                            }
                        } catch (J$e) {
                            J$.Ex(121, J$e);
                        } finally {
                            if (J$.Fr(125))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.F(73, J$.R(69, 'foo', foo, false), false)();
            if (J$.C(12, J$.B(14, '==', J$.G(81, J$.R(77, 'p', p, false), 'f'), J$.T(85, 2, 22)))) {
                J$.M(97, J$.I(typeof console === 'undefined' ? console = J$.R(89, 'console', undefined, true) : console = J$.R(89, 'console', console, true)), 'log', false)(J$.R(93, 'x', x, false));
            }
        } catch (J$e) {
            J$.Ex(129, J$e);
        } finally {
            if (J$.Sr(133))
                continue jalangiLabel1;
            else
                break jalangiLabel1;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=example4_jalangi_.js.map