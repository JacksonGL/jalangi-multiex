jalangiLabel1:
    while (true) {
        try {
            J$.Se(141, '../tests/multiex/examples/example_paper_jalangi_.js');
            J$.N(145, 'x', x, false);
            J$.N(149, 'y', y, false);
            J$.N(153, 'r', r, false);
            J$.N(157, 'z', z, false);
            J$.N(165, 'foo', J$.T(161, foo, 12), false);
            var x = J$.W(13, 'x', J$.M(9, J$, 'readInput', false)(J$.T(5, 1, 22)), x);
            var y = J$.W(25, 'y', J$.M(21, J$, 'readInput', false)(J$.T(17, 1, 22)), y);
            var r = J$.W(37, 'r', J$.M(33, J$, 'readInput', false)(J$.T(29, 1, 22)), r);
            var z = J$.W(49, 'z', J$.M(45, J$, 'readInput', false)(J$.T(41, 1, 22)), z);
            function foo(a, b) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(85, arguments.callee, this);
                            arguments = J$.N(89, 'arguments', arguments, true);
                            a = J$.N(93, 'a', a, true);
                            b = J$.N(97, 'b', b, true);
                            if (J$.C(8, J$.B(6, '>', J$.R(53, 'a', a, false), J$.T(57, 100, 22)))) {
                                if (J$.C(4, J$.R(61, 'b', b, false))) {
                                    r = J$.W(69, 'r', J$.T(65, 0.3, 22), r);
                                }
                                r = J$.W(81, 'r', J$.B(10, '+', J$.R(73, 'r', r, false), J$.T(77, 1, 22)), r);
                            }
                        } catch (J$e) {
                            J$.Ex(169, J$e);
                        } finally {
                            if (J$.Fr(173))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.F(113, J$.R(101, 'foo', foo, false), false)(J$.R(105, 'x', x, false), J$.R(109, 'z', z, false));
            J$.F(129, J$.R(117, 'foo', foo, false), false)(J$.R(121, 'y', y, false), J$.U(14, '!', J$.R(125, 'z', z, false)));
            if (J$.C(12, J$.B(18, '>', J$.R(133, 'r', r, false), J$.T(137, 2, 22)))) {
            }
        } catch (J$e) {
            J$.Ex(177, J$e);
        } finally {
            if (J$.Sr(181))
                continue jalangiLabel1;
            else
                break jalangiLabel1;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=example_paper_jalangi_.js.map