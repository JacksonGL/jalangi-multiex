var x = J$.readInput(1);

var y = !x;
var z = y + 1;
if(z > 1123){

} else {

}