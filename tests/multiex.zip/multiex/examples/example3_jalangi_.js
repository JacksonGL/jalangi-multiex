jalangiLabel3:
    while (true) {
        try {
            J$.Se(153, '../tests/multiex/examples/example3_jalangi_.js');
            J$.N(157, 'x', x, false);
            J$.N(161, 'f', f, false);
            J$.N(169, 'foo', J$.T(165, foo, 12), false);
            var x, f;
            x = J$.W(13, 'x', J$.M(9, J$, 'readInput', false)(J$.T(5, 1, 22)), x);
            function foo(y) {
                jalangiLabel2:
                    while (true) {
                        try {
                            J$.Fe(89, arguments.callee, this);
                            arguments = J$.N(93, 'arguments', arguments, true);
                            y = J$.N(97, 'y', y, true);
                            if (J$.C(4, J$.B(6, '>', J$.R(17, 'y', y, false), J$.T(21, 0, 22)))) {
                                return J$.Rt(53, J$.T(49, function f1(z) {
                                    jalangiLabel0:
                                        while (true) {
                                            try {
                                                J$.Fe(37, arguments.callee, this);
                                                arguments = J$.N(41, 'arguments', arguments, true);
                                                z = J$.N(45, 'z', z, true);
                                                return J$.Rt(33, J$.B(10, '-', J$.R(25, 'z', z, false), J$.T(29, 1, 22)));
                                            } catch (J$e) {
                                                J$.Ex(173, J$e);
                                            } finally {
                                                if (J$.Fr(177))
                                                    continue jalangiLabel0;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12));
                            } else {
                                return J$.Rt(85, J$.T(81, function f2(z) {
                                    jalangiLabel1:
                                        while (true) {
                                            try {
                                                J$.Fe(69, arguments.callee, this);
                                                arguments = J$.N(73, 'arguments', arguments, true);
                                                z = J$.N(77, 'z', z, true);
                                                return J$.Rt(65, J$.B(14, '+', J$.R(57, 'z', z, false), J$.T(61, 1, 22)));
                                            } catch (J$e) {
                                                J$.Ex(181, J$e);
                                            } finally {
                                                if (J$.Fr(185))
                                                    continue jalangiLabel1;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12));
                            }
                        } catch (J$e) {
                            J$.Ex(189, J$e);
                        } finally {
                            if (J$.Fr(193))
                                continue jalangiLabel2;
                            else
                                return J$.Ra();
                        }
                    }
            }
            f = J$.W(113, 'f', J$.F(109, J$.R(101, 'foo', foo, false), false)(J$.R(105, 'x', x, false)), f);
            x = J$.W(129, 'x', J$.F(125, J$.R(117, 'f', f, false), false)(J$.R(121, 'x', x, false)), x);
            if (J$.C(8, J$.B(18, '>', J$.R(133, 'x', x, false), J$.T(137, 0, 22)))) {
                J$.M(149, J$.I(typeof console === 'undefined' ? console = J$.R(141, 'console', undefined, true) : console = J$.R(141, 'console', console, true)), 'log', false)(J$.R(145, 'x', x, false));
            }
        } catch (J$e) {
            J$.Ex(197, J$e);
        } finally {
            if (J$.Sr(201))
                continue jalangiLabel3;
            else
                break jalangiLabel3;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=example3_jalangi_.js.map