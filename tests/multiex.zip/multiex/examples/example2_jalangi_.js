jalangiLabel1:
    while (true) {
        try {
            J$.Se(93, '../tests/multiex/examples/example2_jalangi_.js');
            J$.N(97, 'x', x, false);
            J$.N(101, 'r', r, false);
            J$.N(109, 'foo', J$.T(105, foo, 12), false);
            var x, r;
            r = J$.W(9, 'r', J$.T(5, 9.1, 22), r);
            x = J$.W(21, 'x', J$.M(17, J$, 'readInput', false)(J$.T(13, 1, 22)), x);
            function foo() {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(49, arguments.callee, this);
                            arguments = J$.N(53, 'arguments', arguments, true);
                            if (J$.C(8, J$.B(6, '>', J$.R(25, 'x', x, false), J$.T(29, 100, 22)))) {
                                if (J$.C(4, J$.B(10, '==', J$.R(33, 'x', x, false), J$.T(37, 200, 22))))
                                    r = J$.W(45, 'r', J$.T(41, 0.3, 22), r);
                            }
                        } catch (J$e) {
                            J$.Ex(113, J$e);
                        } finally {
                            if (J$.Fr(117))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.F(61, J$.R(57, 'foo', foo, false), false)();
            if (J$.C(12, J$.B(22, '<', J$.B(18, '-', J$.B(14, '*', J$.R(65, 'r', r, false), J$.R(69, 'r', r, false)), J$.R(73, 'r', r, false)), J$.T(77, 0, 22)))) {
                J$.M(89, J$.I(typeof console === 'undefined' ? console = J$.R(81, 'console', undefined, true) : console = J$.R(81, 'console', console, true)), 'log', false)(J$.R(85, 'x', x, false));
            }
        } catch (J$e) {
            J$.Ex(121, J$e);
        } finally {
            if (J$.Sr(125))
                continue jalangiLabel1;
            else
                break jalangiLabel1;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=example2_jalangi_.js.map