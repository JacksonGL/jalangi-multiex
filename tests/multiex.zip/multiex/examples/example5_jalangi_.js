jalangiLabel1:
    while (true) {
        try {
            J$.Se(109, '../tests/multiex/examples/example5_jalangi_.js');
            J$.N(113, 'x', x, false);
            J$.N(117, 'y', y, false);
            J$.N(121, 'r', r, false);
            J$.N(129, 'foo', J$.T(125, foo, 12), false);
            var x = J$.W(13, 'x', J$.M(9, J$, 'readInput', false)(J$.T(5, 1, 22)), x);
            var y = J$.W(25, 'y', J$.M(21, J$, 'readInput', false)(J$.T(17, 1, 22)), y);
            var r = J$.W(33, 'r', J$.T(29, 0, 22), r);
            function foo(a) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(61, arguments.callee, this);
                            arguments = J$.N(65, 'arguments', arguments, true);
                            a = J$.N(69, 'a', a, true);
                            if (J$.C(8, J$.B(6, '>', J$.R(37, 'a', a, false), J$.T(41, 100, 22)))) {
                                if (J$.C(4, J$.B(10, '==', J$.R(45, 'a', a, false), J$.T(49, 200, 22)))) {
                                    J$.B(22, '-', r = J$.W(57, 'r', J$.B(18, '+', J$.U(14, '+', J$.R(53, 'r', r, false)), 1), r), 1);
                                }
                            }
                        } catch (J$e) {
                            J$.Ex(133, J$e);
                        } finally {
                            if (J$.Fr(137))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.F(81, J$.R(73, 'foo', foo, false), false)(J$.R(77, 'x', x, false));
            J$.F(93, J$.R(85, 'foo', foo, false), false)(J$.R(89, 'y', y, false));
            J$.M(105, J$.I(typeof console === 'undefined' ? console = J$.R(97, 'console', undefined, true) : console = J$.R(97, 'console', console, true)), 'log', false)(J$.R(101, 'r', r, false));
        } catch (J$e) {
            J$.Ex(141, J$e);
        } finally {
            if (J$.Sr(145))
                continue jalangiLabel1;
            else
                break jalangiLabel1;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=example5_jalangi_.js.map