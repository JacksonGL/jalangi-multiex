jalangiLabel1:
    while (true) {
        try {
            J$.Se(173, '../tests/multiex/examples/new_example_jalangi_.js');
            J$.N(181, 'f', J$.T(177, f, 12), false);
            function f(c) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(45, arguments.callee, this);
                            arguments = J$.N(49, 'arguments', arguments, true);
                            c = J$.N(53, 'c', c, true);
                            J$.N(57, 'i', i, false);
                            for (var i = J$.W(9, 'i', J$.T(5, 0, 22), i); J$.C(8, J$.B(6, '<', J$.R(13, 'i', i, false), J$.T(17, 12, 22))); J$.B(18, '-', i = J$.W(25, 'i', J$.B(14, '+', J$.U(10, '+', J$.R(21, 'i', i, false)), 1), i), 1))
                                if (J$.C(4, J$.B(22, '>', J$.R(29, 'c', c, false), J$.T(33, 100, 22)))) {
                                    J$.T(37, 1, 22);
                                } else {
                                    J$.T(41, 2, 22);
                                }
                        } catch (J$e) {
                            J$.Ex(185, J$e);
                        } finally {
                            if (J$.Fr(189))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.F(73, J$.R(61, 'f', f, false), false)(J$.M(69, J$, 'readInput', false)(J$.T(65, 1, 22)));
            J$.F(89, J$.R(77, 'f', f, false), false)(J$.M(85, J$, 'readInput', false)(J$.T(81, 1, 22)));
            J$.F(105, J$.R(93, 'f', f, false), false)(J$.M(101, J$, 'readInput', false)(J$.T(97, 1, 22)));
            J$.F(121, J$.R(109, 'f', f, false), false)(J$.M(117, J$, 'readInput', false)(J$.T(113, 1, 22)));
            J$.F(137, J$.R(125, 'f', f, false), false)(J$.M(133, J$, 'readInput', false)(J$.T(129, 1, 22)));
            J$.F(153, J$.R(141, 'f', f, false), false)(J$.M(149, J$, 'readInput', false)(J$.T(145, 1, 22)));
            J$.F(169, J$.R(157, 'f', f, false), false)(J$.M(165, J$, 'readInput', false)(J$.T(161, 1, 22)));
        } catch (J$e) {
            J$.Ex(193, J$e);
        } finally {
            if (J$.Sr(197))
                continue jalangiLabel1;
            else
                break jalangiLabel1;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=new_example_jalangi_.js.map