


function f(c){
    for(var i=0;i<12;i++)
        if(c>100){
            1;
        } else {
            2;
        }
}

f(J$.readInput(1));
f(J$.readInput(1));
f(J$.readInput(1));
f(J$.readInput(1));
f(J$.readInput(1));
f(J$.readInput(1));
f(J$.readInput(1));
