jalangiLabel1:
    while (true) {
        try {
            J$.Se(193, '../tests/multiex/examples/example1_jalangi_.js');
            J$.N(197, 'p', p, false);
            J$.N(201, 'q', q, false);
            J$.N(205, 't', t, false);
            J$.N(209, 'error', error, false);
            J$.N(213, 'y', y, false);
            J$.N(221, 'foo', J$.T(217, foo, 12), false);
            var p = J$.W(17, 'p', J$.T(5, {}, 11), p), q = J$.W(21, 'q', J$.T(9, {}, 11), q), t = J$.W(25, 't', J$.T(13, {}, 11), t), error, y;
            function foo(r, s) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(89, arguments.callee, this);
                            arguments = J$.N(93, 'arguments', arguments, true);
                            r = J$.N(97, 'r', r, true);
                            s = J$.N(101, 's', s, true);
                            J$.P(37, J$.R(29, 'r', r, false), 'f', J$.T(33, 1, 22));
                            J$.P(49, J$.R(41, 's', s, false), 'f', J$.T(45, 2, 22));
                            if (J$.C(8, J$.B(6, '!=', J$.G(57, J$.R(53, 'r', r, false), 'f'), J$.T(61, 1, 22)))) {
                                if (J$.C(4, J$.B(10, '==', J$.R(65, 'y', y, false), J$.T(69, 100, 22)))) {
                                    error = J$.W(77, 'error', J$.T(73, 1, 22), error);
                                } else {
                                    error = J$.W(85, 'error', J$.T(81, 0, 22), error);
                                }
                            }
                        } catch (J$e) {
                            J$.Ex(225, J$e);
                        } finally {
                            if (J$.Fr(229))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            y = J$.W(113, 'y', J$.M(109, J$, 'readInput', false)(J$.T(105, 1, 22)), y);
            J$.P(129, J$.R(117, 'p', p, false), 'f', J$.M(125, J$, 'readInput', false)(J$.T(121, 1, 22)));
            J$.P(145, J$.R(133, 't', t, false), 'f', J$.M(141, J$, 'readInput', false)(J$.T(137, 1, 22)));
            J$.F(161, J$.R(149, 'foo', foo, false), false)(J$.R(153, 'p', p, false), J$.R(157, 'q', q, false));
            J$.F(177, J$.R(165, 'foo', foo, false), false)(J$.R(169, 't', t, false), J$.R(173, 't', t, false));
            J$.M(189, J$.I(typeof console === 'undefined' ? console = J$.R(181, 'console', undefined, true) : console = J$.R(181, 'console', console, true)), 'log', false)(J$.R(185, 'error', error, false));
        } catch (J$e) {
            J$.Ex(233, J$e);
        } finally {
            if (J$.Sr(237))
                continue jalangiLabel1;
            else
                break jalangiLabel1;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=example1_jalangi_.js.map