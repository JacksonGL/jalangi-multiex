jalangiLabel1:
    while (true) {
        try {
            J$.Se(61, '../tests/multiex/split_jalangi_.js');
            J$.N(69, 'foo', J$.T(65, foo, 12), false);
            function foo(input) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(41, arguments.callee, this);
                            arguments = J$.N(45, 'arguments', arguments, true);
                            input = J$.N(49, 'input', input, true);
                            input = J$.W(17, 'input', J$.M(13, J$.R(5, 'input', input, false), 'split', false)(J$.T(9, 'e', 21)), input);
                            if (J$.C(4, J$.B(6, '>', J$.G(25, J$.R(21, 'input', input, false), 'length'), J$.T(29, 0, 22)))) {
                                J$.T(33, 1, 22);
                            } else {
                                J$.T(37, 2, 22);
                            }
                        } catch (J$e) {
                            J$.Ex(73, J$e);
                        } finally {
                            if (J$.Fr(77))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.F(57, J$.R(53, 'foo', foo, false), false)();
        } catch (J$e) {
            J$.Ex(81, J$e);
        } finally {
            if (J$.Sr(85))
                continue jalangiLabel1;
            else
                break jalangiLabel1;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=split_jalangi_.js.map