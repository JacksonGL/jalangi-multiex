jalangiLabel0:
    while (true) {
        try {
            J$.Se(33, '../tests/multiex/typeof_jalangi_.js');
            J$.N(37, 'input', input, false);
            var input = J$.W(13, 'input', J$.M(9, J$, 'readInput', false)(J$.T(5, true, 23)), input);
            if (J$.C(4, J$.B(10, '===', J$.U(6, 'typeof', J$.R(17, 'input', input, false)), J$.T(21, 'object', 21)))) {
                J$.T(25, 1, 22);
            } else {
                J$.T(29, 2, 22);
            }
        } catch (J$e) {
            J$.Ex(41, J$e);
        } finally {
            if (J$.Sr(45))
                continue jalangiLabel0;
            else
                break jalangiLabel0;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=typeof_jalangi_.js.map