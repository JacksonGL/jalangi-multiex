jalangiLabel21:
    while (true) {
        try {
            J$.Se(2061, '../tests/multiex/urem_jalangi_.js');
            J$.F(2057, J$.T(2053, function () {
                jalangiLabel20:
                    while (true) {
                        try {
                            J$.Fe(1925, arguments.callee, this);
                            arguments = J$.N(1929, 'arguments', arguments, true);
                            J$.N(1933, 'window', window, false);
                            J$.N(1937, 'geval', geval, false);
                            J$.N(1941, 'inbrowser', inbrowser, false);
                            J$.N(1945, 'inharness', inharness, false);
                            J$.N(1949, 'callpath', callpath, false);
                            J$.N(1953, 'JSBNG_Replay', JSBNG_Replay, false);
                            J$.N(1961, 'onload', J$.T(1957, onload, 12), false);
                            J$.N(1969, 'iframe', J$.T(1965, iframe, 12), false);
                            J$.N(1977, 'finalize', J$.T(1973, finalize, 12), false);
                            J$.N(1985, 'verify', J$.T(1981, verify, 12), false);
                            J$.N(1989, 'firstMessage', firstMessage, false);
                            J$.N(1997, 'replayMessage', J$.T(1993, replayMessage, 12), false);
                            J$.N(2005, 'verificationError', J$.T(2001, verificationError, 12), false);
                            J$.N(2013, 'verifySet', J$.T(2009, verifySet, 12), false);
                            J$.N(2021, 'verifyCall', J$.T(2017, verifyCall, 12), false);
                            J$.N(2029, 'verifyPath', J$.T(2025, verifyPath, 12), false);
                            J$.N(2033, 'defineGetter', defineGetter, false);
                            J$.N(2037, 'odp', odp, false);
                            J$.N(2041, 'opdg', opdg, false);
                            J$.N(2045, 'opds', opds, false);
                            J$.N(2049, 'fpc', fpc, false);
                            var window = J$.W(13, 'window', J$.M(9, J$, 'readInput', false)(J$.T(5, {}, 11)), window);
                            var geval = J$.W(17, 'geval', eval, geval);
                            var inbrowser = J$.W(25, 'inbrowser', J$.T(21, false, 23), inbrowser);
                            var inharness = J$.W(33, 'inharness', J$.T(29, false, 23), inharness);
                            if (J$.C(20, J$.C(4, J$.B(10, '!==', J$.U(6, 'typeof', J$.R(37, 'window', window, false)), J$.T(41, 'undefined', 21))) ? J$.B(14, 'in', J$.T(45, 'document', 21), J$.R(49, 'window', window, false)) : J$._())) {
                                inbrowser = J$.W(57, 'inbrowser', J$.T(53, true, 23), inbrowser);
                                if (J$.C(12, J$.C(8, J$.G(65, J$.R(61, 'window', window, false), 'parent')) ? J$.B(18, 'in', J$.T(69, 'JSBNG_handleResult', 21), J$.G(77, J$.R(73, 'window', window, false), 'parent')) : J$._())) {
                                    inharness = J$.W(85, 'inharness', J$.T(81, true, 23), inharness);
                                }
                            } else if (J$.C(16, J$.B(26, '!==', J$.U(22, 'typeof', J$.I(typeof global === 'undefined' ? global = J$.R(89, 'global', undefined, true) : global = J$.R(89, 'global', global, true))), J$.T(93, 'undefined', 21)))) {
                                window = J$.W(101, 'window', J$.I(typeof global === 'undefined' ? global = J$.R(97, 'global', undefined, true) : global = J$.R(97, 'global', global, true)), window);
                                J$.P(113, J$.R(105, 'window', window, false), 'top', J$.R(109, 'window', window, false));
                            } else {
                                window = J$.W(141, 'window', J$.F(137, J$.T(133, function () {
                                    jalangiLabel0:
                                        while (true) {
                                            try {
                                                J$.Fe(125, arguments.callee, this);
                                                arguments = J$.N(129, 'arguments', arguments, true);
                                                return J$.Rt(121, J$.R(117, 'this', this, false));
                                            } catch (J$e) {
                                                J$.Ex(2065, J$e);
                                            } finally {
                                                if (J$.Fr(2069))
                                                    continue jalangiLabel0;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12), false)(), window);
                                J$.P(153, J$.R(145, 'window', window, false), 'top', J$.R(149, 'window', window, false));
                            }
                            if (J$.C(24, J$.B(30, 'in', J$.T(157, 'console', 21), J$.R(161, 'window', window, false)))) {
                                J$.P(177, J$.R(165, 'window', window, false), 'JSBNG_Console', J$.G(173, J$.R(169, 'window', window, false), 'console'));
                            }
                            var callpath = J$.W(185, 'callpath', J$.T(181, [], 10), callpath);
                            var JSBNG_Replay = J$.W(273, 'JSBNG_Replay', J$.P(269, J$.G(193, J$.R(189, 'window', window, false), 'top'), 'JSBNG_Replay', J$.T(265, {
                                    push: J$.T(233, function (arr, fun) {
                                        jalangiLabel1:
                                            while (true) {
                                                try {
                                                    J$.Fe(217, arguments.callee, this);
                                                    arguments = J$.N(221, 'arguments', arguments, true);
                                                    arr = J$.N(225, 'arr', arr, true);
                                                    fun = J$.N(229, 'fun', fun, true);
                                                    J$.M(205, J$.R(197, 'arr', arr, false), 'push', false)(J$.R(201, 'fun', fun, false));
                                                    return J$.Rt(213, J$.R(209, 'fun', fun, false));
                                                } catch (J$e) {
                                                    J$.Ex(2073, J$e);
                                                } finally {
                                                    if (J$.Fr(2077))
                                                        continue jalangiLabel1;
                                                    else
                                                        return J$.Ra();
                                                }
                                            }
                                    }, 12),
                                    path: J$.T(261, function (str) {
                                        jalangiLabel2:
                                            while (true) {
                                                try {
                                                    J$.Fe(249, arguments.callee, this);
                                                    arguments = J$.N(253, 'arguments', arguments, true);
                                                    str = J$.N(257, 'str', str, true);
                                                    J$.F(245, J$.R(237, 'verifyPath', verifyPath, false), false)(J$.R(241, 'str', str, false));
                                                } catch (J$e) {
                                                    J$.Ex(2081, J$e);
                                                } finally {
                                                    if (J$.Fr(2085))
                                                        continue jalangiLabel2;
                                                    else
                                                        return J$.Ra();
                                                }
                                            }
                                    }, 12)
                                }, 11)), JSBNG_Replay);
                            function onload() {
                                jalangiLabel4:
                                    while (true) {
                                        try {
                                            J$.Fe(673, arguments.callee, this);
                                            arguments = J$.N(677, 'arguments', arguments, true);
                                            J$.N(681, 'jr', jr, false);
                                            J$.N(685, 'cb', cb, false);
                                            J$.N(689, 'st', st, false);
                                            try {
                                                delete J$.R(277, 'window', window, false).onload;
                                            } catch (ex) {
                                            }
                                            var jr = J$.W(285, 'jr', J$.I(typeof JSBNG_Replay$ === 'undefined' ? JSBNG_Replay$ = J$.R(281, 'JSBNG_Replay$', undefined, true) : JSBNG_Replay$ = J$.R(281, 'JSBNG_Replay$', JSBNG_Replay$, true)), jr);
                                            var cb = J$.W(609, 'cb', J$.T(605, function () {
                                                    jalangiLabel3:
                                                        while (true) {
                                                            try {
                                                                J$.Fe(585, arguments.callee, this);
                                                                arguments = J$.N(589, 'arguments', arguments, true);
                                                                J$.N(593, 'end', end, false);
                                                                J$.N(597, 'msg', msg, false);
                                                                J$.N(601, 'res', res, false);
                                                                var end = J$.W(305, 'end', J$.M(301, J$.T(297, J$.F(293, J$.I(typeof Date === 'undefined' ? Date = J$.R(289, 'Date', undefined, true) : Date = J$.R(289, 'Date', Date, true)), true)(), 11), 'getTime', false)(), end);
                                                                var msg = J$.W(325, 'msg', J$.B(42, '+', J$.B(38, '+', J$.T(309, 'Time: ', 21), J$.B(34, '-', J$.R(313, 'end', end, false), J$.R(317, 'st', st, false))), J$.T(321, 'ms', 21)), msg);
                                                                if (J$.C(40, J$.R(329, 'inharness', inharness, false))) {
                                                                    J$.M(357, J$.G(337, J$.R(333, 'window', window, false), 'parent'), 'JSBNG_handleResult', false)(J$.T(353, {
                                                                        error: J$.T(341, false, 23),
                                                                        time: J$.B(46, '-', J$.R(345, 'end', end, false), J$.R(349, 'st', st, false))
                                                                    }, 11));
                                                                } else if (J$.C(36, J$.R(361, 'inbrowser', inbrowser, false))) {
                                                                    var res = J$.W(377, 'res', J$.M(373, J$.I(typeof document === 'undefined' ? document = J$.R(365, 'document', undefined, true) : document = J$.R(365, 'document', document, true)), 'createElement', false)(J$.T(369, 'div', 21)), res);
                                                                    J$.P(393, J$.G(385, J$.R(381, 'res', res, false), 'style'), 'position', J$.T(389, 'fixed', 21));
                                                                    J$.P(409, J$.G(401, J$.R(397, 'res', res, false), 'style'), 'left', J$.T(405, '1em', 21));
                                                                    J$.P(425, J$.G(417, J$.R(413, 'res', res, false), 'style'), 'top', J$.T(421, '1em', 21));
                                                                    J$.P(441, J$.G(433, J$.R(429, 'res', res, false), 'style'), 'width', J$.T(437, '35em', 21));
                                                                    J$.P(457, J$.G(449, J$.R(445, 'res', res, false), 'style'), 'height', J$.T(453, '5em', 21));
                                                                    J$.P(473, J$.G(465, J$.R(461, 'res', res, false), 'style'), 'padding', J$.T(469, '1em', 21));
                                                                    J$.P(489, J$.G(481, J$.R(477, 'res', res, false), 'style'), 'backgroundColor', J$.T(485, 'white', 21));
                                                                    J$.P(505, J$.G(497, J$.R(493, 'res', res, false), 'style'), 'color', J$.T(501, 'black', 21));
                                                                    J$.M(525, J$.R(509, 'res', res, false), 'appendChild', false)(J$.M(521, J$.I(typeof document === 'undefined' ? document = J$.R(513, 'document', undefined, true) : document = J$.R(513, 'document', document, true)), 'createTextNode', false)(J$.R(517, 'msg', msg, false)));
                                                                    J$.M(541, J$.G(533, J$.I(typeof document === 'undefined' ? document = J$.R(529, 'document', undefined, true) : document = J$.R(529, 'document', document, true)), 'body'), 'appendChild', false)(J$.R(537, 'res', res, false));
                                                                } else if (J$.C(32, J$.B(54, '!==', J$.U(50, 'typeof', J$.I(typeof console === 'undefined' ? console = J$.R(545, 'console', undefined, true) : console = J$.R(545, 'console', console, true))), J$.T(549, 'undefined', 21)))) {
                                                                    J$.M(561, J$.I(typeof console === 'undefined' ? console = J$.R(553, 'console', undefined, true) : console = J$.R(553, 'console', console, true)), 'log', false)(J$.R(557, 'msg', msg, false));
                                                                } else if (J$.C(28, J$.B(62, '!==', J$.U(58, 'typeof', J$.I(typeof print === 'undefined' ? print = J$.R(565, 'print', undefined, true) : print = J$.R(565, 'print', print, true))), J$.T(569, 'undefined', 21)))) {
                                                                    J$.F(581, J$.I(typeof print === 'undefined' ? print = J$.R(573, 'print', undefined, true) : print = J$.R(573, 'print', print, true)), false)(J$.R(577, 'msg', msg, false));
                                                                }
                                                            } catch (J$e) {
                                                                J$.Ex(2089, J$e);
                                                            } finally {
                                                                if (J$.Fr(2093))
                                                                    continue jalangiLabel3;
                                                                else
                                                                    return J$.Ra();
                                                            }
                                                        }
                                                }, 12), cb);
                                            J$.F(621, J$.R(613, 'jr', jr, false), false)(J$.T(617, false, 23));
                                            var st = J$.W(641, 'st', J$.M(637, J$.T(633, J$.F(629, J$.I(typeof Date === 'undefined' ? Date = J$.R(625, 'Date', undefined, true) : Date = J$.R(625, 'Date', Date, true)), true)(), 11), 'getTime', false)(), st);
                                            while (J$.C(44, J$.B(66, '!==', J$.R(645, 'jr', jr, false), J$.T(649, null, 25)))) {
                                                jr = J$.W(669, 'jr', J$.F(665, J$.R(653, 'jr', jr, false), false)(J$.T(657, true, 23), J$.R(661, 'cb', cb, false)), jr);
                                            }
                                        } catch (J$e) {
                                            J$.Ex(2097, J$e);
                                        } finally {
                                            if (J$.Fr(2101))
                                                continue jalangiLabel4;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function iframe(pageid) {
                                jalangiLabel7:
                                    while (true) {
                                        try {
                                            J$.Fe(893, arguments.callee, this);
                                            arguments = J$.N(897, 'arguments', arguments, true);
                                            pageid = J$.N(901, 'pageid', pageid, true);
                                            J$.N(905, 'iw', iw, false);
                                            J$.N(909, 'iframe', iframe, false);
                                            J$.N(913, 'topwin', topwin, false);
                                            var iw;
                                            if (J$.C(48, J$.R(693, 'inbrowser', inbrowser, false))) {
                                                var iframe = J$.W(709, 'iframe', J$.M(705, J$.I(typeof document === 'undefined' ? document = J$.R(697, 'document', undefined, true) : document = J$.R(697, 'document', document, true)), 'createElement', false)(J$.T(701, 'iframe', 21)), iframe);
                                                J$.P(725, J$.G(717, J$.R(713, 'iframe', iframe, false), 'style'), 'display', J$.T(721, 'none', 21));
                                                J$.M(741, J$.G(733, J$.I(typeof document === 'undefined' ? document = J$.R(729, 'document', undefined, true) : document = J$.R(729, 'document', document, true)), 'body'), 'appendChild', false)(J$.R(737, 'iframe', iframe, false));
                                                iw = J$.W(753, 'iw', J$.G(749, J$.R(745, 'iframe', iframe, false), 'contentWindow'), iw);
                                                J$.M(769, J$.G(761, J$.R(757, 'iw', iw, false), 'document'), 'write', false)(J$.T(765, '<script type="text/javascript">Function.prototype.bind = null; var JSBNG_Replay_geval = eval;</script>', 21));
                                                J$.M(781, J$.G(777, J$.R(773, 'iw', iw, false), 'document'), 'close', false)();
                                            } else {
                                                var topwin = J$.W(789, 'topwin', J$.R(785, 'window', window, false), topwin);
                                                J$.F(881, J$.T(877, function () {
                                                    jalangiLabel6:
                                                        while (true) {
                                                            try {
                                                                J$.Fe(865, arguments.callee, this);
                                                                arguments = J$.N(869, 'arguments', arguments, true);
                                                                J$.N(873, 'window', window, false);
                                                                var window = J$.W(797, 'window', J$.T(793, {}, 11), window);
                                                                J$.P(809, J$.R(801, 'window', window, false), 'window', J$.R(805, 'window', window, false));
                                                                J$.P(821, J$.R(813, 'window', window, false), 'top', J$.R(817, 'topwin', topwin, false));
                                                                J$.P(853, J$.R(825, 'window', window, false), 'JSBNG_Replay_geval', J$.T(849, function (str) {
                                                                    jalangiLabel5:
                                                                        while (true) {
                                                                            try {
                                                                                J$.Fe(837, arguments.callee, this);
                                                                                arguments = J$.N(841, 'arguments', arguments, true);
                                                                                str = J$.N(845, 'str', str, true);
                                                                                eval(J$.instrumentCode(J$.getConcrete(J$.R(829, 'str', str, false)), { wrapProgram: false }, 833).code);
                                                                            } catch (J$e) {
                                                                                J$.Ex(2105, J$e);
                                                                            } finally {
                                                                                if (J$.Fr(2109))
                                                                                    continue jalangiLabel5;
                                                                                else
                                                                                    return J$.Ra();
                                                                            }
                                                                        }
                                                                }, 12));
                                                                iw = J$.W(861, 'iw', J$.R(857, 'window', window, false), iw);
                                                            } catch (J$e) {
                                                                J$.Ex(2113, J$e);
                                                            } finally {
                                                                if (J$.Fr(2117))
                                                                    continue jalangiLabel6;
                                                                else
                                                                    return J$.Ra();
                                                            }
                                                        }
                                                }, 12), false)();
                                            }
                                            return J$.Rt(889, J$.R(885, 'iw', iw, false));
                                        } catch (J$e) {
                                            J$.Ex(2121, J$e);
                                        } finally {
                                            if (J$.Fr(2125))
                                                continue jalangiLabel7;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function finalize() {
                                jalangiLabel8:
                                    while (true) {
                                        try {
                                            J$.Fe(945, arguments.callee, this);
                                            arguments = J$.N(949, 'arguments', arguments, true);
                                            if (J$.C(52, J$.R(917, 'inbrowser', inbrowser, false))) {
                                                J$.F(933, J$.I(typeof setTimeout === 'undefined' ? setTimeout = J$.R(921, 'setTimeout', undefined, true) : setTimeout = J$.R(921, 'setTimeout', setTimeout, true)), false)(J$.R(925, 'onload', onload, false), J$.T(929, 0, 22));
                                            } else {
                                                J$.F(941, J$.R(937, 'onload', onload, false), false)();
                                            }
                                        } catch (J$e) {
                                            J$.Ex(2129, J$e);
                                        } finally {
                                            if (J$.Fr(2133))
                                                continue jalangiLabel8;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function verify(rep, rec) {
                                jalangiLabel9:
                                    while (true) {
                                        try {
                                            J$.Fe(1021, arguments.callee, this);
                                            arguments = J$.N(1025, 'arguments', arguments, true);
                                            rep = J$.N(1029, 'rep', rep, true);
                                            rec = J$.N(1033, 'rec', rec, true);
                                            if (J$.C(76, J$.C(60, J$.B(70, '!==', J$.R(953, 'rec', rec, false), J$.R(957, 'rep', rep, false))) ? J$.C(56, J$.B(74, '===', J$.R(961, 'rep', rep, false), J$.R(965, 'rep', rep, false))) ? J$._() : J$.B(78, '===', J$.R(969, 'rec', rec, false), J$.R(973, 'rec', rec, false)) : J$._())) {
                                                if (J$.C(72, J$.C(68, J$.C(64, J$.B(86, '!==', J$.U(82, 'typeof', J$.R(977, 'rec', rec, false)), J$.T(981, 'object', 21))) ? J$._() : J$.B(90, '===', J$.R(985, 'rec', rec, false), J$.T(989, null, 25))) ? J$._() : J$.U(106, '!', J$.B(102, 'in', J$.B(98, '+', J$.T(993, '__JSBNG_unknown_', 21), J$.U(94, 'typeof', J$.R(997, 'rep', rep, false))), J$.R(1001, 'rec', rec, false))))) {
                                                    return J$.Rt(1009, J$.T(1005, false, 23));
                                                }
                                            }
                                            return J$.Rt(1017, J$.T(1013, true, 23));
                                        } catch (J$e) {
                                            J$.Ex(2137, J$e);
                                        } finally {
                                            if (J$.Fr(2141))
                                                continue jalangiLabel9;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            var firstMessage = J$.W(1041, 'firstMessage', J$.T(1037, true, 23), firstMessage);
                            function replayMessage(msg) {
                                jalangiLabel10:
                                    while (true) {
                                        try {
                                            J$.Fe(1093, arguments.callee, this);
                                            arguments = J$.N(1097, 'arguments', arguments, true);
                                            msg = J$.N(1101, 'msg', msg, true);
                                            if (J$.C(84, J$.R(1045, 'inbrowser', inbrowser, false))) {
                                                if (J$.C(80, J$.R(1049, 'firstMessage', firstMessage, false)))
                                                    J$.M(1057, J$.I(typeof document === 'undefined' ? document = J$.R(1053, 'document', undefined, true) : document = J$.R(1053, 'document', document, true)), 'open', false)();
                                                firstMessage = J$.W(1065, 'firstMessage', J$.T(1061, false, 23), firstMessage);
                                                J$.M(1077, J$.I(typeof document === 'undefined' ? document = J$.R(1069, 'document', undefined, true) : document = J$.R(1069, 'document', document, true)), 'write', false)(J$.R(1073, 'msg', msg, false));
                                            } else {
                                                J$.M(1089, J$.I(typeof console === 'undefined' ? console = J$.R(1081, 'console', undefined, true) : console = J$.R(1081, 'console', console, true)), 'log', false)(J$.R(1085, 'msg', msg, false));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(2145, J$e);
                                        } finally {
                                            if (J$.Fr(2149))
                                                continue jalangiLabel10;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function verificationError(msg) {
                                jalangiLabel11:
                                    while (true) {
                                        try {
                                            J$.Fe(1157, arguments.callee, this);
                                            arguments = J$.N(1161, 'arguments', arguments, true);
                                            msg = J$.N(1165, 'msg', msg, true);
                                            if (J$.C(88, J$.R(1105, 'inharness', inharness, false))) {
                                                J$.M(1129, J$.G(1113, J$.R(1109, 'window', window, false), 'parent'), 'JSBNG_handleResult', false)(J$.T(1125, {
                                                    error: J$.T(1117, true, 23),
                                                    msg: J$.R(1121, 'msg', msg, false)
                                                }, 11));
                                            } else
                                                J$.F(1141, J$.R(1133, 'replayMessage', replayMessage, false), false)(J$.R(1137, 'msg', msg, false));
                                            throw J$.T(1153, J$.F(1149, J$.I(typeof Error === 'undefined' ? Error = J$.R(1145, 'Error', undefined, true) : Error = J$.R(1145, 'Error', Error, true)), true)(), 11);
                                        } catch (J$e) {
                                            J$.Ex(2153, J$e);
                                        } finally {
                                            if (J$.Fr(2157))
                                                continue jalangiLabel11;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function verifySet(objstr, obj, prop, gvalstr, gval) {
                                jalangiLabel12:
                                    while (true) {
                                        try {
                                            J$.Fe(1277, arguments.callee, this);
                                            arguments = J$.N(1281, 'arguments', arguments, true);
                                            objstr = J$.N(1285, 'objstr', objstr, true);
                                            obj = J$.N(1289, 'obj', obj, true);
                                            prop = J$.N(1293, 'prop', prop, true);
                                            gvalstr = J$.N(1297, 'gvalstr', gvalstr, true);
                                            gval = J$.N(1301, 'gval', gval, true);
                                            J$.N(1305, 'bval', bval, false);
                                            J$.N(1309, 'msg', msg, false);
                                            if (J$.C(92, J$.M(1177, J$.T(1169, /^on/, 14), 'test', false)(J$.R(1173, 'prop', prop, false)))) {
                                                return J$.Rt(1181, undefined);
                                            }
                                            if (J$.C(96, J$.U(110, '!', J$.F(1205, J$.R(1185, 'verify', verify, false), false)(J$.G(1197, J$.R(1189, 'obj', obj, false), J$.R(1193, 'prop', prop, false)), J$.R(1201, 'gval', gval, false))))) {
                                                var bval = J$.W(1221, 'bval', J$.G(1217, J$.R(1209, 'obj', obj, false), J$.R(1213, 'prop', prop, false)), bval);
                                                var msg = J$.W(1261, 'msg', J$.B(142, '+', J$.B(138, '+', J$.B(134, '+', J$.B(130, '+', J$.B(126, '+', J$.B(122, '+', J$.B(118, '+', J$.B(114, '+', J$.T(1225, 'Verification failure! ', 21), J$.R(1229, 'objstr', objstr, false)), J$.T(1233, '.', 21)), J$.R(1237, 'prop', prop, false)), J$.T(1241, ' is not ', 21)), J$.R(1245, 'gvalstr', gvalstr, false)), J$.T(1249, ', it\'s ', 21)), J$.R(1253, 'bval', bval, false)), J$.T(1257, '!', 21)), msg);
                                                J$.F(1273, J$.R(1265, 'verificationError', verificationError, false), false)(J$.R(1269, 'msg', msg, false));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(2161, J$e);
                                        } finally {
                                            if (J$.Fr(2165))
                                                continue jalangiLabel12;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function verifyCall(iscall, func, cthis, cargs) {
                                jalangiLabel13:
                                    while (true) {
                                        try {
                                            J$.Fe(1545, arguments.callee, this);
                                            arguments = J$.N(1549, 'arguments', arguments, true);
                                            iscall = J$.N(1553, 'iscall', iscall, true);
                                            func = J$.N(1557, 'func', func, true);
                                            cthis = J$.N(1561, 'cthis', cthis, true);
                                            cargs = J$.N(1565, 'cargs', cargs, true);
                                            J$.N(1569, 'ok', ok, false);
                                            J$.N(1573, 'callArgs', callArgs, false);
                                            J$.N(1577, 'i', i, false);
                                            J$.N(1581, 'msg', msg, false);
                                            var ok = J$.W(1317, 'ok', J$.T(1313, true, 23), ok);
                                            var callArgs = J$.W(1341, 'callArgs', J$.G(1337, J$.G(1325, J$.R(1321, 'func', func, false), 'callArgs'), J$.G(1333, J$.R(1329, 'func', func, false), 'inst')), callArgs);
                                            iscall = J$.W(1357, 'iscall', J$.C(100, J$.R(1345, 'iscall', iscall, false)) ? J$.T(1349, 1, 22) : J$.T(1353, 0, 22), iscall);
                                            if (J$.C(120, J$.B(150, '!==', J$.G(1365, J$.R(1361, 'cargs', cargs, false), 'length'), J$.B(146, '-', J$.G(1373, J$.R(1369, 'callArgs', callArgs, false), 'length'), J$.T(1377, 1, 22))))) {
                                                ok = J$.W(1385, 'ok', J$.T(1381, false, 23), ok);
                                            } else {
                                                if (J$.C(108, J$.C(104, J$.R(1389, 'iscall', iscall, false)) ? J$.U(154, '!', J$.F(1413, J$.R(1393, 'verify', verify, false), false)(J$.R(1397, 'cthis', cthis, false), J$.G(1409, J$.R(1401, 'callArgs', callArgs, false), J$.T(1405, 0, 22)))) : J$._()))
                                                    ok = J$.W(1421, 'ok', J$.T(1417, false, 23), ok);
                                                for (var i = J$.W(1429, 'i', J$.T(1425, 0, 22), i); J$.C(116, J$.B(158, '<', J$.R(1433, 'i', i, false), J$.G(1441, J$.R(1437, 'cargs', cargs, false), 'length'))); J$.B(170, '-', i = J$.W(1449, 'i', J$.B(166, '+', J$.U(162, '+', J$.R(1445, 'i', i, false)), 1), i), 1)) {
                                                    if (J$.C(112, J$.U(178, '!', J$.F(1485, J$.R(1453, 'verify', verify, false), false)(J$.G(1465, J$.R(1457, 'cargs', cargs, false), J$.R(1461, 'i', i, false)), J$.G(1481, J$.R(1469, 'callArgs', callArgs, false), J$.B(174, '+', J$.R(1473, 'i', i, false), J$.T(1477, 1, 22)))))))
                                                        ok = J$.W(1493, 'ok', J$.T(1489, false, 23), ok);
                                                }
                                            }
                                            if (J$.C(124, J$.U(182, '!', J$.R(1497, 'ok', ok, false)))) {
                                                var msg = J$.W(1505, 'msg', J$.T(1501, 'Call verification failure!', 21), msg);
                                                J$.F(1517, J$.R(1509, 'verificationError', verificationError, false), false)(J$.R(1513, 'msg', msg, false));
                                            }
                                            return J$.Rt(1541, J$.G(1537, J$.G(1525, J$.R(1521, 'func', func, false), 'returns'), J$.B(186, '-', J$.A(1533, J$.R(1529, 'func', func, false), 'inst', '+')(1), 1)));
                                        } catch (J$e) {
                                            J$.Ex(2169, J$e);
                                        } finally {
                                            if (J$.Fr(2173))
                                                continue jalangiLabel13;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function verifyPath(func) {
                                jalangiLabel14:
                                    while (true) {
                                        try {
                                            J$.Fe(1637, arguments.callee, this);
                                            arguments = J$.N(1641, 'arguments', arguments, true);
                                            func = J$.N(1645, 'func', func, true);
                                            J$.N(1649, 'real', real, false);
                                            J$.N(1653, 'msg', msg, false);
                                            var real = J$.W(1593, 'real', J$.M(1589, J$.R(1585, 'callpath', callpath, false), 'shift', false)(), real);
                                            if (J$.C(128, J$.B(190, '!==', J$.R(1597, 'real', real, false), J$.R(1601, 'func', func, false)))) {
                                                var msg = J$.W(1621, 'msg', J$.B(202, '+', J$.B(198, '+', J$.B(194, '+', J$.T(1605, 'Call path verification failure! Expected ', 21), J$.R(1609, 'real', real, false)), J$.T(1613, ', found ', 21)), J$.R(1617, 'func', func, false)), msg);
                                                J$.F(1633, J$.R(1625, 'verificationError', verificationError, false), false)(J$.R(1629, 'msg', msg, false));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(2177, J$e);
                                        } finally {
                                            if (J$.Fr(2181))
                                                continue jalangiLabel14;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            var defineGetter;
                            if (J$.C(136, J$.G(1661, J$.I(typeof Object === 'undefined' ? Object = J$.R(1657, 'Object', undefined, true) : Object = J$.R(1657, 'Object', Object, true)), 'defineProperty'))) {
                                var odp = J$.W(1673, 'odp', J$.G(1669, J$.I(typeof Object === 'undefined' ? Object = J$.R(1665, 'Object', undefined, true) : Object = J$.R(1665, 'Object', Object, true)), 'defineProperty'), odp);
                                defineGetter = J$.W(1741, 'defineGetter', J$.T(1737, function (obj, prop, getter) {
                                    jalangiLabel16:
                                        while (true) {
                                            try {
                                                J$.Fe(1717, arguments.callee, this);
                                                arguments = J$.N(1721, 'arguments', arguments, true);
                                                obj = J$.N(1725, 'obj', obj, true);
                                                prop = J$.N(1729, 'prop', prop, true);
                                                getter = J$.N(1733, 'getter', getter, true);
                                                J$.F(1713, J$.R(1677, 'odp', odp, false), false)(J$.R(1681, 'obj', obj, false), J$.R(1685, 'prop', prop, false), J$.T(1709, {
                                                    'enumerable': J$.T(1689, true, 23),
                                                    'get': J$.R(1693, 'getter', getter, false),
                                                    'set': J$.T(1705, function () {
                                                        jalangiLabel15:
                                                            while (true) {
                                                                try {
                                                                    J$.Fe(1697, arguments.callee, this);
                                                                    arguments = J$.N(1701, 'arguments', arguments, true);
                                                                } catch (J$e) {
                                                                    J$.Ex(2185, J$e);
                                                                } finally {
                                                                    if (J$.Fr(2189))
                                                                        continue jalangiLabel15;
                                                                    else
                                                                        return J$.Ra();
                                                                }
                                                            }
                                                    }, 12)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(2193, J$e);
                                            } finally {
                                                if (J$.Fr(2197))
                                                    continue jalangiLabel16;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12), defineGetter);
                            } else if (J$.C(132, J$.G(1753, J$.G(1749, J$.I(typeof Object === 'undefined' ? Object = J$.R(1745, 'Object', undefined, true) : Object = J$.R(1745, 'Object', Object, true)), 'prototype'), '__defineGetter__'))) {
                                var opdg = J$.W(1769, 'opdg', J$.G(1765, J$.G(1761, J$.I(typeof Object === 'undefined' ? Object = J$.R(1757, 'Object', undefined, true) : Object = J$.R(1757, 'Object', Object, true)), 'prototype'), '__defineGetter__'), opdg);
                                var opds = J$.W(1785, 'opds', J$.G(1781, J$.G(1777, J$.I(typeof Object === 'undefined' ? Object = J$.R(1773, 'Object', undefined, true) : Object = J$.R(1773, 'Object', Object, true)), 'prototype'), '__defineSetter__'), opds);
                                defineGetter = J$.W(1861, 'defineGetter', J$.T(1857, function (obj, prop, getter) {
                                    jalangiLabel18:
                                        while (true) {
                                            try {
                                                J$.Fe(1837, arguments.callee, this);
                                                arguments = J$.N(1841, 'arguments', arguments, true);
                                                obj = J$.N(1845, 'obj', obj, true);
                                                prop = J$.N(1849, 'prop', prop, true);
                                                getter = J$.N(1853, 'getter', getter, true);
                                                J$.M(1805, J$.R(1789, 'opdg', opdg, false), 'call', false)(J$.R(1793, 'obj', obj, false), J$.R(1797, 'prop', prop, false), J$.R(1801, 'getter', getter, false));
                                                J$.M(1833, J$.R(1809, 'opds', opds, false), 'call', false)(J$.R(1813, 'obj', obj, false), J$.R(1817, 'prop', prop, false), J$.T(1829, function () {
                                                    jalangiLabel17:
                                                        while (true) {
                                                            try {
                                                                J$.Fe(1821, arguments.callee, this);
                                                                arguments = J$.N(1825, 'arguments', arguments, true);
                                                            } catch (J$e) {
                                                                J$.Ex(2201, J$e);
                                                            } finally {
                                                                if (J$.Fr(2205))
                                                                    continue jalangiLabel17;
                                                                else
                                                                    return J$.Ra();
                                                            }
                                                        }
                                                }, 12));
                                            } catch (J$e) {
                                                J$.Ex(2209, J$e);
                                            } finally {
                                                if (J$.Fr(2213))
                                                    continue jalangiLabel18;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12), defineGetter);
                            } else {
                                defineGetter = J$.W(1889, 'defineGetter', J$.T(1885, function () {
                                    jalangiLabel19:
                                        while (true) {
                                            try {
                                                J$.Fe(1877, arguments.callee, this);
                                                arguments = J$.N(1881, 'arguments', arguments, true);
                                                J$.F(1873, J$.R(1865, 'verificationError', verificationError, false), false)(J$.T(1869, 'This replay requires getters for correct behavior, and your JS engine appears to be incapable of defining getters. Sorry!', 21));
                                            } catch (J$e) {
                                                J$.Ex(2217, J$e);
                                            } finally {
                                                if (J$.Fr(2221))
                                                    continue jalangiLabel19;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12), defineGetter);
                            }
                            var fpc = J$.W(1905, 'fpc', J$.G(1901, J$.G(1897, J$.I(typeof Function === 'undefined' ? Function = J$.R(1893, 'Function', undefined, true) : Function = J$.R(1893, 'Function', Function, true)), 'prototype'), 'call'), fpc);
                            J$.F(1913, J$.R(1909, 'onload', onload, false), false)();
                            J$.F(1921, J$.R(1917, 'finalize', finalize, false), false)();
                        } catch (J$e) {
                            J$.Ex(2225, J$e);
                        } finally {
                            if (J$.Fr(2229))
                                continue jalangiLabel20;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12), false)();
        } catch (J$e) {
            J$.Ex(2233, J$e);
        } finally {
            if (J$.Sr(2237))
                continue jalangiLabel21;
            else
                break jalangiLabel21;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=urem_jalangi_.js.map