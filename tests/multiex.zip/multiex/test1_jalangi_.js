jalangiLabel1:
    while (true) {
        try {
            J$.Se(61, '../tests/multiex/test1_jalangi_.js');
            J$.N(69, 'foo', J$.T(65, foo, 12), false);
            function foo(x) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(37, arguments.callee, this);
                            arguments = J$.N(41, 'arguments', arguments, true);
                            x = J$.N(45, 'x', x, true);
                            J$.N(49, 'r', r, false);
                            var r = J$.W(9, 'r', J$.T(5, 9.1, 22), r);
                            if (J$.C(4, J$.B(6, '>', J$.R(13, 'x', x, false), J$.T(17, 100.01, 22)))) {
                                r = J$.W(25, 'r', J$.T(21, 0.3, 22), r);
                            } else {
                                r = J$.W(33, 'r', J$.T(29, 1, 22), r);
                            }
                        } catch (J$e) {
                            J$.Ex(73, J$e);
                        } finally {
                            if (J$.Fr(77))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.F(57, J$.R(53, 'foo', foo, false), false)();
        } catch (J$e) {
            J$.Ex(81, J$e);
        } finally {
            if (J$.Sr(85))
                continue jalangiLabel1;
            else
                break jalangiLabel1;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=test1_jalangi_.js.map