jalangiLabel153:
    while (true) {
        try {
            J$.Se(28885, '../tests/multiex/esprima_jalangi_.js');
            J$.N(28889, 'esprima', esprima, false);
            J$.N(28893, 'code', code, false);
            J$.N(28897, 'result', result, false);
            var esprima = J$.W(9, 'esprima', J$.T(5, {}, 11), esprima);
            J$.F(28837, J$.T(45, function (root, factory) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(29, arguments.callee, this);
                            arguments = J$.N(33, 'arguments', arguments, true);
                            root = J$.N(37, 'root', root, true);
                            factory = J$.N(41, 'factory', factory, true);
                            J$.T(13, 'use strict', 21);
                            J$.F(25, J$.R(17, 'factory', factory, false), false)(J$.R(21, 'esprima', esprima, false));
                        } catch (J$e) {
                            J$.Ex(28901, J$e);
                        } finally {
                            if (J$.Fr(28905))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12), false)(J$.R(49, 'this', this, false), J$.T(28833, function (exports) {
                jalangiLabel152:
                    while (true) {
                        try {
                            J$.Fe(27925, arguments.callee, this);
                            arguments = J$.N(27929, 'arguments', arguments, true);
                            exports = J$.N(27933, 'exports', exports, true);
                            J$.N(27937, 'Token', Token, false);
                            J$.N(27941, 'TokenName', TokenName, false);
                            J$.N(27945, 'FnExprTokens', FnExprTokens, false);
                            J$.N(27949, 'Syntax', Syntax, false);
                            J$.N(27953, 'PropertyKind', PropertyKind, false);
                            J$.N(27957, 'Messages', Messages, false);
                            J$.N(27961, 'Regex', Regex, false);
                            J$.N(27965, 'SyntaxTreeDelegate', SyntaxTreeDelegate, false);
                            J$.N(27969, 'source', source, false);
                            J$.N(27973, 'strict', strict, false);
                            J$.N(27977, 'index', index, false);
                            J$.N(27981, 'lineNumber', lineNumber, false);
                            J$.N(27985, 'lineStart', lineStart, false);
                            J$.N(27989, 'length', length, false);
                            J$.N(27993, 'delegate', delegate, false);
                            J$.N(27997, 'lookahead', lookahead, false);
                            J$.N(28001, 'state', state, false);
                            J$.N(28005, 'extra', extra, false);
                            J$.N(28013, 'assert', J$.T(28009, assert, 12), false);
                            J$.N(28021, 'isDecimalDigit', J$.T(28017, isDecimalDigit, 12), false);
                            J$.N(28029, 'isHexDigit', J$.T(28025, isHexDigit, 12), false);
                            J$.N(28037, 'isOctalDigit', J$.T(28033, isOctalDigit, 12), false);
                            J$.N(28045, 'isWhiteSpace', J$.T(28041, isWhiteSpace, 12), false);
                            J$.N(28053, 'isLineTerminator', J$.T(28049, isLineTerminator, 12), false);
                            J$.N(28061, 'isIdentifierStart', J$.T(28057, isIdentifierStart, 12), false);
                            J$.N(28069, 'isIdentifierPart', J$.T(28065, isIdentifierPart, 12), false);
                            J$.N(28077, 'isFutureReservedWord', J$.T(28073, isFutureReservedWord, 12), false);
                            J$.N(28085, 'isStrictModeReservedWord', J$.T(28081, isStrictModeReservedWord, 12), false);
                            J$.N(28093, 'isRestrictedWord', J$.T(28089, isRestrictedWord, 12), false);
                            J$.N(28101, 'isKeyword', J$.T(28097, isKeyword, 12), false);
                            J$.N(28109, 'addComment', J$.T(28105, addComment, 12), false);
                            J$.N(28117, 'skipSingleLineComment', J$.T(28113, skipSingleLineComment, 12), false);
                            J$.N(28125, 'skipMultiLineComment', J$.T(28121, skipMultiLineComment, 12), false);
                            J$.N(28133, 'skipComment', J$.T(28129, skipComment, 12), false);
                            J$.N(28141, 'scanHexEscape', J$.T(28137, scanHexEscape, 12), false);
                            J$.N(28149, 'getEscapedIdentifier', J$.T(28145, getEscapedIdentifier, 12), false);
                            J$.N(28157, 'getIdentifier', J$.T(28153, getIdentifier, 12), false);
                            J$.N(28165, 'scanIdentifier', J$.T(28161, scanIdentifier, 12), false);
                            J$.N(28173, 'scanPunctuator', J$.T(28169, scanPunctuator, 12), false);
                            J$.N(28181, 'scanHexLiteral', J$.T(28177, scanHexLiteral, 12), false);
                            J$.N(28189, 'scanOctalLiteral', J$.T(28185, scanOctalLiteral, 12), false);
                            J$.N(28197, 'scanNumericLiteral', J$.T(28193, scanNumericLiteral, 12), false);
                            J$.N(28205, 'scanStringLiteral', J$.T(28201, scanStringLiteral, 12), false);
                            J$.N(28213, 'scanRegExp', J$.T(28209, scanRegExp, 12), false);
                            J$.N(28221, 'collectRegex', J$.T(28217, collectRegex, 12), false);
                            J$.N(28229, 'isIdentifierName', J$.T(28225, isIdentifierName, 12), false);
                            J$.N(28237, 'advanceSlash', J$.T(28233, advanceSlash, 12), false);
                            J$.N(28245, 'advance', J$.T(28241, advance, 12), false);
                            J$.N(28253, 'collectToken', J$.T(28249, collectToken, 12), false);
                            J$.N(28261, 'lex', J$.T(28257, lex, 12), false);
                            J$.N(28269, 'peek', J$.T(28265, peek, 12), false);
                            J$.N(28277, 'peekLineTerminator', J$.T(28273, peekLineTerminator, 12), false);
                            J$.N(28285, 'throwError', J$.T(28281, throwError, 12), false);
                            J$.N(28293, 'throwErrorTolerant', J$.T(28289, throwErrorTolerant, 12), false);
                            J$.N(28301, 'throwUnexpected', J$.T(28297, throwUnexpected, 12), false);
                            J$.N(28309, 'expect', J$.T(28305, expect, 12), false);
                            J$.N(28317, 'expectKeyword', J$.T(28313, expectKeyword, 12), false);
                            J$.N(28325, 'match', J$.T(28321, match, 12), false);
                            J$.N(28333, 'matchKeyword', J$.T(28329, matchKeyword, 12), false);
                            J$.N(28341, 'matchAssign', J$.T(28337, matchAssign, 12), false);
                            J$.N(28349, 'consumeSemicolon', J$.T(28345, consumeSemicolon, 12), false);
                            J$.N(28357, 'isLeftHandSide', J$.T(28353, isLeftHandSide, 12), false);
                            J$.N(28365, 'parseArrayInitialiser', J$.T(28361, parseArrayInitialiser, 12), false);
                            J$.N(28373, 'parsePropertyFunction', J$.T(28369, parsePropertyFunction, 12), false);
                            J$.N(28381, 'parseObjectPropertyKey', J$.T(28377, parseObjectPropertyKey, 12), false);
                            J$.N(28389, 'parseObjectProperty', J$.T(28385, parseObjectProperty, 12), false);
                            J$.N(28397, 'parseObjectInitialiser', J$.T(28393, parseObjectInitialiser, 12), false);
                            J$.N(28405, 'parseGroupExpression', J$.T(28401, parseGroupExpression, 12), false);
                            J$.N(28413, 'parsePrimaryExpression', J$.T(28409, parsePrimaryExpression, 12), false);
                            J$.N(28421, 'parseArguments', J$.T(28417, parseArguments, 12), false);
                            J$.N(28429, 'parseNonComputedProperty', J$.T(28425, parseNonComputedProperty, 12), false);
                            J$.N(28437, 'parseNonComputedMember', J$.T(28433, parseNonComputedMember, 12), false);
                            J$.N(28445, 'parseComputedMember', J$.T(28441, parseComputedMember, 12), false);
                            J$.N(28453, 'parseNewExpression', J$.T(28449, parseNewExpression, 12), false);
                            J$.N(28461, 'parseLeftHandSideExpressionAllowCall', J$.T(28457, parseLeftHandSideExpressionAllowCall, 12), false);
                            J$.N(28469, 'parseLeftHandSideExpression', J$.T(28465, parseLeftHandSideExpression, 12), false);
                            J$.N(28477, 'parsePostfixExpression', J$.T(28473, parsePostfixExpression, 12), false);
                            J$.N(28485, 'parseUnaryExpression', J$.T(28481, parseUnaryExpression, 12), false);
                            J$.N(28493, 'binaryPrecedence', J$.T(28489, binaryPrecedence, 12), false);
                            J$.N(28501, 'parseBinaryExpression', J$.T(28497, parseBinaryExpression, 12), false);
                            J$.N(28509, 'parseConditionalExpression', J$.T(28505, parseConditionalExpression, 12), false);
                            J$.N(28517, 'parseAssignmentExpression', J$.T(28513, parseAssignmentExpression, 12), false);
                            J$.N(28525, 'parseExpression', J$.T(28521, parseExpression, 12), false);
                            J$.N(28533, 'parseStatementList', J$.T(28529, parseStatementList, 12), false);
                            J$.N(28541, 'parseBlock', J$.T(28537, parseBlock, 12), false);
                            J$.N(28549, 'parseVariableIdentifier', J$.T(28545, parseVariableIdentifier, 12), false);
                            J$.N(28557, 'parseVariableDeclaration', J$.T(28553, parseVariableDeclaration, 12), false);
                            J$.N(28565, 'parseVariableDeclarationList', J$.T(28561, parseVariableDeclarationList, 12), false);
                            J$.N(28573, 'parseVariableStatement', J$.T(28569, parseVariableStatement, 12), false);
                            J$.N(28581, 'parseConstLetDeclaration', J$.T(28577, parseConstLetDeclaration, 12), false);
                            J$.N(28589, 'parseEmptyStatement', J$.T(28585, parseEmptyStatement, 12), false);
                            J$.N(28597, 'parseExpressionStatement', J$.T(28593, parseExpressionStatement, 12), false);
                            J$.N(28605, 'parseIfStatement', J$.T(28601, parseIfStatement, 12), false);
                            J$.N(28613, 'parseDoWhileStatement', J$.T(28609, parseDoWhileStatement, 12), false);
                            J$.N(28621, 'parseWhileStatement', J$.T(28617, parseWhileStatement, 12), false);
                            J$.N(28629, 'parseForVariableDeclaration', J$.T(28625, parseForVariableDeclaration, 12), false);
                            J$.N(28637, 'parseForStatement', J$.T(28633, parseForStatement, 12), false);
                            J$.N(28645, 'parseContinueStatement', J$.T(28641, parseContinueStatement, 12), false);
                            J$.N(28653, 'parseBreakStatement', J$.T(28649, parseBreakStatement, 12), false);
                            J$.N(28661, 'parseReturnStatement', J$.T(28657, parseReturnStatement, 12), false);
                            J$.N(28669, 'parseWithStatement', J$.T(28665, parseWithStatement, 12), false);
                            J$.N(28677, 'parseSwitchCase', J$.T(28673, parseSwitchCase, 12), false);
                            J$.N(28685, 'parseSwitchStatement', J$.T(28681, parseSwitchStatement, 12), false);
                            J$.N(28693, 'parseThrowStatement', J$.T(28689, parseThrowStatement, 12), false);
                            J$.N(28701, 'parseCatchClause', J$.T(28697, parseCatchClause, 12), false);
                            J$.N(28709, 'parseTryStatement', J$.T(28705, parseTryStatement, 12), false);
                            J$.N(28717, 'parseDebuggerStatement', J$.T(28713, parseDebuggerStatement, 12), false);
                            J$.N(28725, 'parseStatement', J$.T(28721, parseStatement, 12), false);
                            J$.N(28733, 'parseFunctionSourceElements', J$.T(28729, parseFunctionSourceElements, 12), false);
                            J$.N(28741, 'parseParams', J$.T(28737, parseParams, 12), false);
                            J$.N(28749, 'parseFunctionDeclaration', J$.T(28745, parseFunctionDeclaration, 12), false);
                            J$.N(28757, 'parseFunctionExpression', J$.T(28753, parseFunctionExpression, 12), false);
                            J$.N(28765, 'parseSourceElement', J$.T(28761, parseSourceElement, 12), false);
                            J$.N(28773, 'parseSourceElements', J$.T(28769, parseSourceElements, 12), false);
                            J$.N(28781, 'parseProgram', J$.T(28777, parseProgram, 12), false);
                            J$.N(28789, 'attachComments', J$.T(28785, attachComments, 12), false);
                            J$.N(28797, 'filterTokenLocation', J$.T(28793, filterTokenLocation, 12), false);
                            J$.N(28805, 'LocationMarker', J$.T(28801, LocationMarker, 12), false);
                            J$.N(28813, 'createLocationMarker', J$.T(28809, createLocationMarker, 12), false);
                            J$.N(28821, 'tokenize', J$.T(28817, tokenize, 12), false);
                            J$.N(28829, 'parse', J$.T(28825, parse, 12), false);
                            J$.T(53, 'use strict', 21);
                            var Token, TokenName, FnExprTokens, Syntax, PropertyKind, Messages, Regex, SyntaxTreeDelegate, source, strict, index, lineNumber, lineStart, length, delegate, lookahead, state, extra;
                            Token = J$.W(97, 'Token', J$.T(93, {
                                BooleanLiteral: J$.T(57, 1, 22),
                                EOF: J$.T(61, 2, 22),
                                Identifier: J$.T(65, 3, 22),
                                Keyword: J$.T(69, 4, 22),
                                NullLiteral: J$.T(73, 5, 22),
                                NumericLiteral: J$.T(77, 6, 22),
                                Punctuator: J$.T(81, 7, 22),
                                StringLiteral: J$.T(85, 8, 22),
                                RegularExpression: J$.T(89, 9, 22)
                            }, 11), Token);
                            TokenName = J$.W(105, 'TokenName', J$.T(101, {}, 11), TokenName);
                            J$.P(125, J$.R(109, 'TokenName', TokenName, false), J$.G(117, J$.R(113, 'Token', Token, false), 'BooleanLiteral'), J$.T(121, 'Boolean', 21));
                            J$.P(145, J$.R(129, 'TokenName', TokenName, false), J$.G(137, J$.R(133, 'Token', Token, false), 'EOF'), J$.T(141, '<end>', 21));
                            J$.P(165, J$.R(149, 'TokenName', TokenName, false), J$.G(157, J$.R(153, 'Token', Token, false), 'Identifier'), J$.T(161, 'Identifier', 21));
                            J$.P(185, J$.R(169, 'TokenName', TokenName, false), J$.G(177, J$.R(173, 'Token', Token, false), 'Keyword'), J$.T(181, 'Keyword', 21));
                            J$.P(205, J$.R(189, 'TokenName', TokenName, false), J$.G(197, J$.R(193, 'Token', Token, false), 'NullLiteral'), J$.T(201, 'Null', 21));
                            J$.P(225, J$.R(209, 'TokenName', TokenName, false), J$.G(217, J$.R(213, 'Token', Token, false), 'NumericLiteral'), J$.T(221, 'Numeric', 21));
                            J$.P(245, J$.R(229, 'TokenName', TokenName, false), J$.G(237, J$.R(233, 'Token', Token, false), 'Punctuator'), J$.T(241, 'Punctuator', 21));
                            J$.P(265, J$.R(249, 'TokenName', TokenName, false), J$.G(257, J$.R(253, 'Token', Token, false), 'StringLiteral'), J$.T(261, 'String', 21));
                            J$.P(285, J$.R(269, 'TokenName', TokenName, false), J$.G(277, J$.R(273, 'Token', Token, false), 'RegularExpression'), J$.T(281, 'RegularExpression', 21));
                            FnExprTokens = J$.W(501, 'FnExprTokens', J$.T(497, [
                                J$.T(289, '(', 21),
                                J$.T(293, '{', 21),
                                J$.T(297, '[', 21),
                                J$.T(301, 'in', 21),
                                J$.T(305, 'typeof', 21),
                                J$.T(309, 'instanceof', 21),
                                J$.T(313, 'new', 21),
                                J$.T(317, 'return', 21),
                                J$.T(321, 'case', 21),
                                J$.T(325, 'delete', 21),
                                J$.T(329, 'throw', 21),
                                J$.T(333, 'void', 21),
                                J$.T(337, '=', 21),
                                J$.T(341, '+=', 21),
                                J$.T(345, '-=', 21),
                                J$.T(349, '*=', 21),
                                J$.T(353, '/=', 21),
                                J$.T(357, '%=', 21),
                                J$.T(361, '<<=', 21),
                                J$.T(365, '>>=', 21),
                                J$.T(369, '>>>=', 21),
                                J$.T(373, '&=', 21),
                                J$.T(377, '|=', 21),
                                J$.T(381, '^=', 21),
                                J$.T(385, ',', 21),
                                J$.T(389, '+', 21),
                                J$.T(393, '-', 21),
                                J$.T(397, '*', 21),
                                J$.T(401, '/', 21),
                                J$.T(405, '%', 21),
                                J$.T(409, '++', 21),
                                J$.T(413, '--', 21),
                                J$.T(417, '<<', 21),
                                J$.T(421, '>>', 21),
                                J$.T(425, '>>>', 21),
                                J$.T(429, '&', 21),
                                J$.T(433, '|', 21),
                                J$.T(437, '^', 21),
                                J$.T(441, '!', 21),
                                J$.T(445, '~', 21),
                                J$.T(449, '&&', 21),
                                J$.T(453, '||', 21),
                                J$.T(457, '?', 21),
                                J$.T(461, ':', 21),
                                J$.T(465, '===', 21),
                                J$.T(469, '==', 21),
                                J$.T(473, '>=', 21),
                                J$.T(477, '<=', 21),
                                J$.T(481, '<', 21),
                                J$.T(485, '>', 21),
                                J$.T(489, '!=', 21),
                                J$.T(493, '!==', 21)
                            ], 10), FnExprTokens);
                            Syntax = J$.W(669, 'Syntax', J$.T(665, {
                                AssignmentExpression: J$.T(505, 'AssignmentExpression', 21),
                                ArrayExpression: J$.T(509, 'ArrayExpression', 21),
                                BlockStatement: J$.T(513, 'BlockStatement', 21),
                                BinaryExpression: J$.T(517, 'BinaryExpression', 21),
                                BreakStatement: J$.T(521, 'BreakStatement', 21),
                                CallExpression: J$.T(525, 'CallExpression', 21),
                                CatchClause: J$.T(529, 'CatchClause', 21),
                                ConditionalExpression: J$.T(533, 'ConditionalExpression', 21),
                                ContinueStatement: J$.T(537, 'ContinueStatement', 21),
                                DoWhileStatement: J$.T(541, 'DoWhileStatement', 21),
                                DebuggerStatement: J$.T(545, 'DebuggerStatement', 21),
                                EmptyStatement: J$.T(549, 'EmptyStatement', 21),
                                ExpressionStatement: J$.T(553, 'ExpressionStatement', 21),
                                ForStatement: J$.T(557, 'ForStatement', 21),
                                ForInStatement: J$.T(561, 'ForInStatement', 21),
                                FunctionDeclaration: J$.T(565, 'FunctionDeclaration', 21),
                                FunctionExpression: J$.T(569, 'FunctionExpression', 21),
                                Identifier: J$.T(573, 'Identifier', 21),
                                IfStatement: J$.T(577, 'IfStatement', 21),
                                Literal: J$.T(581, 'Literal', 21),
                                LabeledStatement: J$.T(585, 'LabeledStatement', 21),
                                LogicalExpression: J$.T(589, 'LogicalExpression', 21),
                                MemberExpression: J$.T(593, 'MemberExpression', 21),
                                NewExpression: J$.T(597, 'NewExpression', 21),
                                ObjectExpression: J$.T(601, 'ObjectExpression', 21),
                                Program: J$.T(605, 'Program', 21),
                                Property: J$.T(609, 'Property', 21),
                                ReturnStatement: J$.T(613, 'ReturnStatement', 21),
                                SequenceExpression: J$.T(617, 'SequenceExpression', 21),
                                SwitchStatement: J$.T(621, 'SwitchStatement', 21),
                                SwitchCase: J$.T(625, 'SwitchCase', 21),
                                ThisExpression: J$.T(629, 'ThisExpression', 21),
                                ThrowStatement: J$.T(633, 'ThrowStatement', 21),
                                TryStatement: J$.T(637, 'TryStatement', 21),
                                UnaryExpression: J$.T(641, 'UnaryExpression', 21),
                                UpdateExpression: J$.T(645, 'UpdateExpression', 21),
                                VariableDeclaration: J$.T(649, 'VariableDeclaration', 21),
                                VariableDeclarator: J$.T(653, 'VariableDeclarator', 21),
                                WhileStatement: J$.T(657, 'WhileStatement', 21),
                                WithStatement: J$.T(661, 'WithStatement', 21)
                            }, 11), Syntax);
                            PropertyKind = J$.W(689, 'PropertyKind', J$.T(685, {
                                Data: J$.T(673, 1, 22),
                                Get: J$.T(677, 2, 22),
                                Set: J$.T(681, 4, 22)
                            }, 11), PropertyKind);
                            Messages = J$.W(829, 'Messages', J$.T(825, {
                                UnexpectedToken: J$.T(693, 'Unexpected token %0', 21),
                                UnexpectedNumber: J$.T(697, 'Unexpected number', 21),
                                UnexpectedString: J$.T(701, 'Unexpected string', 21),
                                UnexpectedIdentifier: J$.T(705, 'Unexpected identifier', 21),
                                UnexpectedReserved: J$.T(709, 'Unexpected reserved word', 21),
                                UnexpectedEOS: J$.T(713, 'Unexpected end of input', 21),
                                NewlineAfterThrow: J$.T(717, 'Illegal newline after throw', 21),
                                InvalidRegExp: J$.T(721, 'Invalid regular expression', 21),
                                UnterminatedRegExp: J$.T(725, 'Invalid regular expression: missing /', 21),
                                InvalidLHSInAssignment: J$.T(729, 'Invalid left-hand side in assignment', 21),
                                InvalidLHSInForIn: J$.T(733, 'Invalid left-hand side in for-in', 21),
                                MultipleDefaultsInSwitch: J$.T(737, 'More than one default clause in switch statement', 21),
                                NoCatchOrFinally: J$.T(741, 'Missing catch or finally after try', 21),
                                UnknownLabel: J$.T(745, 'Undefined label \'%0\'', 21),
                                Redeclaration: J$.T(749, '%0 \'%1\' has already been declared', 21),
                                IllegalContinue: J$.T(753, 'Illegal continue statement', 21),
                                IllegalBreak: J$.T(757, 'Illegal break statement', 21),
                                IllegalReturn: J$.T(761, 'Illegal return statement', 21),
                                StrictModeWith: J$.T(765, 'Strict mode code may not include a with statement', 21),
                                StrictCatchVariable: J$.T(769, 'Catch variable may not be eval or arguments in strict mode', 21),
                                StrictVarName: J$.T(773, 'Variable name may not be eval or arguments in strict mode', 21),
                                StrictParamName: J$.T(777, 'Parameter name eval or arguments is not allowed in strict mode', 21),
                                StrictParamDupe: J$.T(781, 'Strict mode function may not have duplicate parameter names', 21),
                                StrictFunctionName: J$.T(785, 'Function name may not be eval or arguments in strict mode', 21),
                                StrictOctalLiteral: J$.T(789, 'Octal literals are not allowed in strict mode.', 21),
                                StrictDelete: J$.T(793, 'Delete of an unqualified identifier in strict mode.', 21),
                                StrictDuplicateProperty: J$.T(797, 'Duplicate data property in object literal not allowed in strict mode', 21),
                                AccessorDataProperty: J$.T(801, 'Object literal may not have data and accessor property with the same name', 21),
                                AccessorGetSet: J$.T(805, 'Object literal may not have multiple get/set accessors with the same name', 21),
                                StrictLHSAssignment: J$.T(809, 'Assignment to eval or arguments is not allowed in strict mode', 21),
                                StrictLHSPostfix: J$.T(813, 'Postfix increment/decrement may not have eval or arguments operand in strict mode', 21),
                                StrictLHSPrefix: J$.T(817, 'Prefix increment/decrement may not have eval or arguments operand in strict mode', 21),
                                StrictReservedWord: J$.T(821, 'Use of future reserved word in strict mode', 21)
                            }, 11), Messages);
                            Regex = J$.W(869, 'Regex', J$.T(865, {
                                NonAsciiIdentifierStart: J$.T(845, J$.F(841, J$.I(typeof RegExp === 'undefined' ? RegExp = J$.R(833, 'RegExp', undefined, true) : RegExp = J$.R(833, 'RegExp', RegExp, true)), true)(J$.T(837, '[\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u0527\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u08A0\u08A2-\u08AC\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0977\u0979-\u097F\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C33\u0C35-\u0C39\u0C3D\u0C58\u0C59\u0C60\u0C61\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D60\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F4\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F0\u1700-\u170C\u170E-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1877\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191C\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19C1-\u19C7\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1CE9-\u1CEC\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FCC\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA697\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA78E\uA790-\uA793\uA7A0-\uA7AA\uA7F8-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA80-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uABC0-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]', 21)), 11),
                                NonAsciiIdentifierPart: J$.T(861, J$.F(857, J$.I(typeof RegExp === 'undefined' ? RegExp = J$.R(849, 'RegExp', undefined, true) : RegExp = J$.R(849, 'RegExp', RegExp, true)), true)(J$.T(853, '[\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0300-\u0374\u0376\u0377\u037A-\u037D\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u0483-\u0487\u048A-\u0527\u0531-\u0556\u0559\u0561-\u0587\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u05D0-\u05EA\u05F0-\u05F2\u0610-\u061A\u0620-\u0669\u066E-\u06D3\u06D5-\u06DC\u06DF-\u06E8\u06EA-\u06FC\u06FF\u0710-\u074A\u074D-\u07B1\u07C0-\u07F5\u07FA\u0800-\u082D\u0840-\u085B\u08A0\u08A2-\u08AC\u08E4-\u08FE\u0900-\u0963\u0966-\u096F\u0971-\u0977\u0979-\u097F\u0981-\u0983\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BC-\u09C4\u09C7\u09C8\u09CB-\u09CE\u09D7\u09DC\u09DD\u09DF-\u09E3\u09E6-\u09F1\u0A01-\u0A03\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A59-\u0A5C\u0A5E\u0A66-\u0A75\u0A81-\u0A83\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABC-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AD0\u0AE0-\u0AE3\u0AE6-\u0AEF\u0B01-\u0B03\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3C-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B56\u0B57\u0B5C\u0B5D\u0B5F-\u0B63\u0B66-\u0B6F\u0B71\u0B82\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD0\u0BD7\u0BE6-\u0BEF\u0C01-\u0C03\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C33\u0C35-\u0C39\u0C3D-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C58\u0C59\u0C60-\u0C63\u0C66-\u0C6F\u0C82\u0C83\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBC-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CDE\u0CE0-\u0CE3\u0CE6-\u0CEF\u0CF1\u0CF2\u0D02\u0D03\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D-\u0D44\u0D46-\u0D48\u0D4A-\u0D4E\u0D57\u0D60-\u0D63\u0D66-\u0D6F\u0D7A-\u0D7F\u0D82\u0D83\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DF2\u0DF3\u0E01-\u0E3A\u0E40-\u0E4E\u0E50-\u0E59\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB9\u0EBB-\u0EBD\u0EC0-\u0EC4\u0EC6\u0EC8-\u0ECD\u0ED0-\u0ED9\u0EDC-\u0EDF\u0F00\u0F18\u0F19\u0F20-\u0F29\u0F35\u0F37\u0F39\u0F3E-\u0F47\u0F49-\u0F6C\u0F71-\u0F84\u0F86-\u0F97\u0F99-\u0FBC\u0FC6\u1000-\u1049\u1050-\u109D\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u135D-\u135F\u1380-\u138F\u13A0-\u13F4\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F0\u1700-\u170C\u170E-\u1714\u1720-\u1734\u1740-\u1753\u1760-\u176C\u176E-\u1770\u1772\u1773\u1780-\u17D3\u17D7\u17DC\u17DD\u17E0-\u17E9\u180B-\u180D\u1810-\u1819\u1820-\u1877\u1880-\u18AA\u18B0-\u18F5\u1900-\u191C\u1920-\u192B\u1930-\u193B\u1946-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u19D0-\u19D9\u1A00-\u1A1B\u1A20-\u1A5E\u1A60-\u1A7C\u1A7F-\u1A89\u1A90-\u1A99\u1AA7\u1B00-\u1B4B\u1B50-\u1B59\u1B6B-\u1B73\u1B80-\u1BF3\u1C00-\u1C37\u1C40-\u1C49\u1C4D-\u1C7D\u1CD0-\u1CD2\u1CD4-\u1CF6\u1D00-\u1DE6\u1DFC-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u200C\u200D\u203F\u2040\u2054\u2071\u207F\u2090-\u209C\u20D0-\u20DC\u20E1\u20E5-\u20F0\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D7F-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2DE0-\u2DFF\u2E2F\u3005-\u3007\u3021-\u302F\u3031-\u3035\u3038-\u303C\u3041-\u3096\u3099\u309A\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FCC\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA62B\uA640-\uA66F\uA674-\uA67D\uA67F-\uA697\uA69F-\uA6F1\uA717-\uA71F\uA722-\uA788\uA78B-\uA78E\uA790-\uA793\uA7A0-\uA7AA\uA7F8-\uA827\uA840-\uA873\uA880-\uA8C4\uA8D0-\uA8D9\uA8E0-\uA8F7\uA8FB\uA900-\uA92D\uA930-\uA953\uA960-\uA97C\uA980-\uA9C0\uA9CF-\uA9D9\uAA00-\uAA36\uAA40-\uAA4D\uAA50-\uAA59\uAA60-\uAA76\uAA7A\uAA7B\uAA80-\uAAC2\uAADB-\uAADD\uAAE0-\uAAEF\uAAF2-\uAAF6\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uABC0-\uABEA\uABEC\uABED\uABF0-\uABF9\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE00-\uFE0F\uFE20-\uFE26\uFE33\uFE34\uFE4D-\uFE4F\uFE70-\uFE74\uFE76-\uFEFC\uFF10-\uFF19\uFF21-\uFF3A\uFF3F\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]', 21)), 11)
                            }, 11), Regex);
                            function assert(condition, message) {
                                jalangiLabel1:
                                    while (true) {
                                        try {
                                            J$.Fe(897, arguments.callee, this);
                                            arguments = J$.N(901, 'arguments', arguments, true);
                                            condition = J$.N(905, 'condition', condition, true);
                                            message = J$.N(909, 'message', message, true);
                                            if (J$.C(4, J$.U(6, '!', J$.R(873, 'condition', condition, false)))) {
                                                throw J$.T(893, J$.F(889, J$.I(typeof Error === 'undefined' ? Error = J$.R(877, 'Error', undefined, true) : Error = J$.R(877, 'Error', Error, true)), true)(J$.B(10, '+', J$.T(881, 'ASSERT: ', 21), J$.R(885, 'message', message, false))), 11);
                                            }
                                        } catch (J$e) {
                                            J$.Ex(28909, J$e);
                                        } finally {
                                            if (J$.Fr(28913))
                                                continue jalangiLabel1;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function isDecimalDigit(ch) {
                                jalangiLabel2:
                                    while (true) {
                                        try {
                                            J$.Fe(933, arguments.callee, this);
                                            arguments = J$.N(937, 'arguments', arguments, true);
                                            ch = J$.N(941, 'ch', ch, true);
                                            return J$.Rt(929, J$.C(8, J$.B(14, '>=', J$.R(913, 'ch', ch, false), J$.T(917, 48, 22))) ? J$.B(18, '<=', J$.R(921, 'ch', ch, false), J$.T(925, 57, 22)) : J$._());
                                        } catch (J$e) {
                                            J$.Ex(28917, J$e);
                                        } finally {
                                            if (J$.Fr(28921))
                                                continue jalangiLabel2;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function isHexDigit(ch) {
                                jalangiLabel3:
                                    while (true) {
                                        try {
                                            J$.Fe(965, arguments.callee, this);
                                            arguments = J$.N(969, 'arguments', arguments, true);
                                            ch = J$.N(973, 'ch', ch, true);
                                            return J$.Rt(961, J$.B(22, '>=', J$.M(953, J$.T(945, '0123456789abcdefABCDEF', 21), 'indexOf', false)(J$.R(949, 'ch', ch, false)), J$.T(957, 0, 22)));
                                        } catch (J$e) {
                                            J$.Ex(28925, J$e);
                                        } finally {
                                            if (J$.Fr(28929))
                                                continue jalangiLabel3;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function isOctalDigit(ch) {
                                jalangiLabel4:
                                    while (true) {
                                        try {
                                            J$.Fe(997, arguments.callee, this);
                                            arguments = J$.N(1001, 'arguments', arguments, true);
                                            ch = J$.N(1005, 'ch', ch, true);
                                            return J$.Rt(993, J$.B(26, '>=', J$.M(985, J$.T(977, '01234567', 21), 'indexOf', false)(J$.R(981, 'ch', ch, false)), J$.T(989, 0, 22)));
                                        } catch (J$e) {
                                            J$.Ex(28933, J$e);
                                        } finally {
                                            if (J$.Fr(28937))
                                                continue jalangiLabel4;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function isWhiteSpace(ch) {
                                jalangiLabel5:
                                    while (true) {
                                        try {
                                            J$.Fe(1145, arguments.callee, this);
                                            arguments = J$.N(1149, 'arguments', arguments, true);
                                            ch = J$.N(1153, 'ch', ch, true);
                                            return J$.Rt(1141, J$.C(32, J$.C(24, J$.C(20, J$.C(16, J$.C(12, J$.B(30, '===', J$.R(1009, 'ch', ch, false), J$.T(1013, 32, 22))) ? J$._() : J$.B(34, '===', J$.R(1017, 'ch', ch, false), J$.T(1021, 9, 22))) ? J$._() : J$.B(38, '===', J$.R(1025, 'ch', ch, false), J$.T(1029, 11, 22))) ? J$._() : J$.B(42, '===', J$.R(1033, 'ch', ch, false), J$.T(1037, 12, 22))) ? J$._() : J$.B(46, '===', J$.R(1041, 'ch', ch, false), J$.T(1045, 160, 22))) ? J$._() : J$.C(28, J$.B(50, '>=', J$.R(1049, 'ch', ch, false), J$.T(1053, 5760, 22))) ? J$.B(54, '>=', J$.M(1133, J$.T(1125, [
                                                J$.T(1057, 5760, 22),
                                                J$.T(1061, 6158, 22),
                                                J$.T(1065, 8192, 22),
                                                J$.T(1069, 8193, 22),
                                                J$.T(1073, 8194, 22),
                                                J$.T(1077, 8195, 22),
                                                J$.T(1081, 8196, 22),
                                                J$.T(1085, 8197, 22),
                                                J$.T(1089, 8198, 22),
                                                J$.T(1093, 8199, 22),
                                                J$.T(1097, 8200, 22),
                                                J$.T(1101, 8201, 22),
                                                J$.T(1105, 8202, 22),
                                                J$.T(1109, 8239, 22),
                                                J$.T(1113, 8287, 22),
                                                J$.T(1117, 12288, 22),
                                                J$.T(1121, 65279, 22)
                                            ], 10), 'indexOf', false)(J$.R(1129, 'ch', ch, false)), J$.T(1137, 0, 22)) : J$._());
                                        } catch (J$e) {
                                            J$.Ex(28941, J$e);
                                        } finally {
                                            if (J$.Fr(28945))
                                                continue jalangiLabel5;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function isLineTerminator(ch) {
                                jalangiLabel6:
                                    while (true) {
                                        try {
                                            J$.Fe(1193, arguments.callee, this);
                                            arguments = J$.N(1197, 'arguments', arguments, true);
                                            ch = J$.N(1201, 'ch', ch, true);
                                            return J$.Rt(1189, J$.C(44, J$.C(40, J$.C(36, J$.B(58, '===', J$.R(1157, 'ch', ch, false), J$.T(1161, 10, 22))) ? J$._() : J$.B(62, '===', J$.R(1165, 'ch', ch, false), J$.T(1169, 13, 22))) ? J$._() : J$.B(66, '===', J$.R(1173, 'ch', ch, false), J$.T(1177, 8232, 22))) ? J$._() : J$.B(70, '===', J$.R(1181, 'ch', ch, false), J$.T(1185, 8233, 22)));
                                        } catch (J$e) {
                                            J$.Ex(28949, J$e);
                                        } finally {
                                            if (J$.Fr(28953))
                                                continue jalangiLabel6;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function isIdentifierStart(ch) {
                                jalangiLabel7:
                                    while (true) {
                                        try {
                                            J$.Fe(1297, arguments.callee, this);
                                            arguments = J$.N(1301, 'arguments', arguments, true);
                                            ch = J$.N(1305, 'ch', ch, true);
                                            return J$.Rt(1293, J$.C(76, J$.C(68, J$.C(64, J$.C(56, J$.C(48, J$.B(74, '===', J$.R(1205, 'ch', ch, false), J$.T(1209, 36, 22))) ? J$._() : J$.B(78, '===', J$.R(1213, 'ch', ch, false), J$.T(1217, 95, 22))) ? J$._() : J$.C(52, J$.B(82, '>=', J$.R(1221, 'ch', ch, false), J$.T(1225, 65, 22))) ? J$.B(86, '<=', J$.R(1229, 'ch', ch, false), J$.T(1233, 90, 22)) : J$._()) ? J$._() : J$.C(60, J$.B(90, '>=', J$.R(1237, 'ch', ch, false), J$.T(1241, 97, 22))) ? J$.B(94, '<=', J$.R(1245, 'ch', ch, false), J$.T(1249, 122, 22)) : J$._()) ? J$._() : J$.B(98, '===', J$.R(1253, 'ch', ch, false), J$.T(1257, 92, 22))) ? J$._() : J$.C(72, J$.B(102, '>=', J$.R(1261, 'ch', ch, false), J$.T(1265, 128, 22))) ? J$.M(1289, J$.G(1273, J$.R(1269, 'Regex', Regex, false), 'NonAsciiIdentifierStart'), 'test', false)(J$.M(1285, J$.I(typeof String === 'undefined' ? String = J$.R(1277, 'String', undefined, true) : String = J$.R(1277, 'String', String, true)), 'fromCharCode', false)(J$.R(1281, 'ch', ch, false))) : J$._());
                                        } catch (J$e) {
                                            J$.Ex(28957, J$e);
                                        } finally {
                                            if (J$.Fr(28961))
                                                continue jalangiLabel7;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function isIdentifierPart(ch) {
                                jalangiLabel8:
                                    while (true) {
                                        try {
                                            J$.Fe(1417, arguments.callee, this);
                                            arguments = J$.N(1421, 'arguments', arguments, true);
                                            ch = J$.N(1425, 'ch', ch, true);
                                            return J$.Rt(1413, J$.C(116, J$.C(108, J$.C(104, J$.C(96, J$.C(88, J$.C(80, J$.B(106, '===', J$.R(1309, 'ch', ch, false), J$.T(1313, 36, 22))) ? J$._() : J$.B(110, '===', J$.R(1317, 'ch', ch, false), J$.T(1321, 95, 22))) ? J$._() : J$.C(84, J$.B(114, '>=', J$.R(1325, 'ch', ch, false), J$.T(1329, 65, 22))) ? J$.B(118, '<=', J$.R(1333, 'ch', ch, false), J$.T(1337, 90, 22)) : J$._()) ? J$._() : J$.C(92, J$.B(122, '>=', J$.R(1341, 'ch', ch, false), J$.T(1345, 97, 22))) ? J$.B(126, '<=', J$.R(1349, 'ch', ch, false), J$.T(1353, 122, 22)) : J$._()) ? J$._() : J$.C(100, J$.B(130, '>=', J$.R(1357, 'ch', ch, false), J$.T(1361, 48, 22))) ? J$.B(134, '<=', J$.R(1365, 'ch', ch, false), J$.T(1369, 57, 22)) : J$._()) ? J$._() : J$.B(138, '===', J$.R(1373, 'ch', ch, false), J$.T(1377, 92, 22))) ? J$._() : J$.C(112, J$.B(142, '>=', J$.R(1381, 'ch', ch, false), J$.T(1385, 128, 22))) ? J$.M(1409, J$.G(1393, J$.R(1389, 'Regex', Regex, false), 'NonAsciiIdentifierPart'), 'test', false)(J$.M(1405, J$.I(typeof String === 'undefined' ? String = J$.R(1397, 'String', undefined, true) : String = J$.R(1397, 'String', String, true)), 'fromCharCode', false)(J$.R(1401, 'ch', ch, false))) : J$._());
                                        } catch (J$e) {
                                            J$.Ex(28965, J$e);
                                        } finally {
                                            if (J$.Fr(28969))
                                                continue jalangiLabel8;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function isFutureReservedWord(id) {
                                jalangiLabel9:
                                    while (true) {
                                        try {
                                            J$.Fe(1473, arguments.callee, this);
                                            arguments = J$.N(1477, 'arguments', arguments, true);
                                            id = J$.N(1481, 'id', id, true);
                                            switch (J$.C1(120, J$.R(1429, 'id', id, false))) {
                                            case J$.C2(124, J$.T(1433, 'class', 21)):
                                            case J$.C2(128, J$.T(1437, 'enum', 21)):
                                            case J$.C2(132, J$.T(1441, 'export', 21)):
                                            case J$.C2(136, J$.T(1445, 'extends', 21)):
                                            case J$.C2(140, J$.T(1449, 'import', 21)):
                                            case J$.C2(144, J$.T(1461, 'super', 21)):
                                                return J$.Rt(1457, J$.T(1453, true, 23));
                                            default:
                                                return J$.Rt(1469, J$.T(1465, false, 23));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(28973, J$e);
                                        } finally {
                                            if (J$.Fr(28977))
                                                continue jalangiLabel9;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function isStrictModeReservedWord(id) {
                                jalangiLabel10:
                                    while (true) {
                                        try {
                                            J$.Fe(1541, arguments.callee, this);
                                            arguments = J$.N(1545, 'arguments', arguments, true);
                                            id = J$.N(1549, 'id', id, true);
                                            switch (J$.C1(148, J$.R(1485, 'id', id, false))) {
                                            case J$.C2(152, J$.T(1489, 'implements', 21)):
                                            case J$.C2(156, J$.T(1493, 'interface', 21)):
                                            case J$.C2(160, J$.T(1497, 'package', 21)):
                                            case J$.C2(164, J$.T(1501, 'private', 21)):
                                            case J$.C2(168, J$.T(1505, 'protected', 21)):
                                            case J$.C2(172, J$.T(1509, 'public', 21)):
                                            case J$.C2(176, J$.T(1513, 'static', 21)):
                                            case J$.C2(180, J$.T(1517, 'yield', 21)):
                                            case J$.C2(184, J$.T(1529, 'let', 21)):
                                                return J$.Rt(1525, J$.T(1521, true, 23));
                                            default:
                                                return J$.Rt(1537, J$.T(1533, false, 23));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(28981, J$e);
                                        } finally {
                                            if (J$.Fr(28985))
                                                continue jalangiLabel10;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function isRestrictedWord(id) {
                                jalangiLabel11:
                                    while (true) {
                                        try {
                                            J$.Fe(1573, arguments.callee, this);
                                            arguments = J$.N(1577, 'arguments', arguments, true);
                                            id = J$.N(1581, 'id', id, true);
                                            return J$.Rt(1569, J$.C(188, J$.B(146, '===', J$.R(1553, 'id', id, false), J$.T(1557, 'eval', 21))) ? J$._() : J$.B(150, '===', J$.R(1561, 'id', id, false), J$.T(1565, 'arguments', 21)));
                                        } catch (J$e) {
                                            J$.Ex(28989, J$e);
                                        } finally {
                                            if (J$.Fr(28993))
                                                continue jalangiLabel11;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function isKeyword(id) {
                                jalangiLabel12:
                                    while (true) {
                                        try {
                                            J$.Fe(1969, arguments.callee, this);
                                            arguments = J$.N(1973, 'arguments', arguments, true);
                                            id = J$.N(1977, 'id', id, true);
                                            if (J$.C(196, J$.C(192, J$.R(1585, 'strict', strict, false)) ? J$.F(1597, J$.R(1589, 'isStrictModeReservedWord', isStrictModeReservedWord, false), false)(J$.R(1593, 'id', id, false)) : J$._())) {
                                                return J$.Rt(1605, J$.T(1601, true, 23));
                                            }
                                            switch (J$.C1(308, J$.G(1613, J$.R(1609, 'id', id, false), 'length'))) {
                                            case J$.C2(312, J$.T(1645, 2, 22)):
                                                return J$.Rt(1641, J$.C(204, J$.C(200, J$.B(154, '===', J$.R(1617, 'id', id, false), J$.T(1621, 'if', 21))) ? J$._() : J$.B(158, '===', J$.R(1625, 'id', id, false), J$.T(1629, 'in', 21))) ? J$._() : J$.B(162, '===', J$.R(1633, 'id', id, false), J$.T(1637, 'do', 21)));
                                            case J$.C2(316, J$.T(1693, 3, 22)):
                                                return J$.Rt(1689, J$.C(220, J$.C(216, J$.C(212, J$.C(208, J$.B(166, '===', J$.R(1649, 'id', id, false), J$.T(1653, 'var', 21))) ? J$._() : J$.B(170, '===', J$.R(1657, 'id', id, false), J$.T(1661, 'for', 21))) ? J$._() : J$.B(174, '===', J$.R(1665, 'id', id, false), J$.T(1669, 'new', 21))) ? J$._() : J$.B(178, '===', J$.R(1673, 'id', id, false), J$.T(1677, 'try', 21))) ? J$._() : J$.B(182, '===', J$.R(1681, 'id', id, false), J$.T(1685, 'let', 21)));
                                            case J$.C2(320, J$.T(1749, 4, 22)):
                                                return J$.Rt(1745, J$.C(240, J$.C(236, J$.C(232, J$.C(228, J$.C(224, J$.B(186, '===', J$.R(1697, 'id', id, false), J$.T(1701, 'this', 21))) ? J$._() : J$.B(190, '===', J$.R(1705, 'id', id, false), J$.T(1709, 'else', 21))) ? J$._() : J$.B(194, '===', J$.R(1713, 'id', id, false), J$.T(1717, 'case', 21))) ? J$._() : J$.B(198, '===', J$.R(1721, 'id', id, false), J$.T(1725, 'void', 21))) ? J$._() : J$.B(202, '===', J$.R(1729, 'id', id, false), J$.T(1733, 'with', 21))) ? J$._() : J$.B(206, '===', J$.R(1737, 'id', id, false), J$.T(1741, 'enum', 21)));
                                            case J$.C2(324, J$.T(1821, 5, 22)):
                                                return J$.Rt(1817, J$.C(268, J$.C(264, J$.C(260, J$.C(256, J$.C(252, J$.C(248, J$.C(244, J$.B(210, '===', J$.R(1753, 'id', id, false), J$.T(1757, 'while', 21))) ? J$._() : J$.B(214, '===', J$.R(1761, 'id', id, false), J$.T(1765, 'break', 21))) ? J$._() : J$.B(218, '===', J$.R(1769, 'id', id, false), J$.T(1773, 'catch', 21))) ? J$._() : J$.B(222, '===', J$.R(1777, 'id', id, false), J$.T(1781, 'throw', 21))) ? J$._() : J$.B(226, '===', J$.R(1785, 'id', id, false), J$.T(1789, 'const', 21))) ? J$._() : J$.B(230, '===', J$.R(1793, 'id', id, false), J$.T(1797, 'yield', 21))) ? J$._() : J$.B(234, '===', J$.R(1801, 'id', id, false), J$.T(1805, 'class', 21))) ? J$._() : J$.B(238, '===', J$.R(1809, 'id', id, false), J$.T(1813, 'super', 21)));
                                            case J$.C2(328, J$.T(1877, 6, 22)):
                                                return J$.Rt(1873, J$.C(288, J$.C(284, J$.C(280, J$.C(276, J$.C(272, J$.B(242, '===', J$.R(1825, 'id', id, false), J$.T(1829, 'return', 21))) ? J$._() : J$.B(246, '===', J$.R(1833, 'id', id, false), J$.T(1837, 'typeof', 21))) ? J$._() : J$.B(250, '===', J$.R(1841, 'id', id, false), J$.T(1845, 'delete', 21))) ? J$._() : J$.B(254, '===', J$.R(1849, 'id', id, false), J$.T(1853, 'switch', 21))) ? J$._() : J$.B(258, '===', J$.R(1857, 'id', id, false), J$.T(1861, 'export', 21))) ? J$._() : J$.B(262, '===', J$.R(1865, 'id', id, false), J$.T(1869, 'import', 21)));
                                            case J$.C2(332, J$.T(1909, 7, 22)):
                                                return J$.Rt(1905, J$.C(296, J$.C(292, J$.B(266, '===', J$.R(1881, 'id', id, false), J$.T(1885, 'default', 21))) ? J$._() : J$.B(270, '===', J$.R(1889, 'id', id, false), J$.T(1893, 'finally', 21))) ? J$._() : J$.B(274, '===', J$.R(1897, 'id', id, false), J$.T(1901, 'extends', 21)));
                                            case J$.C2(336, J$.T(1941, 8, 22)):
                                                return J$.Rt(1937, J$.C(304, J$.C(300, J$.B(278, '===', J$.R(1913, 'id', id, false), J$.T(1917, 'function', 21))) ? J$._() : J$.B(282, '===', J$.R(1921, 'id', id, false), J$.T(1925, 'continue', 21))) ? J$._() : J$.B(286, '===', J$.R(1929, 'id', id, false), J$.T(1933, 'debugger', 21)));
                                            case J$.C2(340, J$.T(1957, 10, 22)):
                                                return J$.Rt(1953, J$.B(290, '===', J$.R(1945, 'id', id, false), J$.T(1949, 'instanceof', 21)));
                                            default:
                                                return J$.Rt(1965, J$.T(1961, false, 23));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(28997, J$e);
                                        } finally {
                                            if (J$.Fr(29001))
                                                continue jalangiLabel12;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function addComment(type, value, start, end, loc) {
                                jalangiLabel13:
                                    while (true) {
                                        try {
                                            J$.Fe(2165, arguments.callee, this);
                                            arguments = J$.N(2169, 'arguments', arguments, true);
                                            type = J$.N(2173, 'type', type, true);
                                            value = J$.N(2177, 'value', value, true);
                                            start = J$.N(2181, 'start', start, true);
                                            end = J$.N(2185, 'end', end, true);
                                            loc = J$.N(2189, 'loc', loc, true);
                                            J$.N(2193, 'comment', comment, false);
                                            J$.N(2197, 'attacher', attacher, false);
                                            var comment, attacher;
                                            J$.F(1997, J$.R(1981, 'assert', assert, false), false)(J$.B(298, '===', J$.U(294, 'typeof', J$.R(1985, 'start', start, false)), J$.T(1989, 'number', 21)), J$.T(1993, 'Comment must have valid position', 21));
                                            if (J$.C(344, J$.B(302, '>=', J$.G(2005, J$.R(2001, 'state', state, false), 'lastCommentStart'), J$.R(2009, 'start', start, false)))) {
                                                return J$.Rt(2013, undefined);
                                            }
                                            J$.P(2025, J$.R(2017, 'state', state, false), 'lastCommentStart', J$.R(2021, 'start', start, false));
                                            comment = J$.W(2041, 'comment', J$.T(2037, {
                                                type: J$.R(2029, 'type', type, false),
                                                value: J$.R(2033, 'value', value, false)
                                            }, 11), comment);
                                            if (J$.C(348, J$.G(2049, J$.R(2045, 'extra', extra, false), 'range'))) {
                                                J$.P(2069, J$.R(2053, 'comment', comment, false), 'range', J$.T(2065, [
                                                    J$.R(2057, 'start', start, false),
                                                    J$.R(2061, 'end', end, false)
                                                ], 10));
                                            }
                                            if (J$.C(352, J$.G(2077, J$.R(2073, 'extra', extra, false), 'loc'))) {
                                                J$.P(2089, J$.R(2081, 'comment', comment, false), 'loc', J$.R(2085, 'loc', loc, false));
                                            }
                                            J$.M(2105, J$.G(2097, J$.R(2093, 'extra', extra, false), 'comments'), 'push', false)(J$.R(2101, 'comment', comment, false));
                                            if (J$.C(356, J$.G(2113, J$.R(2109, 'extra', extra, false), 'attachComment'))) {
                                                attacher = J$.W(2145, 'attacher', J$.T(2141, {
                                                    comment: J$.R(2117, 'comment', comment, false),
                                                    leading: J$.T(2121, null, 25),
                                                    trailing: J$.T(2125, null, 25),
                                                    range: J$.T(2137, [
                                                        J$.R(2129, 'start', start, false),
                                                        J$.R(2133, 'end', end, false)
                                                    ], 10)
                                                }, 11), attacher);
                                                J$.M(2161, J$.G(2153, J$.R(2149, 'extra', extra, false), 'pendingComments'), 'push', false)(J$.R(2157, 'attacher', attacher, false));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(29005, J$e);
                                        } finally {
                                            if (J$.Fr(29009))
                                                continue jalangiLabel13;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function skipSingleLineComment() {
                                jalangiLabel14:
                                    while (true) {
                                        try {
                                            J$.Fe(2517, arguments.callee, this);
                                            arguments = J$.N(2521, 'arguments', arguments, true);
                                            J$.N(2525, 'start', start, false);
                                            J$.N(2529, 'loc', loc, false);
                                            J$.N(2533, 'ch', ch, false);
                                            J$.N(2537, 'comment', comment, false);
                                            var start, loc, ch, comment;
                                            start = J$.W(2209, 'start', J$.B(306, '-', J$.R(2201, 'index', index, false), J$.T(2205, 2, 22)), start);
                                            loc = J$.W(2237, 'loc', J$.T(2233, {
                                                start: J$.T(2229, {
                                                    line: J$.R(2213, 'lineNumber', lineNumber, false),
                                                    column: J$.B(314, '-', J$.B(310, '-', J$.R(2217, 'index', index, false), J$.R(2221, 'lineStart', lineStart, false)), J$.T(2225, 2, 22))
                                                }, 11)
                                            }, 11), loc);
                                            while (J$.C(376, J$.B(318, '<', J$.R(2241, 'index', index, false), J$.R(2245, 'length', length, false)))) {
                                                ch = J$.W(2261, 'ch', J$.M(2257, J$.R(2249, 'source', source, false), 'charCodeAt', false)(J$.R(2253, 'index', index, false)), ch);
                                                index = J$.W(2269, 'index', J$.B(326, '+', J$.U(322, '+', J$.R(2265, 'index', index, false)), 1), index);
                                                if (J$.C(372, J$.F(2281, J$.R(2273, 'isLineTerminator', isLineTerminator, false), false)(J$.R(2277, 'ch', ch, false)))) {
                                                    if (J$.C(360, J$.G(2289, J$.R(2285, 'extra', extra, false), 'comments'))) {
                                                        comment = J$.W(2317, 'comment', J$.M(2313, J$.R(2293, 'source', source, false), 'slice', false)(J$.B(330, '+', J$.R(2297, 'start', start, false), J$.T(2301, 2, 22)), J$.B(334, '-', J$.R(2305, 'index', index, false), J$.T(2309, 1, 22))), comment);
                                                        J$.P(2345, J$.R(2321, 'loc', loc, false), 'end', J$.T(2341, {
                                                            line: J$.R(2325, 'lineNumber', lineNumber, false),
                                                            column: J$.B(342, '-', J$.B(338, '-', J$.R(2329, 'index', index, false), J$.R(2333, 'lineStart', lineStart, false)), J$.T(2337, 1, 22))
                                                        }, 11));
                                                        J$.F(2377, J$.R(2349, 'addComment', addComment, false), false)(J$.T(2353, 'Line', 21), J$.R(2357, 'comment', comment, false), J$.R(2361, 'start', start, false), J$.B(346, '-', J$.R(2365, 'index', index, false), J$.T(2369, 1, 22)), J$.R(2373, 'loc', loc, false));
                                                    }
                                                    if (J$.C(368, J$.C(364, J$.B(350, '===', J$.R(2381, 'ch', ch, false), J$.T(2385, 13, 22))) ? J$.B(354, '===', J$.M(2397, J$.R(2389, 'source', source, false), 'charCodeAt', false)(J$.R(2393, 'index', index, false)), J$.T(2401, 10, 22)) : J$._())) {
                                                        index = J$.W(2409, 'index', J$.B(362, '+', J$.U(358, '+', J$.R(2405, 'index', index, false)), 1), index);
                                                    }
                                                    lineNumber = J$.W(2417, 'lineNumber', J$.B(370, '+', J$.U(366, '+', J$.R(2413, 'lineNumber', lineNumber, false)), 1), lineNumber);
                                                    lineStart = J$.W(2425, 'lineStart', J$.R(2421, 'index', index, false), lineStart);
                                                    return J$.Rt(2429, undefined);
                                                }
                                            }
                                            if (J$.C(380, J$.G(2437, J$.R(2433, 'extra', extra, false), 'comments'))) {
                                                comment = J$.W(2461, 'comment', J$.M(2457, J$.R(2441, 'source', source, false), 'slice', false)(J$.B(374, '+', J$.R(2445, 'start', start, false), J$.T(2449, 2, 22)), J$.R(2453, 'index', index, false)), comment);
                                                J$.P(2485, J$.R(2465, 'loc', loc, false), 'end', J$.T(2481, {
                                                    line: J$.R(2469, 'lineNumber', lineNumber, false),
                                                    column: J$.B(378, '-', J$.R(2473, 'index', index, false), J$.R(2477, 'lineStart', lineStart, false))
                                                }, 11));
                                                J$.F(2513, J$.R(2489, 'addComment', addComment, false), false)(J$.T(2493, 'Line', 21), J$.R(2497, 'comment', comment, false), J$.R(2501, 'start', start, false), J$.R(2505, 'index', index, false), J$.R(2509, 'loc', loc, false));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(29013, J$e);
                                        } finally {
                                            if (J$.Fr(29017))
                                                continue jalangiLabel14;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function skipMultiLineComment() {
                                jalangiLabel15:
                                    while (true) {
                                        try {
                                            J$.Fe(2893, arguments.callee, this);
                                            arguments = J$.N(2897, 'arguments', arguments, true);
                                            J$.N(2901, 'start', start, false);
                                            J$.N(2905, 'loc', loc, false);
                                            J$.N(2909, 'ch', ch, false);
                                            J$.N(2913, 'comment', comment, false);
                                            var start, loc, ch, comment;
                                            if (J$.C(384, J$.G(2545, J$.R(2541, 'extra', extra, false), 'comments'))) {
                                                start = J$.W(2557, 'start', J$.B(382, '-', J$.R(2549, 'index', index, false), J$.T(2553, 2, 22)), start);
                                                loc = J$.W(2585, 'loc', J$.T(2581, {
                                                    start: J$.T(2577, {
                                                        line: J$.R(2561, 'lineNumber', lineNumber, false),
                                                        column: J$.B(390, '-', J$.B(386, '-', J$.R(2565, 'index', index, false), J$.R(2569, 'lineStart', lineStart, false)), J$.T(2573, 2, 22))
                                                    }, 11)
                                                }, 11), loc);
                                            }
                                            while (J$.C(416, J$.B(394, '<', J$.R(2589, 'index', index, false), J$.R(2593, 'length', length, false)))) {
                                                ch = J$.W(2609, 'ch', J$.M(2605, J$.R(2597, 'source', source, false), 'charCodeAt', false)(J$.R(2601, 'index', index, false)), ch);
                                                if (J$.C(412, J$.F(2621, J$.R(2613, 'isLineTerminator', isLineTerminator, false), false)(J$.R(2617, 'ch', ch, false)))) {
                                                    if (J$.C(392, J$.C(388, J$.B(398, '===', J$.R(2625, 'ch', ch, false), J$.T(2629, 13, 22))) ? J$.B(406, '===', J$.M(2645, J$.R(2633, 'source', source, false), 'charCodeAt', false)(J$.B(402, '+', J$.R(2637, 'index', index, false), J$.T(2641, 1, 22))), J$.T(2649, 10, 22)) : J$._())) {
                                                        index = J$.W(2657, 'index', J$.B(414, '+', J$.U(410, '+', J$.R(2653, 'index', index, false)), 1), index);
                                                    }
                                                    lineNumber = J$.W(2665, 'lineNumber', J$.B(422, '+', J$.U(418, '+', J$.R(2661, 'lineNumber', lineNumber, false)), 1), lineNumber);
                                                    index = J$.W(2673, 'index', J$.B(430, '+', J$.U(426, '+', J$.R(2669, 'index', index, false)), 1), index);
                                                    lineStart = J$.W(2681, 'lineStart', J$.R(2677, 'index', index, false), lineStart);
                                                    if (J$.C(396, J$.B(434, '>=', J$.R(2685, 'index', index, false), J$.R(2689, 'length', length, false)))) {
                                                        J$.F(2713, J$.R(2693, 'throwError', throwError, false), false)(J$.T(2697, {}, 11), J$.G(2705, J$.R(2701, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(2709, 'ILLEGAL', 21));
                                                    }
                                                } else if (J$.C(408, J$.B(438, '===', J$.R(2717, 'ch', ch, false), J$.T(2721, 42, 22)))) {
                                                    if (J$.C(404, J$.B(446, '===', J$.M(2737, J$.R(2725, 'source', source, false), 'charCodeAt', false)(J$.B(442, '+', J$.R(2729, 'index', index, false), J$.T(2733, 1, 22))), J$.T(2741, 47, 22)))) {
                                                        index = J$.W(2749, 'index', J$.B(454, '+', J$.U(450, '+', J$.R(2745, 'index', index, false)), 1), index);
                                                        index = J$.W(2757, 'index', J$.B(462, '+', J$.U(458, '+', J$.R(2753, 'index', index, false)), 1), index);
                                                        if (J$.C(400, J$.G(2765, J$.R(2761, 'extra', extra, false), 'comments'))) {
                                                            comment = J$.W(2793, 'comment', J$.M(2789, J$.R(2769, 'source', source, false), 'slice', false)(J$.B(466, '+', J$.R(2773, 'start', start, false), J$.T(2777, 2, 22)), J$.B(470, '-', J$.R(2781, 'index', index, false), J$.T(2785, 2, 22))), comment);
                                                            J$.P(2817, J$.R(2797, 'loc', loc, false), 'end', J$.T(2813, {
                                                                line: J$.R(2801, 'lineNumber', lineNumber, false),
                                                                column: J$.B(474, '-', J$.R(2805, 'index', index, false), J$.R(2809, 'lineStart', lineStart, false))
                                                            }, 11));
                                                            J$.F(2845, J$.R(2821, 'addComment', addComment, false), false)(J$.T(2825, 'Block', 21), J$.R(2829, 'comment', comment, false), J$.R(2833, 'start', start, false), J$.R(2837, 'index', index, false), J$.R(2841, 'loc', loc, false));
                                                        }
                                                        return J$.Rt(2849, undefined);
                                                    }
                                                    index = J$.W(2857, 'index', J$.B(482, '+', J$.U(478, '+', J$.R(2853, 'index', index, false)), 1), index);
                                                } else {
                                                    index = J$.W(2865, 'index', J$.B(490, '+', J$.U(486, '+', J$.R(2861, 'index', index, false)), 1), index);
                                                }
                                            }
                                            J$.F(2889, J$.R(2869, 'throwError', throwError, false), false)(J$.T(2873, {}, 11), J$.G(2881, J$.R(2877, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(2885, 'ILLEGAL', 21));
                                        } catch (J$e) {
                                            J$.Ex(29021, J$e);
                                        } finally {
                                            if (J$.Fr(29025))
                                                continue jalangiLabel15;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function skipComment() {
                                jalangiLabel16:
                                    while (true) {
                                        try {
                                            J$.Fe(3297, arguments.callee, this);
                                            arguments = J$.N(3301, 'arguments', arguments, true);
                                            J$.N(3305, 'ch', ch, false);
                                            J$.N(3309, 'start', start, false);
                                            var ch, start;
                                            start = J$.W(2925, 'start', J$.B(494, '===', J$.R(2917, 'index', index, false), J$.T(2921, 0, 22)), start);
                                            while (J$.C(472, J$.B(498, '<', J$.R(2929, 'index', index, false), J$.R(2933, 'length', length, false)))) {
                                                ch = J$.W(2949, 'ch', J$.M(2945, J$.R(2937, 'source', source, false), 'charCodeAt', false)(J$.R(2941, 'index', index, false)), ch);
                                                if (J$.C(468, J$.F(2961, J$.R(2953, 'isWhiteSpace', isWhiteSpace, false), false)(J$.R(2957, 'ch', ch, false)))) {
                                                    index = J$.W(2969, 'index', J$.B(506, '+', J$.U(502, '+', J$.R(2965, 'index', index, false)), 1), index);
                                                } else if (J$.C(464, J$.F(2981, J$.R(2973, 'isLineTerminator', isLineTerminator, false), false)(J$.R(2977, 'ch', ch, false)))) {
                                                    index = J$.W(2989, 'index', J$.B(514, '+', J$.U(510, '+', J$.R(2985, 'index', index, false)), 1), index);
                                                    if (J$.C(424, J$.C(420, J$.B(518, '===', J$.R(2993, 'ch', ch, false), J$.T(2997, 13, 22))) ? J$.B(522, '===', J$.M(3009, J$.R(3001, 'source', source, false), 'charCodeAt', false)(J$.R(3005, 'index', index, false)), J$.T(3013, 10, 22)) : J$._())) {
                                                        index = J$.W(3021, 'index', J$.B(530, '+', J$.U(526, '+', J$.R(3017, 'index', index, false)), 1), index);
                                                    }
                                                    lineNumber = J$.W(3029, 'lineNumber', J$.B(538, '+', J$.U(534, '+', J$.R(3025, 'lineNumber', lineNumber, false)), 1), lineNumber);
                                                    lineStart = J$.W(3037, 'lineStart', J$.R(3033, 'index', index, false), lineStart);
                                                    start = J$.W(3045, 'start', J$.T(3041, true, 23), start);
                                                } else if (J$.C(460, J$.B(542, '===', J$.R(3049, 'ch', ch, false), J$.T(3053, 47, 22)))) {
                                                    ch = J$.W(3073, 'ch', J$.M(3069, J$.R(3057, 'source', source, false), 'charCodeAt', false)(J$.B(546, '+', J$.R(3061, 'index', index, false), J$.T(3065, 1, 22))), ch);
                                                    if (J$.C(432, J$.B(550, '===', J$.R(3077, 'ch', ch, false), J$.T(3081, 47, 22)))) {
                                                        index = J$.W(3089, 'index', J$.B(558, '+', J$.U(554, '+', J$.R(3085, 'index', index, false)), 1), index);
                                                        index = J$.W(3097, 'index', J$.B(566, '+', J$.U(562, '+', J$.R(3093, 'index', index, false)), 1), index);
                                                        J$.F(3105, J$.R(3101, 'skipSingleLineComment', skipSingleLineComment, false), false)();
                                                        start = J$.W(3113, 'start', J$.T(3109, true, 23), start);
                                                    } else if (J$.C(428, J$.B(570, '===', J$.R(3117, 'ch', ch, false), J$.T(3121, 42, 22)))) {
                                                        index = J$.W(3129, 'index', J$.B(578, '+', J$.U(574, '+', J$.R(3125, 'index', index, false)), 1), index);
                                                        index = J$.W(3137, 'index', J$.B(586, '+', J$.U(582, '+', J$.R(3133, 'index', index, false)), 1), index);
                                                        J$.F(3145, J$.R(3141, 'skipMultiLineComment', skipMultiLineComment, false), false)();
                                                    } else {
                                                        break;
                                                    }
                                                } else if (J$.C(456, J$.C(436, J$.R(3149, 'start', start, false)) ? J$.B(590, '===', J$.R(3153, 'ch', ch, false), J$.T(3157, 45, 22)) : J$._())) {
                                                    if (J$.C(444, J$.C(440, J$.B(598, '===', J$.M(3173, J$.R(3161, 'source', source, false), 'charCodeAt', false)(J$.B(594, '+', J$.R(3165, 'index', index, false), J$.T(3169, 1, 22))), J$.T(3177, 45, 22))) ? J$.B(606, '===', J$.M(3193, J$.R(3181, 'source', source, false), 'charCodeAt', false)(J$.B(602, '+', J$.R(3185, 'index', index, false), J$.T(3189, 2, 22))), J$.T(3197, 62, 22)) : J$._())) {
                                                        index = J$.W(3209, 'index', J$.B(610, '+', J$.R(3205, 'index', index, false), J$.T(3201, 3, 22)), index);
                                                        J$.F(3217, J$.R(3213, 'skipSingleLineComment', skipSingleLineComment, false), false)();
                                                    } else {
                                                        break;
                                                    }
                                                } else if (J$.C(452, J$.B(614, '===', J$.R(3221, 'ch', ch, false), J$.T(3225, 60, 22)))) {
                                                    if (J$.C(448, J$.B(626, '===', J$.M(3249, J$.R(3229, 'source', source, false), 'slice', false)(J$.B(618, '+', J$.R(3233, 'index', index, false), J$.T(3237, 1, 22)), J$.B(622, '+', J$.R(3241, 'index', index, false), J$.T(3245, 4, 22))), J$.T(3253, '!--', 21)))) {
                                                        index = J$.W(3261, 'index', J$.B(634, '+', J$.U(630, '+', J$.R(3257, 'index', index, false)), 1), index);
                                                        index = J$.W(3269, 'index', J$.B(642, '+', J$.U(638, '+', J$.R(3265, 'index', index, false)), 1), index);
                                                        index = J$.W(3277, 'index', J$.B(650, '+', J$.U(646, '+', J$.R(3273, 'index', index, false)), 1), index);
                                                        index = J$.W(3285, 'index', J$.B(658, '+', J$.U(654, '+', J$.R(3281, 'index', index, false)), 1), index);
                                                        J$.F(3293, J$.R(3289, 'skipSingleLineComment', skipSingleLineComment, false), false)();
                                                    } else {
                                                        break;
                                                    }
                                                } else {
                                                    break;
                                                }
                                            }
                                        } catch (J$e) {
                                            J$.Ex(29029, J$e);
                                        } finally {
                                            if (J$.Fr(29033))
                                                continue jalangiLabel16;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function scanHexEscape(prefix) {
                                jalangiLabel17:
                                    while (true) {
                                        try {
                                            J$.Fe(3465, arguments.callee, this);
                                            arguments = J$.N(3469, 'arguments', arguments, true);
                                            prefix = J$.N(3473, 'prefix', prefix, true);
                                            J$.N(3477, 'i', i, false);
                                            J$.N(3481, 'len', len, false);
                                            J$.N(3485, 'ch', ch, false);
                                            J$.N(3489, 'code', code, false);
                                            var i, len, ch, code = J$.W(3317, 'code', J$.T(3313, 0, 22), code);
                                            len = J$.W(3337, 'len', J$.C(476, J$.B(662, '===', J$.R(3321, 'prefix', prefix, false), J$.T(3325, 'u', 21))) ? J$.T(3329, 4, 22) : J$.T(3333, 2, 22), len);
                                            for (i = J$.W(3345, 'i', J$.T(3341, 0, 22), i); J$.C(488, J$.B(666, '<', J$.R(3349, 'i', i, false), J$.R(3353, 'len', len, false))); i = J$.W(3361, 'i', J$.B(674, '+', J$.U(670, '+', J$.R(3357, 'i', i, false)), 1), i)) {
                                                if (J$.C(484, J$.C(480, J$.B(678, '<', J$.R(3365, 'index', index, false), J$.R(3369, 'length', length, false))) ? J$.F(3389, J$.R(3373, 'isHexDigit', isHexDigit, false), false)(J$.G(3385, J$.R(3377, 'source', source, false), J$.R(3381, 'index', index, false))) : J$._())) {
                                                    ch = J$.W(3409, 'ch', J$.G(3405, J$.R(3393, 'source', source, false), J$.B(690, '-', index = J$.W(3401, 'index', J$.B(686, '+', J$.U(682, '+', J$.R(3397, 'index', index, false)), 1), index), 1)), ch);
                                                    code = J$.W(3437, 'code', J$.B(698, '+', J$.B(694, '*', J$.R(3413, 'code', code, false), J$.T(3417, 16, 22)), J$.M(3433, J$.T(3421, '0123456789abcdef', 21), 'indexOf', false)(J$.M(3429, J$.R(3425, 'ch', ch, false), 'toLowerCase', false)())), code);
                                                } else {
                                                    return J$.Rt(3445, J$.T(3441, '', 21));
                                                }
                                            }
                                            return J$.Rt(3461, J$.M(3457, J$.I(typeof String === 'undefined' ? String = J$.R(3449, 'String', undefined, true) : String = J$.R(3449, 'String', String, true)), 'fromCharCode', false)(J$.R(3453, 'code', code, false)));
                                        } catch (J$e) {
                                            J$.Ex(29037, J$e);
                                        } finally {
                                            if (J$.Fr(29041))
                                                continue jalangiLabel17;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function getEscapedIdentifier() {
                                jalangiLabel18:
                                    while (true) {
                                        try {
                                            J$.Fe(3905, arguments.callee, this);
                                            arguments = J$.N(3909, 'arguments', arguments, true);
                                            J$.N(3913, 'ch', ch, false);
                                            J$.N(3917, 'id', id, false);
                                            var ch, id;
                                            ch = J$.W(3509, 'ch', J$.M(3505, J$.R(3493, 'source', source, false), 'charCodeAt', false)(J$.B(710, '-', index = J$.W(3501, 'index', J$.B(706, '+', J$.U(702, '+', J$.R(3497, 'index', index, false)), 1), index), 1)), ch);
                                            id = J$.W(3525, 'id', J$.M(3521, J$.I(typeof String === 'undefined' ? String = J$.R(3513, 'String', undefined, true) : String = J$.R(3513, 'String', String, true)), 'fromCharCode', false)(J$.R(3517, 'ch', ch, false)), id);
                                            if (J$.C(508, J$.B(714, '===', J$.R(3529, 'ch', ch, false), J$.T(3533, 92, 22)))) {
                                                if (J$.C(492, J$.B(718, '!==', J$.M(3545, J$.R(3537, 'source', source, false), 'charCodeAt', false)(J$.R(3541, 'index', index, false)), J$.T(3549, 117, 22)))) {
                                                    J$.F(3573, J$.R(3553, 'throwError', throwError, false), false)(J$.T(3557, {}, 11), J$.G(3565, J$.R(3561, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(3569, 'ILLEGAL', 21));
                                                }
                                                index = J$.W(3581, 'index', J$.B(726, '+', J$.U(722, '+', J$.R(3577, 'index', index, false)), 1), index);
                                                ch = J$.W(3597, 'ch', J$.F(3593, J$.R(3585, 'scanHexEscape', scanHexEscape, false), false)(J$.T(3589, 'u', 21)), ch);
                                                if (J$.C(504, J$.C(500, J$.C(496, J$.U(730, '!', J$.R(3601, 'ch', ch, false))) ? J$._() : J$.B(734, '===', J$.R(3605, 'ch', ch, false), J$.T(3609, '\\', 21))) ? J$._() : J$.U(738, '!', J$.F(3629, J$.R(3613, 'isIdentifierStart', isIdentifierStart, false), false)(J$.M(3625, J$.R(3617, 'ch', ch, false), 'charCodeAt', false)(J$.T(3621, 0, 22)))))) {
                                                    J$.F(3653, J$.R(3633, 'throwError', throwError, false), false)(J$.T(3637, {}, 11), J$.G(3645, J$.R(3641, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(3649, 'ILLEGAL', 21));
                                                }
                                                id = J$.W(3661, 'id', J$.R(3657, 'ch', ch, false), id);
                                            }
                                            while (J$.C(536, J$.B(742, '<', J$.R(3665, 'index', index, false), J$.R(3669, 'length', length, false)))) {
                                                ch = J$.W(3685, 'ch', J$.M(3681, J$.R(3673, 'source', source, false), 'charCodeAt', false)(J$.R(3677, 'index', index, false)), ch);
                                                if (J$.C(512, J$.U(746, '!', J$.F(3697, J$.R(3689, 'isIdentifierPart', isIdentifierPart, false), false)(J$.R(3693, 'ch', ch, false))))) {
                                                    break;
                                                }
                                                index = J$.W(3705, 'index', J$.B(754, '+', J$.U(750, '+', J$.R(3701, 'index', index, false)), 1), index);
                                                id = J$.W(3725, 'id', J$.B(758, '+', J$.R(3721, 'id', id, false), J$.M(3717, J$.I(typeof String === 'undefined' ? String = J$.R(3709, 'String', undefined, true) : String = J$.R(3709, 'String', String, true)), 'fromCharCode', false)(J$.R(3713, 'ch', ch, false))), id);
                                                if (J$.C(532, J$.B(762, '===', J$.R(3729, 'ch', ch, false), J$.T(3733, 92, 22)))) {
                                                    id = J$.W(3761, 'id', J$.M(3757, J$.R(3737, 'id', id, false), 'substr', false)(J$.T(3741, 0, 22), J$.B(766, '-', J$.G(3749, J$.R(3745, 'id', id, false), 'length'), J$.T(3753, 1, 22))), id);
                                                    if (J$.C(516, J$.B(770, '!==', J$.M(3773, J$.R(3765, 'source', source, false), 'charCodeAt', false)(J$.R(3769, 'index', index, false)), J$.T(3777, 117, 22)))) {
                                                        J$.F(3801, J$.R(3781, 'throwError', throwError, false), false)(J$.T(3785, {}, 11), J$.G(3793, J$.R(3789, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(3797, 'ILLEGAL', 21));
                                                    }
                                                    index = J$.W(3809, 'index', J$.B(778, '+', J$.U(774, '+', J$.R(3805, 'index', index, false)), 1), index);
                                                    ch = J$.W(3825, 'ch', J$.F(3821, J$.R(3813, 'scanHexEscape', scanHexEscape, false), false)(J$.T(3817, 'u', 21)), ch);
                                                    if (J$.C(528, J$.C(524, J$.C(520, J$.U(782, '!', J$.R(3829, 'ch', ch, false))) ? J$._() : J$.B(786, '===', J$.R(3833, 'ch', ch, false), J$.T(3837, '\\', 21))) ? J$._() : J$.U(790, '!', J$.F(3857, J$.R(3841, 'isIdentifierPart', isIdentifierPart, false), false)(J$.M(3853, J$.R(3845, 'ch', ch, false), 'charCodeAt', false)(J$.T(3849, 0, 22)))))) {
                                                        J$.F(3881, J$.R(3861, 'throwError', throwError, false), false)(J$.T(3865, {}, 11), J$.G(3873, J$.R(3869, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(3877, 'ILLEGAL', 21));
                                                    }
                                                    id = J$.W(3893, 'id', J$.B(794, '+', J$.R(3889, 'id', id, false), J$.R(3885, 'ch', ch, false)), id);
                                                }
                                            }
                                            return J$.Rt(3901, J$.R(3897, 'id', id, false));
                                        } catch (J$e) {
                                            J$.Ex(29045, J$e);
                                        } finally {
                                            if (J$.Fr(29049))
                                                continue jalangiLabel18;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function getIdentifier() {
                                jalangiLabel19:
                                    while (true) {
                                        try {
                                            J$.Fe(4025, arguments.callee, this);
                                            arguments = J$.N(4029, 'arguments', arguments, true);
                                            J$.N(4033, 'start', start, false);
                                            J$.N(4037, 'ch', ch, false);
                                            var start, ch;
                                            start = J$.W(3929, 'start', J$.B(806, '-', index = J$.W(3925, 'index', J$.B(802, '+', J$.U(798, '+', J$.R(3921, 'index', index, false)), 1), index), 1), start);
                                            while (J$.C(548, J$.B(810, '<', J$.R(3933, 'index', index, false), J$.R(3937, 'length', length, false)))) {
                                                ch = J$.W(3953, 'ch', J$.M(3949, J$.R(3941, 'source', source, false), 'charCodeAt', false)(J$.R(3945, 'index', index, false)), ch);
                                                if (J$.C(540, J$.B(814, '===', J$.R(3957, 'ch', ch, false), J$.T(3961, 92, 22)))) {
                                                    index = J$.W(3969, 'index', J$.R(3965, 'start', start, false), index);
                                                    return J$.Rt(3981, J$.F(3977, J$.R(3973, 'getEscapedIdentifier', getEscapedIdentifier, false), false)());
                                                }
                                                if (J$.C(544, J$.F(3993, J$.R(3985, 'isIdentifierPart', isIdentifierPart, false), false)(J$.R(3989, 'ch', ch, false)))) {
                                                    index = J$.W(4001, 'index', J$.B(822, '+', J$.U(818, '+', J$.R(3997, 'index', index, false)), 1), index);
                                                } else {
                                                    break;
                                                }
                                            }
                                            return J$.Rt(4021, J$.M(4017, J$.R(4005, 'source', source, false), 'slice', false)(J$.R(4009, 'start', start, false), J$.R(4013, 'index', index, false)));
                                        } catch (J$e) {
                                            J$.Ex(29053, J$e);
                                        } finally {
                                            if (J$.Fr(29057))
                                                continue jalangiLabel19;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function scanIdentifier() {
                                jalangiLabel20:
                                    while (true) {
                                        try {
                                            J$.Fe(4229, arguments.callee, this);
                                            arguments = J$.N(4233, 'arguments', arguments, true);
                                            J$.N(4237, 'start', start, false);
                                            J$.N(4241, 'id', id, false);
                                            J$.N(4245, 'type', type, false);
                                            var start, id, type;
                                            start = J$.W(4045, 'start', J$.R(4041, 'index', index, false), start);
                                            id = J$.W(4081, 'id', J$.C(552, J$.B(826, '===', J$.M(4057, J$.R(4049, 'source', source, false), 'charCodeAt', false)(J$.R(4053, 'index', index, false)), J$.T(4061, 92, 22))) ? J$.F(4069, J$.R(4065, 'getEscapedIdentifier', getEscapedIdentifier, false), false)() : J$.F(4077, J$.R(4073, 'getIdentifier', getIdentifier, false), false)(), id);
                                            if (J$.C(572, J$.B(830, '===', J$.G(4089, J$.R(4085, 'id', id, false), 'length'), J$.T(4093, 1, 22)))) {
                                                type = J$.W(4105, 'type', J$.G(4101, J$.R(4097, 'Token', Token, false), 'Identifier'), type);
                                            } else if (J$.C(568, J$.F(4117, J$.R(4109, 'isKeyword', isKeyword, false), false)(J$.R(4113, 'id', id, false)))) {
                                                type = J$.W(4129, 'type', J$.G(4125, J$.R(4121, 'Token', Token, false), 'Keyword'), type);
                                            } else if (J$.C(564, J$.B(834, '===', J$.R(4133, 'id', id, false), J$.T(4137, 'null', 21)))) {
                                                type = J$.W(4149, 'type', J$.G(4145, J$.R(4141, 'Token', Token, false), 'NullLiteral'), type);
                                            } else if (J$.C(560, J$.C(556, J$.B(838, '===', J$.R(4153, 'id', id, false), J$.T(4157, 'true', 21))) ? J$._() : J$.B(842, '===', J$.R(4161, 'id', id, false), J$.T(4165, 'false', 21)))) {
                                                type = J$.W(4177, 'type', J$.G(4173, J$.R(4169, 'Token', Token, false), 'BooleanLiteral'), type);
                                            } else {
                                                type = J$.W(4189, 'type', J$.G(4185, J$.R(4181, 'Token', Token, false), 'Identifier'), type);
                                            }
                                            return J$.Rt(4225, J$.T(4221, {
                                                type: J$.R(4193, 'type', type, false),
                                                value: J$.R(4197, 'id', id, false),
                                                lineNumber: J$.R(4201, 'lineNumber', lineNumber, false),
                                                lineStart: J$.R(4205, 'lineStart', lineStart, false),
                                                range: J$.T(4217, [
                                                    J$.R(4209, 'start', start, false),
                                                    J$.R(4213, 'index', index, false)
                                                ], 10)
                                            }, 11));
                                        } catch (J$e) {
                                            J$.Ex(29061, J$e);
                                        } finally {
                                            if (J$.Fr(29065))
                                                continue jalangiLabel20;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function scanPunctuator() {
                                jalangiLabel21:
                                    while (true) {
                                        try {
                                            J$.Fe(5241, arguments.callee, this);
                                            arguments = J$.N(5245, 'arguments', arguments, true);
                                            J$.N(5249, 'start', start, false);
                                            J$.N(5253, 'code', code, false);
                                            J$.N(5257, 'code2', code2, false);
                                            J$.N(5261, 'ch1', ch1, false);
                                            J$.N(5265, 'ch2', ch2, false);
                                            J$.N(5269, 'ch3', ch3, false);
                                            J$.N(5273, 'ch4', ch4, false);
                                            var start = J$.W(4277, 'start', J$.R(4249, 'index', index, false), start), code = J$.W(4281, 'code', J$.M(4261, J$.R(4253, 'source', source, false), 'charCodeAt', false)(J$.R(4257, 'index', index, false)), code), code2, ch1 = J$.W(4285, 'ch1', J$.G(4273, J$.R(4265, 'source', source, false), J$.R(4269, 'index', index, false)), ch1), ch2, ch3, ch4;
                                            switch (J$.C1(648, J$.R(4289, 'code', code, false))) {
                                            case J$.C2(652, J$.T(4293, 46, 22)):
                                            case J$.C2(656, J$.T(4297, 40, 22)):
                                            case J$.C2(660, J$.T(4301, 41, 22)):
                                            case J$.C2(664, J$.T(4305, 59, 22)):
                                            case J$.C2(668, J$.T(4309, 44, 22)):
                                            case J$.C2(672, J$.T(4313, 123, 22)):
                                            case J$.C2(676, J$.T(4317, 125, 22)):
                                            case J$.C2(680, J$.T(4321, 91, 22)):
                                            case J$.C2(684, J$.T(4325, 93, 22)):
                                            case J$.C2(688, J$.T(4329, 58, 22)):
                                            case J$.C2(692, J$.T(4333, 63, 22)):
                                            case J$.C2(696, J$.T(4457, 126, 22)):
                                                index = J$.W(4341, 'index', J$.B(850, '+', J$.U(846, '+', J$.R(4337, 'index', index, false)), 1), index);
                                                if (J$.C(584, J$.G(4349, J$.R(4345, 'extra', extra, false), 'tokenize'))) {
                                                    if (J$.C(580, J$.B(854, '===', J$.R(4353, 'code', code, false), J$.T(4357, 40, 22)))) {
                                                        J$.P(4377, J$.R(4361, 'extra', extra, false), 'openParenToken', J$.G(4373, J$.G(4369, J$.R(4365, 'extra', extra, false), 'tokens'), 'length'));
                                                    } else if (J$.C(576, J$.B(858, '===', J$.R(4381, 'code', code, false), J$.T(4385, 123, 22)))) {
                                                        J$.P(4405, J$.R(4389, 'extra', extra, false), 'openCurlyToken', J$.G(4401, J$.G(4397, J$.R(4393, 'extra', extra, false), 'tokens'), 'length'));
                                                    }
                                                }
                                                return J$.Rt(4453, J$.T(4449, {
                                                    type: J$.G(4413, J$.R(4409, 'Token', Token, false), 'Punctuator'),
                                                    value: J$.M(4425, J$.I(typeof String === 'undefined' ? String = J$.R(4417, 'String', undefined, true) : String = J$.R(4417, 'String', String, true)), 'fromCharCode', false)(J$.R(4421, 'code', code, false)),
                                                    lineNumber: J$.R(4429, 'lineNumber', lineNumber, false),
                                                    lineStart: J$.R(4433, 'lineStart', lineStart, false),
                                                    range: J$.T(4445, [
                                                        J$.R(4437, 'start', start, false),
                                                        J$.R(4441, 'index', index, false)
                                                    ], 10)
                                                }, 11));
                                            default:
                                                code2 = J$.W(4477, 'code2', J$.M(4473, J$.R(4461, 'source', source, false), 'charCodeAt', false)(J$.B(862, '+', J$.R(4465, 'index', index, false), J$.T(4469, 1, 22))), code2);
                                                if (J$.C(644, J$.B(866, '===', J$.R(4481, 'code2', code2, false), J$.T(4485, 61, 22)))) {
                                                    switch (J$.C1(592, J$.R(4489, 'code', code, false))) {
                                                    case J$.C2(596, J$.T(4493, 37, 22)):
                                                    case J$.C2(600, J$.T(4497, 38, 22)):
                                                    case J$.C2(604, J$.T(4501, 42, 22)):
                                                    case J$.C2(608, J$.T(4505, 43, 22)):
                                                    case J$.C2(612, J$.T(4509, 45, 22)):
                                                    case J$.C2(616, J$.T(4513, 47, 22)):
                                                    case J$.C2(620, J$.T(4517, 60, 22)):
                                                    case J$.C2(624, J$.T(4521, 62, 22)):
                                                    case J$.C2(628, J$.T(4525, 94, 22)):
                                                    case J$.C2(632, J$.T(4601, 124, 22)):
                                                        index = J$.W(4537, 'index', J$.B(870, '+', J$.R(4533, 'index', index, false), J$.T(4529, 2, 22)), index);
                                                        return J$.Rt(4597, J$.T(4593, {
                                                            type: J$.G(4545, J$.R(4541, 'Token', Token, false), 'Punctuator'),
                                                            value: J$.B(874, '+', J$.M(4557, J$.I(typeof String === 'undefined' ? String = J$.R(4549, 'String', undefined, true) : String = J$.R(4549, 'String', String, true)), 'fromCharCode', false)(J$.R(4553, 'code', code, false)), J$.M(4569, J$.I(typeof String === 'undefined' ? String = J$.R(4561, 'String', undefined, true) : String = J$.R(4561, 'String', String, true)), 'fromCharCode', false)(J$.R(4565, 'code2', code2, false))),
                                                            lineNumber: J$.R(4573, 'lineNumber', lineNumber, false),
                                                            lineStart: J$.R(4577, 'lineStart', lineStart, false),
                                                            range: J$.T(4589, [
                                                                J$.R(4581, 'start', start, false),
                                                                J$.R(4585, 'index', index, false)
                                                            ], 10)
                                                        }, 11));
                                                    case J$.C2(636, J$.T(4605, 33, 22)):
                                                    case J$.C2(640, J$.T(4697, 61, 22)):
                                                        index = J$.W(4617, 'index', J$.B(878, '+', J$.R(4613, 'index', index, false), J$.T(4609, 2, 22)), index);
                                                        if (J$.C(588, J$.B(882, '===', J$.M(4629, J$.R(4621, 'source', source, false), 'charCodeAt', false)(J$.R(4625, 'index', index, false)), J$.T(4633, 61, 22)))) {
                                                            index = J$.W(4641, 'index', J$.B(890, '+', J$.U(886, '+', J$.R(4637, 'index', index, false)), 1), index);
                                                        }
                                                        return J$.Rt(4693, J$.T(4689, {
                                                            type: J$.G(4649, J$.R(4645, 'Token', Token, false), 'Punctuator'),
                                                            value: J$.M(4665, J$.R(4653, 'source', source, false), 'slice', false)(J$.R(4657, 'start', start, false), J$.R(4661, 'index', index, false)),
                                                            lineNumber: J$.R(4669, 'lineNumber', lineNumber, false),
                                                            lineStart: J$.R(4673, 'lineStart', lineStart, false),
                                                            range: J$.T(4685, [
                                                                J$.R(4677, 'start', start, false),
                                                                J$.R(4681, 'index', index, false)
                                                            ], 10)
                                                        }, 11));
                                                    default:
                                                        break;
                                                    }
                                                }
                                                break;
                                            }
                                            ch2 = J$.W(4717, 'ch2', J$.G(4713, J$.R(4701, 'source', source, false), J$.B(894, '+', J$.R(4705, 'index', index, false), J$.T(4709, 1, 22))), ch2);
                                            ch3 = J$.W(4737, 'ch3', J$.G(4733, J$.R(4721, 'source', source, false), J$.B(898, '+', J$.R(4725, 'index', index, false), J$.T(4729, 2, 22))), ch3);
                                            ch4 = J$.W(4757, 'ch4', J$.G(4753, J$.R(4741, 'source', source, false), J$.B(902, '+', J$.R(4745, 'index', index, false), J$.T(4749, 3, 22))), ch4);
                                            if (J$.C(712, J$.C(704, J$.C(700, J$.B(906, '===', J$.R(4761, 'ch1', ch1, false), J$.T(4765, '>', 21))) ? J$.B(910, '===', J$.R(4769, 'ch2', ch2, false), J$.T(4773, '>', 21)) : J$._()) ? J$.B(914, '===', J$.R(4777, 'ch3', ch3, false), J$.T(4781, '>', 21)) : J$._())) {
                                                if (J$.C(708, J$.B(918, '===', J$.R(4785, 'ch4', ch4, false), J$.T(4789, '=', 21)))) {
                                                    index = J$.W(4801, 'index', J$.B(922, '+', J$.R(4797, 'index', index, false), J$.T(4793, 4, 22)), index);
                                                    return J$.Rt(4841, J$.T(4837, {
                                                        type: J$.G(4809, J$.R(4805, 'Token', Token, false), 'Punctuator'),
                                                        value: J$.T(4813, '>>>=', 21),
                                                        lineNumber: J$.R(4817, 'lineNumber', lineNumber, false),
                                                        lineStart: J$.R(4821, 'lineStart', lineStart, false),
                                                        range: J$.T(4833, [
                                                            J$.R(4825, 'start', start, false),
                                                            J$.R(4829, 'index', index, false)
                                                        ], 10)
                                                    }, 11));
                                                }
                                            }
                                            if (J$.C(724, J$.C(720, J$.C(716, J$.B(926, '===', J$.R(4845, 'ch1', ch1, false), J$.T(4849, '>', 21))) ? J$.B(930, '===', J$.R(4853, 'ch2', ch2, false), J$.T(4857, '>', 21)) : J$._()) ? J$.B(934, '===', J$.R(4861, 'ch3', ch3, false), J$.T(4865, '>', 21)) : J$._())) {
                                                index = J$.W(4877, 'index', J$.B(938, '+', J$.R(4873, 'index', index, false), J$.T(4869, 3, 22)), index);
                                                return J$.Rt(4917, J$.T(4913, {
                                                    type: J$.G(4885, J$.R(4881, 'Token', Token, false), 'Punctuator'),
                                                    value: J$.T(4889, '>>>', 21),
                                                    lineNumber: J$.R(4893, 'lineNumber', lineNumber, false),
                                                    lineStart: J$.R(4897, 'lineStart', lineStart, false),
                                                    range: J$.T(4909, [
                                                        J$.R(4901, 'start', start, false),
                                                        J$.R(4905, 'index', index, false)
                                                    ], 10)
                                                }, 11));
                                            }
                                            if (J$.C(736, J$.C(732, J$.C(728, J$.B(942, '===', J$.R(4921, 'ch1', ch1, false), J$.T(4925, '<', 21))) ? J$.B(946, '===', J$.R(4929, 'ch2', ch2, false), J$.T(4933, '<', 21)) : J$._()) ? J$.B(950, '===', J$.R(4937, 'ch3', ch3, false), J$.T(4941, '=', 21)) : J$._())) {
                                                index = J$.W(4953, 'index', J$.B(954, '+', J$.R(4949, 'index', index, false), J$.T(4945, 3, 22)), index);
                                                return J$.Rt(4993, J$.T(4989, {
                                                    type: J$.G(4961, J$.R(4957, 'Token', Token, false), 'Punctuator'),
                                                    value: J$.T(4965, '<<=', 21),
                                                    lineNumber: J$.R(4969, 'lineNumber', lineNumber, false),
                                                    lineStart: J$.R(4973, 'lineStart', lineStart, false),
                                                    range: J$.T(4985, [
                                                        J$.R(4977, 'start', start, false),
                                                        J$.R(4981, 'index', index, false)
                                                    ], 10)
                                                }, 11));
                                            }
                                            if (J$.C(748, J$.C(744, J$.C(740, J$.B(958, '===', J$.R(4997, 'ch1', ch1, false), J$.T(5001, '>', 21))) ? J$.B(962, '===', J$.R(5005, 'ch2', ch2, false), J$.T(5009, '>', 21)) : J$._()) ? J$.B(966, '===', J$.R(5013, 'ch3', ch3, false), J$.T(5017, '=', 21)) : J$._())) {
                                                index = J$.W(5029, 'index', J$.B(970, '+', J$.R(5025, 'index', index, false), J$.T(5021, 3, 22)), index);
                                                return J$.Rt(5069, J$.T(5065, {
                                                    type: J$.G(5037, J$.R(5033, 'Token', Token, false), 'Punctuator'),
                                                    value: J$.T(5041, '>>=', 21),
                                                    lineNumber: J$.R(5045, 'lineNumber', lineNumber, false),
                                                    lineStart: J$.R(5049, 'lineStart', lineStart, false),
                                                    range: J$.T(5061, [
                                                        J$.R(5053, 'start', start, false),
                                                        J$.R(5057, 'index', index, false)
                                                    ], 10)
                                                }, 11));
                                            }
                                            if (J$.C(756, J$.C(752, J$.B(974, '===', J$.R(5073, 'ch1', ch1, false), J$.R(5077, 'ch2', ch2, false))) ? J$.B(978, '>=', J$.M(5089, J$.T(5081, '+-<>&|', 21), 'indexOf', false)(J$.R(5085, 'ch1', ch1, false)), J$.T(5093, 0, 22)) : J$._())) {
                                                index = J$.W(5105, 'index', J$.B(982, '+', J$.R(5101, 'index', index, false), J$.T(5097, 2, 22)), index);
                                                return J$.Rt(5149, J$.T(5145, {
                                                    type: J$.G(5113, J$.R(5109, 'Token', Token, false), 'Punctuator'),
                                                    value: J$.B(986, '+', J$.R(5117, 'ch1', ch1, false), J$.R(5121, 'ch2', ch2, false)),
                                                    lineNumber: J$.R(5125, 'lineNumber', lineNumber, false),
                                                    lineStart: J$.R(5129, 'lineStart', lineStart, false),
                                                    range: J$.T(5141, [
                                                        J$.R(5133, 'start', start, false),
                                                        J$.R(5137, 'index', index, false)
                                                    ], 10)
                                                }, 11));
                                            }
                                            if (J$.C(760, J$.B(990, '>=', J$.M(5161, J$.T(5153, '<>=!+-*%&|^/', 21), 'indexOf', false)(J$.R(5157, 'ch1', ch1, false)), J$.T(5165, 0, 22)))) {
                                                index = J$.W(5173, 'index', J$.B(998, '+', J$.U(994, '+', J$.R(5169, 'index', index, false)), 1), index);
                                                return J$.Rt(5213, J$.T(5209, {
                                                    type: J$.G(5181, J$.R(5177, 'Token', Token, false), 'Punctuator'),
                                                    value: J$.R(5185, 'ch1', ch1, false),
                                                    lineNumber: J$.R(5189, 'lineNumber', lineNumber, false),
                                                    lineStart: J$.R(5193, 'lineStart', lineStart, false),
                                                    range: J$.T(5205, [
                                                        J$.R(5197, 'start', start, false),
                                                        J$.R(5201, 'index', index, false)
                                                    ], 10)
                                                }, 11));
                                            }
                                            J$.F(5237, J$.R(5217, 'throwError', throwError, false), false)(J$.T(5221, {}, 11), J$.G(5229, J$.R(5225, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(5233, 'ILLEGAL', 21));
                                        } catch (J$e) {
                                            J$.Ex(29069, J$e);
                                        } finally {
                                            if (J$.Fr(29073))
                                                continue jalangiLabel21;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function scanHexLiteral(start) {
                                jalangiLabel22:
                                    while (true) {
                                        try {
                                            J$.Fe(5473, arguments.callee, this);
                                            arguments = J$.N(5477, 'arguments', arguments, true);
                                            start = J$.N(5481, 'start', start, true);
                                            J$.N(5485, 'number', number, false);
                                            var number = J$.W(5281, 'number', J$.T(5277, '', 21), number);
                                            while (J$.C(768, J$.B(1002, '<', J$.R(5285, 'index', index, false), J$.R(5289, 'length', length, false)))) {
                                                if (J$.C(764, J$.U(1006, '!', J$.F(5309, J$.R(5293, 'isHexDigit', isHexDigit, false), false)(J$.G(5305, J$.R(5297, 'source', source, false), J$.R(5301, 'index', index, false)))))) {
                                                    break;
                                                }
                                                number = J$.W(5333, 'number', J$.B(1022, '+', J$.R(5329, 'number', number, false), J$.G(5325, J$.R(5313, 'source', source, false), J$.B(1018, '-', index = J$.W(5321, 'index', J$.B(1014, '+', J$.U(1010, '+', J$.R(5317, 'index', index, false)), 1), index), 1))), number);
                                            }
                                            if (J$.C(772, J$.B(1026, '===', J$.G(5341, J$.R(5337, 'number', number, false), 'length'), J$.T(5345, 0, 22)))) {
                                                J$.F(5369, J$.R(5349, 'throwError', throwError, false), false)(J$.T(5353, {}, 11), J$.G(5361, J$.R(5357, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(5365, 'ILLEGAL', 21));
                                            }
                                            if (J$.C(776, J$.F(5389, J$.R(5373, 'isIdentifierStart', isIdentifierStart, false), false)(J$.M(5385, J$.R(5377, 'source', source, false), 'charCodeAt', false)(J$.R(5381, 'index', index, false))))) {
                                                J$.F(5413, J$.R(5393, 'throwError', throwError, false), false)(J$.T(5397, {}, 11), J$.G(5405, J$.R(5401, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(5409, 'ILLEGAL', 21));
                                            }
                                            return J$.Rt(5469, J$.T(5465, {
                                                type: J$.G(5421, J$.R(5417, 'Token', Token, false), 'NumericLiteral'),
                                                value: J$.F(5441, J$.I(typeof parseInt === 'undefined' ? parseInt = J$.R(5425, 'parseInt', undefined, true) : parseInt = J$.R(5425, 'parseInt', parseInt, true)), false)(J$.B(1030, '+', J$.T(5429, '0x', 21), J$.R(5433, 'number', number, false)), J$.T(5437, 16, 22)),
                                                lineNumber: J$.R(5445, 'lineNumber', lineNumber, false),
                                                lineStart: J$.R(5449, 'lineStart', lineStart, false),
                                                range: J$.T(5461, [
                                                    J$.R(5453, 'start', start, false),
                                                    J$.R(5457, 'index', index, false)
                                                ], 10)
                                            }, 11));
                                        } catch (J$e) {
                                            J$.Ex(29077, J$e);
                                        } finally {
                                            if (J$.Fr(29081))
                                                continue jalangiLabel22;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function scanOctalLiteral(start) {
                                jalangiLabel23:
                                    while (true) {
                                        try {
                                            J$.Fe(5685, arguments.callee, this);
                                            arguments = J$.N(5689, 'arguments', arguments, true);
                                            start = J$.N(5693, 'start', start, true);
                                            J$.N(5697, 'number', number, false);
                                            var number = J$.W(5509, 'number', J$.B(1046, '+', J$.T(5489, '0', 21), J$.G(5505, J$.R(5493, 'source', source, false), J$.B(1042, '-', index = J$.W(5501, 'index', J$.B(1038, '+', J$.U(1034, '+', J$.R(5497, 'index', index, false)), 1), index), 1))), number);
                                            while (J$.C(784, J$.B(1050, '<', J$.R(5513, 'index', index, false), J$.R(5517, 'length', length, false)))) {
                                                if (J$.C(780, J$.U(1054, '!', J$.F(5537, J$.R(5521, 'isOctalDigit', isOctalDigit, false), false)(J$.G(5533, J$.R(5525, 'source', source, false), J$.R(5529, 'index', index, false)))))) {
                                                    break;
                                                }
                                                number = J$.W(5561, 'number', J$.B(1070, '+', J$.R(5557, 'number', number, false), J$.G(5553, J$.R(5541, 'source', source, false), J$.B(1066, '-', index = J$.W(5549, 'index', J$.B(1062, '+', J$.U(1058, '+', J$.R(5545, 'index', index, false)), 1), index), 1))), number);
                                            }
                                            if (J$.C(792, J$.C(788, J$.F(5581, J$.R(5565, 'isIdentifierStart', isIdentifierStart, false), false)(J$.M(5577, J$.R(5569, 'source', source, false), 'charCodeAt', false)(J$.R(5573, 'index', index, false)))) ? J$._() : J$.F(5601, J$.R(5585, 'isDecimalDigit', isDecimalDigit, false), false)(J$.M(5597, J$.R(5589, 'source', source, false), 'charCodeAt', false)(J$.R(5593, 'index', index, false))))) {
                                                J$.F(5625, J$.R(5605, 'throwError', throwError, false), false)(J$.T(5609, {}, 11), J$.G(5617, J$.R(5613, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(5621, 'ILLEGAL', 21));
                                            }
                                            return J$.Rt(5681, J$.T(5677, {
                                                type: J$.G(5633, J$.R(5629, 'Token', Token, false), 'NumericLiteral'),
                                                value: J$.F(5649, J$.I(typeof parseInt === 'undefined' ? parseInt = J$.R(5637, 'parseInt', undefined, true) : parseInt = J$.R(5637, 'parseInt', parseInt, true)), false)(J$.R(5641, 'number', number, false), J$.T(5645, 8, 22)),
                                                octal: J$.T(5653, true, 23),
                                                lineNumber: J$.R(5657, 'lineNumber', lineNumber, false),
                                                lineStart: J$.R(5661, 'lineStart', lineStart, false),
                                                range: J$.T(5673, [
                                                    J$.R(5665, 'start', start, false),
                                                    J$.R(5669, 'index', index, false)
                                                ], 10)
                                            }, 11));
                                        } catch (J$e) {
                                            J$.Ex(29085, J$e);
                                        } finally {
                                            if (J$.Fr(29089))
                                                continue jalangiLabel23;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function scanNumericLiteral() {
                                jalangiLabel24:
                                    while (true) {
                                        try {
                                            J$.Fe(6369, arguments.callee, this);
                                            arguments = J$.N(6373, 'arguments', arguments, true);
                                            J$.N(6377, 'number', number, false);
                                            J$.N(6381, 'start', start, false);
                                            J$.N(6385, 'ch', ch, false);
                                            var number, start, ch;
                                            ch = J$.W(5713, 'ch', J$.G(5709, J$.R(5701, 'source', source, false), J$.R(5705, 'index', index, false)), ch);
                                            J$.F(5753, J$.R(5717, 'assert', assert, false), false)(J$.C(796, J$.F(5737, J$.R(5721, 'isDecimalDigit', isDecimalDigit, false), false)(J$.M(5733, J$.R(5725, 'ch', ch, false), 'charCodeAt', false)(J$.T(5729, 0, 22)))) ? J$._() : J$.B(1074, '===', J$.R(5741, 'ch', ch, false), J$.T(5745, '.', 21)), J$.T(5749, 'Numeric literal must start with a decimal digit or a decimal point', 21));
                                            start = J$.W(5761, 'start', J$.R(5757, 'index', index, false), start);
                                            number = J$.W(5769, 'number', J$.T(5765, '', 21), number);
                                            if (J$.C(828, J$.B(1078, '!==', J$.R(5773, 'ch', ch, false), J$.T(5777, '.', 21)))) {
                                                number = J$.W(5797, 'number', J$.G(5793, J$.R(5781, 'source', source, false), J$.B(1090, '-', index = J$.W(5789, 'index', J$.B(1086, '+', J$.U(1082, '+', J$.R(5785, 'index', index, false)), 1), index), 1)), number);
                                                ch = J$.W(5813, 'ch', J$.G(5809, J$.R(5801, 'source', source, false), J$.R(5805, 'index', index, false)), ch);
                                                if (J$.C(820, J$.B(1094, '===', J$.R(5817, 'number', number, false), J$.T(5821, '0', 21)))) {
                                                    if (J$.C(804, J$.C(800, J$.B(1098, '===', J$.R(5825, 'ch', ch, false), J$.T(5829, 'x', 21))) ? J$._() : J$.B(1102, '===', J$.R(5833, 'ch', ch, false), J$.T(5837, 'X', 21)))) {
                                                        index = J$.W(5845, 'index', J$.B(1110, '+', J$.U(1106, '+', J$.R(5841, 'index', index, false)), 1), index);
                                                        return J$.Rt(5861, J$.F(5857, J$.R(5849, 'scanHexLiteral', scanHexLiteral, false), false)(J$.R(5853, 'start', start, false)));
                                                    }
                                                    if (J$.C(808, J$.F(5873, J$.R(5865, 'isOctalDigit', isOctalDigit, false), false)(J$.R(5869, 'ch', ch, false)))) {
                                                        return J$.Rt(5889, J$.F(5885, J$.R(5877, 'scanOctalLiteral', scanOctalLiteral, false), false)(J$.R(5881, 'start', start, false)));
                                                    }
                                                    if (J$.C(816, J$.C(812, J$.R(5893, 'ch', ch, false)) ? J$.F(5913, J$.R(5897, 'isDecimalDigit', isDecimalDigit, false), false)(J$.M(5909, J$.R(5901, 'ch', ch, false), 'charCodeAt', false)(J$.T(5905, 0, 22))) : J$._())) {
                                                        J$.F(5937, J$.R(5917, 'throwError', throwError, false), false)(J$.T(5921, {}, 11), J$.G(5929, J$.R(5925, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(5933, 'ILLEGAL', 21));
                                                    }
                                                }
                                                while (J$.C(824, J$.F(5957, J$.R(5941, 'isDecimalDigit', isDecimalDigit, false), false)(J$.M(5953, J$.R(5945, 'source', source, false), 'charCodeAt', false)(J$.R(5949, 'index', index, false))))) {
                                                    number = J$.W(5981, 'number', J$.B(1126, '+', J$.R(5977, 'number', number, false), J$.G(5973, J$.R(5961, 'source', source, false), J$.B(1122, '-', index = J$.W(5969, 'index', J$.B(1118, '+', J$.U(1114, '+', J$.R(5965, 'index', index, false)), 1), index), 1))), number);
                                                }
                                                ch = J$.W(5997, 'ch', J$.G(5993, J$.R(5985, 'source', source, false), J$.R(5989, 'index', index, false)), ch);
                                            }
                                            if (J$.C(836, J$.B(1130, '===', J$.R(6001, 'ch', ch, false), J$.T(6005, '.', 21)))) {
                                                number = J$.W(6029, 'number', J$.B(1146, '+', J$.R(6025, 'number', number, false), J$.G(6021, J$.R(6009, 'source', source, false), J$.B(1142, '-', index = J$.W(6017, 'index', J$.B(1138, '+', J$.U(1134, '+', J$.R(6013, 'index', index, false)), 1), index), 1))), number);
                                                while (J$.C(832, J$.F(6049, J$.R(6033, 'isDecimalDigit', isDecimalDigit, false), false)(J$.M(6045, J$.R(6037, 'source', source, false), 'charCodeAt', false)(J$.R(6041, 'index', index, false))))) {
                                                    number = J$.W(6073, 'number', J$.B(1162, '+', J$.R(6069, 'number', number, false), J$.G(6065, J$.R(6053, 'source', source, false), J$.B(1158, '-', index = J$.W(6061, 'index', J$.B(1154, '+', J$.U(1150, '+', J$.R(6057, 'index', index, false)), 1), index), 1))), number);
                                                }
                                                ch = J$.W(6089, 'ch', J$.G(6085, J$.R(6077, 'source', source, false), J$.R(6081, 'index', index, false)), ch);
                                            }
                                            if (J$.C(860, J$.C(840, J$.B(1166, '===', J$.R(6093, 'ch', ch, false), J$.T(6097, 'e', 21))) ? J$._() : J$.B(1170, '===', J$.R(6101, 'ch', ch, false), J$.T(6105, 'E', 21)))) {
                                                number = J$.W(6129, 'number', J$.B(1186, '+', J$.R(6125, 'number', number, false), J$.G(6121, J$.R(6109, 'source', source, false), J$.B(1182, '-', index = J$.W(6117, 'index', J$.B(1178, '+', J$.U(1174, '+', J$.R(6113, 'index', index, false)), 1), index), 1))), number);
                                                ch = J$.W(6145, 'ch', J$.G(6141, J$.R(6133, 'source', source, false), J$.R(6137, 'index', index, false)), ch);
                                                if (J$.C(848, J$.C(844, J$.B(1190, '===', J$.R(6149, 'ch', ch, false), J$.T(6153, '+', 21))) ? J$._() : J$.B(1194, '===', J$.R(6157, 'ch', ch, false), J$.T(6161, '-', 21)))) {
                                                    number = J$.W(6185, 'number', J$.B(1210, '+', J$.R(6181, 'number', number, false), J$.G(6177, J$.R(6165, 'source', source, false), J$.B(1206, '-', index = J$.W(6173, 'index', J$.B(1202, '+', J$.U(1198, '+', J$.R(6169, 'index', index, false)), 1), index), 1))), number);
                                                }
                                                if (J$.C(856, J$.F(6205, J$.R(6189, 'isDecimalDigit', isDecimalDigit, false), false)(J$.M(6201, J$.R(6193, 'source', source, false), 'charCodeAt', false)(J$.R(6197, 'index', index, false))))) {
                                                    while (J$.C(852, J$.F(6225, J$.R(6209, 'isDecimalDigit', isDecimalDigit, false), false)(J$.M(6221, J$.R(6213, 'source', source, false), 'charCodeAt', false)(J$.R(6217, 'index', index, false))))) {
                                                        number = J$.W(6249, 'number', J$.B(1226, '+', J$.R(6245, 'number', number, false), J$.G(6241, J$.R(6229, 'source', source, false), J$.B(1222, '-', index = J$.W(6237, 'index', J$.B(1218, '+', J$.U(1214, '+', J$.R(6233, 'index', index, false)), 1), index), 1))), number);
                                                    }
                                                } else {
                                                    J$.F(6273, J$.R(6253, 'throwError', throwError, false), false)(J$.T(6257, {}, 11), J$.G(6265, J$.R(6261, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(6269, 'ILLEGAL', 21));
                                                }
                                            }
                                            if (J$.C(864, J$.F(6293, J$.R(6277, 'isIdentifierStart', isIdentifierStart, false), false)(J$.M(6289, J$.R(6281, 'source', source, false), 'charCodeAt', false)(J$.R(6285, 'index', index, false))))) {
                                                J$.F(6317, J$.R(6297, 'throwError', throwError, false), false)(J$.T(6301, {}, 11), J$.G(6309, J$.R(6305, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(6313, 'ILLEGAL', 21));
                                            }
                                            return J$.Rt(6365, J$.T(6361, {
                                                type: J$.G(6325, J$.R(6321, 'Token', Token, false), 'NumericLiteral'),
                                                value: J$.F(6337, J$.I(typeof parseFloat === 'undefined' ? parseFloat = J$.R(6329, 'parseFloat', undefined, true) : parseFloat = J$.R(6329, 'parseFloat', parseFloat, true)), false)(J$.R(6333, 'number', number, false)),
                                                lineNumber: J$.R(6341, 'lineNumber', lineNumber, false),
                                                lineStart: J$.R(6345, 'lineStart', lineStart, false),
                                                range: J$.T(6357, [
                                                    J$.R(6349, 'start', start, false),
                                                    J$.R(6353, 'index', index, false)
                                                ], 10)
                                            }, 11));
                                        } catch (J$e) {
                                            J$.Ex(29093, J$e);
                                        } finally {
                                            if (J$.Fr(29097))
                                                continue jalangiLabel24;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function scanStringLiteral() {
                                jalangiLabel25:
                                    while (true) {
                                        try {
                                            J$.Fe(7105, arguments.callee, this);
                                            arguments = J$.N(7109, 'arguments', arguments, true);
                                            J$.N(7113, 'str', str, false);
                                            J$.N(7117, 'quote', quote, false);
                                            J$.N(7121, 'start', start, false);
                                            J$.N(7125, 'ch', ch, false);
                                            J$.N(7129, 'code', code, false);
                                            J$.N(7133, 'unescaped', unescaped, false);
                                            J$.N(7137, 'restore', restore, false);
                                            J$.N(7141, 'octal', octal, false);
                                            var str = J$.W(6397, 'str', J$.T(6389, '', 21), str), quote, start, ch, code, unescaped, restore, octal = J$.W(6401, 'octal', J$.T(6393, false, 23), octal);
                                            quote = J$.W(6417, 'quote', J$.G(6413, J$.R(6405, 'source', source, false), J$.R(6409, 'index', index, false)), quote);
                                            J$.F(6445, J$.R(6421, 'assert', assert, false), false)(J$.C(868, J$.B(1230, '===', J$.R(6425, 'quote', quote, false), J$.T(6429, '\'', 21))) ? J$._() : J$.B(1234, '===', J$.R(6433, 'quote', quote, false), J$.T(6437, '"', 21)), J$.T(6441, 'String literal must starts with a quote', 21));
                                            start = J$.W(6453, 'start', J$.R(6449, 'index', index, false), start);
                                            index = J$.W(6461, 'index', J$.B(1242, '+', J$.U(1238, '+', J$.R(6457, 'index', index, false)), 1), index);
                                            while (J$.C(968, J$.B(1246, '<', J$.R(6465, 'index', index, false), J$.R(6469, 'length', length, false)))) {
                                                ch = J$.W(6489, 'ch', J$.G(6485, J$.R(6473, 'source', source, false), J$.B(1258, '-', index = J$.W(6481, 'index', J$.B(1254, '+', J$.U(1250, '+', J$.R(6477, 'index', index, false)), 1), index), 1)), ch);
                                                if (J$.C(964, J$.B(1262, '===', J$.R(6493, 'ch', ch, false), J$.R(6497, 'quote', quote, false)))) {
                                                    quote = J$.W(6505, 'quote', J$.T(6501, '', 21), quote);
                                                    break;
                                                } else if (J$.C(960, J$.B(1266, '===', J$.R(6509, 'ch', ch, false), J$.T(6513, '\\', 21)))) {
                                                    ch = J$.W(6533, 'ch', J$.G(6529, J$.R(6517, 'source', source, false), J$.B(1278, '-', index = J$.W(6525, 'index', J$.B(1274, '+', J$.U(1270, '+', J$.R(6521, 'index', index, false)), 1), index), 1)), ch);
                                                    if (J$.C(952, J$.C(872, J$.U(1282, '!', J$.R(6537, 'ch', ch, false))) ? J$._() : J$.U(1286, '!', J$.F(6557, J$.R(6541, 'isLineTerminator', isLineTerminator, false), false)(J$.M(6553, J$.R(6545, 'ch', ch, false), 'charCodeAt', false)(J$.T(6549, 0, 22)))))) {
                                                        switch (J$.C1(908, J$.R(6561, 'ch', ch, false))) {
                                                        case J$.C2(912, J$.T(6577, 'n', 21)):
                                                            str = J$.W(6573, 'str', J$.B(1290, '+', J$.R(6569, 'str', str, false), J$.T(6565, '\n', 21)), str);
                                                            break;
                                                        case J$.C2(916, J$.T(6593, 'r', 21)):
                                                            str = J$.W(6589, 'str', J$.B(1294, '+', J$.R(6585, 'str', str, false), J$.T(6581, '\r', 21)), str);
                                                            break;
                                                        case J$.C2(920, J$.T(6609, 't', 21)):
                                                            str = J$.W(6605, 'str', J$.B(1298, '+', J$.R(6601, 'str', str, false), J$.T(6597, '\t', 21)), str);
                                                            break;
                                                        case J$.C2(924, J$.T(6613, 'u', 21)):
                                                        case J$.C2(928, J$.T(6677, 'x', 21)):
                                                            restore = J$.W(6621, 'restore', J$.R(6617, 'index', index, false), restore);
                                                            unescaped = J$.W(6637, 'unescaped', J$.F(6633, J$.R(6625, 'scanHexEscape', scanHexEscape, false), false)(J$.R(6629, 'ch', ch, false)), unescaped);
                                                            if (J$.C(876, J$.R(6641, 'unescaped', unescaped, false))) {
                                                                str = J$.W(6653, 'str', J$.B(1302, '+', J$.R(6649, 'str', str, false), J$.R(6645, 'unescaped', unescaped, false)), str);
                                                            } else {
                                                                index = J$.W(6661, 'index', J$.R(6657, 'restore', restore, false), index);
                                                                str = J$.W(6673, 'str', J$.B(1306, '+', J$.R(6669, 'str', str, false), J$.R(6665, 'ch', ch, false)), str);
                                                            }
                                                            break;
                                                        case J$.C2(932, J$.T(6693, 'b', 21)):
                                                            str = J$.W(6689, 'str', J$.B(1310, '+', J$.R(6685, 'str', str, false), J$.T(6681, '\b', 21)), str);
                                                            break;
                                                        case J$.C2(936, J$.T(6709, 'f', 21)):
                                                            str = J$.W(6705, 'str', J$.B(1314, '+', J$.R(6701, 'str', str, false), J$.T(6697, '\f', 21)), str);
                                                            break;
                                                        case J$.C2(940, J$.T(6725, 'v', 21)):
                                                            str = J$.W(6721, 'str', J$.B(1318, '+', J$.R(6717, 'str', str, false), J$.T(6713, '\x0B', 21)), str);
                                                            break;
                                                        default:
                                                            if (J$.C(904, J$.F(6737, J$.R(6729, 'isOctalDigit', isOctalDigit, false), false)(J$.R(6733, 'ch', ch, false)))) {
                                                                code = J$.W(6753, 'code', J$.M(6749, J$.T(6741, '01234567', 21), 'indexOf', false)(J$.R(6745, 'ch', ch, false)), code);
                                                                if (J$.C(880, J$.B(1322, '!==', J$.R(6757, 'code', code, false), J$.T(6761, 0, 22)))) {
                                                                    octal = J$.W(6769, 'octal', J$.T(6765, true, 23), octal);
                                                                }
                                                                if (J$.C(900, J$.C(884, J$.B(1326, '<', J$.R(6773, 'index', index, false), J$.R(6777, 'length', length, false))) ? J$.F(6797, J$.R(6781, 'isOctalDigit', isOctalDigit, false), false)(J$.G(6793, J$.R(6785, 'source', source, false), J$.R(6789, 'index', index, false))) : J$._())) {
                                                                    octal = J$.W(6805, 'octal', J$.T(6801, true, 23), octal);
                                                                    code = J$.W(6841, 'code', J$.B(1346, '+', J$.B(1330, '*', J$.R(6809, 'code', code, false), J$.T(6813, 8, 22)), J$.M(6837, J$.T(6817, '01234567', 21), 'indexOf', false)(J$.G(6833, J$.R(6821, 'source', source, false), J$.B(1342, '-', index = J$.W(6829, 'index', J$.B(1338, '+', J$.U(1334, '+', J$.R(6825, 'index', index, false)), 1), index), 1)))), code);
                                                                    if (J$.C(896, J$.C(892, J$.C(888, J$.B(1350, '>=', J$.M(6853, J$.T(6845, '0123', 21), 'indexOf', false)(J$.R(6849, 'ch', ch, false)), J$.T(6857, 0, 22))) ? J$.B(1354, '<', J$.R(6861, 'index', index, false), J$.R(6865, 'length', length, false)) : J$._()) ? J$.F(6885, J$.R(6869, 'isOctalDigit', isOctalDigit, false), false)(J$.G(6881, J$.R(6873, 'source', source, false), J$.R(6877, 'index', index, false))) : J$._())) {
                                                                        code = J$.W(6921, 'code', J$.B(1374, '+', J$.B(1358, '*', J$.R(6889, 'code', code, false), J$.T(6893, 8, 22)), J$.M(6917, J$.T(6897, '01234567', 21), 'indexOf', false)(J$.G(6913, J$.R(6901, 'source', source, false), J$.B(1370, '-', index = J$.W(6909, 'index', J$.B(1366, '+', J$.U(1362, '+', J$.R(6905, 'index', index, false)), 1), index), 1)))), code);
                                                                    }
                                                                }
                                                                str = J$.W(6941, 'str', J$.B(1378, '+', J$.R(6937, 'str', str, false), J$.M(6933, J$.I(typeof String === 'undefined' ? String = J$.R(6925, 'String', undefined, true) : String = J$.R(6925, 'String', String, true)), 'fromCharCode', false)(J$.R(6929, 'code', code, false))), str);
                                                            } else {
                                                                str = J$.W(6953, 'str', J$.B(1382, '+', J$.R(6949, 'str', str, false), J$.R(6945, 'ch', ch, false)), str);
                                                            }
                                                            break;
                                                        }
                                                    } else {
                                                        lineNumber = J$.W(6961, 'lineNumber', J$.B(1390, '+', J$.U(1386, '+', J$.R(6957, 'lineNumber', lineNumber, false)), 1), lineNumber);
                                                        if (J$.C(948, J$.C(944, J$.B(1394, '===', J$.R(6965, 'ch', ch, false), J$.T(6969, '\r', 21))) ? J$.B(1398, '===', J$.G(6981, J$.R(6973, 'source', source, false), J$.R(6977, 'index', index, false)), J$.T(6985, '\n', 21)) : J$._())) {
                                                            index = J$.W(6993, 'index', J$.B(1406, '+', J$.U(1402, '+', J$.R(6989, 'index', index, false)), 1), index);
                                                        }
                                                    }
                                                } else if (J$.C(956, J$.F(7013, J$.R(6997, 'isLineTerminator', isLineTerminator, false), false)(J$.M(7009, J$.R(7001, 'ch', ch, false), 'charCodeAt', false)(J$.T(7005, 0, 22))))) {
                                                    break;
                                                } else {
                                                    str = J$.W(7025, 'str', J$.B(1410, '+', J$.R(7021, 'str', str, false), J$.R(7017, 'ch', ch, false)), str);
                                                }
                                            }
                                            if (J$.C(972, J$.B(1414, '!==', J$.R(7029, 'quote', quote, false), J$.T(7033, '', 21)))) {
                                                J$.F(7057, J$.R(7037, 'throwError', throwError, false), false)(J$.T(7041, {}, 11), J$.G(7049, J$.R(7045, 'Messages', Messages, false), 'UnexpectedToken'), J$.T(7053, 'ILLEGAL', 21));
                                            }
                                            return J$.Rt(7101, J$.T(7097, {
                                                type: J$.G(7065, J$.R(7061, 'Token', Token, false), 'StringLiteral'),
                                                value: J$.R(7069, 'str', str, false),
                                                octal: J$.R(7073, 'octal', octal, false),
                                                lineNumber: J$.R(7077, 'lineNumber', lineNumber, false),
                                                lineStart: J$.R(7081, 'lineStart', lineStart, false),
                                                range: J$.T(7093, [
                                                    J$.R(7085, 'start', start, false),
                                                    J$.R(7089, 'index', index, false)
                                                ], 10)
                                            }, 11));
                                        } catch (J$e) {
                                            J$.Ex(29101, J$e);
                                        } finally {
                                            if (J$.Fr(29105))
                                                continue jalangiLabel25;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function scanRegExp() {
                                jalangiLabel26:
                                    while (true) {
                                        try {
                                            J$.Fe(7889, arguments.callee, this);
                                            arguments = J$.N(7893, 'arguments', arguments, true);
                                            J$.N(7897, 'str', str, false);
                                            J$.N(7901, 'ch', ch, false);
                                            J$.N(7905, 'start', start, false);
                                            J$.N(7909, 'pattern', pattern, false);
                                            J$.N(7913, 'flags', flags, false);
                                            J$.N(7917, 'value', value, false);
                                            J$.N(7921, 'classMarker', classMarker, false);
                                            J$.N(7925, 'restore', restore, false);
                                            J$.N(7929, 'terminated', terminated, false);
                                            var str, ch, start, pattern, flags, value, classMarker = J$.W(7153, 'classMarker', J$.T(7145, false, 23), classMarker), restore, terminated = J$.W(7157, 'terminated', J$.T(7149, false, 23), terminated);
                                            lookahead = J$.W(7165, 'lookahead', J$.T(7161, null, 25), lookahead);
                                            J$.F(7173, J$.R(7169, 'skipComment', skipComment, false), false)();
                                            start = J$.W(7181, 'start', J$.R(7177, 'index', index, false), start);
                                            ch = J$.W(7197, 'ch', J$.G(7193, J$.R(7185, 'source', source, false), J$.R(7189, 'index', index, false)), ch);
                                            J$.F(7217, J$.R(7201, 'assert', assert, false), false)(J$.B(1418, '===', J$.R(7205, 'ch', ch, false), J$.T(7209, '/', 21)), J$.T(7213, 'Regular expression literal must start with a slash', 21));
                                            str = J$.W(7237, 'str', J$.G(7233, J$.R(7221, 'source', source, false), J$.B(1430, '-', index = J$.W(7229, 'index', J$.B(1426, '+', J$.U(1422, '+', J$.R(7225, 'index', index, false)), 1), index), 1)), str);
                                            while (J$.C(1004, J$.B(1434, '<', J$.R(7241, 'index', index, false), J$.R(7245, 'length', length, false)))) {
                                                ch = J$.W(7265, 'ch', J$.G(7261, J$.R(7249, 'source', source, false), J$.B(1446, '-', index = J$.W(7257, 'index', J$.B(1442, '+', J$.U(1438, '+', J$.R(7253, 'index', index, false)), 1), index), 1)), ch);
                                                str = J$.W(7277, 'str', J$.B(1450, '+', J$.R(7273, 'str', str, false), J$.R(7269, 'ch', ch, false)), str);
                                                if (J$.C(1000, J$.B(1454, '===', J$.R(7281, 'ch', ch, false), J$.T(7285, '\\', 21)))) {
                                                    ch = J$.W(7305, 'ch', J$.G(7301, J$.R(7289, 'source', source, false), J$.B(1466, '-', index = J$.W(7297, 'index', J$.B(1462, '+', J$.U(1458, '+', J$.R(7293, 'index', index, false)), 1), index), 1)), ch);
                                                    if (J$.C(976, J$.F(7325, J$.R(7309, 'isLineTerminator', isLineTerminator, false), false)(J$.M(7321, J$.R(7313, 'ch', ch, false), 'charCodeAt', false)(J$.T(7317, 0, 22))))) {
                                                        J$.F(7345, J$.R(7329, 'throwError', throwError, false), false)(J$.T(7333, {}, 11), J$.G(7341, J$.R(7337, 'Messages', Messages, false), 'UnterminatedRegExp'));
                                                    }
                                                    str = J$.W(7357, 'str', J$.B(1470, '+', J$.R(7353, 'str', str, false), J$.R(7349, 'ch', ch, false)), str);
                                                } else if (J$.C(996, J$.F(7377, J$.R(7361, 'isLineTerminator', isLineTerminator, false), false)(J$.M(7373, J$.R(7365, 'ch', ch, false), 'charCodeAt', false)(J$.T(7369, 0, 22))))) {
                                                    J$.F(7397, J$.R(7381, 'throwError', throwError, false), false)(J$.T(7385, {}, 11), J$.G(7393, J$.R(7389, 'Messages', Messages, false), 'UnterminatedRegExp'));
                                                } else if (J$.C(992, J$.R(7401, 'classMarker', classMarker, false))) {
                                                    if (J$.C(980, J$.B(1474, '===', J$.R(7405, 'ch', ch, false), J$.T(7409, ']', 21)))) {
                                                        classMarker = J$.W(7417, 'classMarker', J$.T(7413, false, 23), classMarker);
                                                    }
                                                } else {
                                                    if (J$.C(988, J$.B(1478, '===', J$.R(7421, 'ch', ch, false), J$.T(7425, '/', 21)))) {
                                                        terminated = J$.W(7433, 'terminated', J$.T(7429, true, 23), terminated);
                                                        break;
                                                    } else if (J$.C(984, J$.B(1482, '===', J$.R(7437, 'ch', ch, false), J$.T(7441, '[', 21)))) {
                                                        classMarker = J$.W(7449, 'classMarker', J$.T(7445, true, 23), classMarker);
                                                    }
                                                }
                                            }
                                            if (J$.C(1008, J$.U(1486, '!', J$.R(7453, 'terminated', terminated, false)))) {
                                                J$.F(7473, J$.R(7457, 'throwError', throwError, false), false)(J$.T(7461, {}, 11), J$.G(7469, J$.R(7465, 'Messages', Messages, false), 'UnterminatedRegExp'));
                                            }
                                            pattern = J$.W(7501, 'pattern', J$.M(7497, J$.R(7477, 'str', str, false), 'substr', false)(J$.T(7481, 1, 22), J$.B(1490, '-', J$.G(7489, J$.R(7485, 'str', str, false), 'length'), J$.T(7493, 2, 22))), pattern);
                                            flags = J$.W(7509, 'flags', J$.T(7505, '', 21), flags);
                                            while (J$.C(1036, J$.B(1494, '<', J$.R(7513, 'index', index, false), J$.R(7517, 'length', length, false)))) {
                                                ch = J$.W(7533, 'ch', J$.G(7529, J$.R(7521, 'source', source, false), J$.R(7525, 'index', index, false)), ch);
                                                if (J$.C(1012, J$.U(1498, '!', J$.F(7553, J$.R(7537, 'isIdentifierPart', isIdentifierPart, false), false)(J$.M(7549, J$.R(7541, 'ch', ch, false), 'charCodeAt', false)(J$.T(7545, 0, 22)))))) {
                                                    break;
                                                }
                                                index = J$.W(7561, 'index', J$.B(1506, '+', J$.U(1502, '+', J$.R(7557, 'index', index, false)), 1), index);
                                                if (J$.C(1032, J$.C(1016, J$.B(1510, '===', J$.R(7565, 'ch', ch, false), J$.T(7569, '\\', 21))) ? J$.B(1514, '<', J$.R(7573, 'index', index, false), J$.R(7577, 'length', length, false)) : J$._())) {
                                                    ch = J$.W(7593, 'ch', J$.G(7589, J$.R(7581, 'source', source, false), J$.R(7585, 'index', index, false)), ch);
                                                    if (J$.C(1028, J$.B(1518, '===', J$.R(7597, 'ch', ch, false), J$.T(7601, 'u', 21)))) {
                                                        index = J$.W(7609, 'index', J$.B(1526, '+', J$.U(1522, '+', J$.R(7605, 'index', index, false)), 1), index);
                                                        restore = J$.W(7617, 'restore', J$.R(7613, 'index', index, false), restore);
                                                        ch = J$.W(7633, 'ch', J$.F(7629, J$.R(7621, 'scanHexEscape', scanHexEscape, false), false)(J$.T(7625, 'u', 21)), ch);
                                                        if (J$.C(1024, J$.R(7637, 'ch', ch, false))) {
                                                            flags = J$.W(7649, 'flags', J$.B(1530, '+', J$.R(7645, 'flags', flags, false), J$.R(7641, 'ch', ch, false)), flags);
                                                            for (str = J$.W(7661, 'str', J$.B(1534, '+', J$.R(7657, 'str', str, false), J$.T(7653, '\\u', 21)), str); J$.C(1020, J$.B(1538, '<', J$.R(7665, 'restore', restore, false), J$.R(7669, 'index', index, false))); restore = J$.W(7677, 'restore', J$.B(1546, '+', J$.U(1542, '+', J$.R(7673, 'restore', restore, false)), 1), restore)) {
                                                                str = J$.W(7697, 'str', J$.B(1550, '+', J$.R(7693, 'str', str, false), J$.G(7689, J$.R(7681, 'source', source, false), J$.R(7685, 'restore', restore, false))), str);
                                                            }
                                                        } else {
                                                            index = J$.W(7705, 'index', J$.R(7701, 'restore', restore, false), index);
                                                            flags = J$.W(7717, 'flags', J$.B(1554, '+', J$.R(7713, 'flags', flags, false), J$.T(7709, 'u', 21)), flags);
                                                            str = J$.W(7729, 'str', J$.B(1558, '+', J$.R(7725, 'str', str, false), J$.T(7721, '\\u', 21)), str);
                                                        }
                                                    } else {
                                                        str = J$.W(7741, 'str', J$.B(1562, '+', J$.R(7737, 'str', str, false), J$.T(7733, '\\', 21)), str);
                                                    }
                                                } else {
                                                    flags = J$.W(7753, 'flags', J$.B(1566, '+', J$.R(7749, 'flags', flags, false), J$.R(7745, 'ch', ch, false)), flags);
                                                    str = J$.W(7765, 'str', J$.B(1570, '+', J$.R(7761, 'str', str, false), J$.R(7757, 'ch', ch, false)), str);
                                                }
                                            }
                                            try {
                                                value = J$.W(7789, 'value', J$.T(7785, J$.F(7781, J$.I(typeof RegExp === 'undefined' ? RegExp = J$.R(7769, 'RegExp', undefined, true) : RegExp = J$.R(7769, 'RegExp', RegExp, true)), true)(J$.R(7773, 'pattern', pattern, false), J$.R(7777, 'flags', flags, false)), 11), value);
                                            } catch (e) {
                                                J$.F(7809, J$.R(7793, 'throwError', throwError, false), false)(J$.T(7797, {}, 11), J$.G(7805, J$.R(7801, 'Messages', Messages, false), 'InvalidRegExp'));
                                            }
                                            if (J$.C(1040, J$.G(7817, J$.R(7813, 'extra', extra, false), 'tokenize'))) {
                                                return J$.Rt(7857, J$.T(7853, {
                                                    type: J$.G(7825, J$.R(7821, 'Token', Token, false), 'RegularExpression'),
                                                    value: J$.R(7829, 'value', value, false),
                                                    lineNumber: J$.R(7833, 'lineNumber', lineNumber, false),
                                                    lineStart: J$.R(7837, 'lineStart', lineStart, false),
                                                    range: J$.T(7849, [
                                                        J$.R(7841, 'start', start, false),
                                                        J$.R(7845, 'index', index, false)
                                                    ], 10)
                                                }, 11));
                                            }
                                            return J$.Rt(7885, J$.T(7881, {
                                                literal: J$.R(7861, 'str', str, false),
                                                value: J$.R(7865, 'value', value, false),
                                                range: J$.T(7877, [
                                                    J$.R(7869, 'start', start, false),
                                                    J$.R(7873, 'index', index, false)
                                                ], 10)
                                            }, 11));
                                        } catch (J$e) {
                                            J$.Ex(29109, J$e);
                                        } finally {
                                            if (J$.Fr(29113))
                                                continue jalangiLabel26;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function collectRegex() {
                                jalangiLabel27:
                                    while (true) {
                                        try {
                                            J$.Fe(8185, arguments.callee, this);
                                            arguments = J$.N(8189, 'arguments', arguments, true);
                                            J$.N(8193, 'pos', pos, false);
                                            J$.N(8197, 'loc', loc, false);
                                            J$.N(8201, 'regex', regex, false);
                                            J$.N(8205, 'token', token, false);
                                            var pos, loc, regex, token;
                                            J$.F(7937, J$.R(7933, 'skipComment', skipComment, false), false)();
                                            pos = J$.W(7945, 'pos', J$.R(7941, 'index', index, false), pos);
                                            loc = J$.W(7969, 'loc', J$.T(7965, {
                                                start: J$.T(7961, {
                                                    line: J$.R(7949, 'lineNumber', lineNumber, false),
                                                    column: J$.B(1574, '-', J$.R(7953, 'index', index, false), J$.R(7957, 'lineStart', lineStart, false))
                                                }, 11)
                                            }, 11), loc);
                                            regex = J$.W(7981, 'regex', J$.F(7977, J$.R(7973, 'scanRegExp', scanRegExp, false), false)(), regex);
                                            J$.P(8005, J$.R(7985, 'loc', loc, false), 'end', J$.T(8001, {
                                                line: J$.R(7989, 'lineNumber', lineNumber, false),
                                                column: J$.B(1578, '-', J$.R(7993, 'index', index, false), J$.R(7997, 'lineStart', lineStart, false))
                                            }, 11));
                                            if (J$.C(1064, J$.U(1582, '!', J$.G(8013, J$.R(8009, 'extra', extra, false), 'tokenize')))) {
                                                if (J$.C(1060, J$.B(1586, '>', J$.G(8025, J$.G(8021, J$.R(8017, 'extra', extra, false), 'tokens'), 'length'), J$.T(8029, 0, 22)))) {
                                                    token = J$.W(8061, 'token', J$.G(8057, J$.G(8037, J$.R(8033, 'extra', extra, false), 'tokens'), J$.B(1590, '-', J$.G(8049, J$.G(8045, J$.R(8041, 'extra', extra, false), 'tokens'), 'length'), J$.T(8053, 1, 22))), token);
                                                    if (J$.C(1056, J$.C(1044, J$.B(1594, '===', J$.G(8077, J$.G(8069, J$.R(8065, 'token', token, false), 'range'), J$.T(8073, 0, 22)), J$.R(8081, 'pos', pos, false))) ? J$.B(1598, '===', J$.G(8089, J$.R(8085, 'token', token, false), 'type'), J$.T(8093, 'Punctuator', 21)) : J$._())) {
                                                        if (J$.C(1052, J$.C(1048, J$.B(1602, '===', J$.G(8101, J$.R(8097, 'token', token, false), 'value'), J$.T(8105, '/', 21))) ? J$._() : J$.B(1606, '===', J$.G(8113, J$.R(8109, 'token', token, false), 'value'), J$.T(8117, '/=', 21)))) {
                                                            J$.M(8129, J$.G(8125, J$.R(8121, 'extra', extra, false), 'tokens'), 'pop', false)();
                                                        }
                                                    }
                                                }
                                                J$.M(8173, J$.G(8137, J$.R(8133, 'extra', extra, false), 'tokens'), 'push', false)(J$.T(8169, {
                                                    type: J$.T(8141, 'RegularExpression', 21),
                                                    value: J$.G(8149, J$.R(8145, 'regex', regex, false), 'literal'),
                                                    range: J$.T(8161, [
                                                        J$.R(8153, 'pos', pos, false),
                                                        J$.R(8157, 'index', index, false)
                                                    ], 10),
                                                    loc: J$.R(8165, 'loc', loc, false)
                                                }, 11));
                                            }
                                            return J$.Rt(8181, J$.R(8177, 'regex', regex, false));
                                        } catch (J$e) {
                                            J$.Ex(29117, J$e);
                                        } finally {
                                            if (J$.Fr(29121))
                                                continue jalangiLabel27;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function isIdentifierName(token) {
                                jalangiLabel28:
                                    while (true) {
                                        try {
                                            J$.Fe(8277, arguments.callee, this);
                                            arguments = J$.N(8281, 'arguments', arguments, true);
                                            token = J$.N(8285, 'token', token, true);
                                            return J$.Rt(8273, J$.C(1076, J$.C(1072, J$.C(1068, J$.B(1610, '===', J$.G(8213, J$.R(8209, 'token', token, false), 'type'), J$.G(8221, J$.R(8217, 'Token', Token, false), 'Identifier'))) ? J$._() : J$.B(1614, '===', J$.G(8229, J$.R(8225, 'token', token, false), 'type'), J$.G(8237, J$.R(8233, 'Token', Token, false), 'Keyword'))) ? J$._() : J$.B(1618, '===', J$.G(8245, J$.R(8241, 'token', token, false), 'type'), J$.G(8253, J$.R(8249, 'Token', Token, false), 'BooleanLiteral'))) ? J$._() : J$.B(1622, '===', J$.G(8261, J$.R(8257, 'token', token, false), 'type'), J$.G(8269, J$.R(8265, 'Token', Token, false), 'NullLiteral')));
                                        } catch (J$e) {
                                            J$.Ex(29125, J$e);
                                        } finally {
                                            if (J$.Fr(29129))
                                                continue jalangiLabel28;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function advanceSlash() {
                                jalangiLabel29:
                                    while (true) {
                                        try {
                                            J$.Fe(8793, arguments.callee, this);
                                            arguments = J$.N(8797, 'arguments', arguments, true);
                                            J$.N(8801, 'prevToken', prevToken, false);
                                            J$.N(8805, 'checkToken', checkToken, false);
                                            var prevToken, checkToken;
                                            prevToken = J$.W(8317, 'prevToken', J$.G(8313, J$.G(8293, J$.R(8289, 'extra', extra, false), 'tokens'), J$.B(1626, '-', J$.G(8305, J$.G(8301, J$.R(8297, 'extra', extra, false), 'tokens'), 'length'), J$.T(8309, 1, 22))), prevToken);
                                            if (J$.C(1080, J$.U(1630, '!', J$.R(8321, 'prevToken', prevToken, false)))) {
                                                return J$.Rt(8333, J$.F(8329, J$.R(8325, 'collectRegex', collectRegex, false), false)());
                                            }
                                            if (J$.C(1144, J$.B(1634, '===', J$.G(8341, J$.R(8337, 'prevToken', prevToken, false), 'type'), J$.T(8345, 'Punctuator', 21)))) {
                                                if (J$.C(1108, J$.B(1638, '===', J$.G(8353, J$.R(8349, 'prevToken', prevToken, false), 'value'), J$.T(8357, ')', 21)))) {
                                                    checkToken = J$.W(8385, 'checkToken', J$.G(8381, J$.G(8365, J$.R(8361, 'extra', extra, false), 'tokens'), J$.B(1642, '-', J$.G(8373, J$.R(8369, 'extra', extra, false), 'openParenToken'), J$.T(8377, 1, 22))), checkToken);
                                                    if (J$.C(1104, J$.C(1100, J$.C(1084, J$.R(8389, 'checkToken', checkToken, false)) ? J$.B(1646, '===', J$.G(8397, J$.R(8393, 'checkToken', checkToken, false), 'type'), J$.T(8401, 'Keyword', 21)) : J$._()) ? J$.C(1096, J$.C(1092, J$.C(1088, J$.B(1650, '===', J$.G(8409, J$.R(8405, 'checkToken', checkToken, false), 'value'), J$.T(8413, 'if', 21))) ? J$._() : J$.B(1654, '===', J$.G(8421, J$.R(8417, 'checkToken', checkToken, false), 'value'), J$.T(8425, 'while', 21))) ? J$._() : J$.B(1658, '===', J$.G(8433, J$.R(8429, 'checkToken', checkToken, false), 'value'), J$.T(8437, 'for', 21))) ? J$._() : J$.B(1662, '===', J$.G(8445, J$.R(8441, 'checkToken', checkToken, false), 'value'), J$.T(8449, 'with', 21)) : J$._())) {
                                                        return J$.Rt(8461, J$.F(8457, J$.R(8453, 'collectRegex', collectRegex, false), false)());
                                                    }
                                                    return J$.Rt(8473, J$.F(8469, J$.R(8465, 'scanPunctuator', scanPunctuator, false), false)());
                                                }
                                                if (J$.C(1140, J$.B(1666, '===', J$.G(8481, J$.R(8477, 'prevToken', prevToken, false), 'value'), J$.T(8485, '}', 21)))) {
                                                    if (J$.C(1132, J$.C(1112, J$.G(8509, J$.G(8493, J$.R(8489, 'extra', extra, false), 'tokens'), J$.B(1670, '-', J$.G(8501, J$.R(8497, 'extra', extra, false), 'openCurlyToken'), J$.T(8505, 3, 22)))) ? J$.B(1678, '===', J$.G(8537, J$.G(8533, J$.G(8517, J$.R(8513, 'extra', extra, false), 'tokens'), J$.B(1674, '-', J$.G(8525, J$.R(8521, 'extra', extra, false), 'openCurlyToken'), J$.T(8529, 3, 22))), 'type'), J$.T(8541, 'Keyword', 21)) : J$._())) {
                                                        checkToken = J$.W(8569, 'checkToken', J$.G(8565, J$.G(8549, J$.R(8545, 'extra', extra, false), 'tokens'), J$.B(1682, '-', J$.G(8557, J$.R(8553, 'extra', extra, false), 'openCurlyToken'), J$.T(8561, 4, 22))), checkToken);
                                                        if (J$.C(1116, J$.U(1686, '!', J$.R(8573, 'checkToken', checkToken, false)))) {
                                                            return J$.Rt(8585, J$.F(8581, J$.R(8577, 'scanPunctuator', scanPunctuator, false), false)());
                                                        }
                                                    } else if (J$.C(1128, J$.C(1120, J$.G(8609, J$.G(8593, J$.R(8589, 'extra', extra, false), 'tokens'), J$.B(1690, '-', J$.G(8601, J$.R(8597, 'extra', extra, false), 'openCurlyToken'), J$.T(8605, 4, 22)))) ? J$.B(1698, '===', J$.G(8637, J$.G(8633, J$.G(8617, J$.R(8613, 'extra', extra, false), 'tokens'), J$.B(1694, '-', J$.G(8625, J$.R(8621, 'extra', extra, false), 'openCurlyToken'), J$.T(8629, 4, 22))), 'type'), J$.T(8641, 'Keyword', 21)) : J$._())) {
                                                        checkToken = J$.W(8669, 'checkToken', J$.G(8665, J$.G(8649, J$.R(8645, 'extra', extra, false), 'tokens'), J$.B(1702, '-', J$.G(8657, J$.R(8653, 'extra', extra, false), 'openCurlyToken'), J$.T(8661, 5, 22))), checkToken);
                                                        if (J$.C(1124, J$.U(1706, '!', J$.R(8673, 'checkToken', checkToken, false)))) {
                                                            return J$.Rt(8685, J$.F(8681, J$.R(8677, 'collectRegex', collectRegex, false), false)());
                                                        }
                                                    } else {
                                                        return J$.Rt(8697, J$.F(8693, J$.R(8689, 'scanPunctuator', scanPunctuator, false), false)());
                                                    }
                                                    if (J$.C(1136, J$.B(1710, '>=', J$.M(8713, J$.R(8701, 'FnExprTokens', FnExprTokens, false), 'indexOf', false)(J$.G(8709, J$.R(8705, 'checkToken', checkToken, false), 'value')), J$.T(8717, 0, 22)))) {
                                                        return J$.Rt(8729, J$.F(8725, J$.R(8721, 'scanPunctuator', scanPunctuator, false), false)());
                                                    }
                                                    return J$.Rt(8741, J$.F(8737, J$.R(8733, 'collectRegex', collectRegex, false), false)());
                                                }
                                                return J$.Rt(8753, J$.F(8749, J$.R(8745, 'collectRegex', collectRegex, false), false)());
                                            }
                                            if (J$.C(1148, J$.B(1714, '===', J$.G(8761, J$.R(8757, 'prevToken', prevToken, false), 'type'), J$.T(8765, 'Keyword', 21)))) {
                                                return J$.Rt(8777, J$.F(8773, J$.R(8769, 'collectRegex', collectRegex, false), false)());
                                            }
                                            return J$.Rt(8789, J$.F(8785, J$.R(8781, 'scanPunctuator', scanPunctuator, false), false)());
                                        } catch (J$e) {
                                            J$.Ex(29133, J$e);
                                        } finally {
                                            if (J$.Fr(29137))
                                                continue jalangiLabel29;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function advance() {
                                jalangiLabel30:
                                    while (true) {
                                        try {
                                            J$.Fe(9085, arguments.callee, this);
                                            arguments = J$.N(9089, 'arguments', arguments, true);
                                            J$.N(9093, 'ch', ch, false);
                                            var ch;
                                            J$.F(8813, J$.R(8809, 'skipComment', skipComment, false), false)();
                                            if (J$.C(1152, J$.B(1718, '>=', J$.R(8817, 'index', index, false), J$.R(8821, 'length', length, false)))) {
                                                return J$.Rt(8857, J$.T(8853, {
                                                    type: J$.G(8829, J$.R(8825, 'Token', Token, false), 'EOF'),
                                                    lineNumber: J$.R(8833, 'lineNumber', lineNumber, false),
                                                    lineStart: J$.R(8837, 'lineStart', lineStart, false),
                                                    range: J$.T(8849, [
                                                        J$.R(8841, 'index', index, false),
                                                        J$.R(8845, 'index', index, false)
                                                    ], 10)
                                                }, 11));
                                            }
                                            ch = J$.W(8873, 'ch', J$.M(8869, J$.R(8861, 'source', source, false), 'charCodeAt', false)(J$.R(8865, 'index', index, false)), ch);
                                            if (J$.C(1164, J$.C(1160, J$.C(1156, J$.B(1722, '===', J$.R(8877, 'ch', ch, false), J$.T(8881, 40, 22))) ? J$._() : J$.B(1726, '===', J$.R(8885, 'ch', ch, false), J$.T(8889, 41, 22))) ? J$._() : J$.B(1730, '===', J$.R(8893, 'ch', ch, false), J$.T(8897, 58, 22)))) {
                                                return J$.Rt(8909, J$.F(8905, J$.R(8901, 'scanPunctuator', scanPunctuator, false), false)());
                                            }
                                            if (J$.C(1172, J$.C(1168, J$.B(1734, '===', J$.R(8913, 'ch', ch, false), J$.T(8917, 39, 22))) ? J$._() : J$.B(1738, '===', J$.R(8921, 'ch', ch, false), J$.T(8925, 34, 22)))) {
                                                return J$.Rt(8937, J$.F(8933, J$.R(8929, 'scanStringLiteral', scanStringLiteral, false), false)());
                                            }
                                            if (J$.C(1176, J$.F(8949, J$.R(8941, 'isIdentifierStart', isIdentifierStart, false), false)(J$.R(8945, 'ch', ch, false)))) {
                                                return J$.Rt(8961, J$.F(8957, J$.R(8953, 'scanIdentifier', scanIdentifier, false), false)());
                                            }
                                            if (J$.C(1184, J$.B(1742, '===', J$.R(8965, 'ch', ch, false), J$.T(8969, 46, 22)))) {
                                                if (J$.C(1180, J$.F(8993, J$.R(8973, 'isDecimalDigit', isDecimalDigit, false), false)(J$.M(8989, J$.R(8977, 'source', source, false), 'charCodeAt', false)(J$.B(1746, '+', J$.R(8981, 'index', index, false), J$.T(8985, 1, 22)))))) {
                                                    return J$.Rt(9005, J$.F(9001, J$.R(8997, 'scanNumericLiteral', scanNumericLiteral, false), false)());
                                                }
                                                return J$.Rt(9017, J$.F(9013, J$.R(9009, 'scanPunctuator', scanPunctuator, false), false)());
                                            }
                                            if (J$.C(1188, J$.F(9029, J$.R(9021, 'isDecimalDigit', isDecimalDigit, false), false)(J$.R(9025, 'ch', ch, false)))) {
                                                return J$.Rt(9041, J$.F(9037, J$.R(9033, 'scanNumericLiteral', scanNumericLiteral, false), false)());
                                            }
                                            if (J$.C(1196, J$.C(1192, J$.G(9049, J$.R(9045, 'extra', extra, false), 'tokenize')) ? J$.B(1750, '===', J$.R(9053, 'ch', ch, false), J$.T(9057, 47, 22)) : J$._())) {
                                                return J$.Rt(9069, J$.F(9065, J$.R(9061, 'advanceSlash', advanceSlash, false), false)());
                                            }
                                            return J$.Rt(9081, J$.F(9077, J$.R(9073, 'scanPunctuator', scanPunctuator, false), false)());
                                        } catch (J$e) {
                                            J$.Ex(29141, J$e);
                                        } finally {
                                            if (J$.Fr(29145))
                                                continue jalangiLabel30;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function collectToken() {
                                jalangiLabel31:
                                    while (true) {
                                        try {
                                            J$.Fe(9325, arguments.callee, this);
                                            arguments = J$.N(9329, 'arguments', arguments, true);
                                            J$.N(9333, 'start', start, false);
                                            J$.N(9337, 'loc', loc, false);
                                            J$.N(9341, 'token', token, false);
                                            J$.N(9345, 'range', range, false);
                                            J$.N(9349, 'value', value, false);
                                            var start, loc, token, range, value;
                                            J$.F(9101, J$.R(9097, 'skipComment', skipComment, false), false)();
                                            start = J$.W(9109, 'start', J$.R(9105, 'index', index, false), start);
                                            loc = J$.W(9133, 'loc', J$.T(9129, {
                                                start: J$.T(9125, {
                                                    line: J$.R(9113, 'lineNumber', lineNumber, false),
                                                    column: J$.B(1754, '-', J$.R(9117, 'index', index, false), J$.R(9121, 'lineStart', lineStart, false))
                                                }, 11)
                                            }, 11), loc);
                                            token = J$.W(9145, 'token', J$.F(9141, J$.R(9137, 'advance', advance, false), false)(), token);
                                            J$.P(9169, J$.R(9149, 'loc', loc, false), 'end', J$.T(9165, {
                                                line: J$.R(9153, 'lineNumber', lineNumber, false),
                                                column: J$.B(1758, '-', J$.R(9157, 'index', index, false), J$.R(9161, 'lineStart', lineStart, false))
                                            }, 11));
                                            if (J$.C(1200, J$.B(1762, '!==', J$.G(9177, J$.R(9173, 'token', token, false), 'type'), J$.G(9185, J$.R(9181, 'Token', Token, false), 'EOF')))) {
                                                range = J$.W(9225, 'range', J$.T(9221, [
                                                    J$.G(9201, J$.G(9193, J$.R(9189, 'token', token, false), 'range'), J$.T(9197, 0, 22)),
                                                    J$.G(9217, J$.G(9209, J$.R(9205, 'token', token, false), 'range'), J$.T(9213, 1, 22))
                                                ], 10), range);
                                                value = J$.W(9269, 'value', J$.M(9265, J$.R(9229, 'source', source, false), 'slice', false)(J$.G(9245, J$.G(9237, J$.R(9233, 'token', token, false), 'range'), J$.T(9241, 0, 22)), J$.G(9261, J$.G(9253, J$.R(9249, 'token', token, false), 'range'), J$.T(9257, 1, 22))), value);
                                                J$.M(9313, J$.G(9277, J$.R(9273, 'extra', extra, false), 'tokens'), 'push', false)(J$.T(9309, {
                                                    type: J$.G(9293, J$.R(9281, 'TokenName', TokenName, false), J$.G(9289, J$.R(9285, 'token', token, false), 'type')),
                                                    value: J$.R(9297, 'value', value, false),
                                                    range: J$.R(9301, 'range', range, false),
                                                    loc: J$.R(9305, 'loc', loc, false)
                                                }, 11));
                                            }
                                            return J$.Rt(9321, J$.R(9317, 'token', token, false));
                                        } catch (J$e) {
                                            J$.Ex(29149, J$e);
                                        } finally {
                                            if (J$.Fr(29153))
                                                continue jalangiLabel31;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function lex() {
                                jalangiLabel32:
                                    while (true) {
                                        try {
                                            J$.Fe(9489, arguments.callee, this);
                                            arguments = J$.N(9493, 'arguments', arguments, true);
                                            J$.N(9497, 'token', token, false);
                                            var token;
                                            token = J$.W(9357, 'token', J$.R(9353, 'lookahead', lookahead, false), token);
                                            index = J$.W(9377, 'index', J$.G(9373, J$.G(9365, J$.R(9361, 'token', token, false), 'range'), J$.T(9369, 1, 22)), index);
                                            lineNumber = J$.W(9389, 'lineNumber', J$.G(9385, J$.R(9381, 'token', token, false), 'lineNumber'), lineNumber);
                                            lineStart = J$.W(9401, 'lineStart', J$.G(9397, J$.R(9393, 'token', token, false), 'lineStart'), lineStart);
                                            lookahead = J$.W(9433, 'lookahead', J$.C(1204, J$.B(1770, '!==', J$.U(1766, 'typeof', J$.G(9409, J$.R(9405, 'extra', extra, false), 'tokens')), J$.T(9413, 'undefined', 21))) ? J$.F(9421, J$.R(9417, 'collectToken', collectToken, false), false)() : J$.F(9429, J$.R(9425, 'advance', advance, false), false)(), lookahead);
                                            index = J$.W(9453, 'index', J$.G(9449, J$.G(9441, J$.R(9437, 'token', token, false), 'range'), J$.T(9445, 1, 22)), index);
                                            lineNumber = J$.W(9465, 'lineNumber', J$.G(9461, J$.R(9457, 'token', token, false), 'lineNumber'), lineNumber);
                                            lineStart = J$.W(9477, 'lineStart', J$.G(9473, J$.R(9469, 'token', token, false), 'lineStart'), lineStart);
                                            return J$.Rt(9485, J$.R(9481, 'token', token, false));
                                        } catch (J$e) {
                                            J$.Ex(29157, J$e);
                                        } finally {
                                            if (J$.Fr(29161))
                                                continue jalangiLabel32;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function peek() {
                                jalangiLabel33:
                                    while (true) {
                                        try {
                                            J$.Fe(9581, arguments.callee, this);
                                            arguments = J$.N(9585, 'arguments', arguments, true);
                                            J$.N(9589, 'pos', pos, false);
                                            J$.N(9593, 'line', line, false);
                                            J$.N(9597, 'start', start, false);
                                            var pos, line, start;
                                            pos = J$.W(9505, 'pos', J$.R(9501, 'index', index, false), pos);
                                            line = J$.W(9513, 'line', J$.R(9509, 'lineNumber', lineNumber, false), line);
                                            start = J$.W(9521, 'start', J$.R(9517, 'lineStart', lineStart, false), start);
                                            lookahead = J$.W(9553, 'lookahead', J$.C(1208, J$.B(1778, '!==', J$.U(1774, 'typeof', J$.G(9529, J$.R(9525, 'extra', extra, false), 'tokens')), J$.T(9533, 'undefined', 21))) ? J$.F(9541, J$.R(9537, 'collectToken', collectToken, false), false)() : J$.F(9549, J$.R(9545, 'advance', advance, false), false)(), lookahead);
                                            index = J$.W(9561, 'index', J$.R(9557, 'pos', pos, false), index);
                                            lineNumber = J$.W(9569, 'lineNumber', J$.R(9565, 'line', line, false), lineNumber);
                                            lineStart = J$.W(9577, 'lineStart', J$.R(9573, 'start', start, false), lineStart);
                                        } catch (J$e) {
                                            J$.Ex(29165, J$e);
                                        } finally {
                                            if (J$.Fr(29169))
                                                continue jalangiLabel33;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            SyntaxTreeDelegate = J$.W(12337, 'SyntaxTreeDelegate', J$.T(12333, {
                                name: J$.T(9601, 'SyntaxTree', 21),
                                markStart: J$.T(9681, function () {
                                    jalangiLabel34:
                                        while (true) {
                                            try {
                                                J$.Fe(9673, arguments.callee, this);
                                                arguments = J$.N(9677, 'arguments', arguments, true);
                                                if (J$.C(1212, J$.G(9609, J$.R(9605, 'extra', extra, false), 'loc'))) {
                                                    J$.M(9629, J$.G(9617, J$.R(9613, 'state', state, false), 'markerStack'), 'push', false)(J$.B(1782, '-', J$.R(9621, 'index', index, false), J$.R(9625, 'lineStart', lineStart, false)));
                                                    J$.M(9645, J$.G(9637, J$.R(9633, 'state', state, false), 'markerStack'), 'push', false)(J$.R(9641, 'lineNumber', lineNumber, false));
                                                }
                                                if (J$.C(1216, J$.G(9653, J$.R(9649, 'extra', extra, false), 'range'))) {
                                                    J$.M(9669, J$.G(9661, J$.R(9657, 'state', state, false), 'markerStack'), 'push', false)(J$.R(9665, 'index', index, false));
                                                }
                                            } catch (J$e) {
                                                J$.Ex(29173, J$e);
                                            } finally {
                                                if (J$.Fr(29177))
                                                    continue jalangiLabel34;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                processComment: J$.T(10161, function (node) {
                                    jalangiLabel35:
                                        while (true) {
                                            try {
                                                J$.Fe(10129, arguments.callee, this);
                                                arguments = J$.N(10133, 'arguments', arguments, true);
                                                node = J$.N(10137, 'node', node, true);
                                                J$.N(10141, 'i', i, false);
                                                J$.N(10145, 'attacher', attacher, false);
                                                J$.N(10149, 'pos', pos, false);
                                                J$.N(10153, 'len', len, false);
                                                J$.N(10157, 'candidate', candidate, false);
                                                var i, attacher, pos, len, candidate;
                                                if (J$.C(1224, J$.C(1220, J$.B(1790, '===', J$.U(1786, 'typeof', J$.G(9689, J$.R(9685, 'node', node, false), 'type')), J$.T(9693, 'undefined', 21))) ? J$._() : J$.B(1794, '===', J$.G(9701, J$.R(9697, 'node', node, false), 'type'), J$.G(9709, J$.R(9705, 'Syntax', Syntax, false), 'Program')))) {
                                                    return J$.Rt(9713, undefined);
                                                }
                                                J$.F(9721, J$.R(9717, 'peek', peek, false), false)();
                                                for (i = J$.W(9729, 'i', J$.T(9725, 0, 22), i); J$.C(1260, J$.B(1798, '<', J$.R(9733, 'i', i, false), J$.G(9745, J$.G(9741, J$.R(9737, 'extra', extra, false), 'pendingComments'), 'length'))); i = J$.W(9753, 'i', J$.B(1806, '+', J$.U(1802, '+', J$.R(9749, 'i', i, false)), 1), i)) {
                                                    attacher = J$.W(9773, 'attacher', J$.G(9769, J$.G(9761, J$.R(9757, 'extra', extra, false), 'pendingComments'), J$.R(9765, 'i', i, false)), attacher);
                                                    if (J$.C(1240, J$.B(1810, '>=', J$.G(9789, J$.G(9781, J$.R(9777, 'node', node, false), 'range'), J$.T(9785, 0, 22)), J$.G(9809, J$.G(9801, J$.G(9797, J$.R(9793, 'attacher', attacher, false), 'comment'), 'range'), J$.T(9805, 1, 22))))) {
                                                        candidate = J$.W(9821, 'candidate', J$.G(9817, J$.R(9813, 'attacher', attacher, false), 'leading'), candidate);
                                                        if (J$.C(1236, J$.R(9825, 'candidate', candidate, false))) {
                                                            pos = J$.W(9845, 'pos', J$.G(9841, J$.G(9833, J$.R(9829, 'candidate', candidate, false), 'range'), J$.T(9837, 0, 22)), pos);
                                                            len = J$.W(9869, 'len', J$.B(1814, '-', J$.G(9861, J$.G(9853, J$.R(9849, 'candidate', candidate, false), 'range'), J$.T(9857, 1, 22)), J$.R(9865, 'pos', pos, false)), len);
                                                            if (J$.C(1232, J$.C(1228, J$.B(1818, '<=', J$.G(9885, J$.G(9877, J$.R(9873, 'node', node, false), 'range'), J$.T(9881, 0, 22)), J$.R(9889, 'pos', pos, false))) ? J$.B(1826, '>=', J$.B(1822, '-', J$.G(9905, J$.G(9897, J$.R(9893, 'node', node, false), 'range'), J$.T(9901, 1, 22)), J$.G(9921, J$.G(9913, J$.R(9909, 'node', node, false), 'range'), J$.T(9917, 0, 22))), J$.R(9925, 'len', len, false)) : J$._())) {
                                                                J$.P(9937, J$.R(9929, 'attacher', attacher, false), 'leading', J$.R(9933, 'node', node, false));
                                                            }
                                                        } else {
                                                            J$.P(9949, J$.R(9941, 'attacher', attacher, false), 'leading', J$.R(9945, 'node', node, false));
                                                        }
                                                    }
                                                    if (J$.C(1256, J$.B(1830, '<=', J$.G(9965, J$.G(9957, J$.R(9953, 'node', node, false), 'range'), J$.T(9961, 1, 22)), J$.G(9985, J$.G(9977, J$.G(9973, J$.R(9969, 'attacher', attacher, false), 'comment'), 'range'), J$.T(9981, 0, 22))))) {
                                                        candidate = J$.W(9997, 'candidate', J$.G(9993, J$.R(9989, 'attacher', attacher, false), 'trailing'), candidate);
                                                        if (J$.C(1252, J$.R(10001, 'candidate', candidate, false))) {
                                                            pos = J$.W(10021, 'pos', J$.G(10017, J$.G(10009, J$.R(10005, 'candidate', candidate, false), 'range'), J$.T(10013, 0, 22)), pos);
                                                            len = J$.W(10045, 'len', J$.B(1834, '-', J$.G(10037, J$.G(10029, J$.R(10025, 'candidate', candidate, false), 'range'), J$.T(10033, 1, 22)), J$.R(10041, 'pos', pos, false)), len);
                                                            if (J$.C(1248, J$.C(1244, J$.B(1838, '<=', J$.G(10061, J$.G(10053, J$.R(10049, 'node', node, false), 'range'), J$.T(10057, 0, 22)), J$.R(10065, 'pos', pos, false))) ? J$.B(1846, '>=', J$.B(1842, '-', J$.G(10081, J$.G(10073, J$.R(10069, 'node', node, false), 'range'), J$.T(10077, 1, 22)), J$.G(10097, J$.G(10089, J$.R(10085, 'node', node, false), 'range'), J$.T(10093, 0, 22))), J$.R(10101, 'len', len, false)) : J$._())) {
                                                                J$.P(10113, J$.R(10105, 'attacher', attacher, false), 'trailing', J$.R(10109, 'node', node, false));
                                                            }
                                                        } else {
                                                            J$.P(10125, J$.R(10117, 'attacher', attacher, false), 'trailing', J$.R(10121, 'node', node, false));
                                                        }
                                                    }
                                                }
                                            } catch (J$e) {
                                                J$.Ex(29181, J$e);
                                            } finally {
                                                if (J$.Fr(29185))
                                                    continue jalangiLabel35;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                markEnd: J$.T(10317, function (node) {
                                    jalangiLabel36:
                                        while (true) {
                                            try {
                                                J$.Fe(10305, arguments.callee, this);
                                                arguments = J$.N(10309, 'arguments', arguments, true);
                                                node = J$.N(10313, 'node', node, true);
                                                if (J$.C(1264, J$.G(10169, J$.R(10165, 'extra', extra, false), 'range'))) {
                                                    J$.P(10197, J$.R(10173, 'node', node, false), 'range', J$.T(10193, [
                                                        J$.M(10185, J$.G(10181, J$.R(10177, 'state', state, false), 'markerStack'), 'pop', false)(),
                                                        J$.R(10189, 'index', index, false)
                                                    ], 10));
                                                }
                                                if (J$.C(1268, J$.G(10205, J$.R(10201, 'extra', extra, false), 'loc'))) {
                                                    J$.P(10261, J$.R(10209, 'node', node, false), 'loc', J$.T(10257, {
                                                        start: J$.T(10237, {
                                                            line: J$.M(10221, J$.G(10217, J$.R(10213, 'state', state, false), 'markerStack'), 'pop', false)(),
                                                            column: J$.M(10233, J$.G(10229, J$.R(10225, 'state', state, false), 'markerStack'), 'pop', false)()
                                                        }, 11),
                                                        end: J$.T(10253, {
                                                            line: J$.R(10241, 'lineNumber', lineNumber, false),
                                                            column: J$.B(1850, '-', J$.R(10245, 'index', index, false), J$.R(10249, 'lineStart', lineStart, false))
                                                        }, 11)
                                                    }, 11));
                                                    J$.M(10273, J$.R(10265, 'this', this, false), 'postProcess', false)(J$.R(10269, 'node', node, false));
                                                }
                                                if (J$.C(1272, J$.G(10281, J$.R(10277, 'extra', extra, false), 'attachComment'))) {
                                                    J$.M(10293, J$.R(10285, 'this', this, false), 'processComment', false)(J$.R(10289, 'node', node, false));
                                                }
                                                return J$.Rt(10301, J$.R(10297, 'node', node, false));
                                            } catch (J$e) {
                                                J$.Ex(29189, J$e);
                                            } finally {
                                                if (J$.Fr(29193))
                                                    continue jalangiLabel36;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                markEndIf: J$.T(10421, function (node) {
                                    jalangiLabel37:
                                        while (true) {
                                            try {
                                                J$.Fe(10409, arguments.callee, this);
                                                arguments = J$.N(10413, 'arguments', arguments, true);
                                                node = J$.N(10417, 'node', node, true);
                                                if (J$.C(1288, J$.C(1276, J$.G(10325, J$.R(10321, 'node', node, false), 'range')) ? J$._() : J$.G(10333, J$.R(10329, 'node', node, false), 'loc'))) {
                                                    if (J$.C(1280, J$.G(10341, J$.R(10337, 'extra', extra, false), 'loc'))) {
                                                        J$.M(10353, J$.G(10349, J$.R(10345, 'state', state, false), 'markerStack'), 'pop', false)();
                                                        J$.M(10365, J$.G(10361, J$.R(10357, 'state', state, false), 'markerStack'), 'pop', false)();
                                                    }
                                                    if (J$.C(1284, J$.G(10373, J$.R(10369, 'extra', extra, false), 'range'))) {
                                                        J$.M(10385, J$.G(10381, J$.R(10377, 'state', state, false), 'markerStack'), 'pop', false)();
                                                    }
                                                } else {
                                                    J$.M(10397, J$.R(10389, 'this', this, false), 'markEnd', false)(J$.R(10393, 'node', node, false));
                                                }
                                                return J$.Rt(10405, J$.R(10401, 'node', node, false));
                                            } catch (J$e) {
                                                J$.Ex(29197, J$e);
                                            } finally {
                                                if (J$.Fr(29201))
                                                    continue jalangiLabel37;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                postProcess: J$.T(10473, function (node) {
                                    jalangiLabel38:
                                        while (true) {
                                            try {
                                                J$.Fe(10461, arguments.callee, this);
                                                arguments = J$.N(10465, 'arguments', arguments, true);
                                                node = J$.N(10469, 'node', node, true);
                                                if (J$.C(1292, J$.G(10429, J$.R(10425, 'extra', extra, false), 'source'))) {
                                                    J$.P(10449, J$.G(10437, J$.R(10433, 'node', node, false), 'loc'), 'source', J$.G(10445, J$.R(10441, 'extra', extra, false), 'source'));
                                                }
                                                return J$.Rt(10457, J$.R(10453, 'node', node, false));
                                            } catch (J$e) {
                                                J$.Ex(29205, J$e);
                                            } finally {
                                                if (J$.Fr(29209))
                                                    continue jalangiLabel38;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createArrayExpression: J$.T(10509, function (elements) {
                                    jalangiLabel39:
                                        while (true) {
                                            try {
                                                J$.Fe(10497, arguments.callee, this);
                                                arguments = J$.N(10501, 'arguments', arguments, true);
                                                elements = J$.N(10505, 'elements', elements, true);
                                                return J$.Rt(10493, J$.T(10489, {
                                                    type: J$.G(10481, J$.R(10477, 'Syntax', Syntax, false), 'ArrayExpression'),
                                                    elements: J$.R(10485, 'elements', elements, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29213, J$e);
                                            } finally {
                                                if (J$.Fr(29217))
                                                    continue jalangiLabel39;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createAssignmentExpression: J$.T(10561, function (operator, left, right) {
                                    jalangiLabel40:
                                        while (true) {
                                            try {
                                                J$.Fe(10541, arguments.callee, this);
                                                arguments = J$.N(10545, 'arguments', arguments, true);
                                                operator = J$.N(10549, 'operator', operator, true);
                                                left = J$.N(10553, 'left', left, true);
                                                right = J$.N(10557, 'right', right, true);
                                                return J$.Rt(10537, J$.T(10533, {
                                                    type: J$.G(10517, J$.R(10513, 'Syntax', Syntax, false), 'AssignmentExpression'),
                                                    operator: J$.R(10521, 'operator', operator, false),
                                                    left: J$.R(10525, 'left', left, false),
                                                    right: J$.R(10529, 'right', right, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29221, J$e);
                                            } finally {
                                                if (J$.Fr(29225))
                                                    continue jalangiLabel40;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createBinaryExpression: J$.T(10649, function (operator, left, right) {
                                    jalangiLabel41:
                                        while (true) {
                                            try {
                                                J$.Fe(10625, arguments.callee, this);
                                                arguments = J$.N(10629, 'arguments', arguments, true);
                                                operator = J$.N(10633, 'operator', operator, true);
                                                left = J$.N(10637, 'left', left, true);
                                                right = J$.N(10641, 'right', right, true);
                                                J$.N(10645, 'type', type, false);
                                                var type = J$.W(10597, 'type', J$.C(1300, J$.C(1296, J$.B(1854, '===', J$.R(10565, 'operator', operator, false), J$.T(10569, '||', 21))) ? J$._() : J$.B(1858, '===', J$.R(10573, 'operator', operator, false), J$.T(10577, '&&', 21))) ? J$.G(10585, J$.R(10581, 'Syntax', Syntax, false), 'LogicalExpression') : J$.G(10593, J$.R(10589, 'Syntax', Syntax, false), 'BinaryExpression'), type);
                                                return J$.Rt(10621, J$.T(10617, {
                                                    type: J$.R(10601, 'type', type, false),
                                                    operator: J$.R(10605, 'operator', operator, false),
                                                    left: J$.R(10609, 'left', left, false),
                                                    right: J$.R(10613, 'right', right, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29229, J$e);
                                            } finally {
                                                if (J$.Fr(29233))
                                                    continue jalangiLabel41;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createBlockStatement: J$.T(10685, function (body) {
                                    jalangiLabel42:
                                        while (true) {
                                            try {
                                                J$.Fe(10673, arguments.callee, this);
                                                arguments = J$.N(10677, 'arguments', arguments, true);
                                                body = J$.N(10681, 'body', body, true);
                                                return J$.Rt(10669, J$.T(10665, {
                                                    type: J$.G(10657, J$.R(10653, 'Syntax', Syntax, false), 'BlockStatement'),
                                                    body: J$.R(10661, 'body', body, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29237, J$e);
                                            } finally {
                                                if (J$.Fr(29241))
                                                    continue jalangiLabel42;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createBreakStatement: J$.T(10721, function (label) {
                                    jalangiLabel43:
                                        while (true) {
                                            try {
                                                J$.Fe(10709, arguments.callee, this);
                                                arguments = J$.N(10713, 'arguments', arguments, true);
                                                label = J$.N(10717, 'label', label, true);
                                                return J$.Rt(10705, J$.T(10701, {
                                                    type: J$.G(10693, J$.R(10689, 'Syntax', Syntax, false), 'BreakStatement'),
                                                    label: J$.R(10697, 'label', label, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29245, J$e);
                                            } finally {
                                                if (J$.Fr(29249))
                                                    continue jalangiLabel43;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createCallExpression: J$.T(10765, function (callee, args) {
                                    jalangiLabel44:
                                        while (true) {
                                            try {
                                                J$.Fe(10749, arguments.callee, this);
                                                arguments = J$.N(10753, 'arguments', arguments, true);
                                                callee = J$.N(10757, 'callee', callee, true);
                                                args = J$.N(10761, 'args', args, true);
                                                return J$.Rt(10745, J$.T(10741, {
                                                    type: J$.G(10729, J$.R(10725, 'Syntax', Syntax, false), 'CallExpression'),
                                                    callee: J$.R(10733, 'callee', callee, false),
                                                    'arguments': J$.R(10737, 'args', args, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29253, J$e);
                                            } finally {
                                                if (J$.Fr(29257))
                                                    continue jalangiLabel44;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createCatchClause: J$.T(10809, function (param, body) {
                                    jalangiLabel45:
                                        while (true) {
                                            try {
                                                J$.Fe(10793, arguments.callee, this);
                                                arguments = J$.N(10797, 'arguments', arguments, true);
                                                param = J$.N(10801, 'param', param, true);
                                                body = J$.N(10805, 'body', body, true);
                                                return J$.Rt(10789, J$.T(10785, {
                                                    type: J$.G(10773, J$.R(10769, 'Syntax', Syntax, false), 'CatchClause'),
                                                    param: J$.R(10777, 'param', param, false),
                                                    body: J$.R(10781, 'body', body, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29261, J$e);
                                            } finally {
                                                if (J$.Fr(29265))
                                                    continue jalangiLabel45;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createConditionalExpression: J$.T(10861, function (test, consequent, alternate) {
                                    jalangiLabel46:
                                        while (true) {
                                            try {
                                                J$.Fe(10841, arguments.callee, this);
                                                arguments = J$.N(10845, 'arguments', arguments, true);
                                                test = J$.N(10849, 'test', test, true);
                                                consequent = J$.N(10853, 'consequent', consequent, true);
                                                alternate = J$.N(10857, 'alternate', alternate, true);
                                                return J$.Rt(10837, J$.T(10833, {
                                                    type: J$.G(10817, J$.R(10813, 'Syntax', Syntax, false), 'ConditionalExpression'),
                                                    test: J$.R(10821, 'test', test, false),
                                                    consequent: J$.R(10825, 'consequent', consequent, false),
                                                    alternate: J$.R(10829, 'alternate', alternate, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29269, J$e);
                                            } finally {
                                                if (J$.Fr(29273))
                                                    continue jalangiLabel46;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createContinueStatement: J$.T(10897, function (label) {
                                    jalangiLabel47:
                                        while (true) {
                                            try {
                                                J$.Fe(10885, arguments.callee, this);
                                                arguments = J$.N(10889, 'arguments', arguments, true);
                                                label = J$.N(10893, 'label', label, true);
                                                return J$.Rt(10881, J$.T(10877, {
                                                    type: J$.G(10869, J$.R(10865, 'Syntax', Syntax, false), 'ContinueStatement'),
                                                    label: J$.R(10873, 'label', label, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29277, J$e);
                                            } finally {
                                                if (J$.Fr(29281))
                                                    continue jalangiLabel47;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createDebuggerStatement: J$.T(10925, function () {
                                    jalangiLabel48:
                                        while (true) {
                                            try {
                                                J$.Fe(10917, arguments.callee, this);
                                                arguments = J$.N(10921, 'arguments', arguments, true);
                                                return J$.Rt(10913, J$.T(10909, { type: J$.G(10905, J$.R(10901, 'Syntax', Syntax, false), 'DebuggerStatement') }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29285, J$e);
                                            } finally {
                                                if (J$.Fr(29289))
                                                    continue jalangiLabel48;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createDoWhileStatement: J$.T(10969, function (body, test) {
                                    jalangiLabel49:
                                        while (true) {
                                            try {
                                                J$.Fe(10953, arguments.callee, this);
                                                arguments = J$.N(10957, 'arguments', arguments, true);
                                                body = J$.N(10961, 'body', body, true);
                                                test = J$.N(10965, 'test', test, true);
                                                return J$.Rt(10949, J$.T(10945, {
                                                    type: J$.G(10933, J$.R(10929, 'Syntax', Syntax, false), 'DoWhileStatement'),
                                                    body: J$.R(10937, 'body', body, false),
                                                    test: J$.R(10941, 'test', test, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29293, J$e);
                                            } finally {
                                                if (J$.Fr(29297))
                                                    continue jalangiLabel49;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createEmptyStatement: J$.T(10997, function () {
                                    jalangiLabel50:
                                        while (true) {
                                            try {
                                                J$.Fe(10989, arguments.callee, this);
                                                arguments = J$.N(10993, 'arguments', arguments, true);
                                                return J$.Rt(10985, J$.T(10981, { type: J$.G(10977, J$.R(10973, 'Syntax', Syntax, false), 'EmptyStatement') }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29301, J$e);
                                            } finally {
                                                if (J$.Fr(29305))
                                                    continue jalangiLabel50;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createExpressionStatement: J$.T(11033, function (expression) {
                                    jalangiLabel51:
                                        while (true) {
                                            try {
                                                J$.Fe(11021, arguments.callee, this);
                                                arguments = J$.N(11025, 'arguments', arguments, true);
                                                expression = J$.N(11029, 'expression', expression, true);
                                                return J$.Rt(11017, J$.T(11013, {
                                                    type: J$.G(11005, J$.R(11001, 'Syntax', Syntax, false), 'ExpressionStatement'),
                                                    expression: J$.R(11009, 'expression', expression, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29309, J$e);
                                            } finally {
                                                if (J$.Fr(29313))
                                                    continue jalangiLabel51;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createForStatement: J$.T(11093, function (init, test, update, body) {
                                    jalangiLabel52:
                                        while (true) {
                                            try {
                                                J$.Fe(11069, arguments.callee, this);
                                                arguments = J$.N(11073, 'arguments', arguments, true);
                                                init = J$.N(11077, 'init', init, true);
                                                test = J$.N(11081, 'test', test, true);
                                                update = J$.N(11085, 'update', update, true);
                                                body = J$.N(11089, 'body', body, true);
                                                return J$.Rt(11065, J$.T(11061, {
                                                    type: J$.G(11041, J$.R(11037, 'Syntax', Syntax, false), 'ForStatement'),
                                                    init: J$.R(11045, 'init', init, false),
                                                    test: J$.R(11049, 'test', test, false),
                                                    update: J$.R(11053, 'update', update, false),
                                                    body: J$.R(11057, 'body', body, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29317, J$e);
                                            } finally {
                                                if (J$.Fr(29321))
                                                    continue jalangiLabel52;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createForInStatement: J$.T(11149, function (left, right, body) {
                                    jalangiLabel53:
                                        while (true) {
                                            try {
                                                J$.Fe(11129, arguments.callee, this);
                                                arguments = J$.N(11133, 'arguments', arguments, true);
                                                left = J$.N(11137, 'left', left, true);
                                                right = J$.N(11141, 'right', right, true);
                                                body = J$.N(11145, 'body', body, true);
                                                return J$.Rt(11125, J$.T(11121, {
                                                    type: J$.G(11101, J$.R(11097, 'Syntax', Syntax, false), 'ForInStatement'),
                                                    left: J$.R(11105, 'left', left, false),
                                                    right: J$.R(11109, 'right', right, false),
                                                    body: J$.R(11113, 'body', body, false),
                                                    each: J$.T(11117, false, 23)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29325, J$e);
                                            } finally {
                                                if (J$.Fr(29329))
                                                    continue jalangiLabel53;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createFunctionDeclaration: J$.T(11221, function (id, params, defaults, body) {
                                    jalangiLabel54:
                                        while (true) {
                                            try {
                                                J$.Fe(11197, arguments.callee, this);
                                                arguments = J$.N(11201, 'arguments', arguments, true);
                                                id = J$.N(11205, 'id', id, true);
                                                params = J$.N(11209, 'params', params, true);
                                                defaults = J$.N(11213, 'defaults', defaults, true);
                                                body = J$.N(11217, 'body', body, true);
                                                return J$.Rt(11193, J$.T(11189, {
                                                    type: J$.G(11157, J$.R(11153, 'Syntax', Syntax, false), 'FunctionDeclaration'),
                                                    id: J$.R(11161, 'id', id, false),
                                                    params: J$.R(11165, 'params', params, false),
                                                    defaults: J$.R(11169, 'defaults', defaults, false),
                                                    body: J$.R(11173, 'body', body, false),
                                                    rest: J$.T(11177, null, 25),
                                                    generator: J$.T(11181, false, 23),
                                                    expression: J$.T(11185, false, 23)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29333, J$e);
                                            } finally {
                                                if (J$.Fr(29337))
                                                    continue jalangiLabel54;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createFunctionExpression: J$.T(11293, function (id, params, defaults, body) {
                                    jalangiLabel55:
                                        while (true) {
                                            try {
                                                J$.Fe(11269, arguments.callee, this);
                                                arguments = J$.N(11273, 'arguments', arguments, true);
                                                id = J$.N(11277, 'id', id, true);
                                                params = J$.N(11281, 'params', params, true);
                                                defaults = J$.N(11285, 'defaults', defaults, true);
                                                body = J$.N(11289, 'body', body, true);
                                                return J$.Rt(11265, J$.T(11261, {
                                                    type: J$.G(11229, J$.R(11225, 'Syntax', Syntax, false), 'FunctionExpression'),
                                                    id: J$.R(11233, 'id', id, false),
                                                    params: J$.R(11237, 'params', params, false),
                                                    defaults: J$.R(11241, 'defaults', defaults, false),
                                                    body: J$.R(11245, 'body', body, false),
                                                    rest: J$.T(11249, null, 25),
                                                    generator: J$.T(11253, false, 23),
                                                    expression: J$.T(11257, false, 23)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29341, J$e);
                                            } finally {
                                                if (J$.Fr(29345))
                                                    continue jalangiLabel55;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createIdentifier: J$.T(11329, function (name) {
                                    jalangiLabel56:
                                        while (true) {
                                            try {
                                                J$.Fe(11317, arguments.callee, this);
                                                arguments = J$.N(11321, 'arguments', arguments, true);
                                                name = J$.N(11325, 'name', name, true);
                                                return J$.Rt(11313, J$.T(11309, {
                                                    type: J$.G(11301, J$.R(11297, 'Syntax', Syntax, false), 'Identifier'),
                                                    name: J$.R(11305, 'name', name, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29349, J$e);
                                            } finally {
                                                if (J$.Fr(29353))
                                                    continue jalangiLabel56;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createIfStatement: J$.T(11381, function (test, consequent, alternate) {
                                    jalangiLabel57:
                                        while (true) {
                                            try {
                                                J$.Fe(11361, arguments.callee, this);
                                                arguments = J$.N(11365, 'arguments', arguments, true);
                                                test = J$.N(11369, 'test', test, true);
                                                consequent = J$.N(11373, 'consequent', consequent, true);
                                                alternate = J$.N(11377, 'alternate', alternate, true);
                                                return J$.Rt(11357, J$.T(11353, {
                                                    type: J$.G(11337, J$.R(11333, 'Syntax', Syntax, false), 'IfStatement'),
                                                    test: J$.R(11341, 'test', test, false),
                                                    consequent: J$.R(11345, 'consequent', consequent, false),
                                                    alternate: J$.R(11349, 'alternate', alternate, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29357, J$e);
                                            } finally {
                                                if (J$.Fr(29361))
                                                    continue jalangiLabel57;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createLabeledStatement: J$.T(11425, function (label, body) {
                                    jalangiLabel58:
                                        while (true) {
                                            try {
                                                J$.Fe(11409, arguments.callee, this);
                                                arguments = J$.N(11413, 'arguments', arguments, true);
                                                label = J$.N(11417, 'label', label, true);
                                                body = J$.N(11421, 'body', body, true);
                                                return J$.Rt(11405, J$.T(11401, {
                                                    type: J$.G(11389, J$.R(11385, 'Syntax', Syntax, false), 'LabeledStatement'),
                                                    label: J$.R(11393, 'label', label, false),
                                                    body: J$.R(11397, 'body', body, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29365, J$e);
                                            } finally {
                                                if (J$.Fr(29369))
                                                    continue jalangiLabel58;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createLiteral: J$.T(11505, function (token) {
                                    jalangiLabel59:
                                        while (true) {
                                            try {
                                                J$.Fe(11493, arguments.callee, this);
                                                arguments = J$.N(11497, 'arguments', arguments, true);
                                                token = J$.N(11501, 'token', token, true);
                                                return J$.Rt(11489, J$.T(11485, {
                                                    type: J$.G(11433, J$.R(11429, 'Syntax', Syntax, false), 'Literal'),
                                                    value: J$.G(11441, J$.R(11437, 'token', token, false), 'value'),
                                                    raw: J$.M(11481, J$.R(11445, 'source', source, false), 'slice', false)(J$.G(11461, J$.G(11453, J$.R(11449, 'token', token, false), 'range'), J$.T(11457, 0, 22)), J$.G(11477, J$.G(11469, J$.R(11465, 'token', token, false), 'range'), J$.T(11473, 1, 22)))
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29373, J$e);
                                            } finally {
                                                if (J$.Fr(29377))
                                                    continue jalangiLabel59;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createMemberExpression: J$.T(11561, function (accessor, object, property) {
                                    jalangiLabel60:
                                        while (true) {
                                            try {
                                                J$.Fe(11541, arguments.callee, this);
                                                arguments = J$.N(11545, 'arguments', arguments, true);
                                                accessor = J$.N(11549, 'accessor', accessor, true);
                                                object = J$.N(11553, 'object', object, true);
                                                property = J$.N(11557, 'property', property, true);
                                                return J$.Rt(11537, J$.T(11533, {
                                                    type: J$.G(11513, J$.R(11509, 'Syntax', Syntax, false), 'MemberExpression'),
                                                    computed: J$.B(1862, '===', J$.R(11517, 'accessor', accessor, false), J$.T(11521, '[', 21)),
                                                    object: J$.R(11525, 'object', object, false),
                                                    property: J$.R(11529, 'property', property, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29381, J$e);
                                            } finally {
                                                if (J$.Fr(29385))
                                                    continue jalangiLabel60;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createNewExpression: J$.T(11605, function (callee, args) {
                                    jalangiLabel61:
                                        while (true) {
                                            try {
                                                J$.Fe(11589, arguments.callee, this);
                                                arguments = J$.N(11593, 'arguments', arguments, true);
                                                callee = J$.N(11597, 'callee', callee, true);
                                                args = J$.N(11601, 'args', args, true);
                                                return J$.Rt(11585, J$.T(11581, {
                                                    type: J$.G(11569, J$.R(11565, 'Syntax', Syntax, false), 'NewExpression'),
                                                    callee: J$.R(11573, 'callee', callee, false),
                                                    'arguments': J$.R(11577, 'args', args, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29389, J$e);
                                            } finally {
                                                if (J$.Fr(29393))
                                                    continue jalangiLabel61;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createObjectExpression: J$.T(11641, function (properties) {
                                    jalangiLabel62:
                                        while (true) {
                                            try {
                                                J$.Fe(11629, arguments.callee, this);
                                                arguments = J$.N(11633, 'arguments', arguments, true);
                                                properties = J$.N(11637, 'properties', properties, true);
                                                return J$.Rt(11625, J$.T(11621, {
                                                    type: J$.G(11613, J$.R(11609, 'Syntax', Syntax, false), 'ObjectExpression'),
                                                    properties: J$.R(11617, 'properties', properties, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29397, J$e);
                                            } finally {
                                                if (J$.Fr(29401))
                                                    continue jalangiLabel62;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createPostfixExpression: J$.T(11689, function (operator, argument) {
                                    jalangiLabel63:
                                        while (true) {
                                            try {
                                                J$.Fe(11673, arguments.callee, this);
                                                arguments = J$.N(11677, 'arguments', arguments, true);
                                                operator = J$.N(11681, 'operator', operator, true);
                                                argument = J$.N(11685, 'argument', argument, true);
                                                return J$.Rt(11669, J$.T(11665, {
                                                    type: J$.G(11649, J$.R(11645, 'Syntax', Syntax, false), 'UpdateExpression'),
                                                    operator: J$.R(11653, 'operator', operator, false),
                                                    argument: J$.R(11657, 'argument', argument, false),
                                                    prefix: J$.T(11661, false, 23)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29405, J$e);
                                            } finally {
                                                if (J$.Fr(29409))
                                                    continue jalangiLabel63;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createProgram: J$.T(11725, function (body) {
                                    jalangiLabel64:
                                        while (true) {
                                            try {
                                                J$.Fe(11713, arguments.callee, this);
                                                arguments = J$.N(11717, 'arguments', arguments, true);
                                                body = J$.N(11721, 'body', body, true);
                                                return J$.Rt(11709, J$.T(11705, {
                                                    type: J$.G(11697, J$.R(11693, 'Syntax', Syntax, false), 'Program'),
                                                    body: J$.R(11701, 'body', body, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29413, J$e);
                                            } finally {
                                                if (J$.Fr(29417))
                                                    continue jalangiLabel64;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createProperty: J$.T(11777, function (kind, key, value) {
                                    jalangiLabel65:
                                        while (true) {
                                            try {
                                                J$.Fe(11757, arguments.callee, this);
                                                arguments = J$.N(11761, 'arguments', arguments, true);
                                                kind = J$.N(11765, 'kind', kind, true);
                                                key = J$.N(11769, 'key', key, true);
                                                value = J$.N(11773, 'value', value, true);
                                                return J$.Rt(11753, J$.T(11749, {
                                                    type: J$.G(11733, J$.R(11729, 'Syntax', Syntax, false), 'Property'),
                                                    key: J$.R(11737, 'key', key, false),
                                                    value: J$.R(11741, 'value', value, false),
                                                    kind: J$.R(11745, 'kind', kind, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29421, J$e);
                                            } finally {
                                                if (J$.Fr(29425))
                                                    continue jalangiLabel65;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createReturnStatement: J$.T(11813, function (argument) {
                                    jalangiLabel66:
                                        while (true) {
                                            try {
                                                J$.Fe(11801, arguments.callee, this);
                                                arguments = J$.N(11805, 'arguments', arguments, true);
                                                argument = J$.N(11809, 'argument', argument, true);
                                                return J$.Rt(11797, J$.T(11793, {
                                                    type: J$.G(11785, J$.R(11781, 'Syntax', Syntax, false), 'ReturnStatement'),
                                                    argument: J$.R(11789, 'argument', argument, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29429, J$e);
                                            } finally {
                                                if (J$.Fr(29433))
                                                    continue jalangiLabel66;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createSequenceExpression: J$.T(11849, function (expressions) {
                                    jalangiLabel67:
                                        while (true) {
                                            try {
                                                J$.Fe(11837, arguments.callee, this);
                                                arguments = J$.N(11841, 'arguments', arguments, true);
                                                expressions = J$.N(11845, 'expressions', expressions, true);
                                                return J$.Rt(11833, J$.T(11829, {
                                                    type: J$.G(11821, J$.R(11817, 'Syntax', Syntax, false), 'SequenceExpression'),
                                                    expressions: J$.R(11825, 'expressions', expressions, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29437, J$e);
                                            } finally {
                                                if (J$.Fr(29441))
                                                    continue jalangiLabel67;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createSwitchCase: J$.T(11893, function (test, consequent) {
                                    jalangiLabel68:
                                        while (true) {
                                            try {
                                                J$.Fe(11877, arguments.callee, this);
                                                arguments = J$.N(11881, 'arguments', arguments, true);
                                                test = J$.N(11885, 'test', test, true);
                                                consequent = J$.N(11889, 'consequent', consequent, true);
                                                return J$.Rt(11873, J$.T(11869, {
                                                    type: J$.G(11857, J$.R(11853, 'Syntax', Syntax, false), 'SwitchCase'),
                                                    test: J$.R(11861, 'test', test, false),
                                                    consequent: J$.R(11865, 'consequent', consequent, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29445, J$e);
                                            } finally {
                                                if (J$.Fr(29449))
                                                    continue jalangiLabel68;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createSwitchStatement: J$.T(11937, function (discriminant, cases) {
                                    jalangiLabel69:
                                        while (true) {
                                            try {
                                                J$.Fe(11921, arguments.callee, this);
                                                arguments = J$.N(11925, 'arguments', arguments, true);
                                                discriminant = J$.N(11929, 'discriminant', discriminant, true);
                                                cases = J$.N(11933, 'cases', cases, true);
                                                return J$.Rt(11917, J$.T(11913, {
                                                    type: J$.G(11901, J$.R(11897, 'Syntax', Syntax, false), 'SwitchStatement'),
                                                    discriminant: J$.R(11905, 'discriminant', discriminant, false),
                                                    cases: J$.R(11909, 'cases', cases, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29453, J$e);
                                            } finally {
                                                if (J$.Fr(29457))
                                                    continue jalangiLabel69;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createThisExpression: J$.T(11965, function () {
                                    jalangiLabel70:
                                        while (true) {
                                            try {
                                                J$.Fe(11957, arguments.callee, this);
                                                arguments = J$.N(11961, 'arguments', arguments, true);
                                                return J$.Rt(11953, J$.T(11949, { type: J$.G(11945, J$.R(11941, 'Syntax', Syntax, false), 'ThisExpression') }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29461, J$e);
                                            } finally {
                                                if (J$.Fr(29465))
                                                    continue jalangiLabel70;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createThrowStatement: J$.T(12001, function (argument) {
                                    jalangiLabel71:
                                        while (true) {
                                            try {
                                                J$.Fe(11989, arguments.callee, this);
                                                arguments = J$.N(11993, 'arguments', arguments, true);
                                                argument = J$.N(11997, 'argument', argument, true);
                                                return J$.Rt(11985, J$.T(11981, {
                                                    type: J$.G(11973, J$.R(11969, 'Syntax', Syntax, false), 'ThrowStatement'),
                                                    argument: J$.R(11977, 'argument', argument, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29469, J$e);
                                            } finally {
                                                if (J$.Fr(29473))
                                                    continue jalangiLabel71;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createTryStatement: J$.T(12061, function (block, guardedHandlers, handlers, finalizer) {
                                    jalangiLabel72:
                                        while (true) {
                                            try {
                                                J$.Fe(12037, arguments.callee, this);
                                                arguments = J$.N(12041, 'arguments', arguments, true);
                                                block = J$.N(12045, 'block', block, true);
                                                guardedHandlers = J$.N(12049, 'guardedHandlers', guardedHandlers, true);
                                                handlers = J$.N(12053, 'handlers', handlers, true);
                                                finalizer = J$.N(12057, 'finalizer', finalizer, true);
                                                return J$.Rt(12033, J$.T(12029, {
                                                    type: J$.G(12009, J$.R(12005, 'Syntax', Syntax, false), 'TryStatement'),
                                                    block: J$.R(12013, 'block', block, false),
                                                    guardedHandlers: J$.R(12017, 'guardedHandlers', guardedHandlers, false),
                                                    handlers: J$.R(12021, 'handlers', handlers, false),
                                                    finalizer: J$.R(12025, 'finalizer', finalizer, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29477, J$e);
                                            } finally {
                                                if (J$.Fr(29481))
                                                    continue jalangiLabel72;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createUnaryExpression: J$.T(12153, function (operator, argument) {
                                    jalangiLabel73:
                                        while (true) {
                                            try {
                                                J$.Fe(12137, arguments.callee, this);
                                                arguments = J$.N(12141, 'arguments', arguments, true);
                                                operator = J$.N(12145, 'operator', operator, true);
                                                argument = J$.N(12149, 'argument', argument, true);
                                                if (J$.C(1308, J$.C(1304, J$.B(1866, '===', J$.R(12065, 'operator', operator, false), J$.T(12069, '++', 21))) ? J$._() : J$.B(1870, '===', J$.R(12073, 'operator', operator, false), J$.T(12077, '--', 21)))) {
                                                    return J$.Rt(12105, J$.T(12101, {
                                                        type: J$.G(12085, J$.R(12081, 'Syntax', Syntax, false), 'UpdateExpression'),
                                                        operator: J$.R(12089, 'operator', operator, false),
                                                        argument: J$.R(12093, 'argument', argument, false),
                                                        prefix: J$.T(12097, true, 23)
                                                    }, 11));
                                                }
                                                return J$.Rt(12133, J$.T(12129, {
                                                    type: J$.G(12113, J$.R(12109, 'Syntax', Syntax, false), 'UnaryExpression'),
                                                    operator: J$.R(12117, 'operator', operator, false),
                                                    argument: J$.R(12121, 'argument', argument, false),
                                                    prefix: J$.T(12125, true, 23)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29485, J$e);
                                            } finally {
                                                if (J$.Fr(29489))
                                                    continue jalangiLabel73;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createVariableDeclaration: J$.T(12197, function (declarations, kind) {
                                    jalangiLabel74:
                                        while (true) {
                                            try {
                                                J$.Fe(12181, arguments.callee, this);
                                                arguments = J$.N(12185, 'arguments', arguments, true);
                                                declarations = J$.N(12189, 'declarations', declarations, true);
                                                kind = J$.N(12193, 'kind', kind, true);
                                                return J$.Rt(12177, J$.T(12173, {
                                                    type: J$.G(12161, J$.R(12157, 'Syntax', Syntax, false), 'VariableDeclaration'),
                                                    declarations: J$.R(12165, 'declarations', declarations, false),
                                                    kind: J$.R(12169, 'kind', kind, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29493, J$e);
                                            } finally {
                                                if (J$.Fr(29497))
                                                    continue jalangiLabel74;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createVariableDeclarator: J$.T(12241, function (id, init) {
                                    jalangiLabel75:
                                        while (true) {
                                            try {
                                                J$.Fe(12225, arguments.callee, this);
                                                arguments = J$.N(12229, 'arguments', arguments, true);
                                                id = J$.N(12233, 'id', id, true);
                                                init = J$.N(12237, 'init', init, true);
                                                return J$.Rt(12221, J$.T(12217, {
                                                    type: J$.G(12205, J$.R(12201, 'Syntax', Syntax, false), 'VariableDeclarator'),
                                                    id: J$.R(12209, 'id', id, false),
                                                    init: J$.R(12213, 'init', init, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29501, J$e);
                                            } finally {
                                                if (J$.Fr(29505))
                                                    continue jalangiLabel75;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createWhileStatement: J$.T(12285, function (test, body) {
                                    jalangiLabel76:
                                        while (true) {
                                            try {
                                                J$.Fe(12269, arguments.callee, this);
                                                arguments = J$.N(12273, 'arguments', arguments, true);
                                                test = J$.N(12277, 'test', test, true);
                                                body = J$.N(12281, 'body', body, true);
                                                return J$.Rt(12265, J$.T(12261, {
                                                    type: J$.G(12249, J$.R(12245, 'Syntax', Syntax, false), 'WhileStatement'),
                                                    test: J$.R(12253, 'test', test, false),
                                                    body: J$.R(12257, 'body', body, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29509, J$e);
                                            } finally {
                                                if (J$.Fr(29513))
                                                    continue jalangiLabel76;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                createWithStatement: J$.T(12329, function (object, body) {
                                    jalangiLabel77:
                                        while (true) {
                                            try {
                                                J$.Fe(12313, arguments.callee, this);
                                                arguments = J$.N(12317, 'arguments', arguments, true);
                                                object = J$.N(12321, 'object', object, true);
                                                body = J$.N(12325, 'body', body, true);
                                                return J$.Rt(12309, J$.T(12305, {
                                                    type: J$.G(12293, J$.R(12289, 'Syntax', Syntax, false), 'WithStatement'),
                                                    object: J$.R(12297, 'object', object, false),
                                                    body: J$.R(12301, 'body', body, false)
                                                }, 11));
                                            } catch (J$e) {
                                                J$.Ex(29517, J$e);
                                            } finally {
                                                if (J$.Fr(29521))
                                                    continue jalangiLabel77;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12)
                            }, 11), SyntaxTreeDelegate);
                            function peekLineTerminator() {
                                jalangiLabel78:
                                    while (true) {
                                        try {
                                            J$.Fe(12417, arguments.callee, this);
                                            arguments = J$.N(12421, 'arguments', arguments, true);
                                            J$.N(12425, 'pos', pos, false);
                                            J$.N(12429, 'line', line, false);
                                            J$.N(12433, 'start', start, false);
                                            J$.N(12437, 'found', found, false);
                                            var pos, line, start, found;
                                            pos = J$.W(12345, 'pos', J$.R(12341, 'index', index, false), pos);
                                            line = J$.W(12353, 'line', J$.R(12349, 'lineNumber', lineNumber, false), line);
                                            start = J$.W(12361, 'start', J$.R(12357, 'lineStart', lineStart, false), start);
                                            J$.F(12369, J$.R(12365, 'skipComment', skipComment, false), false)();
                                            found = J$.W(12381, 'found', J$.B(1874, '!==', J$.R(12373, 'lineNumber', lineNumber, false), J$.R(12377, 'line', line, false)), found);
                                            index = J$.W(12389, 'index', J$.R(12385, 'pos', pos, false), index);
                                            lineNumber = J$.W(12397, 'lineNumber', J$.R(12393, 'line', line, false), lineNumber);
                                            lineStart = J$.W(12405, 'lineStart', J$.R(12401, 'start', start, false), lineStart);
                                            return J$.Rt(12413, J$.R(12409, 'found', found, false));
                                        } catch (J$e) {
                                            J$.Ex(29525, J$e);
                                        } finally {
                                            if (J$.Fr(29529))
                                                continue jalangiLabel78;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function throwError(token, messageFormat) {
                                jalangiLabel80:
                                    while (true) {
                                        try {
                                            J$.Fe(12757, arguments.callee, this);
                                            arguments = J$.N(12761, 'arguments', arguments, true);
                                            token = J$.N(12765, 'token', token, true);
                                            messageFormat = J$.N(12769, 'messageFormat', messageFormat, true);
                                            J$.N(12773, 'error', error, false);
                                            J$.N(12777, 'args', args, false);
                                            J$.N(12781, 'msg', msg, false);
                                            var error, args = J$.W(12537, 'args', J$.M(12461, J$.G(12449, J$.G(12445, J$.I(typeof Array === 'undefined' ? Array = J$.R(12441, 'Array', undefined, true) : Array = J$.R(12441, 'Array', Array, true)), 'prototype'), 'slice'), 'call', false)(J$.I(typeof arguments === 'undefined' ? arguments = J$.R(12453, 'arguments', undefined, true) : arguments = J$.R(12453, 'arguments', arguments, true)), J$.T(12457, 2, 22)), args), msg = J$.W(12541, 'msg', J$.M(12533, J$.R(12465, 'messageFormat', messageFormat, false), 'replace', false)(J$.T(12469, /%(\d)/g, 14), J$.T(12529, function (whole, index) {
                                                    jalangiLabel79:
                                                        while (true) {
                                                            try {
                                                                J$.Fe(12513, arguments.callee, this);
                                                                arguments = J$.N(12517, 'arguments', arguments, true);
                                                                whole = J$.N(12521, 'whole', whole, true);
                                                                index = J$.N(12525, 'index', index, true);
                                                                J$.F(12493, J$.R(12473, 'assert', assert, false), false)(J$.B(1878, '<', J$.R(12477, 'index', index, false), J$.G(12485, J$.R(12481, 'args', args, false), 'length')), J$.T(12489, 'Message reference must be in range', 21));
                                                                return J$.Rt(12509, J$.G(12505, J$.R(12497, 'args', args, false), J$.R(12501, 'index', index, false)));
                                                            } catch (J$e) {
                                                                J$.Ex(29533, J$e);
                                                            } finally {
                                                                if (J$.Fr(29537))
                                                                    continue jalangiLabel79;
                                                                else
                                                                    return J$.Ra();
                                                            }
                                                        }
                                                }, 12)), msg);
                                            if (J$.C(1312, J$.B(1886, '===', J$.U(1882, 'typeof', J$.G(12549, J$.R(12545, 'token', token, false), 'lineNumber')), J$.T(12553, 'number', 21)))) {
                                                error = J$.W(12589, 'error', J$.T(12585, J$.F(12581, J$.I(typeof Error === 'undefined' ? Error = J$.R(12557, 'Error', undefined, true) : Error = J$.R(12557, 'Error', Error, true)), true)(J$.B(1898, '+', J$.B(1894, '+', J$.B(1890, '+', J$.T(12561, 'Line ', 21), J$.G(12569, J$.R(12565, 'token', token, false), 'lineNumber')), J$.T(12573, ': ', 21)), J$.R(12577, 'msg', msg, false))), 11), error);
                                                J$.P(12613, J$.R(12593, 'error', error, false), 'index', J$.G(12609, J$.G(12601, J$.R(12597, 'token', token, false), 'range'), J$.T(12605, 0, 22)));
                                                J$.P(12629, J$.R(12617, 'error', error, false), 'lineNumber', J$.G(12625, J$.R(12621, 'token', token, false), 'lineNumber'));
                                                J$.P(12661, J$.R(12633, 'error', error, false), 'column', J$.B(1906, '+', J$.B(1902, '-', J$.G(12649, J$.G(12641, J$.R(12637, 'token', token, false), 'range'), J$.T(12645, 0, 22)), J$.R(12653, 'lineStart', lineStart, false)), J$.T(12657, 1, 22)));
                                            } else {
                                                error = J$.W(12693, 'error', J$.T(12689, J$.F(12685, J$.I(typeof Error === 'undefined' ? Error = J$.R(12665, 'Error', undefined, true) : Error = J$.R(12665, 'Error', Error, true)), true)(J$.B(1918, '+', J$.B(1914, '+', J$.B(1910, '+', J$.T(12669, 'Line ', 21), J$.R(12673, 'lineNumber', lineNumber, false)), J$.T(12677, ': ', 21)), J$.R(12681, 'msg', msg, false))), 11), error);
                                                J$.P(12705, J$.R(12697, 'error', error, false), 'index', J$.R(12701, 'index', index, false));
                                                J$.P(12717, J$.R(12709, 'error', error, false), 'lineNumber', J$.R(12713, 'lineNumber', lineNumber, false));
                                                J$.P(12737, J$.R(12721, 'error', error, false), 'column', J$.B(1926, '+', J$.B(1922, '-', J$.R(12725, 'index', index, false), J$.R(12729, 'lineStart', lineStart, false)), J$.T(12733, 1, 22)));
                                            }
                                            J$.P(12749, J$.R(12741, 'error', error, false), 'description', J$.R(12745, 'msg', msg, false));
                                            throw J$.R(12753, 'error', error, false);
                                        } catch (J$e) {
                                            J$.Ex(29541, J$e);
                                        } finally {
                                            if (J$.Fr(29545))
                                                continue jalangiLabel80;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function throwErrorTolerant() {
                                jalangiLabel81:
                                    while (true) {
                                        try {
                                            J$.Fe(12829, arguments.callee, this);
                                            arguments = J$.N(12833, 'arguments', arguments, true);
                                            try {
                                                J$.M(12797, J$.R(12785, 'throwError', throwError, false), 'apply', false)(J$.T(12789, null, 25), J$.I(typeof arguments === 'undefined' ? arguments = J$.R(12793, 'arguments', undefined, true) : arguments = J$.R(12793, 'arguments', arguments, true)));
                                            } catch (e) {
                                                if (J$.C(1316, J$.G(12805, J$.R(12801, 'extra', extra, false), 'errors'))) {
                                                    J$.M(12821, J$.G(12813, J$.R(12809, 'extra', extra, false), 'errors'), 'push', false)(J$.R(12817, 'e', e, false));
                                                } else {
                                                    throw J$.R(12825, 'e', e, false);
                                                }
                                            }
                                        } catch (J$e) {
                                            J$.Ex(29549, J$e);
                                        } finally {
                                            if (J$.Fr(29553))
                                                continue jalangiLabel81;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function throwUnexpected(token) {
                                jalangiLabel82:
                                    while (true) {
                                        try {
                                            J$.Fe(13133, arguments.callee, this);
                                            arguments = J$.N(13137, 'arguments', arguments, true);
                                            token = J$.N(13141, 'token', token, true);
                                            if (J$.C(1320, J$.B(1930, '===', J$.G(12841, J$.R(12837, 'token', token, false), 'type'), J$.G(12849, J$.R(12845, 'Token', Token, false), 'EOF')))) {
                                                J$.F(12869, J$.R(12853, 'throwError', throwError, false), false)(J$.R(12857, 'token', token, false), J$.G(12865, J$.R(12861, 'Messages', Messages, false), 'UnexpectedEOS'));
                                            }
                                            if (J$.C(1324, J$.B(1934, '===', J$.G(12877, J$.R(12873, 'token', token, false), 'type'), J$.G(12885, J$.R(12881, 'Token', Token, false), 'NumericLiteral')))) {
                                                J$.F(12905, J$.R(12889, 'throwError', throwError, false), false)(J$.R(12893, 'token', token, false), J$.G(12901, J$.R(12897, 'Messages', Messages, false), 'UnexpectedNumber'));
                                            }
                                            if (J$.C(1328, J$.B(1938, '===', J$.G(12913, J$.R(12909, 'token', token, false), 'type'), J$.G(12921, J$.R(12917, 'Token', Token, false), 'StringLiteral')))) {
                                                J$.F(12941, J$.R(12925, 'throwError', throwError, false), false)(J$.R(12929, 'token', token, false), J$.G(12937, J$.R(12933, 'Messages', Messages, false), 'UnexpectedString'));
                                            }
                                            if (J$.C(1332, J$.B(1942, '===', J$.G(12949, J$.R(12945, 'token', token, false), 'type'), J$.G(12957, J$.R(12953, 'Token', Token, false), 'Identifier')))) {
                                                J$.F(12977, J$.R(12961, 'throwError', throwError, false), false)(J$.R(12965, 'token', token, false), J$.G(12973, J$.R(12969, 'Messages', Messages, false), 'UnexpectedIdentifier'));
                                            }
                                            if (J$.C(1348, J$.B(1946, '===', J$.G(12985, J$.R(12981, 'token', token, false), 'type'), J$.G(12993, J$.R(12989, 'Token', Token, false), 'Keyword')))) {
                                                if (J$.C(1344, J$.F(13009, J$.R(12997, 'isFutureReservedWord', isFutureReservedWord, false), false)(J$.G(13005, J$.R(13001, 'token', token, false), 'value')))) {
                                                    J$.F(13029, J$.R(13013, 'throwError', throwError, false), false)(J$.R(13017, 'token', token, false), J$.G(13025, J$.R(13021, 'Messages', Messages, false), 'UnexpectedReserved'));
                                                } else if (J$.C(1340, J$.C(1336, J$.R(13033, 'strict', strict, false)) ? J$.F(13049, J$.R(13037, 'isStrictModeReservedWord', isStrictModeReservedWord, false), false)(J$.G(13045, J$.R(13041, 'token', token, false), 'value')) : J$._())) {
                                                    J$.F(13069, J$.R(13053, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.R(13057, 'token', token, false), J$.G(13065, J$.R(13061, 'Messages', Messages, false), 'StrictReservedWord'));
                                                    return J$.Rt(13073, undefined);
                                                }
                                                J$.F(13101, J$.R(13077, 'throwError', throwError, false), false)(J$.R(13081, 'token', token, false), J$.G(13089, J$.R(13085, 'Messages', Messages, false), 'UnexpectedToken'), J$.G(13097, J$.R(13093, 'token', token, false), 'value'));
                                            }
                                            J$.F(13129, J$.R(13105, 'throwError', throwError, false), false)(J$.R(13109, 'token', token, false), J$.G(13117, J$.R(13113, 'Messages', Messages, false), 'UnexpectedToken'), J$.G(13125, J$.R(13121, 'token', token, false), 'value'));
                                        } catch (J$e) {
                                            J$.Ex(29557, J$e);
                                        } finally {
                                            if (J$.Fr(29561))
                                                continue jalangiLabel82;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function expect(value) {
                                jalangiLabel83:
                                    while (true) {
                                        try {
                                            J$.Fe(13197, arguments.callee, this);
                                            arguments = J$.N(13201, 'arguments', arguments, true);
                                            value = J$.N(13205, 'value', value, true);
                                            J$.N(13209, 'token', token, false);
                                            var token = J$.W(13153, 'token', J$.F(13149, J$.R(13145, 'lex', lex, false), false)(), token);
                                            if (J$.C(1356, J$.C(1352, J$.B(1950, '!==', J$.G(13161, J$.R(13157, 'token', token, false), 'type'), J$.G(13169, J$.R(13165, 'Token', Token, false), 'Punctuator'))) ? J$._() : J$.B(1954, '!==', J$.G(13177, J$.R(13173, 'token', token, false), 'value'), J$.R(13181, 'value', value, false)))) {
                                                J$.F(13193, J$.R(13185, 'throwUnexpected', throwUnexpected, false), false)(J$.R(13189, 'token', token, false));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(29565, J$e);
                                        } finally {
                                            if (J$.Fr(29569))
                                                continue jalangiLabel83;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function expectKeyword(keyword) {
                                jalangiLabel84:
                                    while (true) {
                                        try {
                                            J$.Fe(13265, arguments.callee, this);
                                            arguments = J$.N(13269, 'arguments', arguments, true);
                                            keyword = J$.N(13273, 'keyword', keyword, true);
                                            J$.N(13277, 'token', token, false);
                                            var token = J$.W(13221, 'token', J$.F(13217, J$.R(13213, 'lex', lex, false), false)(), token);
                                            if (J$.C(1364, J$.C(1360, J$.B(1958, '!==', J$.G(13229, J$.R(13225, 'token', token, false), 'type'), J$.G(13237, J$.R(13233, 'Token', Token, false), 'Keyword'))) ? J$._() : J$.B(1962, '!==', J$.G(13245, J$.R(13241, 'token', token, false), 'value'), J$.R(13249, 'keyword', keyword, false)))) {
                                                J$.F(13261, J$.R(13253, 'throwUnexpected', throwUnexpected, false), false)(J$.R(13257, 'token', token, false));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(29573, J$e);
                                        } finally {
                                            if (J$.Fr(29577))
                                                continue jalangiLabel84;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function match(value) {
                                jalangiLabel85:
                                    while (true) {
                                        try {
                                            J$.Fe(13313, arguments.callee, this);
                                            arguments = J$.N(13317, 'arguments', arguments, true);
                                            value = J$.N(13321, 'value', value, true);
                                            return J$.Rt(13309, J$.C(1368, J$.B(1966, '===', J$.G(13285, J$.R(13281, 'lookahead', lookahead, false), 'type'), J$.G(13293, J$.R(13289, 'Token', Token, false), 'Punctuator'))) ? J$.B(1970, '===', J$.G(13301, J$.R(13297, 'lookahead', lookahead, false), 'value'), J$.R(13305, 'value', value, false)) : J$._());
                                        } catch (J$e) {
                                            J$.Ex(29581, J$e);
                                        } finally {
                                            if (J$.Fr(29585))
                                                continue jalangiLabel85;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function matchKeyword(keyword) {
                                jalangiLabel86:
                                    while (true) {
                                        try {
                                            J$.Fe(13357, arguments.callee, this);
                                            arguments = J$.N(13361, 'arguments', arguments, true);
                                            keyword = J$.N(13365, 'keyword', keyword, true);
                                            return J$.Rt(13353, J$.C(1372, J$.B(1974, '===', J$.G(13329, J$.R(13325, 'lookahead', lookahead, false), 'type'), J$.G(13337, J$.R(13333, 'Token', Token, false), 'Keyword'))) ? J$.B(1978, '===', J$.G(13345, J$.R(13341, 'lookahead', lookahead, false), 'value'), J$.R(13349, 'keyword', keyword, false)) : J$._());
                                        } catch (J$e) {
                                            J$.Ex(29589, J$e);
                                        } finally {
                                            if (J$.Fr(29593))
                                                continue jalangiLabel86;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function matchAssign() {
                                jalangiLabel87:
                                    while (true) {
                                        try {
                                            J$.Fe(13505, arguments.callee, this);
                                            arguments = J$.N(13509, 'arguments', arguments, true);
                                            J$.N(13513, 'op', op, false);
                                            var op;
                                            if (J$.C(1376, J$.B(1982, '!==', J$.G(13373, J$.R(13369, 'lookahead', lookahead, false), 'type'), J$.G(13381, J$.R(13377, 'Token', Token, false), 'Punctuator')))) {
                                                return J$.Rt(13389, J$.T(13385, false, 23));
                                            }
                                            op = J$.W(13401, 'op', J$.G(13397, J$.R(13393, 'lookahead', lookahead, false), 'value'), op);
                                            return J$.Rt(13501, J$.C(1420, J$.C(1416, J$.C(1412, J$.C(1408, J$.C(1404, J$.C(1400, J$.C(1396, J$.C(1392, J$.C(1388, J$.C(1384, J$.C(1380, J$.B(1986, '===', J$.R(13405, 'op', op, false), J$.T(13409, '=', 21))) ? J$._() : J$.B(1990, '===', J$.R(13413, 'op', op, false), J$.T(13417, '*=', 21))) ? J$._() : J$.B(1994, '===', J$.R(13421, 'op', op, false), J$.T(13425, '/=', 21))) ? J$._() : J$.B(1998, '===', J$.R(13429, 'op', op, false), J$.T(13433, '%=', 21))) ? J$._() : J$.B(2002, '===', J$.R(13437, 'op', op, false), J$.T(13441, '+=', 21))) ? J$._() : J$.B(2006, '===', J$.R(13445, 'op', op, false), J$.T(13449, '-=', 21))) ? J$._() : J$.B(2010, '===', J$.R(13453, 'op', op, false), J$.T(13457, '<<=', 21))) ? J$._() : J$.B(2014, '===', J$.R(13461, 'op', op, false), J$.T(13465, '>>=', 21))) ? J$._() : J$.B(2018, '===', J$.R(13469, 'op', op, false), J$.T(13473, '>>>=', 21))) ? J$._() : J$.B(2022, '===', J$.R(13477, 'op', op, false), J$.T(13481, '&=', 21))) ? J$._() : J$.B(2026, '===', J$.R(13485, 'op', op, false), J$.T(13489, '^=', 21))) ? J$._() : J$.B(2030, '===', J$.R(13493, 'op', op, false), J$.T(13497, '|=', 21)));
                                        } catch (J$e) {
                                            J$.Ex(29597, J$e);
                                        } finally {
                                            if (J$.Fr(29601))
                                                continue jalangiLabel87;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function consumeSemicolon() {
                                jalangiLabel88:
                                    while (true) {
                                        try {
                                            J$.Fe(13637, arguments.callee, this);
                                            arguments = J$.N(13641, 'arguments', arguments, true);
                                            J$.N(13645, 'line', line, false);
                                            var line;
                                            if (J$.C(1424, J$.B(2034, '===', J$.M(13525, J$.R(13517, 'source', source, false), 'charCodeAt', false)(J$.R(13521, 'index', index, false)), J$.T(13529, 59, 22)))) {
                                                J$.F(13537, J$.R(13533, 'lex', lex, false), false)();
                                                return J$.Rt(13541, undefined);
                                            }
                                            line = J$.W(13549, 'line', J$.R(13545, 'lineNumber', lineNumber, false), line);
                                            J$.F(13557, J$.R(13553, 'skipComment', skipComment, false), false)();
                                            if (J$.C(1428, J$.B(2038, '!==', J$.R(13561, 'lineNumber', lineNumber, false), J$.R(13565, 'line', line, false)))) {
                                                return J$.Rt(13569, undefined);
                                            }
                                            if (J$.C(1432, J$.F(13581, J$.R(13573, 'match', match, false), false)(J$.T(13577, ';', 21)))) {
                                                J$.F(13589, J$.R(13585, 'lex', lex, false), false)();
                                                return J$.Rt(13593, undefined);
                                            }
                                            if (J$.C(1440, J$.C(1436, J$.B(2042, '!==', J$.G(13601, J$.R(13597, 'lookahead', lookahead, false), 'type'), J$.G(13609, J$.R(13605, 'Token', Token, false), 'EOF'))) ? J$.U(2046, '!', J$.F(13621, J$.R(13613, 'match', match, false), false)(J$.T(13617, '}', 21))) : J$._())) {
                                                J$.F(13633, J$.R(13625, 'throwUnexpected', throwUnexpected, false), false)(J$.R(13629, 'lookahead', lookahead, false));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(29605, J$e);
                                        } finally {
                                            if (J$.Fr(29609))
                                                continue jalangiLabel88;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function isLeftHandSide(expr) {
                                jalangiLabel89:
                                    while (true) {
                                        try {
                                            J$.Fe(13685, arguments.callee, this);
                                            arguments = J$.N(13689, 'arguments', arguments, true);
                                            expr = J$.N(13693, 'expr', expr, true);
                                            return J$.Rt(13681, J$.C(1444, J$.B(2050, '===', J$.G(13653, J$.R(13649, 'expr', expr, false), 'type'), J$.G(13661, J$.R(13657, 'Syntax', Syntax, false), 'Identifier'))) ? J$._() : J$.B(2054, '===', J$.G(13669, J$.R(13665, 'expr', expr, false), 'type'), J$.G(13677, J$.R(13673, 'Syntax', Syntax, false), 'MemberExpression')));
                                        } catch (J$e) {
                                            J$.Ex(29613, J$e);
                                        } finally {
                                            if (J$.Fr(29617))
                                                continue jalangiLabel89;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseArrayInitialiser() {
                                jalangiLabel90:
                                    while (true) {
                                        try {
                                            J$.Fe(13829, arguments.callee, this);
                                            arguments = J$.N(13833, 'arguments', arguments, true);
                                            J$.N(13837, 'elements', elements, false);
                                            var elements = J$.W(13701, 'elements', J$.T(13697, [], 10), elements);
                                            J$.F(13713, J$.R(13705, 'expect', expect, false), false)(J$.T(13709, '[', 21));
                                            while (J$.C(1456, J$.U(2058, '!', J$.F(13725, J$.R(13717, 'match', match, false), false)(J$.T(13721, ']', 21))))) {
                                                if (J$.C(1452, J$.F(13737, J$.R(13729, 'match', match, false), false)(J$.T(13733, ',', 21)))) {
                                                    J$.F(13745, J$.R(13741, 'lex', lex, false), false)();
                                                    J$.M(13757, J$.R(13749, 'elements', elements, false), 'push', false)(J$.T(13753, null, 25));
                                                } else {
                                                    J$.M(13773, J$.R(13761, 'elements', elements, false), 'push', false)(J$.F(13769, J$.R(13765, 'parseAssignmentExpression', parseAssignmentExpression, false), false)());
                                                    if (J$.C(1448, J$.U(2062, '!', J$.F(13785, J$.R(13777, 'match', match, false), false)(J$.T(13781, ']', 21))))) {
                                                        J$.F(13797, J$.R(13789, 'expect', expect, false), false)(J$.T(13793, ',', 21));
                                                    }
                                                }
                                            }
                                            J$.F(13809, J$.R(13801, 'expect', expect, false), false)(J$.T(13805, ']', 21));
                                            return J$.Rt(13825, J$.M(13821, J$.R(13813, 'delegate', delegate, false), 'createArrayExpression', false)(J$.R(13817, 'elements', elements, false)));
                                        } catch (J$e) {
                                            J$.Ex(29621, J$e);
                                        } finally {
                                            if (J$.Fr(29625))
                                                continue jalangiLabel90;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parsePropertyFunction(param, first) {
                                jalangiLabel91:
                                    while (true) {
                                        try {
                                            J$.Fe(13973, arguments.callee, this);
                                            arguments = J$.N(13977, 'arguments', arguments, true);
                                            param = J$.N(13981, 'param', param, true);
                                            first = J$.N(13985, 'first', first, true);
                                            J$.N(13989, 'previousStrict', previousStrict, false);
                                            J$.N(13993, 'body', body, false);
                                            var previousStrict, body;
                                            previousStrict = J$.W(13845, 'previousStrict', J$.R(13841, 'strict', strict, false), previousStrict);
                                            J$.F(13853, J$.R(13849, 'skipComment', skipComment, false), false)();
                                            J$.M(13861, J$.R(13857, 'delegate', delegate, false), 'markStart', false)();
                                            body = J$.W(13873, 'body', J$.F(13869, J$.R(13865, 'parseFunctionSourceElements', parseFunctionSourceElements, false), false)(), body);
                                            if (J$.C(1468, J$.C(1464, J$.C(1460, J$.R(13877, 'first', first, false)) ? J$.R(13881, 'strict', strict, false) : J$._()) ? J$.F(13905, J$.R(13885, 'isRestrictedWord', isRestrictedWord, false), false)(J$.G(13901, J$.G(13897, J$.R(13889, 'param', param, false), J$.T(13893, 0, 22)), 'name')) : J$._())) {
                                                J$.F(13925, J$.R(13909, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.R(13913, 'first', first, false), J$.G(13921, J$.R(13917, 'Messages', Messages, false), 'StrictParamName'));
                                            }
                                            strict = J$.W(13933, 'strict', J$.R(13929, 'previousStrict', previousStrict, false), strict);
                                            return J$.Rt(13969, J$.M(13965, J$.R(13937, 'delegate', delegate, false), 'markEnd', false)(J$.M(13961, J$.R(13941, 'delegate', delegate, false), 'createFunctionExpression', false)(J$.T(13945, null, 25), J$.R(13949, 'param', param, false), J$.T(13953, [], 10), J$.R(13957, 'body', body, false))));
                                        } catch (J$e) {
                                            J$.Ex(29629, J$e);
                                        } finally {
                                            if (J$.Fr(29633))
                                                continue jalangiLabel91;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseObjectPropertyKey() {
                                jalangiLabel92:
                                    while (true) {
                                        try {
                                            J$.Fe(14141, arguments.callee, this);
                                            arguments = J$.N(14145, 'arguments', arguments, true);
                                            J$.N(14149, 'token', token, false);
                                            var token;
                                            J$.F(14001, J$.R(13997, 'skipComment', skipComment, false), false)();
                                            J$.M(14009, J$.R(14005, 'delegate', delegate, false), 'markStart', false)();
                                            token = J$.W(14021, 'token', J$.F(14017, J$.R(14013, 'lex', lex, false), false)(), token);
                                            if (J$.C(1484, J$.C(1472, J$.B(2066, '===', J$.G(14029, J$.R(14025, 'token', token, false), 'type'), J$.G(14037, J$.R(14033, 'Token', Token, false), 'StringLiteral'))) ? J$._() : J$.B(2070, '===', J$.G(14045, J$.R(14041, 'token', token, false), 'type'), J$.G(14053, J$.R(14049, 'Token', Token, false), 'NumericLiteral')))) {
                                                if (J$.C(1480, J$.C(1476, J$.R(14057, 'strict', strict, false)) ? J$.G(14065, J$.R(14061, 'token', token, false), 'octal') : J$._())) {
                                                    J$.F(14085, J$.R(14069, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.R(14073, 'token', token, false), J$.G(14081, J$.R(14077, 'Messages', Messages, false), 'StrictOctalLiteral'));
                                                }
                                                return J$.Rt(14109, J$.M(14105, J$.R(14089, 'delegate', delegate, false), 'markEnd', false)(J$.M(14101, J$.R(14093, 'delegate', delegate, false), 'createLiteral', false)(J$.R(14097, 'token', token, false))));
                                            }
                                            return J$.Rt(14137, J$.M(14133, J$.R(14113, 'delegate', delegate, false), 'markEnd', false)(J$.M(14129, J$.R(14117, 'delegate', delegate, false), 'createIdentifier', false)(J$.G(14125, J$.R(14121, 'token', token, false), 'value'))));
                                        } catch (J$e) {
                                            J$.Ex(29637, J$e);
                                        } finally {
                                            if (J$.Fr(29641))
                                                continue jalangiLabel92;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseObjectProperty() {
                                jalangiLabel93:
                                    while (true) {
                                        try {
                                            J$.Fe(14689, arguments.callee, this);
                                            arguments = J$.N(14693, 'arguments', arguments, true);
                                            J$.N(14697, 'token', token, false);
                                            J$.N(14701, 'key', key, false);
                                            J$.N(14705, 'id', id, false);
                                            J$.N(14709, 'value', value, false);
                                            J$.N(14713, 'param', param, false);
                                            var token, key, id, value, param;
                                            token = J$.W(14157, 'token', J$.R(14153, 'lookahead', lookahead, false), token);
                                            J$.F(14165, J$.R(14161, 'skipComment', skipComment, false), false)();
                                            J$.M(14173, J$.R(14169, 'delegate', delegate, false), 'markStart', false)();
                                            if (J$.C(1508, J$.B(2074, '===', J$.G(14181, J$.R(14177, 'token', token, false), 'type'), J$.G(14189, J$.R(14185, 'Token', Token, false), 'Identifier')))) {
                                                id = J$.W(14201, 'id', J$.F(14197, J$.R(14193, 'parseObjectPropertyKey', parseObjectPropertyKey, false), false)(), id);
                                                if (J$.C(1492, J$.C(1488, J$.B(2078, '===', J$.G(14209, J$.R(14205, 'token', token, false), 'value'), J$.T(14213, 'get', 21))) ? J$.U(2082, '!', J$.F(14225, J$.R(14217, 'match', match, false), false)(J$.T(14221, ':', 21))) : J$._())) {
                                                    key = J$.W(14237, 'key', J$.F(14233, J$.R(14229, 'parseObjectPropertyKey', parseObjectPropertyKey, false), false)(), key);
                                                    J$.F(14249, J$.R(14241, 'expect', expect, false), false)(J$.T(14245, '(', 21));
                                                    J$.F(14261, J$.R(14253, 'expect', expect, false), false)(J$.T(14257, ')', 21));
                                                    value = J$.W(14277, 'value', J$.F(14273, J$.R(14265, 'parsePropertyFunction', parsePropertyFunction, false), false)(J$.T(14269, [], 10)), value);
                                                    return J$.Rt(14309, J$.M(14305, J$.R(14281, 'delegate', delegate, false), 'markEnd', false)(J$.M(14301, J$.R(14285, 'delegate', delegate, false), 'createProperty', false)(J$.T(14289, 'get', 21), J$.R(14293, 'key', key, false), J$.R(14297, 'value', value, false))));
                                                }
                                                if (J$.C(1504, J$.C(1496, J$.B(2086, '===', J$.G(14317, J$.R(14313, 'token', token, false), 'value'), J$.T(14321, 'set', 21))) ? J$.U(2090, '!', J$.F(14333, J$.R(14325, 'match', match, false), false)(J$.T(14329, ':', 21))) : J$._())) {
                                                    key = J$.W(14345, 'key', J$.F(14341, J$.R(14337, 'parseObjectPropertyKey', parseObjectPropertyKey, false), false)(), key);
                                                    J$.F(14357, J$.R(14349, 'expect', expect, false), false)(J$.T(14353, '(', 21));
                                                    token = J$.W(14365, 'token', J$.R(14361, 'lookahead', lookahead, false), token);
                                                    if (J$.C(1500, J$.B(2094, '!==', J$.G(14373, J$.R(14369, 'token', token, false), 'type'), J$.G(14381, J$.R(14377, 'Token', Token, false), 'Identifier')))) {
                                                        J$.F(14393, J$.R(14385, 'expect', expect, false), false)(J$.T(14389, ')', 21));
                                                        J$.F(14421, J$.R(14397, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.R(14401, 'token', token, false), J$.G(14409, J$.R(14405, 'Messages', Messages, false), 'UnexpectedToken'), J$.G(14417, J$.R(14413, 'token', token, false), 'value'));
                                                        value = J$.W(14437, 'value', J$.F(14433, J$.R(14425, 'parsePropertyFunction', parsePropertyFunction, false), false)(J$.T(14429, [], 10)), value);
                                                    } else {
                                                        param = J$.W(14453, 'param', J$.T(14449, [J$.F(14445, J$.R(14441, 'parseVariableIdentifier', parseVariableIdentifier, false), false)()], 10), param);
                                                        J$.F(14465, J$.R(14457, 'expect', expect, false), false)(J$.T(14461, ')', 21));
                                                        value = J$.W(14485, 'value', J$.F(14481, J$.R(14469, 'parsePropertyFunction', parsePropertyFunction, false), false)(J$.R(14473, 'param', param, false), J$.R(14477, 'token', token, false)), value);
                                                    }
                                                    return J$.Rt(14517, J$.M(14513, J$.R(14489, 'delegate', delegate, false), 'markEnd', false)(J$.M(14509, J$.R(14493, 'delegate', delegate, false), 'createProperty', false)(J$.T(14497, 'set', 21), J$.R(14501, 'key', key, false), J$.R(14505, 'value', value, false))));
                                                }
                                                J$.F(14529, J$.R(14521, 'expect', expect, false), false)(J$.T(14525, ':', 21));
                                                value = J$.W(14541, 'value', J$.F(14537, J$.R(14533, 'parseAssignmentExpression', parseAssignmentExpression, false), false)(), value);
                                                return J$.Rt(14573, J$.M(14569, J$.R(14545, 'delegate', delegate, false), 'markEnd', false)(J$.M(14565, J$.R(14549, 'delegate', delegate, false), 'createProperty', false)(J$.T(14553, 'init', 21), J$.R(14557, 'id', id, false), J$.R(14561, 'value', value, false))));
                                            }
                                            if (J$.C(1516, J$.C(1512, J$.B(2098, '===', J$.G(14581, J$.R(14577, 'token', token, false), 'type'), J$.G(14589, J$.R(14585, 'Token', Token, false), 'EOF'))) ? J$._() : J$.B(2102, '===', J$.G(14597, J$.R(14593, 'token', token, false), 'type'), J$.G(14605, J$.R(14601, 'Token', Token, false), 'Punctuator')))) {
                                                J$.F(14617, J$.R(14609, 'throwUnexpected', throwUnexpected, false), false)(J$.R(14613, 'token', token, false));
                                            } else {
                                                key = J$.W(14629, 'key', J$.F(14625, J$.R(14621, 'parseObjectPropertyKey', parseObjectPropertyKey, false), false)(), key);
                                                J$.F(14641, J$.R(14633, 'expect', expect, false), false)(J$.T(14637, ':', 21));
                                                value = J$.W(14653, 'value', J$.F(14649, J$.R(14645, 'parseAssignmentExpression', parseAssignmentExpression, false), false)(), value);
                                                return J$.Rt(14685, J$.M(14681, J$.R(14657, 'delegate', delegate, false), 'markEnd', false)(J$.M(14677, J$.R(14661, 'delegate', delegate, false), 'createProperty', false)(J$.T(14665, 'init', 21), J$.R(14669, 'key', key, false), J$.R(14673, 'value', value, false))));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(29645, J$e);
                                        } finally {
                                            if (J$.Fr(29649))
                                                continue jalangiLabel93;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseObjectInitialiser() {
                                jalangiLabel94:
                                    while (true) {
                                        try {
                                            J$.Fe(15177, arguments.callee, this);
                                            arguments = J$.N(15181, 'arguments', arguments, true);
                                            J$.N(15185, 'properties', properties, false);
                                            J$.N(15189, 'property', property, false);
                                            J$.N(15193, 'name', name, false);
                                            J$.N(15197, 'key', key, false);
                                            J$.N(15201, 'kind', kind, false);
                                            J$.N(15205, 'map', map, false);
                                            J$.N(15209, 'toString', toString, false);
                                            var properties = J$.W(14729, 'properties', J$.T(14717, [], 10), properties), property, name, key, kind, map = J$.W(14733, 'map', J$.T(14721, {}, 11), map), toString = J$.W(14737, 'toString', J$.I(typeof String === 'undefined' ? String = J$.R(14725, 'String', undefined, true) : String = J$.R(14725, 'String', String, true)), toString);
                                            J$.F(14749, J$.R(14741, 'expect', expect, false), false)(J$.T(14745, '{', 21));
                                            while (J$.C(1564, J$.U(2106, '!', J$.F(14761, J$.R(14753, 'match', match, false), false)(J$.T(14757, '}', 21))))) {
                                                property = J$.W(14773, 'property', J$.F(14769, J$.R(14765, 'parseObjectProperty', parseObjectProperty, false), false)(), property);
                                                if (J$.C(1520, J$.B(2110, '===', J$.G(14785, J$.G(14781, J$.R(14777, 'property', property, false), 'key'), 'type'), J$.G(14793, J$.R(14789, 'Syntax', Syntax, false), 'Identifier')))) {
                                                    name = J$.W(14809, 'name', J$.G(14805, J$.G(14801, J$.R(14797, 'property', property, false), 'key'), 'name'), name);
                                                } else {
                                                    name = J$.W(14833, 'name', J$.F(14829, J$.R(14813, 'toString', toString, false), false)(J$.G(14825, J$.G(14821, J$.R(14817, 'property', property, false), 'key'), 'value')), name);
                                                }
                                                kind = J$.W(14885, 'kind', J$.C(1528, J$.B(2114, '===', J$.G(14841, J$.R(14837, 'property', property, false), 'kind'), J$.T(14845, 'init', 21))) ? J$.G(14853, J$.R(14849, 'PropertyKind', PropertyKind, false), 'Data') : J$.C(1524, J$.B(2118, '===', J$.G(14861, J$.R(14857, 'property', property, false), 'kind'), J$.T(14865, 'get', 21))) ? J$.G(14873, J$.R(14869, 'PropertyKind', PropertyKind, false), 'Get') : J$.G(14881, J$.R(14877, 'PropertyKind', PropertyKind, false), 'Set'), kind);
                                                key = J$.W(14897, 'key', J$.B(2122, '+', J$.T(14889, '$', 21), J$.R(14893, 'name', name, false)), key);
                                                if (J$.C(1556, J$.M(14921, J$.G(14909, J$.G(14905, J$.I(typeof Object === 'undefined' ? Object = J$.R(14901, 'Object', undefined, true) : Object = J$.R(14901, 'Object', Object, true)), 'prototype'), 'hasOwnProperty'), 'call', false)(J$.R(14913, 'map', map, false), J$.R(14917, 'key', key, false)))) {
                                                    if (J$.C(1552, J$.B(2126, '===', J$.G(14933, J$.R(14925, 'map', map, false), J$.R(14929, 'key', key, false)), J$.G(14941, J$.R(14937, 'PropertyKind', PropertyKind, false), 'Data')))) {
                                                        if (J$.C(1540, J$.C(1532, J$.R(14945, 'strict', strict, false)) ? J$.B(2130, '===', J$.R(14949, 'kind', kind, false), J$.G(14957, J$.R(14953, 'PropertyKind', PropertyKind, false), 'Data')) : J$._())) {
                                                            J$.F(14977, J$.R(14961, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(14965, {}, 11), J$.G(14973, J$.R(14969, 'Messages', Messages, false), 'StrictDuplicateProperty'));
                                                        } else if (J$.C(1536, J$.B(2134, '!==', J$.R(14981, 'kind', kind, false), J$.G(14989, J$.R(14985, 'PropertyKind', PropertyKind, false), 'Data')))) {
                                                            J$.F(15009, J$.R(14993, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(14997, {}, 11), J$.G(15005, J$.R(15001, 'Messages', Messages, false), 'AccessorDataProperty'));
                                                        }
                                                    } else {
                                                        if (J$.C(1548, J$.B(2138, '===', J$.R(15013, 'kind', kind, false), J$.G(15021, J$.R(15017, 'PropertyKind', PropertyKind, false), 'Data')))) {
                                                            J$.F(15041, J$.R(15025, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(15029, {}, 11), J$.G(15037, J$.R(15033, 'Messages', Messages, false), 'AccessorDataProperty'));
                                                        } else if (J$.C(1544, J$.B(2142, '&', J$.G(15053, J$.R(15045, 'map', map, false), J$.R(15049, 'key', key, false)), J$.R(15057, 'kind', kind, false)))) {
                                                            J$.F(15077, J$.R(15061, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(15065, {}, 11), J$.G(15073, J$.R(15069, 'Messages', Messages, false), 'AccessorGetSet'));
                                                        }
                                                    }
                                                    J$.A(15093, J$.R(15081, 'map', map, false), J$.R(15085, 'key', key, false), '|')(J$.R(15089, 'kind', kind, false));
                                                } else {
                                                    J$.P(15109, J$.R(15097, 'map', map, false), J$.R(15101, 'key', key, false), J$.R(15105, 'kind', kind, false));
                                                }
                                                J$.M(15121, J$.R(15113, 'properties', properties, false), 'push', false)(J$.R(15117, 'property', property, false));
                                                if (J$.C(1560, J$.U(2146, '!', J$.F(15133, J$.R(15125, 'match', match, false), false)(J$.T(15129, '}', 21))))) {
                                                    J$.F(15145, J$.R(15137, 'expect', expect, false), false)(J$.T(15141, ',', 21));
                                                }
                                            }
                                            J$.F(15157, J$.R(15149, 'expect', expect, false), false)(J$.T(15153, '}', 21));
                                            return J$.Rt(15173, J$.M(15169, J$.R(15161, 'delegate', delegate, false), 'createObjectExpression', false)(J$.R(15165, 'properties', properties, false)));
                                        } catch (J$e) {
                                            J$.Ex(29653, J$e);
                                        } finally {
                                            if (J$.Fr(29657))
                                                continue jalangiLabel94;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseGroupExpression() {
                                jalangiLabel95:
                                    while (true) {
                                        try {
                                            J$.Fe(15257, arguments.callee, this);
                                            arguments = J$.N(15261, 'arguments', arguments, true);
                                            J$.N(15265, 'expr', expr, false);
                                            var expr;
                                            J$.F(15221, J$.R(15213, 'expect', expect, false), false)(J$.T(15217, '(', 21));
                                            expr = J$.W(15233, 'expr', J$.F(15229, J$.R(15225, 'parseExpression', parseExpression, false), false)(), expr);
                                            J$.F(15245, J$.R(15237, 'expect', expect, false), false)(J$.T(15241, ')', 21));
                                            return J$.Rt(15253, J$.R(15249, 'expr', expr, false));
                                        } catch (J$e) {
                                            J$.Ex(29661, J$e);
                                        } finally {
                                            if (J$.Fr(29665))
                                                continue jalangiLabel95;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parsePrimaryExpression() {
                                jalangiLabel96:
                                    while (true) {
                                        try {
                                            J$.Fe(15773, arguments.callee, this);
                                            arguments = J$.N(15777, 'arguments', arguments, true);
                                            J$.N(15781, 'type', type, false);
                                            J$.N(15785, 'token', token, false);
                                            J$.N(15789, 'expr', expr, false);
                                            var type, token, expr;
                                            if (J$.C(1568, J$.F(15277, J$.R(15269, 'match', match, false), false)(J$.T(15273, '(', 21)))) {
                                                return J$.Rt(15289, J$.F(15285, J$.R(15281, 'parseGroupExpression', parseGroupExpression, false), false)());
                                            }
                                            type = J$.W(15301, 'type', J$.G(15297, J$.R(15293, 'lookahead', lookahead, false), 'type'), type);
                                            J$.M(15309, J$.R(15305, 'delegate', delegate, false), 'markStart', false)();
                                            if (J$.C(1628, J$.B(2150, '===', J$.R(15313, 'type', type, false), J$.G(15321, J$.R(15317, 'Token', Token, false), 'Identifier')))) {
                                                expr = J$.W(15345, 'expr', J$.M(15341, J$.R(15325, 'delegate', delegate, false), 'createIdentifier', false)(J$.G(15337, J$.F(15333, J$.R(15329, 'lex', lex, false), false)(), 'value')), expr);
                                            } else if (J$.C(1624, J$.C(1572, J$.B(2154, '===', J$.R(15349, 'type', type, false), J$.G(15357, J$.R(15353, 'Token', Token, false), 'StringLiteral'))) ? J$._() : J$.B(2158, '===', J$.R(15361, 'type', type, false), J$.G(15369, J$.R(15365, 'Token', Token, false), 'NumericLiteral')))) {
                                                if (J$.C(1580, J$.C(1576, J$.R(15373, 'strict', strict, false)) ? J$.G(15381, J$.R(15377, 'lookahead', lookahead, false), 'octal') : J$._())) {
                                                    J$.F(15401, J$.R(15385, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.R(15389, 'lookahead', lookahead, false), J$.G(15397, J$.R(15393, 'Messages', Messages, false), 'StrictOctalLiteral'));
                                                }
                                                expr = J$.W(15421, 'expr', J$.M(15417, J$.R(15405, 'delegate', delegate, false), 'createLiteral', false)(J$.F(15413, J$.R(15409, 'lex', lex, false), false)()), expr);
                                            } else if (J$.C(1620, J$.B(2162, '===', J$.R(15425, 'type', type, false), J$.G(15433, J$.R(15429, 'Token', Token, false), 'Keyword')))) {
                                                if (J$.C(1588, J$.F(15445, J$.R(15437, 'matchKeyword', matchKeyword, false), false)(J$.T(15441, 'this', 21)))) {
                                                    J$.F(15453, J$.R(15449, 'lex', lex, false), false)();
                                                    expr = J$.W(15465, 'expr', J$.M(15461, J$.R(15457, 'delegate', delegate, false), 'createThisExpression', false)(), expr);
                                                } else if (J$.C(1584, J$.F(15477, J$.R(15469, 'matchKeyword', matchKeyword, false), false)(J$.T(15473, 'function', 21)))) {
                                                    expr = J$.W(15489, 'expr', J$.F(15485, J$.R(15481, 'parseFunctionExpression', parseFunctionExpression, false), false)(), expr);
                                                }
                                            } else if (J$.C(1616, J$.B(2166, '===', J$.R(15493, 'type', type, false), J$.G(15501, J$.R(15497, 'Token', Token, false), 'BooleanLiteral')))) {
                                                token = J$.W(15513, 'token', J$.F(15509, J$.R(15505, 'lex', lex, false), false)(), token);
                                                J$.P(15533, J$.R(15517, 'token', token, false), 'value', J$.B(2170, '===', J$.G(15525, J$.R(15521, 'token', token, false), 'value'), J$.T(15529, 'true', 21)));
                                                expr = J$.W(15549, 'expr', J$.M(15545, J$.R(15537, 'delegate', delegate, false), 'createLiteral', false)(J$.R(15541, 'token', token, false)), expr);
                                            } else if (J$.C(1612, J$.B(2174, '===', J$.R(15553, 'type', type, false), J$.G(15561, J$.R(15557, 'Token', Token, false), 'NullLiteral')))) {
                                                token = J$.W(15573, 'token', J$.F(15569, J$.R(15565, 'lex', lex, false), false)(), token);
                                                J$.P(15585, J$.R(15577, 'token', token, false), 'value', J$.T(15581, null, 25));
                                                expr = J$.W(15601, 'expr', J$.M(15597, J$.R(15589, 'delegate', delegate, false), 'createLiteral', false)(J$.R(15593, 'token', token, false)), expr);
                                            } else if (J$.C(1608, J$.F(15613, J$.R(15605, 'match', match, false), false)(J$.T(15609, '[', 21)))) {
                                                expr = J$.W(15625, 'expr', J$.F(15621, J$.R(15617, 'parseArrayInitialiser', parseArrayInitialiser, false), false)(), expr);
                                            } else if (J$.C(1604, J$.F(15637, J$.R(15629, 'match', match, false), false)(J$.T(15633, '{', 21)))) {
                                                expr = J$.W(15649, 'expr', J$.F(15645, J$.R(15641, 'parseObjectInitialiser', parseObjectInitialiser, false), false)(), expr);
                                            } else if (J$.C(1600, J$.C(1592, J$.F(15661, J$.R(15653, 'match', match, false), false)(J$.T(15657, '/', 21))) ? J$._() : J$.F(15673, J$.R(15665, 'match', match, false), false)(J$.T(15669, '/=', 21)))) {
                                                if (J$.C(1596, J$.B(2182, '!==', J$.U(2178, 'typeof', J$.G(15681, J$.R(15677, 'extra', extra, false), 'tokens')), J$.T(15685, 'undefined', 21)))) {
                                                    expr = J$.W(15705, 'expr', J$.M(15701, J$.R(15689, 'delegate', delegate, false), 'createLiteral', false)(J$.F(15697, J$.R(15693, 'collectRegex', collectRegex, false), false)()), expr);
                                                } else {
                                                    expr = J$.W(15725, 'expr', J$.M(15721, J$.R(15709, 'delegate', delegate, false), 'createLiteral', false)(J$.F(15717, J$.R(15713, 'scanRegExp', scanRegExp, false), false)()), expr);
                                                }
                                                J$.F(15733, J$.R(15729, 'peek', peek, false), false)();
                                            }
                                            if (J$.C(1632, J$.R(15737, 'expr', expr, false))) {
                                                return J$.Rt(15753, J$.M(15749, J$.R(15741, 'delegate', delegate, false), 'markEnd', false)(J$.R(15745, 'expr', expr, false)));
                                            }
                                            J$.F(15769, J$.R(15757, 'throwUnexpected', throwUnexpected, false), false)(J$.F(15765, J$.R(15761, 'lex', lex, false), false)());
                                        } catch (J$e) {
                                            J$.Ex(29669, J$e);
                                        } finally {
                                            if (J$.Fr(29673))
                                                continue jalangiLabel96;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseArguments() {
                                jalangiLabel97:
                                    while (true) {
                                        try {
                                            J$.Fe(15893, arguments.callee, this);
                                            arguments = J$.N(15897, 'arguments', arguments, true);
                                            J$.N(15901, 'args', args, false);
                                            var args = J$.W(15797, 'args', J$.T(15793, [], 10), args);
                                            J$.F(15809, J$.R(15801, 'expect', expect, false), false)(J$.T(15805, '(', 21));
                                            if (J$.C(1644, J$.U(2186, '!', J$.F(15821, J$.R(15813, 'match', match, false), false)(J$.T(15817, ')', 21))))) {
                                                while (J$.C(1640, J$.B(2190, '<', J$.R(15825, 'index', index, false), J$.R(15829, 'length', length, false)))) {
                                                    J$.M(15845, J$.R(15833, 'args', args, false), 'push', false)(J$.F(15841, J$.R(15837, 'parseAssignmentExpression', parseAssignmentExpression, false), false)());
                                                    if (J$.C(1636, J$.F(15857, J$.R(15849, 'match', match, false), false)(J$.T(15853, ')', 21)))) {
                                                        break;
                                                    }
                                                    J$.F(15869, J$.R(15861, 'expect', expect, false), false)(J$.T(15865, ',', 21));
                                                }
                                            }
                                            J$.F(15881, J$.R(15873, 'expect', expect, false), false)(J$.T(15877, ')', 21));
                                            return J$.Rt(15889, J$.R(15885, 'args', args, false));
                                        } catch (J$e) {
                                            J$.Ex(29677, J$e);
                                        } finally {
                                            if (J$.Fr(29681))
                                                continue jalangiLabel97;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseNonComputedProperty() {
                                jalangiLabel98:
                                    while (true) {
                                        try {
                                            J$.Fe(15977, arguments.callee, this);
                                            arguments = J$.N(15981, 'arguments', arguments, true);
                                            J$.N(15985, 'token', token, false);
                                            var token;
                                            J$.M(15909, J$.R(15905, 'delegate', delegate, false), 'markStart', false)();
                                            token = J$.W(15921, 'token', J$.F(15917, J$.R(15913, 'lex', lex, false), false)(), token);
                                            if (J$.C(1648, J$.U(2194, '!', J$.F(15933, J$.R(15925, 'isIdentifierName', isIdentifierName, false), false)(J$.R(15929, 'token', token, false))))) {
                                                J$.F(15945, J$.R(15937, 'throwUnexpected', throwUnexpected, false), false)(J$.R(15941, 'token', token, false));
                                            }
                                            return J$.Rt(15973, J$.M(15969, J$.R(15949, 'delegate', delegate, false), 'markEnd', false)(J$.M(15965, J$.R(15953, 'delegate', delegate, false), 'createIdentifier', false)(J$.G(15961, J$.R(15957, 'token', token, false), 'value'))));
                                        } catch (J$e) {
                                            J$.Ex(29685, J$e);
                                        } finally {
                                            if (J$.Fr(29689))
                                                continue jalangiLabel98;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseNonComputedMember() {
                                jalangiLabel99:
                                    while (true) {
                                        try {
                                            J$.Fe(16013, arguments.callee, this);
                                            arguments = J$.N(16017, 'arguments', arguments, true);
                                            J$.F(15997, J$.R(15989, 'expect', expect, false), false)(J$.T(15993, '.', 21));
                                            return J$.Rt(16009, J$.F(16005, J$.R(16001, 'parseNonComputedProperty', parseNonComputedProperty, false), false)());
                                        } catch (J$e) {
                                            J$.Ex(29693, J$e);
                                        } finally {
                                            if (J$.Fr(29697))
                                                continue jalangiLabel99;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseComputedMember() {
                                jalangiLabel100:
                                    while (true) {
                                        try {
                                            J$.Fe(16065, arguments.callee, this);
                                            arguments = J$.N(16069, 'arguments', arguments, true);
                                            J$.N(16073, 'expr', expr, false);
                                            var expr;
                                            J$.F(16029, J$.R(16021, 'expect', expect, false), false)(J$.T(16025, '[', 21));
                                            expr = J$.W(16041, 'expr', J$.F(16037, J$.R(16033, 'parseExpression', parseExpression, false), false)(), expr);
                                            J$.F(16053, J$.R(16045, 'expect', expect, false), false)(J$.T(16049, ']', 21));
                                            return J$.Rt(16061, J$.R(16057, 'expr', expr, false));
                                        } catch (J$e) {
                                            J$.Ex(29701, J$e);
                                        } finally {
                                            if (J$.Fr(29705))
                                                continue jalangiLabel100;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseNewExpression() {
                                jalangiLabel101:
                                    while (true) {
                                        try {
                                            J$.Fe(16165, arguments.callee, this);
                                            arguments = J$.N(16169, 'arguments', arguments, true);
                                            J$.N(16173, 'callee', callee, false);
                                            J$.N(16177, 'args', args, false);
                                            var callee, args;
                                            J$.M(16081, J$.R(16077, 'delegate', delegate, false), 'markStart', false)();
                                            J$.F(16093, J$.R(16085, 'expectKeyword', expectKeyword, false), false)(J$.T(16089, 'new', 21));
                                            callee = J$.W(16105, 'callee', J$.F(16101, J$.R(16097, 'parseLeftHandSideExpression', parseLeftHandSideExpression, false), false)(), callee);
                                            args = J$.W(16133, 'args', J$.C(1652, J$.F(16117, J$.R(16109, 'match', match, false), false)(J$.T(16113, '(', 21))) ? J$.F(16125, J$.R(16121, 'parseArguments', parseArguments, false), false)() : J$.T(16129, [], 10), args);
                                            return J$.Rt(16161, J$.M(16157, J$.R(16137, 'delegate', delegate, false), 'markEnd', false)(J$.M(16153, J$.R(16141, 'delegate', delegate, false), 'createNewExpression', false)(J$.R(16145, 'callee', callee, false), J$.R(16149, 'args', args, false))));
                                        } catch (J$e) {
                                            J$.Ex(29709, J$e);
                                        } finally {
                                            if (J$.Fr(29713))
                                                continue jalangiLabel101;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseLeftHandSideExpressionAllowCall() {
                                jalangiLabel102:
                                    while (true) {
                                        try {
                                            J$.Fe(16457, arguments.callee, this);
                                            arguments = J$.N(16461, 'arguments', arguments, true);
                                            J$.N(16465, 'marker', marker, false);
                                            J$.N(16469, 'previousAllowIn', previousAllowIn, false);
                                            J$.N(16473, 'expr', expr, false);
                                            J$.N(16477, 'args', args, false);
                                            J$.N(16481, 'property', property, false);
                                            var marker, previousAllowIn, expr, args, property;
                                            marker = J$.W(16189, 'marker', J$.F(16185, J$.R(16181, 'createLocationMarker', createLocationMarker, false), false)(), marker);
                                            previousAllowIn = J$.W(16201, 'previousAllowIn', J$.G(16197, J$.R(16193, 'state', state, false), 'allowIn'), previousAllowIn);
                                            J$.P(16213, J$.R(16205, 'state', state, false), 'allowIn', J$.T(16209, true, 23));
                                            expr = J$.W(16245, 'expr', J$.C(1656, J$.F(16225, J$.R(16217, 'matchKeyword', matchKeyword, false), false)(J$.T(16221, 'new', 21))) ? J$.F(16233, J$.R(16229, 'parseNewExpression', parseNewExpression, false), false)() : J$.F(16241, J$.R(16237, 'parsePrimaryExpression', parsePrimaryExpression, false), false)(), expr);
                                            J$.P(16257, J$.R(16249, 'state', state, false), 'allowIn', J$.R(16253, 'previousAllowIn', previousAllowIn, false));
                                            while (J$.C(1680, J$.C(1664, J$.C(1660, J$.F(16269, J$.R(16261, 'match', match, false), false)(J$.T(16265, '.', 21))) ? J$._() : J$.F(16281, J$.R(16273, 'match', match, false), false)(J$.T(16277, '[', 21))) ? J$._() : J$.F(16293, J$.R(16285, 'match', match, false), false)(J$.T(16289, '(', 21)))) {
                                                if (J$.C(1672, J$.F(16305, J$.R(16297, 'match', match, false), false)(J$.T(16301, '(', 21)))) {
                                                    args = J$.W(16317, 'args', J$.F(16313, J$.R(16309, 'parseArguments', parseArguments, false), false)(), args);
                                                    expr = J$.W(16337, 'expr', J$.M(16333, J$.R(16321, 'delegate', delegate, false), 'createCallExpression', false)(J$.R(16325, 'expr', expr, false), J$.R(16329, 'args', args, false)), expr);
                                                } else if (J$.C(1668, J$.F(16349, J$.R(16341, 'match', match, false), false)(J$.T(16345, '[', 21)))) {
                                                    property = J$.W(16361, 'property', J$.F(16357, J$.R(16353, 'parseComputedMember', parseComputedMember, false), false)(), property);
                                                    expr = J$.W(16385, 'expr', J$.M(16381, J$.R(16365, 'delegate', delegate, false), 'createMemberExpression', false)(J$.T(16369, '[', 21), J$.R(16373, 'expr', expr, false), J$.R(16377, 'property', property, false)), expr);
                                                } else {
                                                    property = J$.W(16397, 'property', J$.F(16393, J$.R(16389, 'parseNonComputedMember', parseNonComputedMember, false), false)(), property);
                                                    expr = J$.W(16421, 'expr', J$.M(16417, J$.R(16401, 'delegate', delegate, false), 'createMemberExpression', false)(J$.T(16405, '.', 21), J$.R(16409, 'expr', expr, false), J$.R(16413, 'property', property, false)), expr);
                                                }
                                                if (J$.C(1676, J$.R(16425, 'marker', marker, false))) {
                                                    J$.M(16433, J$.R(16429, 'marker', marker, false), 'end', false)();
                                                    J$.M(16445, J$.R(16437, 'marker', marker, false), 'apply', false)(J$.R(16441, 'expr', expr, false));
                                                }
                                            }
                                            return J$.Rt(16453, J$.R(16449, 'expr', expr, false));
                                        } catch (J$e) {
                                            J$.Ex(29717, J$e);
                                        } finally {
                                            if (J$.Fr(29721))
                                                continue jalangiLabel102;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseLeftHandSideExpression() {
                                jalangiLabel103:
                                    while (true) {
                                        try {
                                            J$.Fe(16693, arguments.callee, this);
                                            arguments = J$.N(16697, 'arguments', arguments, true);
                                            J$.N(16701, 'marker', marker, false);
                                            J$.N(16705, 'previousAllowIn', previousAllowIn, false);
                                            J$.N(16709, 'expr', expr, false);
                                            J$.N(16713, 'property', property, false);
                                            var marker, previousAllowIn, expr, property;
                                            marker = J$.W(16493, 'marker', J$.F(16489, J$.R(16485, 'createLocationMarker', createLocationMarker, false), false)(), marker);
                                            previousAllowIn = J$.W(16505, 'previousAllowIn', J$.G(16501, J$.R(16497, 'state', state, false), 'allowIn'), previousAllowIn);
                                            expr = J$.W(16537, 'expr', J$.C(1684, J$.F(16517, J$.R(16509, 'matchKeyword', matchKeyword, false), false)(J$.T(16513, 'new', 21))) ? J$.F(16525, J$.R(16521, 'parseNewExpression', parseNewExpression, false), false)() : J$.F(16533, J$.R(16529, 'parsePrimaryExpression', parsePrimaryExpression, false), false)(), expr);
                                            J$.P(16549, J$.R(16541, 'state', state, false), 'allowIn', J$.R(16545, 'previousAllowIn', previousAllowIn, false));
                                            while (J$.C(1700, J$.C(1688, J$.F(16561, J$.R(16553, 'match', match, false), false)(J$.T(16557, '.', 21))) ? J$._() : J$.F(16573, J$.R(16565, 'match', match, false), false)(J$.T(16569, '[', 21)))) {
                                                if (J$.C(1692, J$.F(16585, J$.R(16577, 'match', match, false), false)(J$.T(16581, '[', 21)))) {
                                                    property = J$.W(16597, 'property', J$.F(16593, J$.R(16589, 'parseComputedMember', parseComputedMember, false), false)(), property);
                                                    expr = J$.W(16621, 'expr', J$.M(16617, J$.R(16601, 'delegate', delegate, false), 'createMemberExpression', false)(J$.T(16605, '[', 21), J$.R(16609, 'expr', expr, false), J$.R(16613, 'property', property, false)), expr);
                                                } else {
                                                    property = J$.W(16633, 'property', J$.F(16629, J$.R(16625, 'parseNonComputedMember', parseNonComputedMember, false), false)(), property);
                                                    expr = J$.W(16657, 'expr', J$.M(16653, J$.R(16637, 'delegate', delegate, false), 'createMemberExpression', false)(J$.T(16641, '.', 21), J$.R(16645, 'expr', expr, false), J$.R(16649, 'property', property, false)), expr);
                                                }
                                                if (J$.C(1696, J$.R(16661, 'marker', marker, false))) {
                                                    J$.M(16669, J$.R(16665, 'marker', marker, false), 'end', false)();
                                                    J$.M(16681, J$.R(16673, 'marker', marker, false), 'apply', false)(J$.R(16677, 'expr', expr, false));
                                                }
                                            }
                                            return J$.Rt(16689, J$.R(16685, 'expr', expr, false));
                                        } catch (J$e) {
                                            J$.Ex(29725, J$e);
                                        } finally {
                                            if (J$.Fr(29729))
                                                continue jalangiLabel103;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parsePostfixExpression() {
                                jalangiLabel104:
                                    while (true) {
                                        try {
                                            J$.Fe(16925, arguments.callee, this);
                                            arguments = J$.N(16929, 'arguments', arguments, true);
                                            J$.N(16933, 'expr', expr, false);
                                            J$.N(16937, 'token', token, false);
                                            var expr, token;
                                            J$.M(16721, J$.R(16717, 'delegate', delegate, false), 'markStart', false)();
                                            expr = J$.W(16733, 'expr', J$.F(16729, J$.R(16725, 'parseLeftHandSideExpressionAllowCall', parseLeftHandSideExpressionAllowCall, false), false)(), expr);
                                            if (J$.C(1732, J$.B(2198, '===', J$.G(16741, J$.R(16737, 'lookahead', lookahead, false), 'type'), J$.G(16749, J$.R(16745, 'Token', Token, false), 'Punctuator')))) {
                                                if (J$.C(1728, J$.C(1708, J$.C(1704, J$.F(16761, J$.R(16753, 'match', match, false), false)(J$.T(16757, '++', 21))) ? J$._() : J$.F(16773, J$.R(16765, 'match', match, false), false)(J$.T(16769, '--', 21))) ? J$.U(2202, '!', J$.F(16781, J$.R(16777, 'peekLineTerminator', peekLineTerminator, false), false)()) : J$._())) {
                                                    if (J$.C(1720, J$.C(1716, J$.C(1712, J$.R(16785, 'strict', strict, false)) ? J$.B(2206, '===', J$.G(16793, J$.R(16789, 'expr', expr, false), 'type'), J$.G(16801, J$.R(16797, 'Syntax', Syntax, false), 'Identifier')) : J$._()) ? J$.F(16817, J$.R(16805, 'isRestrictedWord', isRestrictedWord, false), false)(J$.G(16813, J$.R(16809, 'expr', expr, false), 'name')) : J$._())) {
                                                        J$.F(16837, J$.R(16821, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(16825, {}, 11), J$.G(16833, J$.R(16829, 'Messages', Messages, false), 'StrictLHSPostfix'));
                                                    }
                                                    if (J$.C(1724, J$.U(2210, '!', J$.F(16849, J$.R(16841, 'isLeftHandSide', isLeftHandSide, false), false)(J$.R(16845, 'expr', expr, false))))) {
                                                        J$.F(16869, J$.R(16853, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(16857, {}, 11), J$.G(16865, J$.R(16861, 'Messages', Messages, false), 'InvalidLHSInAssignment'));
                                                    }
                                                    token = J$.W(16881, 'token', J$.F(16877, J$.R(16873, 'lex', lex, false), false)(), token);
                                                    expr = J$.W(16905, 'expr', J$.M(16901, J$.R(16885, 'delegate', delegate, false), 'createPostfixExpression', false)(J$.G(16893, J$.R(16889, 'token', token, false), 'value'), J$.R(16897, 'expr', expr, false)), expr);
                                                }
                                            }
                                            return J$.Rt(16921, J$.M(16917, J$.R(16909, 'delegate', delegate, false), 'markEndIf', false)(J$.R(16913, 'expr', expr, false)));
                                        } catch (J$e) {
                                            J$.Ex(29733, J$e);
                                        } finally {
                                            if (J$.Fr(29737))
                                                continue jalangiLabel104;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseUnaryExpression() {
                                jalangiLabel105:
                                    while (true) {
                                        try {
                                            J$.Fe(17417, arguments.callee, this);
                                            arguments = J$.N(17421, 'arguments', arguments, true);
                                            J$.N(17425, 'token', token, false);
                                            J$.N(17429, 'expr', expr, false);
                                            var token, expr;
                                            J$.M(16945, J$.R(16941, 'delegate', delegate, false), 'markStart', false)();
                                            if (J$.C(1804, J$.C(1736, J$.B(2214, '!==', J$.G(16953, J$.R(16949, 'lookahead', lookahead, false), 'type'), J$.G(16961, J$.R(16957, 'Token', Token, false), 'Punctuator'))) ? J$.B(2218, '!==', J$.G(16969, J$.R(16965, 'lookahead', lookahead, false), 'type'), J$.G(16977, J$.R(16973, 'Token', Token, false), 'Keyword')) : J$._())) {
                                                expr = J$.W(16989, 'expr', J$.F(16985, J$.R(16981, 'parsePostfixExpression', parsePostfixExpression, false), false)(), expr);
                                            } else if (J$.C(1800, J$.C(1740, J$.F(17001, J$.R(16993, 'match', match, false), false)(J$.T(16997, '++', 21))) ? J$._() : J$.F(17013, J$.R(17005, 'match', match, false), false)(J$.T(17009, '--', 21)))) {
                                                token = J$.W(17025, 'token', J$.F(17021, J$.R(17017, 'lex', lex, false), false)(), token);
                                                expr = J$.W(17037, 'expr', J$.F(17033, J$.R(17029, 'parseUnaryExpression', parseUnaryExpression, false), false)(), expr);
                                                if (J$.C(1752, J$.C(1748, J$.C(1744, J$.R(17041, 'strict', strict, false)) ? J$.B(2222, '===', J$.G(17049, J$.R(17045, 'expr', expr, false), 'type'), J$.G(17057, J$.R(17053, 'Syntax', Syntax, false), 'Identifier')) : J$._()) ? J$.F(17073, J$.R(17061, 'isRestrictedWord', isRestrictedWord, false), false)(J$.G(17069, J$.R(17065, 'expr', expr, false), 'name')) : J$._())) {
                                                    J$.F(17093, J$.R(17077, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(17081, {}, 11), J$.G(17089, J$.R(17085, 'Messages', Messages, false), 'StrictLHSPrefix'));
                                                }
                                                if (J$.C(1756, J$.U(2226, '!', J$.F(17105, J$.R(17097, 'isLeftHandSide', isLeftHandSide, false), false)(J$.R(17101, 'expr', expr, false))))) {
                                                    J$.F(17125, J$.R(17109, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(17113, {}, 11), J$.G(17121, J$.R(17117, 'Messages', Messages, false), 'InvalidLHSInAssignment'));
                                                }
                                                expr = J$.W(17149, 'expr', J$.M(17145, J$.R(17129, 'delegate', delegate, false), 'createUnaryExpression', false)(J$.G(17137, J$.R(17133, 'token', token, false), 'value'), J$.R(17141, 'expr', expr, false)), expr);
                                            } else if (J$.C(1796, J$.C(1768, J$.C(1764, J$.C(1760, J$.F(17161, J$.R(17153, 'match', match, false), false)(J$.T(17157, '+', 21))) ? J$._() : J$.F(17173, J$.R(17165, 'match', match, false), false)(J$.T(17169, '-', 21))) ? J$._() : J$.F(17185, J$.R(17177, 'match', match, false), false)(J$.T(17181, '~', 21))) ? J$._() : J$.F(17197, J$.R(17189, 'match', match, false), false)(J$.T(17193, '!', 21)))) {
                                                token = J$.W(17209, 'token', J$.F(17205, J$.R(17201, 'lex', lex, false), false)(), token);
                                                expr = J$.W(17221, 'expr', J$.F(17217, J$.R(17213, 'parseUnaryExpression', parseUnaryExpression, false), false)(), expr);
                                                expr = J$.W(17245, 'expr', J$.M(17241, J$.R(17225, 'delegate', delegate, false), 'createUnaryExpression', false)(J$.G(17233, J$.R(17229, 'token', token, false), 'value'), J$.R(17237, 'expr', expr, false)), expr);
                                            } else if (J$.C(1792, J$.C(1776, J$.C(1772, J$.F(17257, J$.R(17249, 'matchKeyword', matchKeyword, false), false)(J$.T(17253, 'delete', 21))) ? J$._() : J$.F(17269, J$.R(17261, 'matchKeyword', matchKeyword, false), false)(J$.T(17265, 'void', 21))) ? J$._() : J$.F(17281, J$.R(17273, 'matchKeyword', matchKeyword, false), false)(J$.T(17277, 'typeof', 21)))) {
                                                token = J$.W(17293, 'token', J$.F(17289, J$.R(17285, 'lex', lex, false), false)(), token);
                                                expr = J$.W(17305, 'expr', J$.F(17301, J$.R(17297, 'parseUnaryExpression', parseUnaryExpression, false), false)(), expr);
                                                expr = J$.W(17329, 'expr', J$.M(17325, J$.R(17309, 'delegate', delegate, false), 'createUnaryExpression', false)(J$.G(17317, J$.R(17313, 'token', token, false), 'value'), J$.R(17321, 'expr', expr, false)), expr);
                                                if (J$.C(1788, J$.C(1784, J$.C(1780, J$.R(17333, 'strict', strict, false)) ? J$.B(2230, '===', J$.G(17341, J$.R(17337, 'expr', expr, false), 'operator'), J$.T(17345, 'delete', 21)) : J$._()) ? J$.B(2234, '===', J$.G(17357, J$.G(17353, J$.R(17349, 'expr', expr, false), 'argument'), 'type'), J$.G(17365, J$.R(17361, 'Syntax', Syntax, false), 'Identifier')) : J$._())) {
                                                    J$.F(17385, J$.R(17369, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(17373, {}, 11), J$.G(17381, J$.R(17377, 'Messages', Messages, false), 'StrictDelete'));
                                                }
                                            } else {
                                                expr = J$.W(17397, 'expr', J$.F(17393, J$.R(17389, 'parsePostfixExpression', parsePostfixExpression, false), false)(), expr);
                                            }
                                            return J$.Rt(17413, J$.M(17409, J$.R(17401, 'delegate', delegate, false), 'markEndIf', false)(J$.R(17405, 'expr', expr, false)));
                                        } catch (J$e) {
                                            J$.Ex(29741, J$e);
                                        } finally {
                                            if (J$.Fr(29745))
                                                continue jalangiLabel105;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function binaryPrecedence(token, allowIn) {
                                jalangiLabel106:
                                    while (true) {
                                        try {
                                            J$.Fe(17685, arguments.callee, this);
                                            arguments = J$.N(17689, 'arguments', arguments, true);
                                            token = J$.N(17693, 'token', token, true);
                                            allowIn = J$.N(17697, 'allowIn', allowIn, true);
                                            J$.N(17701, 'prec', prec, false);
                                            var prec = J$.W(17437, 'prec', J$.T(17433, 0, 22), prec);
                                            if (J$.C(1812, J$.C(1808, J$.B(2238, '!==', J$.G(17445, J$.R(17441, 'token', token, false), 'type'), J$.G(17453, J$.R(17449, 'Token', Token, false), 'Punctuator'))) ? J$.B(2242, '!==', J$.G(17461, J$.R(17457, 'token', token, false), 'type'), J$.G(17469, J$.R(17465, 'Token', Token, false), 'Keyword')) : J$._())) {
                                                return J$.Rt(17477, J$.T(17473, 0, 22));
                                            }
                                            switch (J$.C1(1820, J$.G(17485, J$.R(17481, 'token', token, false), 'value'))) {
                                            case J$.C2(1824, J$.T(17497, '||', 21)):
                                                prec = J$.W(17493, 'prec', J$.T(17489, 1, 22), prec);
                                                break;
                                            case J$.C2(1828, J$.T(17509, '&&', 21)):
                                                prec = J$.W(17505, 'prec', J$.T(17501, 2, 22), prec);
                                                break;
                                            case J$.C2(1832, J$.T(17521, '|', 21)):
                                                prec = J$.W(17517, 'prec', J$.T(17513, 3, 22), prec);
                                                break;
                                            case J$.C2(1836, J$.T(17533, '^', 21)):
                                                prec = J$.W(17529, 'prec', J$.T(17525, 4, 22), prec);
                                                break;
                                            case J$.C2(1840, J$.T(17545, '&', 21)):
                                                prec = J$.W(17541, 'prec', J$.T(17537, 5, 22), prec);
                                                break;
                                            case J$.C2(1844, J$.T(17549, '==', 21)):
                                            case J$.C2(1848, J$.T(17553, '!=', 21)):
                                            case J$.C2(1852, J$.T(17557, '===', 21)):
                                            case J$.C2(1856, J$.T(17569, '!==', 21)):
                                                prec = J$.W(17565, 'prec', J$.T(17561, 6, 22), prec);
                                                break;
                                            case J$.C2(1860, J$.T(17573, '<', 21)):
                                            case J$.C2(1864, J$.T(17577, '>', 21)):
                                            case J$.C2(1868, J$.T(17581, '<=', 21)):
                                            case J$.C2(1872, J$.T(17585, '>=', 21)):
                                            case J$.C2(1876, J$.T(17597, 'instanceof', 21)):
                                                prec = J$.W(17593, 'prec', J$.T(17589, 7, 22), prec);
                                                break;
                                            case J$.C2(1880, J$.T(17617, 'in', 21)):
                                                prec = J$.W(17613, 'prec', J$.C(1816, J$.R(17601, 'allowIn', allowIn, false)) ? J$.T(17605, 7, 22) : J$.T(17609, 0, 22), prec);
                                                break;
                                            case J$.C2(1884, J$.T(17621, '<<', 21)):
                                            case J$.C2(1888, J$.T(17625, '>>', 21)):
                                            case J$.C2(1892, J$.T(17637, '>>>', 21)):
                                                prec = J$.W(17633, 'prec', J$.T(17629, 8, 22), prec);
                                                break;
                                            case J$.C2(1896, J$.T(17641, '+', 21)):
                                            case J$.C2(1900, J$.T(17653, '-', 21)):
                                                prec = J$.W(17649, 'prec', J$.T(17645, 9, 22), prec);
                                                break;
                                            case J$.C2(1904, J$.T(17657, '*', 21)):
                                            case J$.C2(1908, J$.T(17661, '/', 21)):
                                            case J$.C2(1912, J$.T(17673, '%', 21)):
                                                prec = J$.W(17669, 'prec', J$.T(17665, 11, 22), prec);
                                                break;
                                            default:
                                                break;
                                            }
                                            return J$.Rt(17681, J$.R(17677, 'prec', prec, false));
                                        } catch (J$e) {
                                            J$.Ex(29749, J$e);
                                        } finally {
                                            if (J$.Fr(29753))
                                                continue jalangiLabel106;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseBinaryExpression() {
                                jalangiLabel107:
                                    while (true) {
                                        try {
                                            J$.Fe(18281, arguments.callee, this);
                                            arguments = J$.N(18285, 'arguments', arguments, true);
                                            J$.N(18289, 'marker', marker, false);
                                            J$.N(18293, 'markers', markers, false);
                                            J$.N(18297, 'expr', expr, false);
                                            J$.N(18301, 'token', token, false);
                                            J$.N(18305, 'prec', prec, false);
                                            J$.N(18309, 'stack', stack, false);
                                            J$.N(18313, 'right', right, false);
                                            J$.N(18317, 'operator', operator, false);
                                            J$.N(18321, 'left', left, false);
                                            J$.N(18325, 'i', i, false);
                                            var marker, markers, expr, token, prec, stack, right, operator, left, i;
                                            marker = J$.W(17713, 'marker', J$.F(17709, J$.R(17705, 'createLocationMarker', createLocationMarker, false), false)(), marker);
                                            left = J$.W(17725, 'left', J$.F(17721, J$.R(17717, 'parseUnaryExpression', parseUnaryExpression, false), false)(), left);
                                            token = J$.W(17733, 'token', J$.R(17729, 'lookahead', lookahead, false), token);
                                            prec = J$.W(17757, 'prec', J$.F(17753, J$.R(17737, 'binaryPrecedence', binaryPrecedence, false), false)(J$.R(17741, 'token', token, false), J$.G(17749, J$.R(17745, 'state', state, false), 'allowIn')), prec);
                                            if (J$.C(1916, J$.B(2246, '===', J$.R(17761, 'prec', prec, false), J$.T(17765, 0, 22)))) {
                                                return J$.Rt(17773, J$.R(17769, 'left', left, false));
                                            }
                                            J$.P(17785, J$.R(17777, 'token', token, false), 'prec', J$.R(17781, 'prec', prec, false));
                                            J$.F(17793, J$.R(17789, 'lex', lex, false), false)();
                                            markers = J$.W(17813, 'markers', J$.T(17809, [
                                                J$.R(17797, 'marker', marker, false),
                                                J$.F(17805, J$.R(17801, 'createLocationMarker', createLocationMarker, false), false)()
                                            ], 10), markers);
                                            right = J$.W(17825, 'right', J$.F(17821, J$.R(17817, 'parseUnaryExpression', parseUnaryExpression, false), false)(), right);
                                            stack = J$.W(17845, 'stack', J$.T(17841, [
                                                J$.R(17829, 'left', left, false),
                                                J$.R(17833, 'token', token, false),
                                                J$.R(17837, 'right', right, false)
                                            ], 10), stack);
                                            while (J$.C(1932, J$.B(2250, '>', prec = J$.W(17869, 'prec', J$.F(17865, J$.R(17849, 'binaryPrecedence', binaryPrecedence, false), false)(J$.R(17853, 'lookahead', lookahead, false), J$.G(17861, J$.R(17857, 'state', state, false), 'allowIn')), prec), J$.T(17873, 0, 22)))) {
                                                while (J$.C(1928, J$.C(1920, J$.B(2254, '>', J$.G(17881, J$.R(17877, 'stack', stack, false), 'length'), J$.T(17885, 2, 22))) ? J$.B(2262, '<=', J$.R(17889, 'prec', prec, false), J$.G(17913, J$.G(17909, J$.R(17893, 'stack', stack, false), J$.B(2258, '-', J$.G(17901, J$.R(17897, 'stack', stack, false), 'length'), J$.T(17905, 2, 22))), 'prec')) : J$._())) {
                                                    right = J$.W(17925, 'right', J$.M(17921, J$.R(17917, 'stack', stack, false), 'pop', false)(), right);
                                                    operator = J$.W(17941, 'operator', J$.G(17937, J$.M(17933, J$.R(17929, 'stack', stack, false), 'pop', false)(), 'value'), operator);
                                                    left = J$.W(17953, 'left', J$.M(17949, J$.R(17945, 'stack', stack, false), 'pop', false)(), left);
                                                    expr = J$.W(17977, 'expr', J$.M(17973, J$.R(17957, 'delegate', delegate, false), 'createBinaryExpression', false)(J$.R(17961, 'operator', operator, false), J$.R(17965, 'left', left, false), J$.R(17969, 'right', right, false)), expr);
                                                    J$.M(17985, J$.R(17981, 'markers', markers, false), 'pop', false)();
                                                    marker = J$.W(17997, 'marker', J$.M(17993, J$.R(17989, 'markers', markers, false), 'pop', false)(), marker);
                                                    if (J$.C(1924, J$.R(18001, 'marker', marker, false))) {
                                                        J$.M(18009, J$.R(18005, 'marker', marker, false), 'end', false)();
                                                        J$.M(18021, J$.R(18013, 'marker', marker, false), 'apply', false)(J$.R(18017, 'expr', expr, false));
                                                    }
                                                    J$.M(18033, J$.R(18025, 'stack', stack, false), 'push', false)(J$.R(18029, 'expr', expr, false));
                                                    J$.M(18045, J$.R(18037, 'markers', markers, false), 'push', false)(J$.R(18041, 'marker', marker, false));
                                                }
                                                token = J$.W(18057, 'token', J$.F(18053, J$.R(18049, 'lex', lex, false), false)(), token);
                                                J$.P(18069, J$.R(18061, 'token', token, false), 'prec', J$.R(18065, 'prec', prec, false));
                                                J$.M(18081, J$.R(18073, 'stack', stack, false), 'push', false)(J$.R(18077, 'token', token, false));
                                                J$.M(18097, J$.R(18085, 'markers', markers, false), 'push', false)(J$.F(18093, J$.R(18089, 'createLocationMarker', createLocationMarker, false), false)());
                                                expr = J$.W(18109, 'expr', J$.F(18105, J$.R(18101, 'parseUnaryExpression', parseUnaryExpression, false), false)(), expr);
                                                J$.M(18121, J$.R(18113, 'stack', stack, false), 'push', false)(J$.R(18117, 'expr', expr, false));
                                            }
                                            i = J$.W(18137, 'i', J$.B(2266, '-', J$.G(18129, J$.R(18125, 'stack', stack, false), 'length'), J$.T(18133, 1, 22)), i);
                                            expr = J$.W(18153, 'expr', J$.G(18149, J$.R(18141, 'stack', stack, false), J$.R(18145, 'i', i, false)), expr);
                                            J$.M(18161, J$.R(18157, 'markers', markers, false), 'pop', false)();
                                            while (J$.C(1940, J$.B(2270, '>', J$.R(18165, 'i', i, false), J$.T(18169, 1, 22)))) {
                                                expr = J$.W(18221, 'expr', J$.M(18217, J$.R(18173, 'delegate', delegate, false), 'createBinaryExpression', false)(J$.G(18193, J$.G(18189, J$.R(18177, 'stack', stack, false), J$.B(2274, '-', J$.R(18181, 'i', i, false), J$.T(18185, 1, 22))), 'value'), J$.G(18209, J$.R(18197, 'stack', stack, false), J$.B(2278, '-', J$.R(18201, 'i', i, false), J$.T(18205, 2, 22))), J$.R(18213, 'expr', expr, false)), expr);
                                                i = J$.W(18233, 'i', J$.B(2282, '-', J$.R(18229, 'i', i, false), J$.T(18225, 2, 22)), i);
                                                marker = J$.W(18245, 'marker', J$.M(18241, J$.R(18237, 'markers', markers, false), 'pop', false)(), marker);
                                                if (J$.C(1936, J$.R(18249, 'marker', marker, false))) {
                                                    J$.M(18257, J$.R(18253, 'marker', marker, false), 'end', false)();
                                                    J$.M(18269, J$.R(18261, 'marker', marker, false), 'apply', false)(J$.R(18265, 'expr', expr, false));
                                                }
                                            }
                                            return J$.Rt(18277, J$.R(18273, 'expr', expr, false));
                                        } catch (J$e) {
                                            J$.Ex(29757, J$e);
                                        } finally {
                                            if (J$.Fr(29761))
                                                continue jalangiLabel107;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseConditionalExpression() {
                                jalangiLabel108:
                                    while (true) {
                                        try {
                                            J$.Fe(18493, arguments.callee, this);
                                            arguments = J$.N(18497, 'arguments', arguments, true);
                                            J$.N(18501, 'expr', expr, false);
                                            J$.N(18505, 'previousAllowIn', previousAllowIn, false);
                                            J$.N(18509, 'consequent', consequent, false);
                                            J$.N(18513, 'alternate', alternate, false);
                                            var expr, previousAllowIn, consequent, alternate;
                                            J$.M(18333, J$.R(18329, 'delegate', delegate, false), 'markStart', false)();
                                            expr = J$.W(18345, 'expr', J$.F(18341, J$.R(18337, 'parseBinaryExpression', parseBinaryExpression, false), false)(), expr);
                                            if (J$.C(1944, J$.F(18357, J$.R(18349, 'match', match, false), false)(J$.T(18353, '?', 21)))) {
                                                J$.F(18365, J$.R(18361, 'lex', lex, false), false)();
                                                previousAllowIn = J$.W(18377, 'previousAllowIn', J$.G(18373, J$.R(18369, 'state', state, false), 'allowIn'), previousAllowIn);
                                                J$.P(18389, J$.R(18381, 'state', state, false), 'allowIn', J$.T(18385, true, 23));
                                                consequent = J$.W(18401, 'consequent', J$.F(18397, J$.R(18393, 'parseAssignmentExpression', parseAssignmentExpression, false), false)(), consequent);
                                                J$.P(18413, J$.R(18405, 'state', state, false), 'allowIn', J$.R(18409, 'previousAllowIn', previousAllowIn, false));
                                                J$.F(18425, J$.R(18417, 'expect', expect, false), false)(J$.T(18421, ':', 21));
                                                alternate = J$.W(18437, 'alternate', J$.F(18433, J$.R(18429, 'parseAssignmentExpression', parseAssignmentExpression, false), false)(), alternate);
                                                expr = J$.W(18469, 'expr', J$.M(18465, J$.R(18441, 'delegate', delegate, false), 'markEnd', false)(J$.M(18461, J$.R(18445, 'delegate', delegate, false), 'createConditionalExpression', false)(J$.R(18449, 'expr', expr, false), J$.R(18453, 'consequent', consequent, false), J$.R(18457, 'alternate', alternate, false))), expr);
                                            } else {
                                                J$.M(18481, J$.R(18473, 'delegate', delegate, false), 'markEnd', false)(J$.T(18477, {}, 11));
                                            }
                                            return J$.Rt(18489, J$.R(18485, 'expr', expr, false));
                                        } catch (J$e) {
                                            J$.Ex(29765, J$e);
                                        } finally {
                                            if (J$.Fr(29769))
                                                continue jalangiLabel108;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseAssignmentExpression() {
                                jalangiLabel109:
                                    while (true) {
                                        try {
                                            J$.Fe(18713, arguments.callee, this);
                                            arguments = J$.N(18717, 'arguments', arguments, true);
                                            J$.N(18721, 'token', token, false);
                                            J$.N(18725, 'left', left, false);
                                            J$.N(18729, 'right', right, false);
                                            J$.N(18733, 'node', node, false);
                                            var token, left, right, node;
                                            token = J$.W(18521, 'token', J$.R(18517, 'lookahead', lookahead, false), token);
                                            J$.M(18529, J$.R(18525, 'delegate', delegate, false), 'markStart', false)();
                                            node = J$.W(18545, 'node', left = J$.W(18541, 'left', J$.F(18537, J$.R(18533, 'parseConditionalExpression', parseConditionalExpression, false), false)(), left), node);
                                            if (J$.C(1964, J$.F(18553, J$.R(18549, 'matchAssign', matchAssign, false), false)())) {
                                                if (J$.C(1948, J$.U(2286, '!', J$.F(18565, J$.R(18557, 'isLeftHandSide', isLeftHandSide, false), false)(J$.R(18561, 'left', left, false))))) {
                                                    J$.F(18585, J$.R(18569, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(18573, {}, 11), J$.G(18581, J$.R(18577, 'Messages', Messages, false), 'InvalidLHSInAssignment'));
                                                }
                                                if (J$.C(1960, J$.C(1956, J$.C(1952, J$.R(18589, 'strict', strict, false)) ? J$.B(2290, '===', J$.G(18597, J$.R(18593, 'left', left, false), 'type'), J$.G(18605, J$.R(18601, 'Syntax', Syntax, false), 'Identifier')) : J$._()) ? J$.F(18621, J$.R(18609, 'isRestrictedWord', isRestrictedWord, false), false)(J$.G(18617, J$.R(18613, 'left', left, false), 'name')) : J$._())) {
                                                    J$.F(18641, J$.R(18625, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.R(18629, 'token', token, false), J$.G(18637, J$.R(18633, 'Messages', Messages, false), 'StrictLHSAssignment'));
                                                }
                                                token = J$.W(18653, 'token', J$.F(18649, J$.R(18645, 'lex', lex, false), false)(), token);
                                                right = J$.W(18665, 'right', J$.F(18661, J$.R(18657, 'parseAssignmentExpression', parseAssignmentExpression, false), false)(), right);
                                                node = J$.W(18693, 'node', J$.M(18689, J$.R(18669, 'delegate', delegate, false), 'createAssignmentExpression', false)(J$.G(18677, J$.R(18673, 'token', token, false), 'value'), J$.R(18681, 'left', left, false), J$.R(18685, 'right', right, false)), node);
                                            }
                                            return J$.Rt(18709, J$.M(18705, J$.R(18697, 'delegate', delegate, false), 'markEndIf', false)(J$.R(18701, 'node', node, false)));
                                        } catch (J$e) {
                                            J$.Ex(29773, J$e);
                                        } finally {
                                            if (J$.Fr(29777))
                                                continue jalangiLabel109;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseExpression() {
                                jalangiLabel110:
                                    while (true) {
                                        try {
                                            J$.Fe(18853, arguments.callee, this);
                                            arguments = J$.N(18857, 'arguments', arguments, true);
                                            J$.N(18861, 'expr', expr, false);
                                            var expr;
                                            J$.M(18741, J$.R(18737, 'delegate', delegate, false), 'markStart', false)();
                                            expr = J$.W(18753, 'expr', J$.F(18749, J$.R(18745, 'parseAssignmentExpression', parseAssignmentExpression, false), false)(), expr);
                                            if (J$.C(1976, J$.F(18765, J$.R(18757, 'match', match, false), false)(J$.T(18761, ',', 21)))) {
                                                expr = J$.W(18785, 'expr', J$.M(18781, J$.R(18769, 'delegate', delegate, false), 'createSequenceExpression', false)(J$.T(18777, [J$.R(18773, 'expr', expr, false)], 10)), expr);
                                                while (J$.C(1972, J$.B(2294, '<', J$.R(18789, 'index', index, false), J$.R(18793, 'length', length, false)))) {
                                                    if (J$.C(1968, J$.U(2298, '!', J$.F(18805, J$.R(18797, 'match', match, false), false)(J$.T(18801, ',', 21))))) {
                                                        break;
                                                    }
                                                    J$.F(18813, J$.R(18809, 'lex', lex, false), false)();
                                                    J$.M(18833, J$.G(18821, J$.R(18817, 'expr', expr, false), 'expressions'), 'push', false)(J$.F(18829, J$.R(18825, 'parseAssignmentExpression', parseAssignmentExpression, false), false)());
                                                }
                                            }
                                            return J$.Rt(18849, J$.M(18845, J$.R(18837, 'delegate', delegate, false), 'markEndIf', false)(J$.R(18841, 'expr', expr, false)));
                                        } catch (J$e) {
                                            J$.Ex(29781, J$e);
                                        } finally {
                                            if (J$.Fr(29785))
                                                continue jalangiLabel110;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseStatementList() {
                                jalangiLabel111:
                                    while (true) {
                                        try {
                                            J$.Fe(18933, arguments.callee, this);
                                            arguments = J$.N(18937, 'arguments', arguments, true);
                                            J$.N(18941, 'list', list, false);
                                            J$.N(18945, 'statement', statement, false);
                                            var list = J$.W(18869, 'list', J$.T(18865, [], 10), list), statement;
                                            while (J$.C(1988, J$.B(2302, '<', J$.R(18873, 'index', index, false), J$.R(18877, 'length', length, false)))) {
                                                if (J$.C(1980, J$.F(18889, J$.R(18881, 'match', match, false), false)(J$.T(18885, '}', 21)))) {
                                                    break;
                                                }
                                                statement = J$.W(18901, 'statement', J$.F(18897, J$.R(18893, 'parseSourceElement', parseSourceElement, false), false)(), statement);
                                                if (J$.C(1984, J$.B(2310, '===', J$.U(2306, 'typeof', J$.R(18905, 'statement', statement, false)), J$.T(18909, 'undefined', 21)))) {
                                                    break;
                                                }
                                                J$.M(18921, J$.R(18913, 'list', list, false), 'push', false)(J$.R(18917, 'statement', statement, false));
                                            }
                                            return J$.Rt(18929, J$.R(18925, 'list', list, false));
                                        } catch (J$e) {
                                            J$.Ex(29789, J$e);
                                        } finally {
                                            if (J$.Fr(29793))
                                                continue jalangiLabel111;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseBlock() {
                                jalangiLabel112:
                                    while (true) {
                                        try {
                                            J$.Fe(19025, arguments.callee, this);
                                            arguments = J$.N(19029, 'arguments', arguments, true);
                                            J$.N(19033, 'block', block, false);
                                            var block;
                                            J$.F(18953, J$.R(18949, 'skipComment', skipComment, false), false)();
                                            J$.M(18961, J$.R(18957, 'delegate', delegate, false), 'markStart', false)();
                                            J$.F(18973, J$.R(18965, 'expect', expect, false), false)(J$.T(18969, '{', 21));
                                            block = J$.W(18985, 'block', J$.F(18981, J$.R(18977, 'parseStatementList', parseStatementList, false), false)(), block);
                                            J$.F(18997, J$.R(18989, 'expect', expect, false), false)(J$.T(18993, '}', 21));
                                            return J$.Rt(19021, J$.M(19017, J$.R(19001, 'delegate', delegate, false), 'markEnd', false)(J$.M(19013, J$.R(19005, 'delegate', delegate, false), 'createBlockStatement', false)(J$.R(19009, 'block', block, false))));
                                        } catch (J$e) {
                                            J$.Ex(29797, J$e);
                                        } finally {
                                            if (J$.Fr(29801))
                                                continue jalangiLabel112;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseVariableIdentifier() {
                                jalangiLabel113:
                                    while (true) {
                                        try {
                                            J$.Fe(19121, arguments.callee, this);
                                            arguments = J$.N(19125, 'arguments', arguments, true);
                                            J$.N(19129, 'token', token, false);
                                            var token;
                                            J$.F(19041, J$.R(19037, 'skipComment', skipComment, false), false)();
                                            J$.M(19049, J$.R(19045, 'delegate', delegate, false), 'markStart', false)();
                                            token = J$.W(19061, 'token', J$.F(19057, J$.R(19053, 'lex', lex, false), false)(), token);
                                            if (J$.C(1992, J$.B(2314, '!==', J$.G(19069, J$.R(19065, 'token', token, false), 'type'), J$.G(19077, J$.R(19073, 'Token', Token, false), 'Identifier')))) {
                                                J$.F(19089, J$.R(19081, 'throwUnexpected', throwUnexpected, false), false)(J$.R(19085, 'token', token, false));
                                            }
                                            return J$.Rt(19117, J$.M(19113, J$.R(19093, 'delegate', delegate, false), 'markEnd', false)(J$.M(19109, J$.R(19097, 'delegate', delegate, false), 'createIdentifier', false)(J$.G(19105, J$.R(19101, 'token', token, false), 'value'))));
                                        } catch (J$e) {
                                            J$.Ex(29805, J$e);
                                        } finally {
                                            if (J$.Fr(29809))
                                                continue jalangiLabel113;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseVariableDeclaration(kind) {
                                jalangiLabel114:
                                    while (true) {
                                        try {
                                            J$.Fe(19301, arguments.callee, this);
                                            arguments = J$.N(19305, 'arguments', arguments, true);
                                            kind = J$.N(19309, 'kind', kind, true);
                                            J$.N(19313, 'init', init, false);
                                            J$.N(19317, 'id', id, false);
                                            var init = J$.W(19137, 'init', J$.T(19133, null, 25), init), id;
                                            J$.F(19145, J$.R(19141, 'skipComment', skipComment, false), false)();
                                            J$.M(19153, J$.R(19149, 'delegate', delegate, false), 'markStart', false)();
                                            id = J$.W(19165, 'id', J$.F(19161, J$.R(19157, 'parseVariableIdentifier', parseVariableIdentifier, false), false)(), id);
                                            if (J$.C(2000, J$.C(1996, J$.R(19169, 'strict', strict, false)) ? J$.F(19185, J$.R(19173, 'isRestrictedWord', isRestrictedWord, false), false)(J$.G(19181, J$.R(19177, 'id', id, false), 'name')) : J$._())) {
                                                J$.F(19205, J$.R(19189, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(19193, {}, 11), J$.G(19201, J$.R(19197, 'Messages', Messages, false), 'StrictVarName'));
                                            }
                                            if (J$.C(2008, J$.B(2318, '===', J$.R(19209, 'kind', kind, false), J$.T(19213, 'const', 21)))) {
                                                J$.F(19225, J$.R(19217, 'expect', expect, false), false)(J$.T(19221, '=', 21));
                                                init = J$.W(19237, 'init', J$.F(19233, J$.R(19229, 'parseAssignmentExpression', parseAssignmentExpression, false), false)(), init);
                                            } else if (J$.C(2004, J$.F(19249, J$.R(19241, 'match', match, false), false)(J$.T(19245, '=', 21)))) {
                                                J$.F(19257, J$.R(19253, 'lex', lex, false), false)();
                                                init = J$.W(19269, 'init', J$.F(19265, J$.R(19261, 'parseAssignmentExpression', parseAssignmentExpression, false), false)(), init);
                                            }
                                            return J$.Rt(19297, J$.M(19293, J$.R(19273, 'delegate', delegate, false), 'markEnd', false)(J$.M(19289, J$.R(19277, 'delegate', delegate, false), 'createVariableDeclarator', false)(J$.R(19281, 'id', id, false), J$.R(19285, 'init', init, false))));
                                        } catch (J$e) {
                                            J$.Ex(29813, J$e);
                                        } finally {
                                            if (J$.Fr(29817))
                                                continue jalangiLabel114;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseVariableDeclarationList(kind) {
                                jalangiLabel115:
                                    while (true) {
                                        try {
                                            J$.Fe(19385, arguments.callee, this);
                                            arguments = J$.N(19389, 'arguments', arguments, true);
                                            kind = J$.N(19393, 'kind', kind, true);
                                            J$.N(19397, 'list', list, false);
                                            var list = J$.W(19325, 'list', J$.T(19321, [], 10), list);
                                            do {
                                                J$.M(19345, J$.R(19329, 'list', list, false), 'push', false)(J$.F(19341, J$.R(19333, 'parseVariableDeclaration', parseVariableDeclaration, false), false)(J$.R(19337, 'kind', kind, false)));
                                                if (J$.C(2012, J$.U(2322, '!', J$.F(19357, J$.R(19349, 'match', match, false), false)(J$.T(19353, ',', 21))))) {
                                                    break;
                                                }
                                                J$.F(19365, J$.R(19361, 'lex', lex, false), false)();
                                            } while (J$.C(2016, J$.B(2326, '<', J$.R(19369, 'index', index, false), J$.R(19373, 'length', length, false))));
                                            return J$.Rt(19381, J$.R(19377, 'list', list, false));
                                        } catch (J$e) {
                                            J$.Ex(29821, J$e);
                                        } finally {
                                            if (J$.Fr(29825))
                                                continue jalangiLabel115;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseVariableStatement() {
                                jalangiLabel116:
                                    while (true) {
                                        try {
                                            J$.Fe(19453, arguments.callee, this);
                                            arguments = J$.N(19457, 'arguments', arguments, true);
                                            J$.N(19461, 'declarations', declarations, false);
                                            var declarations;
                                            J$.F(19409, J$.R(19401, 'expectKeyword', expectKeyword, false), false)(J$.T(19405, 'var', 21));
                                            declarations = J$.W(19421, 'declarations', J$.F(19417, J$.R(19413, 'parseVariableDeclarationList', parseVariableDeclarationList, false), false)(), declarations);
                                            J$.F(19429, J$.R(19425, 'consumeSemicolon', consumeSemicolon, false), false)();
                                            return J$.Rt(19449, J$.M(19445, J$.R(19433, 'delegate', delegate, false), 'createVariableDeclaration', false)(J$.R(19437, 'declarations', declarations, false), J$.T(19441, 'var', 21)));
                                        } catch (J$e) {
                                            J$.Ex(29829, J$e);
                                        } finally {
                                            if (J$.Fr(29833))
                                                continue jalangiLabel116;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseConstLetDeclaration(kind) {
                                jalangiLabel117:
                                    while (true) {
                                        try {
                                            J$.Fe(19545, arguments.callee, this);
                                            arguments = J$.N(19549, 'arguments', arguments, true);
                                            kind = J$.N(19553, 'kind', kind, true);
                                            J$.N(19557, 'declarations', declarations, false);
                                            var declarations;
                                            J$.F(19469, J$.R(19465, 'skipComment', skipComment, false), false)();
                                            J$.M(19477, J$.R(19473, 'delegate', delegate, false), 'markStart', false)();
                                            J$.F(19489, J$.R(19481, 'expectKeyword', expectKeyword, false), false)(J$.R(19485, 'kind', kind, false));
                                            declarations = J$.W(19505, 'declarations', J$.F(19501, J$.R(19493, 'parseVariableDeclarationList', parseVariableDeclarationList, false), false)(J$.R(19497, 'kind', kind, false)), declarations);
                                            J$.F(19513, J$.R(19509, 'consumeSemicolon', consumeSemicolon, false), false)();
                                            return J$.Rt(19541, J$.M(19537, J$.R(19517, 'delegate', delegate, false), 'markEnd', false)(J$.M(19533, J$.R(19521, 'delegate', delegate, false), 'createVariableDeclaration', false)(J$.R(19525, 'declarations', declarations, false), J$.R(19529, 'kind', kind, false))));
                                        } catch (J$e) {
                                            J$.Ex(29837, J$e);
                                        } finally {
                                            if (J$.Fr(29841))
                                                continue jalangiLabel117;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseEmptyStatement() {
                                jalangiLabel118:
                                    while (true) {
                                        try {
                                            J$.Fe(19585, arguments.callee, this);
                                            arguments = J$.N(19589, 'arguments', arguments, true);
                                            J$.F(19569, J$.R(19561, 'expect', expect, false), false)(J$.T(19565, ';', 21));
                                            return J$.Rt(19581, J$.M(19577, J$.R(19573, 'delegate', delegate, false), 'createEmptyStatement', false)());
                                        } catch (J$e) {
                                            J$.Ex(29845, J$e);
                                        } finally {
                                            if (J$.Fr(29849))
                                                continue jalangiLabel118;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseExpressionStatement() {
                                jalangiLabel119:
                                    while (true) {
                                        try {
                                            J$.Fe(19629, arguments.callee, this);
                                            arguments = J$.N(19633, 'arguments', arguments, true);
                                            J$.N(19637, 'expr', expr, false);
                                            var expr = J$.W(19601, 'expr', J$.F(19597, J$.R(19593, 'parseExpression', parseExpression, false), false)(), expr);
                                            J$.F(19609, J$.R(19605, 'consumeSemicolon', consumeSemicolon, false), false)();
                                            return J$.Rt(19625, J$.M(19621, J$.R(19613, 'delegate', delegate, false), 'createExpressionStatement', false)(J$.R(19617, 'expr', expr, false)));
                                        } catch (J$e) {
                                            J$.Ex(29853, J$e);
                                        } finally {
                                            if (J$.Fr(29857))
                                                continue jalangiLabel119;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseIfStatement() {
                                jalangiLabel120:
                                    while (true) {
                                        try {
                                            J$.Fe(19765, arguments.callee, this);
                                            arguments = J$.N(19769, 'arguments', arguments, true);
                                            J$.N(19773, 'test', test, false);
                                            J$.N(19777, 'consequent', consequent, false);
                                            J$.N(19781, 'alternate', alternate, false);
                                            var test, consequent, alternate;
                                            J$.F(19649, J$.R(19641, 'expectKeyword', expectKeyword, false), false)(J$.T(19645, 'if', 21));
                                            J$.F(19661, J$.R(19653, 'expect', expect, false), false)(J$.T(19657, '(', 21));
                                            test = J$.W(19673, 'test', J$.F(19669, J$.R(19665, 'parseExpression', parseExpression, false), false)(), test);
                                            J$.F(19685, J$.R(19677, 'expect', expect, false), false)(J$.T(19681, ')', 21));
                                            consequent = J$.W(19697, 'consequent', J$.F(19693, J$.R(19689, 'parseStatement', parseStatement, false), false)(), consequent);
                                            if (J$.C(2020, J$.F(19709, J$.R(19701, 'matchKeyword', matchKeyword, false), false)(J$.T(19705, 'else', 21)))) {
                                                J$.F(19717, J$.R(19713, 'lex', lex, false), false)();
                                                alternate = J$.W(19729, 'alternate', J$.F(19725, J$.R(19721, 'parseStatement', parseStatement, false), false)(), alternate);
                                            } else {
                                                alternate = J$.W(19737, 'alternate', J$.T(19733, null, 25), alternate);
                                            }
                                            return J$.Rt(19761, J$.M(19757, J$.R(19741, 'delegate', delegate, false), 'createIfStatement', false)(J$.R(19745, 'test', test, false), J$.R(19749, 'consequent', consequent, false), J$.R(19753, 'alternate', alternate, false)));
                                        } catch (J$e) {
                                            J$.Ex(29861, J$e);
                                        } finally {
                                            if (J$.Fr(29865))
                                                continue jalangiLabel120;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseDoWhileStatement() {
                                jalangiLabel121:
                                    while (true) {
                                        try {
                                            J$.Fe(19933, arguments.callee, this);
                                            arguments = J$.N(19937, 'arguments', arguments, true);
                                            J$.N(19941, 'body', body, false);
                                            J$.N(19945, 'test', test, false);
                                            J$.N(19949, 'oldInIteration', oldInIteration, false);
                                            var body, test, oldInIteration;
                                            J$.F(19793, J$.R(19785, 'expectKeyword', expectKeyword, false), false)(J$.T(19789, 'do', 21));
                                            oldInIteration = J$.W(19805, 'oldInIteration', J$.G(19801, J$.R(19797, 'state', state, false), 'inIteration'), oldInIteration);
                                            J$.P(19817, J$.R(19809, 'state', state, false), 'inIteration', J$.T(19813, true, 23));
                                            body = J$.W(19829, 'body', J$.F(19825, J$.R(19821, 'parseStatement', parseStatement, false), false)(), body);
                                            J$.P(19841, J$.R(19833, 'state', state, false), 'inIteration', J$.R(19837, 'oldInIteration', oldInIteration, false));
                                            J$.F(19853, J$.R(19845, 'expectKeyword', expectKeyword, false), false)(J$.T(19849, 'while', 21));
                                            J$.F(19865, J$.R(19857, 'expect', expect, false), false)(J$.T(19861, '(', 21));
                                            test = J$.W(19877, 'test', J$.F(19873, J$.R(19869, 'parseExpression', parseExpression, false), false)(), test);
                                            J$.F(19889, J$.R(19881, 'expect', expect, false), false)(J$.T(19885, ')', 21));
                                            if (J$.C(2024, J$.F(19901, J$.R(19893, 'match', match, false), false)(J$.T(19897, ';', 21)))) {
                                                J$.F(19909, J$.R(19905, 'lex', lex, false), false)();
                                            }
                                            return J$.Rt(19929, J$.M(19925, J$.R(19913, 'delegate', delegate, false), 'createDoWhileStatement', false)(J$.R(19917, 'body', body, false), J$.R(19921, 'test', test, false)));
                                        } catch (J$e) {
                                            J$.Ex(29869, J$e);
                                        } finally {
                                            if (J$.Fr(29873))
                                                continue jalangiLabel121;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseWhileStatement() {
                                jalangiLabel122:
                                    while (true) {
                                        try {
                                            J$.Fe(20069, arguments.callee, this);
                                            arguments = J$.N(20073, 'arguments', arguments, true);
                                            J$.N(20077, 'test', test, false);
                                            J$.N(20081, 'body', body, false);
                                            J$.N(20085, 'oldInIteration', oldInIteration, false);
                                            var test, body, oldInIteration;
                                            J$.F(19961, J$.R(19953, 'expectKeyword', expectKeyword, false), false)(J$.T(19957, 'while', 21));
                                            J$.F(19973, J$.R(19965, 'expect', expect, false), false)(J$.T(19969, '(', 21));
                                            test = J$.W(19985, 'test', J$.F(19981, J$.R(19977, 'parseExpression', parseExpression, false), false)(), test);
                                            J$.F(19997, J$.R(19989, 'expect', expect, false), false)(J$.T(19993, ')', 21));
                                            oldInIteration = J$.W(20009, 'oldInIteration', J$.G(20005, J$.R(20001, 'state', state, false), 'inIteration'), oldInIteration);
                                            J$.P(20021, J$.R(20013, 'state', state, false), 'inIteration', J$.T(20017, true, 23));
                                            body = J$.W(20033, 'body', J$.F(20029, J$.R(20025, 'parseStatement', parseStatement, false), false)(), body);
                                            J$.P(20045, J$.R(20037, 'state', state, false), 'inIteration', J$.R(20041, 'oldInIteration', oldInIteration, false));
                                            return J$.Rt(20065, J$.M(20061, J$.R(20049, 'delegate', delegate, false), 'createWhileStatement', false)(J$.R(20053, 'test', test, false), J$.R(20057, 'body', body, false)));
                                        } catch (J$e) {
                                            J$.Ex(29877, J$e);
                                        } finally {
                                            if (J$.Fr(29881))
                                                continue jalangiLabel122;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseForVariableDeclaration() {
                                jalangiLabel123:
                                    while (true) {
                                        try {
                                            J$.Fe(20153, arguments.callee, this);
                                            arguments = J$.N(20157, 'arguments', arguments, true);
                                            J$.N(20161, 'token', token, false);
                                            J$.N(20165, 'declarations', declarations, false);
                                            var token, declarations;
                                            J$.M(20093, J$.R(20089, 'delegate', delegate, false), 'markStart', false)();
                                            token = J$.W(20105, 'token', J$.F(20101, J$.R(20097, 'lex', lex, false), false)(), token);
                                            declarations = J$.W(20117, 'declarations', J$.F(20113, J$.R(20109, 'parseVariableDeclarationList', parseVariableDeclarationList, false), false)(), declarations);
                                            return J$.Rt(20149, J$.M(20145, J$.R(20121, 'delegate', delegate, false), 'markEnd', false)(J$.M(20141, J$.R(20125, 'delegate', delegate, false), 'createVariableDeclaration', false)(J$.R(20129, 'declarations', declarations, false), J$.G(20137, J$.R(20133, 'token', token, false), 'value'))));
                                        } catch (J$e) {
                                            J$.Ex(29885, J$e);
                                        } finally {
                                            if (J$.Fr(29889))
                                                continue jalangiLabel123;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseForStatement() {
                                jalangiLabel124:
                                    while (true) {
                                        try {
                                            J$.Fe(20673, arguments.callee, this);
                                            arguments = J$.N(20677, 'arguments', arguments, true);
                                            J$.N(20681, 'init', init, false);
                                            J$.N(20685, 'test', test, false);
                                            J$.N(20689, 'update', update, false);
                                            J$.N(20693, 'left', left, false);
                                            J$.N(20697, 'right', right, false);
                                            J$.N(20701, 'body', body, false);
                                            J$.N(20705, 'oldInIteration', oldInIteration, false);
                                            var init, test, update, left, right, body, oldInIteration;
                                            init = J$.W(20181, 'init', test = J$.W(20177, 'test', update = J$.W(20173, 'update', J$.T(20169, null, 25), update), test), init);
                                            J$.F(20193, J$.R(20185, 'expectKeyword', expectKeyword, false), false)(J$.T(20189, 'for', 21));
                                            J$.F(20205, J$.R(20197, 'expect', expect, false), false)(J$.T(20201, '(', 21));
                                            if (J$.C(2056, J$.F(20217, J$.R(20209, 'match', match, false), false)(J$.T(20213, ';', 21)))) {
                                                J$.F(20225, J$.R(20221, 'lex', lex, false), false)();
                                            } else {
                                                if (J$.C(2048, J$.C(2028, J$.F(20237, J$.R(20229, 'matchKeyword', matchKeyword, false), false)(J$.T(20233, 'var', 21))) ? J$._() : J$.F(20249, J$.R(20241, 'matchKeyword', matchKeyword, false), false)(J$.T(20245, 'let', 21)))) {
                                                    J$.P(20261, J$.R(20253, 'state', state, false), 'allowIn', J$.T(20257, false, 23));
                                                    init = J$.W(20273, 'init', J$.F(20269, J$.R(20265, 'parseForVariableDeclaration', parseForVariableDeclaration, false), false)(), init);
                                                    J$.P(20285, J$.R(20277, 'state', state, false), 'allowIn', J$.T(20281, true, 23));
                                                    if (J$.C(2036, J$.C(2032, J$.B(2330, '===', J$.G(20297, J$.G(20293, J$.R(20289, 'init', init, false), 'declarations'), 'length'), J$.T(20301, 1, 22))) ? J$.F(20313, J$.R(20305, 'matchKeyword', matchKeyword, false), false)(J$.T(20309, 'in', 21)) : J$._())) {
                                                        J$.F(20321, J$.R(20317, 'lex', lex, false), false)();
                                                        left = J$.W(20329, 'left', J$.R(20325, 'init', init, false), left);
                                                        right = J$.W(20341, 'right', J$.F(20337, J$.R(20333, 'parseExpression', parseExpression, false), false)(), right);
                                                        init = J$.W(20349, 'init', J$.T(20345, null, 25), init);
                                                    }
                                                } else {
                                                    J$.P(20361, J$.R(20353, 'state', state, false), 'allowIn', J$.T(20357, false, 23));
                                                    init = J$.W(20373, 'init', J$.F(20369, J$.R(20365, 'parseExpression', parseExpression, false), false)(), init);
                                                    J$.P(20385, J$.R(20377, 'state', state, false), 'allowIn', J$.T(20381, true, 23));
                                                    if (J$.C(2044, J$.F(20397, J$.R(20389, 'matchKeyword', matchKeyword, false), false)(J$.T(20393, 'in', 21)))) {
                                                        if (J$.C(2040, J$.U(2334, '!', J$.F(20409, J$.R(20401, 'isLeftHandSide', isLeftHandSide, false), false)(J$.R(20405, 'init', init, false))))) {
                                                            J$.F(20429, J$.R(20413, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(20417, {}, 11), J$.G(20425, J$.R(20421, 'Messages', Messages, false), 'InvalidLHSInForIn'));
                                                        }
                                                        J$.F(20437, J$.R(20433, 'lex', lex, false), false)();
                                                        left = J$.W(20445, 'left', J$.R(20441, 'init', init, false), left);
                                                        right = J$.W(20457, 'right', J$.F(20453, J$.R(20449, 'parseExpression', parseExpression, false), false)(), right);
                                                        init = J$.W(20465, 'init', J$.T(20461, null, 25), init);
                                                    }
                                                }
                                                if (J$.C(2052, J$.B(2342, '===', J$.U(2338, 'typeof', J$.R(20469, 'left', left, false)), J$.T(20473, 'undefined', 21)))) {
                                                    J$.F(20485, J$.R(20477, 'expect', expect, false), false)(J$.T(20481, ';', 21));
                                                }
                                            }
                                            if (J$.C(2068, J$.B(2350, '===', J$.U(2346, 'typeof', J$.R(20489, 'left', left, false)), J$.T(20493, 'undefined', 21)))) {
                                                if (J$.C(2060, J$.U(2354, '!', J$.F(20505, J$.R(20497, 'match', match, false), false)(J$.T(20501, ';', 21))))) {
                                                    test = J$.W(20517, 'test', J$.F(20513, J$.R(20509, 'parseExpression', parseExpression, false), false)(), test);
                                                }
                                                J$.F(20529, J$.R(20521, 'expect', expect, false), false)(J$.T(20525, ';', 21));
                                                if (J$.C(2064, J$.U(2358, '!', J$.F(20541, J$.R(20533, 'match', match, false), false)(J$.T(20537, ')', 21))))) {
                                                    update = J$.W(20553, 'update', J$.F(20549, J$.R(20545, 'parseExpression', parseExpression, false), false)(), update);
                                                }
                                            }
                                            J$.F(20565, J$.R(20557, 'expect', expect, false), false)(J$.T(20561, ')', 21));
                                            oldInIteration = J$.W(20577, 'oldInIteration', J$.G(20573, J$.R(20569, 'state', state, false), 'inIteration'), oldInIteration);
                                            J$.P(20589, J$.R(20581, 'state', state, false), 'inIteration', J$.T(20585, true, 23));
                                            body = J$.W(20601, 'body', J$.F(20597, J$.R(20593, 'parseStatement', parseStatement, false), false)(), body);
                                            J$.P(20613, J$.R(20605, 'state', state, false), 'inIteration', J$.R(20609, 'oldInIteration', oldInIteration, false));
                                            return J$.Rt(20669, J$.C(2072, J$.B(2366, '===', J$.U(2362, 'typeof', J$.R(20617, 'left', left, false)), J$.T(20621, 'undefined', 21))) ? J$.M(20645, J$.R(20625, 'delegate', delegate, false), 'createForStatement', false)(J$.R(20629, 'init', init, false), J$.R(20633, 'test', test, false), J$.R(20637, 'update', update, false), J$.R(20641, 'body', body, false)) : J$.M(20665, J$.R(20649, 'delegate', delegate, false), 'createForInStatement', false)(J$.R(20653, 'left', left, false), J$.R(20657, 'right', right, false), J$.R(20661, 'body', body, false)));
                                        } catch (J$e) {
                                            J$.Ex(29893, J$e);
                                        } finally {
                                            if (J$.Fr(29897))
                                                continue jalangiLabel124;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseContinueStatement() {
                                jalangiLabel125:
                                    while (true) {
                                        try {
                                            J$.Fe(21009, arguments.callee, this);
                                            arguments = J$.N(21013, 'arguments', arguments, true);
                                            J$.N(21017, 'label', label, false);
                                            J$.N(21021, 'key', key, false);
                                            var label = J$.W(20713, 'label', J$.T(20709, null, 25), label), key;
                                            J$.F(20725, J$.R(20717, 'expectKeyword', expectKeyword, false), false)(J$.T(20721, 'continue', 21));
                                            if (J$.C(2080, J$.B(2370, '===', J$.M(20737, J$.R(20729, 'source', source, false), 'charCodeAt', false)(J$.R(20733, 'index', index, false)), J$.T(20741, 59, 22)))) {
                                                J$.F(20749, J$.R(20745, 'lex', lex, false), false)();
                                                if (J$.C(2076, J$.U(2374, '!', J$.G(20757, J$.R(20753, 'state', state, false), 'inIteration')))) {
                                                    J$.F(20777, J$.R(20761, 'throwError', throwError, false), false)(J$.T(20765, {}, 11), J$.G(20773, J$.R(20769, 'Messages', Messages, false), 'IllegalContinue'));
                                                }
                                                return J$.Rt(20793, J$.M(20789, J$.R(20781, 'delegate', delegate, false), 'createContinueStatement', false)(J$.T(20785, null, 25)));
                                            }
                                            if (J$.C(2088, J$.F(20801, J$.R(20797, 'peekLineTerminator', peekLineTerminator, false), false)())) {
                                                if (J$.C(2084, J$.U(2378, '!', J$.G(20809, J$.R(20805, 'state', state, false), 'inIteration')))) {
                                                    J$.F(20829, J$.R(20813, 'throwError', throwError, false), false)(J$.T(20817, {}, 11), J$.G(20825, J$.R(20821, 'Messages', Messages, false), 'IllegalContinue'));
                                                }
                                                return J$.Rt(20845, J$.M(20841, J$.R(20833, 'delegate', delegate, false), 'createContinueStatement', false)(J$.T(20837, null, 25)));
                                            }
                                            if (J$.C(2096, J$.B(2382, '===', J$.G(20853, J$.R(20849, 'lookahead', lookahead, false), 'type'), J$.G(20861, J$.R(20857, 'Token', Token, false), 'Identifier')))) {
                                                label = J$.W(20873, 'label', J$.F(20869, J$.R(20865, 'parseVariableIdentifier', parseVariableIdentifier, false), false)(), label);
                                                key = J$.W(20889, 'key', J$.B(2386, '+', J$.T(20877, '$', 21), J$.G(20885, J$.R(20881, 'label', label, false), 'name')), key);
                                                if (J$.C(2092, J$.U(2390, '!', J$.M(20917, J$.G(20901, J$.G(20897, J$.I(typeof Object === 'undefined' ? Object = J$.R(20893, 'Object', undefined, true) : Object = J$.R(20893, 'Object', Object, true)), 'prototype'), 'hasOwnProperty'), 'call', false)(J$.G(20909, J$.R(20905, 'state', state, false), 'labelSet'), J$.R(20913, 'key', key, false))))) {
                                                    J$.F(20945, J$.R(20921, 'throwError', throwError, false), false)(J$.T(20925, {}, 11), J$.G(20933, J$.R(20929, 'Messages', Messages, false), 'UnknownLabel'), J$.G(20941, J$.R(20937, 'label', label, false), 'name'));
                                                }
                                            }
                                            J$.F(20953, J$.R(20949, 'consumeSemicolon', consumeSemicolon, false), false)();
                                            if (J$.C(2104, J$.C(2100, J$.B(2394, '===', J$.R(20957, 'label', label, false), J$.T(20961, null, 25))) ? J$.U(2398, '!', J$.G(20969, J$.R(20965, 'state', state, false), 'inIteration')) : J$._())) {
                                                J$.F(20989, J$.R(20973, 'throwError', throwError, false), false)(J$.T(20977, {}, 11), J$.G(20985, J$.R(20981, 'Messages', Messages, false), 'IllegalContinue'));
                                            }
                                            return J$.Rt(21005, J$.M(21001, J$.R(20993, 'delegate', delegate, false), 'createContinueStatement', false)(J$.R(20997, 'label', label, false)));
                                        } catch (J$e) {
                                            J$.Ex(29901, J$e);
                                        } finally {
                                            if (J$.Fr(29905))
                                                continue jalangiLabel125;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseBreakStatement() {
                                jalangiLabel126:
                                    while (true) {
                                        try {
                                            J$.Fe(21349, arguments.callee, this);
                                            arguments = J$.N(21353, 'arguments', arguments, true);
                                            J$.N(21357, 'label', label, false);
                                            J$.N(21361, 'key', key, false);
                                            var label = J$.W(21029, 'label', J$.T(21025, null, 25), label), key;
                                            J$.F(21041, J$.R(21033, 'expectKeyword', expectKeyword, false), false)(J$.T(21037, 'break', 21));
                                            if (J$.C(2116, J$.B(2402, '===', J$.M(21053, J$.R(21045, 'source', source, false), 'charCodeAt', false)(J$.R(21049, 'index', index, false)), J$.T(21057, 59, 22)))) {
                                                J$.F(21065, J$.R(21061, 'lex', lex, false), false)();
                                                if (J$.C(2112, J$.U(2406, '!', J$.C(2108, J$.G(21073, J$.R(21069, 'state', state, false), 'inIteration')) ? J$._() : J$.G(21081, J$.R(21077, 'state', state, false), 'inSwitch')))) {
                                                    J$.F(21101, J$.R(21085, 'throwError', throwError, false), false)(J$.T(21089, {}, 11), J$.G(21097, J$.R(21093, 'Messages', Messages, false), 'IllegalBreak'));
                                                }
                                                return J$.Rt(21117, J$.M(21113, J$.R(21105, 'delegate', delegate, false), 'createBreakStatement', false)(J$.T(21109, null, 25)));
                                            }
                                            if (J$.C(2128, J$.F(21125, J$.R(21121, 'peekLineTerminator', peekLineTerminator, false), false)())) {
                                                if (J$.C(2124, J$.U(2410, '!', J$.C(2120, J$.G(21133, J$.R(21129, 'state', state, false), 'inIteration')) ? J$._() : J$.G(21141, J$.R(21137, 'state', state, false), 'inSwitch')))) {
                                                    J$.F(21161, J$.R(21145, 'throwError', throwError, false), false)(J$.T(21149, {}, 11), J$.G(21157, J$.R(21153, 'Messages', Messages, false), 'IllegalBreak'));
                                                }
                                                return J$.Rt(21177, J$.M(21173, J$.R(21165, 'delegate', delegate, false), 'createBreakStatement', false)(J$.T(21169, null, 25)));
                                            }
                                            if (J$.C(2136, J$.B(2414, '===', J$.G(21185, J$.R(21181, 'lookahead', lookahead, false), 'type'), J$.G(21193, J$.R(21189, 'Token', Token, false), 'Identifier')))) {
                                                label = J$.W(21205, 'label', J$.F(21201, J$.R(21197, 'parseVariableIdentifier', parseVariableIdentifier, false), false)(), label);
                                                key = J$.W(21221, 'key', J$.B(2418, '+', J$.T(21209, '$', 21), J$.G(21217, J$.R(21213, 'label', label, false), 'name')), key);
                                                if (J$.C(2132, J$.U(2422, '!', J$.M(21249, J$.G(21233, J$.G(21229, J$.I(typeof Object === 'undefined' ? Object = J$.R(21225, 'Object', undefined, true) : Object = J$.R(21225, 'Object', Object, true)), 'prototype'), 'hasOwnProperty'), 'call', false)(J$.G(21241, J$.R(21237, 'state', state, false), 'labelSet'), J$.R(21245, 'key', key, false))))) {
                                                    J$.F(21277, J$.R(21253, 'throwError', throwError, false), false)(J$.T(21257, {}, 11), J$.G(21265, J$.R(21261, 'Messages', Messages, false), 'UnknownLabel'), J$.G(21273, J$.R(21269, 'label', label, false), 'name'));
                                                }
                                            }
                                            J$.F(21285, J$.R(21281, 'consumeSemicolon', consumeSemicolon, false), false)();
                                            if (J$.C(2148, J$.C(2144, J$.B(2426, '===', J$.R(21289, 'label', label, false), J$.T(21293, null, 25))) ? J$.U(2430, '!', J$.C(2140, J$.G(21301, J$.R(21297, 'state', state, false), 'inIteration')) ? J$._() : J$.G(21309, J$.R(21305, 'state', state, false), 'inSwitch')) : J$._())) {
                                                J$.F(21329, J$.R(21313, 'throwError', throwError, false), false)(J$.T(21317, {}, 11), J$.G(21325, J$.R(21321, 'Messages', Messages, false), 'IllegalBreak'));
                                            }
                                            return J$.Rt(21345, J$.M(21341, J$.R(21333, 'delegate', delegate, false), 'createBreakStatement', false)(J$.R(21337, 'label', label, false)));
                                        } catch (J$e) {
                                            J$.Ex(29909, J$e);
                                        } finally {
                                            if (J$.Fr(29913))
                                                continue jalangiLabel126;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseReturnStatement() {
                                jalangiLabel127:
                                    while (true) {
                                        try {
                                            J$.Fe(21589, arguments.callee, this);
                                            arguments = J$.N(21593, 'arguments', arguments, true);
                                            J$.N(21597, 'argument', argument, false);
                                            var argument = J$.W(21369, 'argument', J$.T(21365, null, 25), argument);
                                            J$.F(21381, J$.R(21373, 'expectKeyword', expectKeyword, false), false)(J$.T(21377, 'return', 21));
                                            if (J$.C(2152, J$.U(2434, '!', J$.G(21389, J$.R(21385, 'state', state, false), 'inFunctionBody')))) {
                                                J$.F(21409, J$.R(21393, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(21397, {}, 11), J$.G(21405, J$.R(21401, 'Messages', Messages, false), 'IllegalReturn'));
                                            }
                                            if (J$.C(2160, J$.B(2438, '===', J$.M(21421, J$.R(21413, 'source', source, false), 'charCodeAt', false)(J$.R(21417, 'index', index, false)), J$.T(21425, 32, 22)))) {
                                                if (J$.C(2156, J$.F(21449, J$.R(21429, 'isIdentifierStart', isIdentifierStart, false), false)(J$.M(21445, J$.R(21433, 'source', source, false), 'charCodeAt', false)(J$.B(2442, '+', J$.R(21437, 'index', index, false), J$.T(21441, 1, 22)))))) {
                                                    argument = J$.W(21461, 'argument', J$.F(21457, J$.R(21453, 'parseExpression', parseExpression, false), false)(), argument);
                                                    J$.F(21469, J$.R(21465, 'consumeSemicolon', consumeSemicolon, false), false)();
                                                    return J$.Rt(21485, J$.M(21481, J$.R(21473, 'delegate', delegate, false), 'createReturnStatement', false)(J$.R(21477, 'argument', argument, false)));
                                                }
                                            }
                                            if (J$.C(2164, J$.F(21493, J$.R(21489, 'peekLineTerminator', peekLineTerminator, false), false)())) {
                                                return J$.Rt(21509, J$.M(21505, J$.R(21497, 'delegate', delegate, false), 'createReturnStatement', false)(J$.T(21501, null, 25)));
                                            }
                                            if (J$.C(2176, J$.U(2446, '!', J$.F(21521, J$.R(21513, 'match', match, false), false)(J$.T(21517, ';', 21))))) {
                                                if (J$.C(2172, J$.C(2168, J$.U(2450, '!', J$.F(21533, J$.R(21525, 'match', match, false), false)(J$.T(21529, '}', 21)))) ? J$.B(2454, '!==', J$.G(21541, J$.R(21537, 'lookahead', lookahead, false), 'type'), J$.G(21549, J$.R(21545, 'Token', Token, false), 'EOF')) : J$._())) {
                                                    argument = J$.W(21561, 'argument', J$.F(21557, J$.R(21553, 'parseExpression', parseExpression, false), false)(), argument);
                                                }
                                            }
                                            J$.F(21569, J$.R(21565, 'consumeSemicolon', consumeSemicolon, false), false)();
                                            return J$.Rt(21585, J$.M(21581, J$.R(21573, 'delegate', delegate, false), 'createReturnStatement', false)(J$.R(21577, 'argument', argument, false)));
                                        } catch (J$e) {
                                            J$.Ex(29917, J$e);
                                        } finally {
                                            if (J$.Fr(29921))
                                                continue jalangiLabel127;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseWithStatement() {
                                jalangiLabel128:
                                    while (true) {
                                        try {
                                            J$.Fe(21705, arguments.callee, this);
                                            arguments = J$.N(21709, 'arguments', arguments, true);
                                            J$.N(21713, 'object', object, false);
                                            J$.N(21717, 'body', body, false);
                                            var object, body;
                                            if (J$.C(2180, J$.R(21601, 'strict', strict, false))) {
                                                J$.F(21621, J$.R(21605, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(21609, {}, 11), J$.G(21617, J$.R(21613, 'Messages', Messages, false), 'StrictModeWith'));
                                            }
                                            J$.F(21633, J$.R(21625, 'expectKeyword', expectKeyword, false), false)(J$.T(21629, 'with', 21));
                                            J$.F(21645, J$.R(21637, 'expect', expect, false), false)(J$.T(21641, '(', 21));
                                            object = J$.W(21657, 'object', J$.F(21653, J$.R(21649, 'parseExpression', parseExpression, false), false)(), object);
                                            J$.F(21669, J$.R(21661, 'expect', expect, false), false)(J$.T(21665, ')', 21));
                                            body = J$.W(21681, 'body', J$.F(21677, J$.R(21673, 'parseStatement', parseStatement, false), false)(), body);
                                            return J$.Rt(21701, J$.M(21697, J$.R(21685, 'delegate', delegate, false), 'createWithStatement', false)(J$.R(21689, 'object', object, false), J$.R(21693, 'body', body, false)));
                                        } catch (J$e) {
                                            J$.Ex(29925, J$e);
                                        } finally {
                                            if (J$.Fr(29929))
                                                continue jalangiLabel128;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseSwitchCase() {
                                jalangiLabel129:
                                    while (true) {
                                        try {
                                            J$.Fe(21905, arguments.callee, this);
                                            arguments = J$.N(21909, 'arguments', arguments, true);
                                            J$.N(21913, 'test', test, false);
                                            J$.N(21917, 'consequent', consequent, false);
                                            J$.N(21921, 'statement', statement, false);
                                            var test, consequent = J$.W(21725, 'consequent', J$.T(21721, [], 10), consequent), statement;
                                            J$.F(21733, J$.R(21729, 'skipComment', skipComment, false), false)();
                                            J$.M(21741, J$.R(21737, 'delegate', delegate, false), 'markStart', false)();
                                            if (J$.C(2184, J$.F(21753, J$.R(21745, 'matchKeyword', matchKeyword, false), false)(J$.T(21749, 'default', 21)))) {
                                                J$.F(21761, J$.R(21757, 'lex', lex, false), false)();
                                                test = J$.W(21769, 'test', J$.T(21765, null, 25), test);
                                            } else {
                                                J$.F(21781, J$.R(21773, 'expectKeyword', expectKeyword, false), false)(J$.T(21777, 'case', 21));
                                                test = J$.W(21793, 'test', J$.F(21789, J$.R(21785, 'parseExpression', parseExpression, false), false)(), test);
                                            }
                                            J$.F(21805, J$.R(21797, 'expect', expect, false), false)(J$.T(21801, ':', 21));
                                            while (J$.C(2200, J$.B(2458, '<', J$.R(21809, 'index', index, false), J$.R(21813, 'length', length, false)))) {
                                                if (J$.C(2196, J$.C(2192, J$.C(2188, J$.F(21825, J$.R(21817, 'match', match, false), false)(J$.T(21821, '}', 21))) ? J$._() : J$.F(21837, J$.R(21829, 'matchKeyword', matchKeyword, false), false)(J$.T(21833, 'default', 21))) ? J$._() : J$.F(21849, J$.R(21841, 'matchKeyword', matchKeyword, false), false)(J$.T(21845, 'case', 21)))) {
                                                    break;
                                                }
                                                statement = J$.W(21861, 'statement', J$.F(21857, J$.R(21853, 'parseStatement', parseStatement, false), false)(), statement);
                                                J$.M(21873, J$.R(21865, 'consequent', consequent, false), 'push', false)(J$.R(21869, 'statement', statement, false));
                                            }
                                            return J$.Rt(21901, J$.M(21897, J$.R(21877, 'delegate', delegate, false), 'markEnd', false)(J$.M(21893, J$.R(21881, 'delegate', delegate, false), 'createSwitchCase', false)(J$.R(21885, 'test', test, false), J$.R(21889, 'consequent', consequent, false))));
                                        } catch (J$e) {
                                            J$.Ex(29933, J$e);
                                        } finally {
                                            if (J$.Fr(29937))
                                                continue jalangiLabel129;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseSwitchStatement() {
                                jalangiLabel130:
                                    while (true) {
                                        try {
                                            J$.Fe(22197, arguments.callee, this);
                                            arguments = J$.N(22201, 'arguments', arguments, true);
                                            J$.N(22205, 'discriminant', discriminant, false);
                                            J$.N(22209, 'cases', cases, false);
                                            J$.N(22213, 'clause', clause, false);
                                            J$.N(22217, 'oldInSwitch', oldInSwitch, false);
                                            J$.N(22221, 'defaultFound', defaultFound, false);
                                            var discriminant, cases, clause, oldInSwitch, defaultFound;
                                            J$.F(21933, J$.R(21925, 'expectKeyword', expectKeyword, false), false)(J$.T(21929, 'switch', 21));
                                            J$.F(21945, J$.R(21937, 'expect', expect, false), false)(J$.T(21941, '(', 21));
                                            discriminant = J$.W(21957, 'discriminant', J$.F(21953, J$.R(21949, 'parseExpression', parseExpression, false), false)(), discriminant);
                                            J$.F(21969, J$.R(21961, 'expect', expect, false), false)(J$.T(21965, ')', 21));
                                            J$.F(21981, J$.R(21973, 'expect', expect, false), false)(J$.T(21977, '{', 21));
                                            cases = J$.W(21989, 'cases', J$.T(21985, [], 10), cases);
                                            if (J$.C(2204, J$.F(22001, J$.R(21993, 'match', match, false), false)(J$.T(21997, '}', 21)))) {
                                                J$.F(22009, J$.R(22005, 'lex', lex, false), false)();
                                                return J$.Rt(22029, J$.M(22025, J$.R(22013, 'delegate', delegate, false), 'createSwitchStatement', false)(J$.R(22017, 'discriminant', discriminant, false), J$.R(22021, 'cases', cases, false)));
                                            }
                                            oldInSwitch = J$.W(22041, 'oldInSwitch', J$.G(22037, J$.R(22033, 'state', state, false), 'inSwitch'), oldInSwitch);
                                            J$.P(22053, J$.R(22045, 'state', state, false), 'inSwitch', J$.T(22049, true, 23));
                                            defaultFound = J$.W(22061, 'defaultFound', J$.T(22057, false, 23), defaultFound);
                                            while (J$.C(2220, J$.B(2462, '<', J$.R(22065, 'index', index, false), J$.R(22069, 'length', length, false)))) {
                                                if (J$.C(2208, J$.F(22081, J$.R(22073, 'match', match, false), false)(J$.T(22077, '}', 21)))) {
                                                    break;
                                                }
                                                clause = J$.W(22093, 'clause', J$.F(22089, J$.R(22085, 'parseSwitchCase', parseSwitchCase, false), false)(), clause);
                                                if (J$.C(2216, J$.B(2466, '===', J$.G(22101, J$.R(22097, 'clause', clause, false), 'test'), J$.T(22105, null, 25)))) {
                                                    if (J$.C(2212, J$.R(22109, 'defaultFound', defaultFound, false))) {
                                                        J$.F(22129, J$.R(22113, 'throwError', throwError, false), false)(J$.T(22117, {}, 11), J$.G(22125, J$.R(22121, 'Messages', Messages, false), 'MultipleDefaultsInSwitch'));
                                                    }
                                                    defaultFound = J$.W(22137, 'defaultFound', J$.T(22133, true, 23), defaultFound);
                                                }
                                                J$.M(22149, J$.R(22141, 'cases', cases, false), 'push', false)(J$.R(22145, 'clause', clause, false));
                                            }
                                            J$.P(22161, J$.R(22153, 'state', state, false), 'inSwitch', J$.R(22157, 'oldInSwitch', oldInSwitch, false));
                                            J$.F(22173, J$.R(22165, 'expect', expect, false), false)(J$.T(22169, '}', 21));
                                            return J$.Rt(22193, J$.M(22189, J$.R(22177, 'delegate', delegate, false), 'createSwitchStatement', false)(J$.R(22181, 'discriminant', discriminant, false), J$.R(22185, 'cases', cases, false)));
                                        } catch (J$e) {
                                            J$.Ex(29941, J$e);
                                        } finally {
                                            if (J$.Fr(29945))
                                                continue jalangiLabel130;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseThrowStatement() {
                                jalangiLabel131:
                                    while (true) {
                                        try {
                                            J$.Fe(22301, arguments.callee, this);
                                            arguments = J$.N(22305, 'arguments', arguments, true);
                                            J$.N(22309, 'argument', argument, false);
                                            var argument;
                                            J$.F(22233, J$.R(22225, 'expectKeyword', expectKeyword, false), false)(J$.T(22229, 'throw', 21));
                                            if (J$.C(2224, J$.F(22241, J$.R(22237, 'peekLineTerminator', peekLineTerminator, false), false)())) {
                                                J$.F(22261, J$.R(22245, 'throwError', throwError, false), false)(J$.T(22249, {}, 11), J$.G(22257, J$.R(22253, 'Messages', Messages, false), 'NewlineAfterThrow'));
                                            }
                                            argument = J$.W(22273, 'argument', J$.F(22269, J$.R(22265, 'parseExpression', parseExpression, false), false)(), argument);
                                            J$.F(22281, J$.R(22277, 'consumeSemicolon', consumeSemicolon, false), false)();
                                            return J$.Rt(22297, J$.M(22293, J$.R(22285, 'delegate', delegate, false), 'createThrowStatement', false)(J$.R(22289, 'argument', argument, false)));
                                        } catch (J$e) {
                                            J$.Ex(29949, J$e);
                                        } finally {
                                            if (J$.Fr(29953))
                                                continue jalangiLabel131;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseCatchClause() {
                                jalangiLabel132:
                                    while (true) {
                                        try {
                                            J$.Fe(22481, arguments.callee, this);
                                            arguments = J$.N(22485, 'arguments', arguments, true);
                                            J$.N(22489, 'param', param, false);
                                            J$.N(22493, 'body', body, false);
                                            var param, body;
                                            J$.F(22317, J$.R(22313, 'skipComment', skipComment, false), false)();
                                            J$.M(22325, J$.R(22321, 'delegate', delegate, false), 'markStart', false)();
                                            J$.F(22337, J$.R(22329, 'expectKeyword', expectKeyword, false), false)(J$.T(22333, 'catch', 21));
                                            J$.F(22349, J$.R(22341, 'expect', expect, false), false)(J$.T(22345, '(', 21));
                                            if (J$.C(2228, J$.F(22361, J$.R(22353, 'match', match, false), false)(J$.T(22357, ')', 21)))) {
                                                J$.F(22373, J$.R(22365, 'throwUnexpected', throwUnexpected, false), false)(J$.R(22369, 'lookahead', lookahead, false));
                                            }
                                            param = J$.W(22385, 'param', J$.F(22381, J$.R(22377, 'parseVariableIdentifier', parseVariableIdentifier, false), false)(), param);
                                            if (J$.C(2236, J$.C(2232, J$.R(22389, 'strict', strict, false)) ? J$.F(22405, J$.R(22393, 'isRestrictedWord', isRestrictedWord, false), false)(J$.G(22401, J$.R(22397, 'param', param, false), 'name')) : J$._())) {
                                                J$.F(22425, J$.R(22409, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.T(22413, {}, 11), J$.G(22421, J$.R(22417, 'Messages', Messages, false), 'StrictCatchVariable'));
                                            }
                                            J$.F(22437, J$.R(22429, 'expect', expect, false), false)(J$.T(22433, ')', 21));
                                            body = J$.W(22449, 'body', J$.F(22445, J$.R(22441, 'parseBlock', parseBlock, false), false)(), body);
                                            return J$.Rt(22477, J$.M(22473, J$.R(22453, 'delegate', delegate, false), 'markEnd', false)(J$.M(22469, J$.R(22457, 'delegate', delegate, false), 'createCatchClause', false)(J$.R(22461, 'param', param, false), J$.R(22465, 'body', body, false))));
                                        } catch (J$e) {
                                            J$.Ex(29957, J$e);
                                        } finally {
                                            if (J$.Fr(29961))
                                                continue jalangiLabel132;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseTryStatement() {
                                jalangiLabel133:
                                    while (true) {
                                        try {
                                            J$.Fe(22661, arguments.callee, this);
                                            arguments = J$.N(22665, 'arguments', arguments, true);
                                            J$.N(22669, 'block', block, false);
                                            J$.N(22673, 'handlers', handlers, false);
                                            J$.N(22677, 'finalizer', finalizer, false);
                                            var block, handlers = J$.W(22505, 'handlers', J$.T(22497, [], 10), handlers), finalizer = J$.W(22509, 'finalizer', J$.T(22501, null, 25), finalizer);
                                            J$.F(22521, J$.R(22513, 'expectKeyword', expectKeyword, false), false)(J$.T(22517, 'try', 21));
                                            block = J$.W(22533, 'block', J$.F(22529, J$.R(22525, 'parseBlock', parseBlock, false), false)(), block);
                                            if (J$.C(2240, J$.F(22545, J$.R(22537, 'matchKeyword', matchKeyword, false), false)(J$.T(22541, 'catch', 21)))) {
                                                J$.M(22561, J$.R(22549, 'handlers', handlers, false), 'push', false)(J$.F(22557, J$.R(22553, 'parseCatchClause', parseCatchClause, false), false)());
                                            }
                                            if (J$.C(2244, J$.F(22573, J$.R(22565, 'matchKeyword', matchKeyword, false), false)(J$.T(22569, 'finally', 21)))) {
                                                J$.F(22581, J$.R(22577, 'lex', lex, false), false)();
                                                finalizer = J$.W(22593, 'finalizer', J$.F(22589, J$.R(22585, 'parseBlock', parseBlock, false), false)(), finalizer);
                                            }
                                            if (J$.C(2252, J$.C(2248, J$.B(2470, '===', J$.G(22601, J$.R(22597, 'handlers', handlers, false), 'length'), J$.T(22605, 0, 22))) ? J$.U(2474, '!', J$.R(22609, 'finalizer', finalizer, false)) : J$._())) {
                                                J$.F(22629, J$.R(22613, 'throwError', throwError, false), false)(J$.T(22617, {}, 11), J$.G(22625, J$.R(22621, 'Messages', Messages, false), 'NoCatchOrFinally'));
                                            }
                                            return J$.Rt(22657, J$.M(22653, J$.R(22633, 'delegate', delegate, false), 'createTryStatement', false)(J$.R(22637, 'block', block, false), J$.T(22641, [], 10), J$.R(22645, 'handlers', handlers, false), J$.R(22649, 'finalizer', finalizer, false)));
                                        } catch (J$e) {
                                            J$.Ex(29965, J$e);
                                        } finally {
                                            if (J$.Fr(29969))
                                                continue jalangiLabel133;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseDebuggerStatement() {
                                jalangiLabel134:
                                    while (true) {
                                        try {
                                            J$.Fe(22713, arguments.callee, this);
                                            arguments = J$.N(22717, 'arguments', arguments, true);
                                            J$.F(22689, J$.R(22681, 'expectKeyword', expectKeyword, false), false)(J$.T(22685, 'debugger', 21));
                                            J$.F(22697, J$.R(22693, 'consumeSemicolon', consumeSemicolon, false), false)();
                                            return J$.Rt(22709, J$.M(22705, J$.R(22701, 'delegate', delegate, false), 'createDebuggerStatement', false)());
                                        } catch (J$e) {
                                            J$.Ex(29973, J$e);
                                        } finally {
                                            if (J$.Fr(29977))
                                                continue jalangiLabel134;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseStatement() {
                                jalangiLabel135:
                                    while (true) {
                                        try {
                                            J$.Fe(23449, arguments.callee, this);
                                            arguments = J$.N(23453, 'arguments', arguments, true);
                                            J$.N(23457, 'type', type, false);
                                            J$.N(23461, 'expr', expr, false);
                                            J$.N(23465, 'labeledBody', labeledBody, false);
                                            J$.N(23469, 'key', key, false);
                                            var type = J$.W(22729, 'type', J$.G(22725, J$.R(22721, 'lookahead', lookahead, false), 'type'), type), expr, labeledBody, key;
                                            if (J$.C(2256, J$.B(2478, '===', J$.R(22733, 'type', type, false), J$.G(22741, J$.R(22737, 'Token', Token, false), 'EOF')))) {
                                                J$.F(22753, J$.R(22745, 'throwUnexpected', throwUnexpected, false), false)(J$.R(22749, 'lookahead', lookahead, false));
                                            }
                                            J$.F(22761, J$.R(22757, 'skipComment', skipComment, false), false)();
                                            J$.M(22769, J$.R(22765, 'delegate', delegate, false), 'markStart', false)();
                                            if (J$.C(2276, J$.B(2482, '===', J$.R(22773, 'type', type, false), J$.G(22781, J$.R(22777, 'Token', Token, false), 'Punctuator')))) {
                                                switch (J$.C1(2260, J$.G(22789, J$.R(22785, 'lookahead', lookahead, false), 'value'))) {
                                                case J$.C2(2264, J$.T(22813, ';', 21)):
                                                    return J$.Rt(22809, J$.M(22805, J$.R(22793, 'delegate', delegate, false), 'markEnd', false)(J$.F(22801, J$.R(22797, 'parseEmptyStatement', parseEmptyStatement, false), false)()));
                                                case J$.C2(2268, J$.T(22837, '{', 21)):
                                                    return J$.Rt(22833, J$.M(22829, J$.R(22817, 'delegate', delegate, false), 'markEnd', false)(J$.F(22825, J$.R(22821, 'parseBlock', parseBlock, false), false)()));
                                                case J$.C2(2272, J$.T(22861, '(', 21)):
                                                    return J$.Rt(22857, J$.M(22853, J$.R(22841, 'delegate', delegate, false), 'markEnd', false)(J$.F(22849, J$.R(22845, 'parseExpressionStatement', parseExpressionStatement, false), false)()));
                                                default:
                                                    break;
                                                }
                                            }
                                            if (J$.C(2340, J$.B(2486, '===', J$.R(22865, 'type', type, false), J$.G(22873, J$.R(22869, 'Token', Token, false), 'Keyword')))) {
                                                switch (J$.C1(2280, J$.G(22881, J$.R(22877, 'lookahead', lookahead, false), 'value'))) {
                                                case J$.C2(2284, J$.T(22905, 'break', 21)):
                                                    return J$.Rt(22901, J$.M(22897, J$.R(22885, 'delegate', delegate, false), 'markEnd', false)(J$.F(22893, J$.R(22889, 'parseBreakStatement', parseBreakStatement, false), false)()));
                                                case J$.C2(2288, J$.T(22929, 'continue', 21)):
                                                    return J$.Rt(22925, J$.M(22921, J$.R(22909, 'delegate', delegate, false), 'markEnd', false)(J$.F(22917, J$.R(22913, 'parseContinueStatement', parseContinueStatement, false), false)()));
                                                case J$.C2(2292, J$.T(22953, 'debugger', 21)):
                                                    return J$.Rt(22949, J$.M(22945, J$.R(22933, 'delegate', delegate, false), 'markEnd', false)(J$.F(22941, J$.R(22937, 'parseDebuggerStatement', parseDebuggerStatement, false), false)()));
                                                case J$.C2(2296, J$.T(22977, 'do', 21)):
                                                    return J$.Rt(22973, J$.M(22969, J$.R(22957, 'delegate', delegate, false), 'markEnd', false)(J$.F(22965, J$.R(22961, 'parseDoWhileStatement', parseDoWhileStatement, false), false)()));
                                                case J$.C2(2300, J$.T(23001, 'for', 21)):
                                                    return J$.Rt(22997, J$.M(22993, J$.R(22981, 'delegate', delegate, false), 'markEnd', false)(J$.F(22989, J$.R(22985, 'parseForStatement', parseForStatement, false), false)()));
                                                case J$.C2(2304, J$.T(23025, 'function', 21)):
                                                    return J$.Rt(23021, J$.M(23017, J$.R(23005, 'delegate', delegate, false), 'markEnd', false)(J$.F(23013, J$.R(23009, 'parseFunctionDeclaration', parseFunctionDeclaration, false), false)()));
                                                case J$.C2(2308, J$.T(23049, 'if', 21)):
                                                    return J$.Rt(23045, J$.M(23041, J$.R(23029, 'delegate', delegate, false), 'markEnd', false)(J$.F(23037, J$.R(23033, 'parseIfStatement', parseIfStatement, false), false)()));
                                                case J$.C2(2312, J$.T(23073, 'return', 21)):
                                                    return J$.Rt(23069, J$.M(23065, J$.R(23053, 'delegate', delegate, false), 'markEnd', false)(J$.F(23061, J$.R(23057, 'parseReturnStatement', parseReturnStatement, false), false)()));
                                                case J$.C2(2316, J$.T(23097, 'switch', 21)):
                                                    return J$.Rt(23093, J$.M(23089, J$.R(23077, 'delegate', delegate, false), 'markEnd', false)(J$.F(23085, J$.R(23081, 'parseSwitchStatement', parseSwitchStatement, false), false)()));
                                                case J$.C2(2320, J$.T(23121, 'throw', 21)):
                                                    return J$.Rt(23117, J$.M(23113, J$.R(23101, 'delegate', delegate, false), 'markEnd', false)(J$.F(23109, J$.R(23105, 'parseThrowStatement', parseThrowStatement, false), false)()));
                                                case J$.C2(2324, J$.T(23145, 'try', 21)):
                                                    return J$.Rt(23141, J$.M(23137, J$.R(23125, 'delegate', delegate, false), 'markEnd', false)(J$.F(23133, J$.R(23129, 'parseTryStatement', parseTryStatement, false), false)()));
                                                case J$.C2(2328, J$.T(23169, 'var', 21)):
                                                    return J$.Rt(23165, J$.M(23161, J$.R(23149, 'delegate', delegate, false), 'markEnd', false)(J$.F(23157, J$.R(23153, 'parseVariableStatement', parseVariableStatement, false), false)()));
                                                case J$.C2(2332, J$.T(23193, 'while', 21)):
                                                    return J$.Rt(23189, J$.M(23185, J$.R(23173, 'delegate', delegate, false), 'markEnd', false)(J$.F(23181, J$.R(23177, 'parseWhileStatement', parseWhileStatement, false), false)()));
                                                case J$.C2(2336, J$.T(23217, 'with', 21)):
                                                    return J$.Rt(23213, J$.M(23209, J$.R(23197, 'delegate', delegate, false), 'markEnd', false)(J$.F(23205, J$.R(23201, 'parseWithStatement', parseWithStatement, false), false)()));
                                                default:
                                                    break;
                                                }
                                            }
                                            expr = J$.W(23229, 'expr', J$.F(23225, J$.R(23221, 'parseExpression', parseExpression, false), false)(), expr);
                                            if (J$.C(2352, J$.C(2344, J$.B(2490, '===', J$.G(23237, J$.R(23233, 'expr', expr, false), 'type'), J$.G(23245, J$.R(23241, 'Syntax', Syntax, false), 'Identifier'))) ? J$.F(23257, J$.R(23249, 'match', match, false), false)(J$.T(23253, ':', 21)) : J$._())) {
                                                J$.F(23265, J$.R(23261, 'lex', lex, false), false)();
                                                key = J$.W(23281, 'key', J$.B(2494, '+', J$.T(23269, '$', 21), J$.G(23277, J$.R(23273, 'expr', expr, false), 'name')), key);
                                                if (J$.C(2348, J$.M(23309, J$.G(23293, J$.G(23289, J$.I(typeof Object === 'undefined' ? Object = J$.R(23285, 'Object', undefined, true) : Object = J$.R(23285, 'Object', Object, true)), 'prototype'), 'hasOwnProperty'), 'call', false)(J$.G(23301, J$.R(23297, 'state', state, false), 'labelSet'), J$.R(23305, 'key', key, false)))) {
                                                    J$.F(23341, J$.R(23313, 'throwError', throwError, false), false)(J$.T(23317, {}, 11), J$.G(23325, J$.R(23321, 'Messages', Messages, false), 'Redeclaration'), J$.T(23329, 'Label', 21), J$.G(23337, J$.R(23333, 'expr', expr, false), 'name'));
                                                }
                                                J$.P(23361, J$.G(23349, J$.R(23345, 'state', state, false), 'labelSet'), J$.R(23353, 'key', key, false), J$.T(23357, true, 23));
                                                labeledBody = J$.W(23373, 'labeledBody', J$.F(23369, J$.R(23365, 'parseStatement', parseStatement, false), false)(), labeledBody);
                                                delete J$.G(23381, J$.R(23377, 'state', state, false), 'labelSet')[J$.R(23385, 'key', key, false)];
                                                return J$.Rt(23413, J$.M(23409, J$.R(23389, 'delegate', delegate, false), 'markEnd', false)(J$.M(23405, J$.R(23393, 'delegate', delegate, false), 'createLabeledStatement', false)(J$.R(23397, 'expr', expr, false), J$.R(23401, 'labeledBody', labeledBody, false))));
                                            }
                                            J$.F(23421, J$.R(23417, 'consumeSemicolon', consumeSemicolon, false), false)();
                                            return J$.Rt(23445, J$.M(23441, J$.R(23425, 'delegate', delegate, false), 'markEnd', false)(J$.M(23437, J$.R(23429, 'delegate', delegate, false), 'createExpressionStatement', false)(J$.R(23433, 'expr', expr, false))));
                                        } catch (J$e) {
                                            J$.Ex(29981, J$e);
                                        } finally {
                                            if (J$.Fr(29985))
                                                continue jalangiLabel135;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseFunctionSourceElements() {
                                jalangiLabel136:
                                    while (true) {
                                        try {
                                            J$.Fe(23929, arguments.callee, this);
                                            arguments = J$.N(23933, 'arguments', arguments, true);
                                            J$.N(23937, 'sourceElement', sourceElement, false);
                                            J$.N(23941, 'sourceElements', sourceElements, false);
                                            J$.N(23945, 'token', token, false);
                                            J$.N(23949, 'directive', directive, false);
                                            J$.N(23953, 'firstRestricted', firstRestricted, false);
                                            J$.N(23957, 'oldLabelSet', oldLabelSet, false);
                                            J$.N(23961, 'oldInIteration', oldInIteration, false);
                                            J$.N(23965, 'oldInSwitch', oldInSwitch, false);
                                            J$.N(23969, 'oldInFunctionBody', oldInFunctionBody, false);
                                            var sourceElement, sourceElements = J$.W(23477, 'sourceElements', J$.T(23473, [], 10), sourceElements), token, directive, firstRestricted, oldLabelSet, oldInIteration, oldInSwitch, oldInFunctionBody;
                                            J$.F(23485, J$.R(23481, 'skipComment', skipComment, false), false)();
                                            J$.M(23493, J$.R(23489, 'delegate', delegate, false), 'markStart', false)();
                                            J$.F(23505, J$.R(23497, 'expect', expect, false), false)(J$.T(23501, '{', 21));
                                            while (J$.C(2380, J$.B(2498, '<', J$.R(23509, 'index', index, false), J$.R(23513, 'length', length, false)))) {
                                                if (J$.C(2356, J$.B(2502, '!==', J$.G(23521, J$.R(23517, 'lookahead', lookahead, false), 'type'), J$.G(23529, J$.R(23525, 'Token', Token, false), 'StringLiteral')))) {
                                                    break;
                                                }
                                                token = J$.W(23537, 'token', J$.R(23533, 'lookahead', lookahead, false), token);
                                                sourceElement = J$.W(23549, 'sourceElement', J$.F(23545, J$.R(23541, 'parseSourceElement', parseSourceElement, false), false)(), sourceElement);
                                                J$.M(23561, J$.R(23553, 'sourceElements', sourceElements, false), 'push', false)(J$.R(23557, 'sourceElement', sourceElement, false));
                                                if (J$.C(2360, J$.B(2506, '!==', J$.G(23573, J$.G(23569, J$.R(23565, 'sourceElement', sourceElement, false), 'expression'), 'type'), J$.G(23581, J$.R(23577, 'Syntax', Syntax, false), 'Literal')))) {
                                                    break;
                                                }
                                                directive = J$.W(23633, 'directive', J$.M(23629, J$.R(23585, 'source', source, false), 'slice', false)(J$.B(2510, '+', J$.G(23601, J$.G(23593, J$.R(23589, 'token', token, false), 'range'), J$.T(23597, 0, 22)), J$.T(23605, 1, 22)), J$.B(2514, '-', J$.G(23621, J$.G(23613, J$.R(23609, 'token', token, false), 'range'), J$.T(23617, 1, 22)), J$.T(23625, 1, 22))), directive);
                                                if (J$.C(2376, J$.B(2518, '===', J$.R(23637, 'directive', directive, false), J$.T(23641, 'use strict', 21)))) {
                                                    strict = J$.W(23649, 'strict', J$.T(23645, true, 23), strict);
                                                    if (J$.C(2364, J$.R(23653, 'firstRestricted', firstRestricted, false))) {
                                                        J$.F(23673, J$.R(23657, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.R(23661, 'firstRestricted', firstRestricted, false), J$.G(23669, J$.R(23665, 'Messages', Messages, false), 'StrictOctalLiteral'));
                                                    }
                                                } else {
                                                    if (J$.C(2372, J$.C(2368, J$.U(2522, '!', J$.R(23677, 'firstRestricted', firstRestricted, false))) ? J$.G(23685, J$.R(23681, 'token', token, false), 'octal') : J$._())) {
                                                        firstRestricted = J$.W(23693, 'firstRestricted', J$.R(23689, 'token', token, false), firstRestricted);
                                                    }
                                                }
                                            }
                                            oldLabelSet = J$.W(23705, 'oldLabelSet', J$.G(23701, J$.R(23697, 'state', state, false), 'labelSet'), oldLabelSet);
                                            oldInIteration = J$.W(23717, 'oldInIteration', J$.G(23713, J$.R(23709, 'state', state, false), 'inIteration'), oldInIteration);
                                            oldInSwitch = J$.W(23729, 'oldInSwitch', J$.G(23725, J$.R(23721, 'state', state, false), 'inSwitch'), oldInSwitch);
                                            oldInFunctionBody = J$.W(23741, 'oldInFunctionBody', J$.G(23737, J$.R(23733, 'state', state, false), 'inFunctionBody'), oldInFunctionBody);
                                            J$.P(23753, J$.R(23745, 'state', state, false), 'labelSet', J$.T(23749, {}, 11));
                                            J$.P(23765, J$.R(23757, 'state', state, false), 'inIteration', J$.T(23761, false, 23));
                                            J$.P(23777, J$.R(23769, 'state', state, false), 'inSwitch', J$.T(23773, false, 23));
                                            J$.P(23789, J$.R(23781, 'state', state, false), 'inFunctionBody', J$.T(23785, true, 23));
                                            while (J$.C(2392, J$.B(2526, '<', J$.R(23793, 'index', index, false), J$.R(23797, 'length', length, false)))) {
                                                if (J$.C(2384, J$.F(23809, J$.R(23801, 'match', match, false), false)(J$.T(23805, '}', 21)))) {
                                                    break;
                                                }
                                                sourceElement = J$.W(23821, 'sourceElement', J$.F(23817, J$.R(23813, 'parseSourceElement', parseSourceElement, false), false)(), sourceElement);
                                                if (J$.C(2388, J$.B(2534, '===', J$.U(2530, 'typeof', J$.R(23825, 'sourceElement', sourceElement, false)), J$.T(23829, 'undefined', 21)))) {
                                                    break;
                                                }
                                                J$.M(23841, J$.R(23833, 'sourceElements', sourceElements, false), 'push', false)(J$.R(23837, 'sourceElement', sourceElement, false));
                                            }
                                            J$.F(23853, J$.R(23845, 'expect', expect, false), false)(J$.T(23849, '}', 21));
                                            J$.P(23865, J$.R(23857, 'state', state, false), 'labelSet', J$.R(23861, 'oldLabelSet', oldLabelSet, false));
                                            J$.P(23877, J$.R(23869, 'state', state, false), 'inIteration', J$.R(23873, 'oldInIteration', oldInIteration, false));
                                            J$.P(23889, J$.R(23881, 'state', state, false), 'inSwitch', J$.R(23885, 'oldInSwitch', oldInSwitch, false));
                                            J$.P(23901, J$.R(23893, 'state', state, false), 'inFunctionBody', J$.R(23897, 'oldInFunctionBody', oldInFunctionBody, false));
                                            return J$.Rt(23925, J$.M(23921, J$.R(23905, 'delegate', delegate, false), 'markEnd', false)(J$.M(23917, J$.R(23909, 'delegate', delegate, false), 'createBlockStatement', false)(J$.R(23913, 'sourceElements', sourceElements, false))));
                                        } catch (J$e) {
                                            J$.Ex(29989, J$e);
                                        } finally {
                                            if (J$.Fr(29993))
                                                continue jalangiLabel136;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseParams(firstRestricted) {
                                jalangiLabel137:
                                    while (true) {
                                        try {
                                            J$.Fe(24349, arguments.callee, this);
                                            arguments = J$.N(24353, 'arguments', arguments, true);
                                            firstRestricted = J$.N(24357, 'firstRestricted', firstRestricted, true);
                                            J$.N(24361, 'param', param, false);
                                            J$.N(24365, 'params', params, false);
                                            J$.N(24369, 'token', token, false);
                                            J$.N(24373, 'stricted', stricted, false);
                                            J$.N(24377, 'paramSet', paramSet, false);
                                            J$.N(24381, 'key', key, false);
                                            J$.N(24385, 'message', message, false);
                                            var param, params = J$.W(23977, 'params', J$.T(23973, [], 10), params), token, stricted, paramSet, key, message;
                                            J$.F(23989, J$.R(23981, 'expect', expect, false), false)(J$.T(23985, '(', 21));
                                            if (J$.C(2432, J$.U(2538, '!', J$.F(24001, J$.R(23993, 'match', match, false), false)(J$.T(23997, ')', 21))))) {
                                                paramSet = J$.W(24009, 'paramSet', J$.T(24005, {}, 11), paramSet);
                                                while (J$.C(2428, J$.B(2542, '<', J$.R(24013, 'index', index, false), J$.R(24017, 'length', length, false)))) {
                                                    token = J$.W(24025, 'token', J$.R(24021, 'lookahead', lookahead, false), token);
                                                    param = J$.W(24037, 'param', J$.F(24033, J$.R(24029, 'parseVariableIdentifier', parseVariableIdentifier, false), false)(), param);
                                                    key = J$.W(24053, 'key', J$.B(2546, '+', J$.T(24041, '$', 21), J$.G(24049, J$.R(24045, 'token', token, false), 'value')), key);
                                                    if (J$.C(2420, J$.R(24057, 'strict', strict, false))) {
                                                        if (J$.C(2396, J$.F(24073, J$.R(24061, 'isRestrictedWord', isRestrictedWord, false), false)(J$.G(24069, J$.R(24065, 'token', token, false), 'value')))) {
                                                            stricted = J$.W(24081, 'stricted', J$.R(24077, 'token', token, false), stricted);
                                                            message = J$.W(24093, 'message', J$.G(24089, J$.R(24085, 'Messages', Messages, false), 'StrictParamName'), message);
                                                        }
                                                        if (J$.C(2400, J$.M(24117, J$.G(24105, J$.G(24101, J$.I(typeof Object === 'undefined' ? Object = J$.R(24097, 'Object', undefined, true) : Object = J$.R(24097, 'Object', Object, true)), 'prototype'), 'hasOwnProperty'), 'call', false)(J$.R(24109, 'paramSet', paramSet, false), J$.R(24113, 'key', key, false)))) {
                                                            stricted = J$.W(24125, 'stricted', J$.R(24121, 'token', token, false), stricted);
                                                            message = J$.W(24137, 'message', J$.G(24133, J$.R(24129, 'Messages', Messages, false), 'StrictParamDupe'), message);
                                                        }
                                                    } else if (J$.C(2416, J$.U(2550, '!', J$.R(24141, 'firstRestricted', firstRestricted, false)))) {
                                                        if (J$.C(2412, J$.F(24157, J$.R(24145, 'isRestrictedWord', isRestrictedWord, false), false)(J$.G(24153, J$.R(24149, 'token', token, false), 'value')))) {
                                                            firstRestricted = J$.W(24165, 'firstRestricted', J$.R(24161, 'token', token, false), firstRestricted);
                                                            message = J$.W(24177, 'message', J$.G(24173, J$.R(24169, 'Messages', Messages, false), 'StrictParamName'), message);
                                                        } else if (J$.C(2408, J$.F(24193, J$.R(24181, 'isStrictModeReservedWord', isStrictModeReservedWord, false), false)(J$.G(24189, J$.R(24185, 'token', token, false), 'value')))) {
                                                            firstRestricted = J$.W(24201, 'firstRestricted', J$.R(24197, 'token', token, false), firstRestricted);
                                                            message = J$.W(24213, 'message', J$.G(24209, J$.R(24205, 'Messages', Messages, false), 'StrictReservedWord'), message);
                                                        } else if (J$.C(2404, J$.M(24237, J$.G(24225, J$.G(24221, J$.I(typeof Object === 'undefined' ? Object = J$.R(24217, 'Object', undefined, true) : Object = J$.R(24217, 'Object', Object, true)), 'prototype'), 'hasOwnProperty'), 'call', false)(J$.R(24229, 'paramSet', paramSet, false), J$.R(24233, 'key', key, false)))) {
                                                            firstRestricted = J$.W(24245, 'firstRestricted', J$.R(24241, 'token', token, false), firstRestricted);
                                                            message = J$.W(24257, 'message', J$.G(24253, J$.R(24249, 'Messages', Messages, false), 'StrictParamDupe'), message);
                                                        }
                                                    }
                                                    J$.M(24269, J$.R(24261, 'params', params, false), 'push', false)(J$.R(24265, 'param', param, false));
                                                    J$.P(24285, J$.R(24273, 'paramSet', paramSet, false), J$.R(24277, 'key', key, false), J$.T(24281, true, 23));
                                                    if (J$.C(2424, J$.F(24297, J$.R(24289, 'match', match, false), false)(J$.T(24293, ')', 21)))) {
                                                        break;
                                                    }
                                                    J$.F(24309, J$.R(24301, 'expect', expect, false), false)(J$.T(24305, ',', 21));
                                                }
                                            }
                                            J$.F(24321, J$.R(24313, 'expect', expect, false), false)(J$.T(24317, ')', 21));
                                            return J$.Rt(24345, J$.T(24341, {
                                                params: J$.R(24325, 'params', params, false),
                                                stricted: J$.R(24329, 'stricted', stricted, false),
                                                firstRestricted: J$.R(24333, 'firstRestricted', firstRestricted, false),
                                                message: J$.R(24337, 'message', message, false)
                                            }, 11));
                                        } catch (J$e) {
                                            J$.Ex(29997, J$e);
                                        } finally {
                                            if (J$.Fr(30001))
                                                continue jalangiLabel137;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseFunctionDeclaration() {
                                jalangiLabel138:
                                    while (true) {
                                        try {
                                            J$.Fe(24741, arguments.callee, this);
                                            arguments = J$.N(24745, 'arguments', arguments, true);
                                            J$.N(24749, 'id', id, false);
                                            J$.N(24753, 'params', params, false);
                                            J$.N(24757, 'body', body, false);
                                            J$.N(24761, 'token', token, false);
                                            J$.N(24765, 'stricted', stricted, false);
                                            J$.N(24769, 'tmp', tmp, false);
                                            J$.N(24773, 'firstRestricted', firstRestricted, false);
                                            J$.N(24777, 'message', message, false);
                                            J$.N(24781, 'previousStrict', previousStrict, false);
                                            var id, params = J$.W(24393, 'params', J$.T(24389, [], 10), params), body, token, stricted, tmp, firstRestricted, message, previousStrict;
                                            J$.F(24401, J$.R(24397, 'skipComment', skipComment, false), false)();
                                            J$.M(24409, J$.R(24405, 'delegate', delegate, false), 'markStart', false)();
                                            J$.F(24421, J$.R(24413, 'expectKeyword', expectKeyword, false), false)(J$.T(24417, 'function', 21));
                                            token = J$.W(24429, 'token', J$.R(24425, 'lookahead', lookahead, false), token);
                                            id = J$.W(24441, 'id', J$.F(24437, J$.R(24433, 'parseVariableIdentifier', parseVariableIdentifier, false), false)(), id);
                                            if (J$.C(2448, J$.R(24445, 'strict', strict, false))) {
                                                if (J$.C(2436, J$.F(24461, J$.R(24449, 'isRestrictedWord', isRestrictedWord, false), false)(J$.G(24457, J$.R(24453, 'token', token, false), 'value')))) {
                                                    J$.F(24481, J$.R(24465, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.R(24469, 'token', token, false), J$.G(24477, J$.R(24473, 'Messages', Messages, false), 'StrictFunctionName'));
                                                }
                                            } else {
                                                if (J$.C(2444, J$.F(24497, J$.R(24485, 'isRestrictedWord', isRestrictedWord, false), false)(J$.G(24493, J$.R(24489, 'token', token, false), 'value')))) {
                                                    firstRestricted = J$.W(24505, 'firstRestricted', J$.R(24501, 'token', token, false), firstRestricted);
                                                    message = J$.W(24517, 'message', J$.G(24513, J$.R(24509, 'Messages', Messages, false), 'StrictFunctionName'), message);
                                                } else if (J$.C(2440, J$.F(24533, J$.R(24521, 'isStrictModeReservedWord', isStrictModeReservedWord, false), false)(J$.G(24529, J$.R(24525, 'token', token, false), 'value')))) {
                                                    firstRestricted = J$.W(24541, 'firstRestricted', J$.R(24537, 'token', token, false), firstRestricted);
                                                    message = J$.W(24553, 'message', J$.G(24549, J$.R(24545, 'Messages', Messages, false), 'StrictReservedWord'), message);
                                                }
                                            }
                                            tmp = J$.W(24569, 'tmp', J$.F(24565, J$.R(24557, 'parseParams', parseParams, false), false)(J$.R(24561, 'firstRestricted', firstRestricted, false)), tmp);
                                            params = J$.W(24581, 'params', J$.G(24577, J$.R(24573, 'tmp', tmp, false), 'params'), params);
                                            stricted = J$.W(24593, 'stricted', J$.G(24589, J$.R(24585, 'tmp', tmp, false), 'stricted'), stricted);
                                            firstRestricted = J$.W(24605, 'firstRestricted', J$.G(24601, J$.R(24597, 'tmp', tmp, false), 'firstRestricted'), firstRestricted);
                                            if (J$.C(2452, J$.G(24613, J$.R(24609, 'tmp', tmp, false), 'message'))) {
                                                message = J$.W(24625, 'message', J$.G(24621, J$.R(24617, 'tmp', tmp, false), 'message'), message);
                                            }
                                            previousStrict = J$.W(24633, 'previousStrict', J$.R(24629, 'strict', strict, false), previousStrict);
                                            body = J$.W(24645, 'body', J$.F(24641, J$.R(24637, 'parseFunctionSourceElements', parseFunctionSourceElements, false), false)(), body);
                                            if (J$.C(2460, J$.C(2456, J$.R(24649, 'strict', strict, false)) ? J$.R(24653, 'firstRestricted', firstRestricted, false) : J$._())) {
                                                J$.F(24669, J$.R(24657, 'throwError', throwError, false), false)(J$.R(24661, 'firstRestricted', firstRestricted, false), J$.R(24665, 'message', message, false));
                                            }
                                            if (J$.C(2468, J$.C(2464, J$.R(24673, 'strict', strict, false)) ? J$.R(24677, 'stricted', stricted, false) : J$._())) {
                                                J$.F(24693, J$.R(24681, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.R(24685, 'stricted', stricted, false), J$.R(24689, 'message', message, false));
                                            }
                                            strict = J$.W(24701, 'strict', J$.R(24697, 'previousStrict', previousStrict, false), strict);
                                            return J$.Rt(24737, J$.M(24733, J$.R(24705, 'delegate', delegate, false), 'markEnd', false)(J$.M(24729, J$.R(24709, 'delegate', delegate, false), 'createFunctionDeclaration', false)(J$.R(24713, 'id', id, false), J$.R(24717, 'params', params, false), J$.T(24721, [], 10), J$.R(24725, 'body', body, false))));
                                        } catch (J$e) {
                                            J$.Ex(30005, J$e);
                                        } finally {
                                            if (J$.Fr(30009))
                                                continue jalangiLabel138;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseFunctionExpression() {
                                jalangiLabel139:
                                    while (true) {
                                        try {
                                            J$.Fe(25149, arguments.callee, this);
                                            arguments = J$.N(25153, 'arguments', arguments, true);
                                            J$.N(25157, 'token', token, false);
                                            J$.N(25161, 'id', id, false);
                                            J$.N(25165, 'stricted', stricted, false);
                                            J$.N(25169, 'firstRestricted', firstRestricted, false);
                                            J$.N(25173, 'message', message, false);
                                            J$.N(25177, 'tmp', tmp, false);
                                            J$.N(25181, 'params', params, false);
                                            J$.N(25185, 'body', body, false);
                                            J$.N(25189, 'previousStrict', previousStrict, false);
                                            var token, id = J$.W(24793, 'id', J$.T(24785, null, 25), id), stricted, firstRestricted, message, tmp, params = J$.W(24797, 'params', J$.T(24789, [], 10), params), body, previousStrict;
                                            J$.M(24805, J$.R(24801, 'delegate', delegate, false), 'markStart', false)();
                                            J$.F(24817, J$.R(24809, 'expectKeyword', expectKeyword, false), false)(J$.T(24813, 'function', 21));
                                            if (J$.C(2488, J$.U(2554, '!', J$.F(24829, J$.R(24821, 'match', match, false), false)(J$.T(24825, '(', 21))))) {
                                                token = J$.W(24837, 'token', J$.R(24833, 'lookahead', lookahead, false), token);
                                                id = J$.W(24849, 'id', J$.F(24845, J$.R(24841, 'parseVariableIdentifier', parseVariableIdentifier, false), false)(), id);
                                                if (J$.C(2484, J$.R(24853, 'strict', strict, false))) {
                                                    if (J$.C(2472, J$.F(24869, J$.R(24857, 'isRestrictedWord', isRestrictedWord, false), false)(J$.G(24865, J$.R(24861, 'token', token, false), 'value')))) {
                                                        J$.F(24889, J$.R(24873, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.R(24877, 'token', token, false), J$.G(24885, J$.R(24881, 'Messages', Messages, false), 'StrictFunctionName'));
                                                    }
                                                } else {
                                                    if (J$.C(2480, J$.F(24905, J$.R(24893, 'isRestrictedWord', isRestrictedWord, false), false)(J$.G(24901, J$.R(24897, 'token', token, false), 'value')))) {
                                                        firstRestricted = J$.W(24913, 'firstRestricted', J$.R(24909, 'token', token, false), firstRestricted);
                                                        message = J$.W(24925, 'message', J$.G(24921, J$.R(24917, 'Messages', Messages, false), 'StrictFunctionName'), message);
                                                    } else if (J$.C(2476, J$.F(24941, J$.R(24929, 'isStrictModeReservedWord', isStrictModeReservedWord, false), false)(J$.G(24937, J$.R(24933, 'token', token, false), 'value')))) {
                                                        firstRestricted = J$.W(24949, 'firstRestricted', J$.R(24945, 'token', token, false), firstRestricted);
                                                        message = J$.W(24961, 'message', J$.G(24957, J$.R(24953, 'Messages', Messages, false), 'StrictReservedWord'), message);
                                                    }
                                                }
                                            }
                                            tmp = J$.W(24977, 'tmp', J$.F(24973, J$.R(24965, 'parseParams', parseParams, false), false)(J$.R(24969, 'firstRestricted', firstRestricted, false)), tmp);
                                            params = J$.W(24989, 'params', J$.G(24985, J$.R(24981, 'tmp', tmp, false), 'params'), params);
                                            stricted = J$.W(25001, 'stricted', J$.G(24997, J$.R(24993, 'tmp', tmp, false), 'stricted'), stricted);
                                            firstRestricted = J$.W(25013, 'firstRestricted', J$.G(25009, J$.R(25005, 'tmp', tmp, false), 'firstRestricted'), firstRestricted);
                                            if (J$.C(2492, J$.G(25021, J$.R(25017, 'tmp', tmp, false), 'message'))) {
                                                message = J$.W(25033, 'message', J$.G(25029, J$.R(25025, 'tmp', tmp, false), 'message'), message);
                                            }
                                            previousStrict = J$.W(25041, 'previousStrict', J$.R(25037, 'strict', strict, false), previousStrict);
                                            body = J$.W(25053, 'body', J$.F(25049, J$.R(25045, 'parseFunctionSourceElements', parseFunctionSourceElements, false), false)(), body);
                                            if (J$.C(2500, J$.C(2496, J$.R(25057, 'strict', strict, false)) ? J$.R(25061, 'firstRestricted', firstRestricted, false) : J$._())) {
                                                J$.F(25077, J$.R(25065, 'throwError', throwError, false), false)(J$.R(25069, 'firstRestricted', firstRestricted, false), J$.R(25073, 'message', message, false));
                                            }
                                            if (J$.C(2508, J$.C(2504, J$.R(25081, 'strict', strict, false)) ? J$.R(25085, 'stricted', stricted, false) : J$._())) {
                                                J$.F(25101, J$.R(25089, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.R(25093, 'stricted', stricted, false), J$.R(25097, 'message', message, false));
                                            }
                                            strict = J$.W(25109, 'strict', J$.R(25105, 'previousStrict', previousStrict, false), strict);
                                            return J$.Rt(25145, J$.M(25141, J$.R(25113, 'delegate', delegate, false), 'markEnd', false)(J$.M(25137, J$.R(25117, 'delegate', delegate, false), 'createFunctionExpression', false)(J$.R(25121, 'id', id, false), J$.R(25125, 'params', params, false), J$.T(25129, [], 10), J$.R(25133, 'body', body, false))));
                                        } catch (J$e) {
                                            J$.Ex(30013, J$e);
                                        } finally {
                                            if (J$.Fr(30017))
                                                continue jalangiLabel139;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseSourceElement() {
                                jalangiLabel140:
                                    while (true) {
                                        try {
                                            J$.Fe(25301, arguments.callee, this);
                                            arguments = J$.N(25305, 'arguments', arguments, true);
                                            if (J$.C(2528, J$.B(2558, '===', J$.G(25197, J$.R(25193, 'lookahead', lookahead, false), 'type'), J$.G(25205, J$.R(25201, 'Token', Token, false), 'Keyword')))) {
                                                switch (J$.C1(2512, J$.G(25213, J$.R(25209, 'lookahead', lookahead, false), 'value'))) {
                                                case J$.C2(2516, J$.T(25217, 'const', 21)):
                                                case J$.C2(2520, J$.T(25241, 'let', 21)):
                                                    return J$.Rt(25237, J$.F(25233, J$.R(25221, 'parseConstLetDeclaration', parseConstLetDeclaration, false), false)(J$.G(25229, J$.R(25225, 'lookahead', lookahead, false), 'value')));
                                                case J$.C2(2524, J$.T(25257, 'function', 21)):
                                                    return J$.Rt(25253, J$.F(25249, J$.R(25245, 'parseFunctionDeclaration', parseFunctionDeclaration, false), false)());
                                                default:
                                                    return J$.Rt(25269, J$.F(25265, J$.R(25261, 'parseStatement', parseStatement, false), false)());
                                                }
                                            }
                                            if (J$.C(2532, J$.B(2562, '!==', J$.G(25277, J$.R(25273, 'lookahead', lookahead, false), 'type'), J$.G(25285, J$.R(25281, 'Token', Token, false), 'EOF')))) {
                                                return J$.Rt(25297, J$.F(25293, J$.R(25289, 'parseStatement', parseStatement, false), false)());
                                            }
                                        } catch (J$e) {
                                            J$.Ex(30021, J$e);
                                        } finally {
                                            if (J$.Fr(30025))
                                                continue jalangiLabel140;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseSourceElements() {
                                jalangiLabel141:
                                    while (true) {
                                        try {
                                            J$.Fe(25553, arguments.callee, this);
                                            arguments = J$.N(25557, 'arguments', arguments, true);
                                            J$.N(25561, 'sourceElement', sourceElement, false);
                                            J$.N(25565, 'sourceElements', sourceElements, false);
                                            J$.N(25569, 'token', token, false);
                                            J$.N(25573, 'directive', directive, false);
                                            J$.N(25577, 'firstRestricted', firstRestricted, false);
                                            var sourceElement, sourceElements = J$.W(25313, 'sourceElements', J$.T(25309, [], 10), sourceElements), token, directive, firstRestricted;
                                            while (J$.C(2560, J$.B(2566, '<', J$.R(25317, 'index', index, false), J$.R(25321, 'length', length, false)))) {
                                                token = J$.W(25329, 'token', J$.R(25325, 'lookahead', lookahead, false), token);
                                                if (J$.C(2536, J$.B(2570, '!==', J$.G(25337, J$.R(25333, 'token', token, false), 'type'), J$.G(25345, J$.R(25341, 'Token', Token, false), 'StringLiteral')))) {
                                                    break;
                                                }
                                                sourceElement = J$.W(25357, 'sourceElement', J$.F(25353, J$.R(25349, 'parseSourceElement', parseSourceElement, false), false)(), sourceElement);
                                                J$.M(25369, J$.R(25361, 'sourceElements', sourceElements, false), 'push', false)(J$.R(25365, 'sourceElement', sourceElement, false));
                                                if (J$.C(2540, J$.B(2574, '!==', J$.G(25381, J$.G(25377, J$.R(25373, 'sourceElement', sourceElement, false), 'expression'), 'type'), J$.G(25389, J$.R(25385, 'Syntax', Syntax, false), 'Literal')))) {
                                                    break;
                                                }
                                                directive = J$.W(25441, 'directive', J$.M(25437, J$.R(25393, 'source', source, false), 'slice', false)(J$.B(2578, '+', J$.G(25409, J$.G(25401, J$.R(25397, 'token', token, false), 'range'), J$.T(25405, 0, 22)), J$.T(25413, 1, 22)), J$.B(2582, '-', J$.G(25429, J$.G(25421, J$.R(25417, 'token', token, false), 'range'), J$.T(25425, 1, 22)), J$.T(25433, 1, 22))), directive);
                                                if (J$.C(2556, J$.B(2586, '===', J$.R(25445, 'directive', directive, false), J$.T(25449, 'use strict', 21)))) {
                                                    strict = J$.W(25457, 'strict', J$.T(25453, true, 23), strict);
                                                    if (J$.C(2544, J$.R(25461, 'firstRestricted', firstRestricted, false))) {
                                                        J$.F(25481, J$.R(25465, 'throwErrorTolerant', throwErrorTolerant, false), false)(J$.R(25469, 'firstRestricted', firstRestricted, false), J$.G(25477, J$.R(25473, 'Messages', Messages, false), 'StrictOctalLiteral'));
                                                    }
                                                } else {
                                                    if (J$.C(2552, J$.C(2548, J$.U(2590, '!', J$.R(25485, 'firstRestricted', firstRestricted, false))) ? J$.G(25493, J$.R(25489, 'token', token, false), 'octal') : J$._())) {
                                                        firstRestricted = J$.W(25501, 'firstRestricted', J$.R(25497, 'token', token, false), firstRestricted);
                                                    }
                                                }
                                            }
                                            while (J$.C(2568, J$.B(2594, '<', J$.R(25505, 'index', index, false), J$.R(25509, 'length', length, false)))) {
                                                sourceElement = J$.W(25521, 'sourceElement', J$.F(25517, J$.R(25513, 'parseSourceElement', parseSourceElement, false), false)(), sourceElement);
                                                if (J$.C(2564, J$.B(2602, '===', J$.U(2598, 'typeof', J$.R(25525, 'sourceElement', sourceElement, false)), J$.T(25529, 'undefined', 21)))) {
                                                    break;
                                                }
                                                J$.M(25541, J$.R(25533, 'sourceElements', sourceElements, false), 'push', false)(J$.R(25537, 'sourceElement', sourceElement, false));
                                            }
                                            return J$.Rt(25549, J$.R(25545, 'sourceElements', sourceElements, false));
                                        } catch (J$e) {
                                            J$.Ex(30029, J$e);
                                        } finally {
                                            if (J$.Fr(30033))
                                                continue jalangiLabel141;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parseProgram() {
                                jalangiLabel142:
                                    while (true) {
                                        try {
                                            J$.Fe(25649, arguments.callee, this);
                                            arguments = J$.N(25653, 'arguments', arguments, true);
                                            J$.N(25657, 'body', body, false);
                                            var body;
                                            J$.F(25585, J$.R(25581, 'skipComment', skipComment, false), false)();
                                            J$.M(25593, J$.R(25589, 'delegate', delegate, false), 'markStart', false)();
                                            strict = J$.W(25601, 'strict', J$.T(25597, false, 23), strict);
                                            J$.F(25609, J$.R(25605, 'peek', peek, false), false)();
                                            body = J$.W(25621, 'body', J$.F(25617, J$.R(25613, 'parseSourceElements', parseSourceElements, false), false)(), body);
                                            return J$.Rt(25645, J$.M(25641, J$.R(25625, 'delegate', delegate, false), 'markEnd', false)(J$.M(25637, J$.R(25629, 'delegate', delegate, false), 'createProgram', false)(J$.R(25633, 'body', body, false))));
                                        } catch (J$e) {
                                            J$.Ex(30037, J$e);
                                        } finally {
                                            if (J$.Fr(30041))
                                                continue jalangiLabel142;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function attachComments() {
                                jalangiLabel143:
                                    while (true) {
                                        try {
                                            J$.Fe(25857, arguments.callee, this);
                                            arguments = J$.N(25861, 'arguments', arguments, true);
                                            J$.N(25865, 'i', i, false);
                                            J$.N(25869, 'attacher', attacher, false);
                                            J$.N(25873, 'comment', comment, false);
                                            J$.N(25877, 'leading', leading, false);
                                            J$.N(25881, 'trailing', trailing, false);
                                            var i, attacher, comment, leading, trailing;
                                            for (i = J$.W(25665, 'i', J$.T(25661, 0, 22), i); J$.C(2588, J$.B(2606, '<', J$.R(25669, 'i', i, false), J$.G(25681, J$.G(25677, J$.R(25673, 'extra', extra, false), 'pendingComments'), 'length'))); i = J$.W(25689, 'i', J$.B(2614, '+', J$.U(2610, '+', J$.R(25685, 'i', i, false)), 1), i)) {
                                                attacher = J$.W(25709, 'attacher', J$.G(25705, J$.G(25697, J$.R(25693, 'extra', extra, false), 'pendingComments'), J$.R(25701, 'i', i, false)), attacher);
                                                comment = J$.W(25721, 'comment', J$.G(25717, J$.R(25713, 'attacher', attacher, false), 'comment'), comment);
                                                leading = J$.W(25733, 'leading', J$.G(25729, J$.R(25725, 'attacher', attacher, false), 'leading'), leading);
                                                if (J$.C(2576, J$.R(25737, 'leading', leading, false))) {
                                                    if (J$.C(2572, J$.B(2622, '===', J$.U(2618, 'typeof', J$.G(25745, J$.R(25741, 'leading', leading, false), 'leadingComments')), J$.T(25749, 'undefined', 21)))) {
                                                        J$.P(25761, J$.R(25753, 'leading', leading, false), 'leadingComments', J$.T(25757, [], 10));
                                                    }
                                                    J$.M(25781, J$.G(25769, J$.R(25765, 'leading', leading, false), 'leadingComments'), 'push', false)(J$.G(25777, J$.R(25773, 'attacher', attacher, false), 'comment'));
                                                }
                                                trailing = J$.W(25793, 'trailing', J$.G(25789, J$.R(25785, 'attacher', attacher, false), 'trailing'), trailing);
                                                if (J$.C(2584, J$.R(25797, 'trailing', trailing, false))) {
                                                    if (J$.C(2580, J$.B(2630, '===', J$.U(2626, 'typeof', J$.G(25805, J$.R(25801, 'trailing', trailing, false), 'trailingComments')), J$.T(25809, 'undefined', 21)))) {
                                                        J$.P(25821, J$.R(25813, 'trailing', trailing, false), 'trailingComments', J$.T(25817, [], 10));
                                                    }
                                                    J$.M(25841, J$.G(25829, J$.R(25825, 'trailing', trailing, false), 'trailingComments'), 'push', false)(J$.G(25837, J$.R(25833, 'attacher', attacher, false), 'comment'));
                                                }
                                            }
                                            J$.P(25853, J$.R(25845, 'extra', extra, false), 'pendingComments', J$.T(25849, [], 10));
                                        } catch (J$e) {
                                            J$.Ex(30045, J$e);
                                        } finally {
                                            if (J$.Fr(30049))
                                                continue jalangiLabel143;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function filterTokenLocation() {
                                jalangiLabel144:
                                    while (true) {
                                        try {
                                            J$.Fe(26041, arguments.callee, this);
                                            arguments = J$.N(26045, 'arguments', arguments, true);
                                            J$.N(26049, 'i', i, false);
                                            J$.N(26053, 'entry', entry, false);
                                            J$.N(26057, 'token', token, false);
                                            J$.N(26061, 'tokens', tokens, false);
                                            var i, entry, token, tokens = J$.W(25889, 'tokens', J$.T(25885, [], 10), tokens);
                                            for (i = J$.W(25897, 'i', J$.T(25893, 0, 22), i); J$.C(2600, J$.B(2634, '<', J$.R(25901, 'i', i, false), J$.G(25913, J$.G(25909, J$.R(25905, 'extra', extra, false), 'tokens'), 'length'))); i = J$.W(25921, 'i', J$.B(2642, '+', J$.U(2638, '+', J$.R(25917, 'i', i, false)), 1), i)) {
                                                entry = J$.W(25941, 'entry', J$.G(25937, J$.G(25929, J$.R(25925, 'extra', extra, false), 'tokens'), J$.R(25933, 'i', i, false)), entry);
                                                token = J$.W(25965, 'token', J$.T(25961, {
                                                    type: J$.G(25949, J$.R(25945, 'entry', entry, false), 'type'),
                                                    value: J$.G(25957, J$.R(25953, 'entry', entry, false), 'value')
                                                }, 11), token);
                                                if (J$.C(2592, J$.G(25973, J$.R(25969, 'extra', extra, false), 'range'))) {
                                                    J$.P(25989, J$.R(25977, 'token', token, false), 'range', J$.G(25985, J$.R(25981, 'entry', entry, false), 'range'));
                                                }
                                                if (J$.C(2596, J$.G(25997, J$.R(25993, 'extra', extra, false), 'loc'))) {
                                                    J$.P(26013, J$.R(26001, 'token', token, false), 'loc', J$.G(26009, J$.R(26005, 'entry', entry, false), 'loc'));
                                                }
                                                J$.M(26025, J$.R(26017, 'tokens', tokens, false), 'push', false)(J$.R(26021, 'token', token, false));
                                            }
                                            J$.P(26037, J$.R(26029, 'extra', extra, false), 'tokens', J$.R(26033, 'tokens', tokens, false));
                                        } catch (J$e) {
                                            J$.Ex(30053, J$e);
                                        } finally {
                                            if (J$.Fr(30057))
                                                continue jalangiLabel144;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function LocationMarker() {
                                jalangiLabel145:
                                    while (true) {
                                        try {
                                            J$.Fe(26105, arguments.callee, this);
                                            arguments = J$.N(26109, 'arguments', arguments, true);
                                            J$.P(26101, J$.R(26065, 'this', this, false), 'marker', J$.T(26097, [
                                                J$.R(26069, 'index', index, false),
                                                J$.R(26073, 'lineNumber', lineNumber, false),
                                                J$.B(2646, '-', J$.R(26077, 'index', index, false), J$.R(26081, 'lineStart', lineStart, false)),
                                                J$.T(26085, 0, 22),
                                                J$.T(26089, 0, 22),
                                                J$.T(26093, 0, 22)
                                            ], 10));
                                        } catch (J$e) {
                                            J$.Ex(30061, J$e);
                                        } finally {
                                            if (J$.Fr(30065))
                                                continue jalangiLabel145;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            J$.P(26397, J$.R(26113, 'LocationMarker', LocationMarker, false), 'prototype', J$.T(26393, {
                                constructor: J$.R(26117, 'LocationMarker', LocationMarker, false),
                                end: J$.T(26193, function () {
                                    jalangiLabel146:
                                        while (true) {
                                            try {
                                                J$.Fe(26185, arguments.callee, this);
                                                arguments = J$.N(26189, 'arguments', arguments, true);
                                                J$.P(26137, J$.G(26125, J$.R(26121, 'this', this, false), 'marker'), J$.T(26129, 3, 22), J$.R(26133, 'index', index, false));
                                                J$.P(26157, J$.G(26145, J$.R(26141, 'this', this, false), 'marker'), J$.T(26149, 4, 22), J$.R(26153, 'lineNumber', lineNumber, false));
                                                J$.P(26181, J$.G(26165, J$.R(26161, 'this', this, false), 'marker'), J$.T(26169, 5, 22), J$.B(2650, '-', J$.R(26173, 'index', index, false), J$.R(26177, 'lineStart', lineStart, false)));
                                            } catch (J$e) {
                                                J$.Ex(30069, J$e);
                                            } finally {
                                                if (J$.Fr(30073))
                                                    continue jalangiLabel146;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12),
                                apply: J$.T(26389, function (node) {
                                    jalangiLabel147:
                                        while (true) {
                                            try {
                                                J$.Fe(26377, arguments.callee, this);
                                                arguments = J$.N(26381, 'arguments', arguments, true);
                                                node = J$.N(26385, 'node', node, true);
                                                if (J$.C(2604, J$.G(26201, J$.R(26197, 'extra', extra, false), 'range'))) {
                                                    J$.P(26245, J$.R(26205, 'node', node, false), 'range', J$.T(26241, [
                                                        J$.G(26221, J$.G(26213, J$.R(26209, 'this', this, false), 'marker'), J$.T(26217, 0, 22)),
                                                        J$.G(26237, J$.G(26229, J$.R(26225, 'this', this, false), 'marker'), J$.T(26233, 3, 22))
                                                    ], 10));
                                                }
                                                if (J$.C(2608, J$.G(26253, J$.R(26249, 'extra', extra, false), 'loc'))) {
                                                    J$.P(26337, J$.R(26257, 'node', node, false), 'loc', J$.T(26333, {
                                                        start: J$.T(26293, {
                                                            line: J$.G(26273, J$.G(26265, J$.R(26261, 'this', this, false), 'marker'), J$.T(26269, 1, 22)),
                                                            column: J$.G(26289, J$.G(26281, J$.R(26277, 'this', this, false), 'marker'), J$.T(26285, 2, 22))
                                                        }, 11),
                                                        end: J$.T(26329, {
                                                            line: J$.G(26309, J$.G(26301, J$.R(26297, 'this', this, false), 'marker'), J$.T(26305, 4, 22)),
                                                            column: J$.G(26325, J$.G(26317, J$.R(26313, 'this', this, false), 'marker'), J$.T(26321, 5, 22))
                                                        }, 11)
                                                    }, 11));
                                                    node = J$.W(26353, 'node', J$.M(26349, J$.R(26341, 'delegate', delegate, false), 'postProcess', false)(J$.R(26345, 'node', node, false)), node);
                                                }
                                                if (J$.C(2612, J$.G(26361, J$.R(26357, 'extra', extra, false), 'attachComment'))) {
                                                    J$.M(26373, J$.R(26365, 'delegate', delegate, false), 'processComment', false)(J$.R(26369, 'node', node, false));
                                                }
                                            } catch (J$e) {
                                                J$.Ex(30077, J$e);
                                            } finally {
                                                if (J$.Fr(30081))
                                                    continue jalangiLabel147;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12)
                            }, 11));
                            function createLocationMarker() {
                                jalangiLabel148:
                                    while (true) {
                                        try {
                                            J$.Fe(26449, arguments.callee, this);
                                            arguments = J$.N(26453, 'arguments', arguments, true);
                                            if (J$.C(2620, J$.C(2616, J$.U(2654, '!', J$.G(26405, J$.R(26401, 'extra', extra, false), 'loc'))) ? J$.U(2658, '!', J$.G(26413, J$.R(26409, 'extra', extra, false), 'range')) : J$._())) {
                                                return J$.Rt(26421, J$.T(26417, null, 25));
                                            }
                                            J$.F(26429, J$.R(26425, 'skipComment', skipComment, false), false)();
                                            return J$.Rt(26445, J$.T(26441, J$.F(26437, J$.R(26433, 'LocationMarker', LocationMarker, false), true)(), 11));
                                        } catch (J$e) {
                                            J$.Ex(30085, J$e);
                                        } finally {
                                            if (J$.Fr(30089))
                                                continue jalangiLabel148;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function tokenize(code, options) {
                                jalangiLabel149:
                                    while (true) {
                                        try {
                                            J$.Fe(27057, arguments.callee, this);
                                            arguments = J$.N(27061, 'arguments', arguments, true);
                                            code = J$.N(27065, 'code', code, true);
                                            options = J$.N(27069, 'options', options, true);
                                            J$.N(27073, 'toString', toString, false);
                                            J$.N(27077, 'token', token, false);
                                            J$.N(27081, 'tokens', tokens, false);
                                            var toString, token, tokens;
                                            toString = J$.W(26461, 'toString', J$.I(typeof String === 'undefined' ? String = J$.R(26457, 'String', undefined, true) : String = J$.R(26457, 'String', String, true)), toString);
                                            if (J$.C(2628, J$.C(2624, J$.B(2666, '!==', J$.U(2662, 'typeof', J$.R(26465, 'code', code, false)), J$.T(26469, 'string', 21))) ? J$.U(2674, '!', J$.B(2670, 'instanceof', J$.R(26473, 'code', code, false), J$.I(typeof String === 'undefined' ? String = J$.R(26477, 'String', undefined, true) : String = J$.R(26477, 'String', String, true)))) : J$._())) {
                                                code = J$.W(26493, 'code', J$.F(26489, J$.R(26481, 'toString', toString, false), false)(J$.R(26485, 'code', code, false)), code);
                                            }
                                            delegate = J$.W(26501, 'delegate', J$.R(26497, 'SyntaxTreeDelegate', SyntaxTreeDelegate, false), delegate);
                                            source = J$.W(26509, 'source', J$.R(26505, 'code', code, false), source);
                                            index = J$.W(26517, 'index', J$.T(26513, 0, 22), index);
                                            lineNumber = J$.W(26541, 'lineNumber', J$.C(2632, J$.B(2678, '>', J$.G(26525, J$.R(26521, 'source', source, false), 'length'), J$.T(26529, 0, 22))) ? J$.T(26533, 1, 22) : J$.T(26537, 0, 22), lineNumber);
                                            lineStart = J$.W(26549, 'lineStart', J$.T(26545, 0, 22), lineStart);
                                            length = J$.W(26561, 'length', J$.G(26557, J$.R(26553, 'source', source, false), 'length'), length);
                                            lookahead = J$.W(26569, 'lookahead', J$.T(26565, null, 25), lookahead);
                                            state = J$.W(26601, 'state', J$.T(26597, {
                                                allowIn: J$.T(26573, true, 23),
                                                labelSet: J$.T(26577, {}, 11),
                                                inFunctionBody: J$.T(26581, false, 23),
                                                inIteration: J$.T(26585, false, 23),
                                                inSwitch: J$.T(26589, false, 23),
                                                lastCommentStart: J$.U(2682, '-', J$.T(26593, 1, 22))
                                            }, 11), state);
                                            extra = J$.W(26609, 'extra', J$.T(26605, {}, 11), extra);
                                            options = J$.W(26621, 'options', J$.C(2636, J$.R(26613, 'options', options, false)) ? J$._() : J$.T(26617, {}, 11), options);
                                            J$.P(26633, J$.R(26625, 'options', options, false), 'tokens', J$.T(26629, true, 23));
                                            J$.P(26645, J$.R(26637, 'extra', extra, false), 'tokens', J$.T(26641, [], 10));
                                            J$.P(26657, J$.R(26649, 'extra', extra, false), 'tokenize', J$.T(26653, true, 23));
                                            J$.P(26669, J$.R(26661, 'extra', extra, false), 'openParenToken', J$.U(2686, '-', J$.T(26665, 1, 22)));
                                            J$.P(26681, J$.R(26673, 'extra', extra, false), 'openCurlyToken', J$.U(2690, '-', J$.T(26677, 1, 22)));
                                            J$.P(26709, J$.R(26685, 'extra', extra, false), 'range', J$.C(2640, J$.B(2698, '===', J$.U(2694, 'typeof', J$.G(26693, J$.R(26689, 'options', options, false), 'range')), J$.T(26697, 'boolean', 21))) ? J$.G(26705, J$.R(26701, 'options', options, false), 'range') : J$._());
                                            J$.P(26737, J$.R(26713, 'extra', extra, false), 'loc', J$.C(2644, J$.B(2706, '===', J$.U(2702, 'typeof', J$.G(26721, J$.R(26717, 'options', options, false), 'loc')), J$.T(26725, 'boolean', 21))) ? J$.G(26733, J$.R(26729, 'options', options, false), 'loc') : J$._());
                                            if (J$.C(2652, J$.C(2648, J$.B(2714, '===', J$.U(2710, 'typeof', J$.G(26745, J$.R(26741, 'options', options, false), 'comment')), J$.T(26749, 'boolean', 21))) ? J$.G(26757, J$.R(26753, 'options', options, false), 'comment') : J$._())) {
                                                J$.P(26769, J$.R(26761, 'extra', extra, false), 'comments', J$.T(26765, [], 10));
                                            }
                                            if (J$.C(2660, J$.C(2656, J$.B(2722, '===', J$.U(2718, 'typeof', J$.G(26777, J$.R(26773, 'options', options, false), 'tolerant')), J$.T(26781, 'boolean', 21))) ? J$.G(26789, J$.R(26785, 'options', options, false), 'tolerant') : J$._())) {
                                                J$.P(26801, J$.R(26793, 'extra', extra, false), 'errors', J$.T(26797, [], 10));
                                            }
                                            if (J$.C(2672, J$.B(2726, '>', J$.R(26805, 'length', length, false), J$.T(26809, 0, 22)))) {
                                                if (J$.C(2668, J$.B(2734, '===', J$.U(2730, 'typeof', J$.G(26821, J$.R(26813, 'source', source, false), J$.T(26817, 0, 22))), J$.T(26825, 'undefined', 21)))) {
                                                    if (J$.C(2664, J$.B(2738, 'instanceof', J$.R(26829, 'code', code, false), J$.I(typeof String === 'undefined' ? String = J$.R(26833, 'String', undefined, true) : String = J$.R(26833, 'String', String, true))))) {
                                                        source = J$.W(26845, 'source', J$.M(26841, J$.R(26837, 'code', code, false), 'valueOf', false)(), source);
                                                    }
                                                }
                                            }
                                            try {
                                                J$.F(26853, J$.R(26849, 'peek', peek, false), false)();
                                                if (J$.C(2676, J$.B(2742, '===', J$.G(26861, J$.R(26857, 'lookahead', lookahead, false), 'type'), J$.G(26869, J$.R(26865, 'Token', Token, false), 'EOF')))) {
                                                    return J$.Rt(26881, J$.G(26877, J$.R(26873, 'extra', extra, false), 'tokens'));
                                                }
                                                token = J$.W(26893, 'token', J$.F(26889, J$.R(26885, 'lex', lex, false), false)(), token);
                                                while (J$.C(2684, J$.B(2746, '!==', J$.G(26901, J$.R(26897, 'lookahead', lookahead, false), 'type'), J$.G(26909, J$.R(26905, 'Token', Token, false), 'EOF')))) {
                                                    try {
                                                        token = J$.W(26921, 'token', J$.F(26917, J$.R(26913, 'lex', lex, false), false)(), token);
                                                    } catch (lexError) {
                                                        token = J$.W(26929, 'token', J$.R(26925, 'lookahead', lookahead, false), token);
                                                        if (J$.C(2680, J$.G(26937, J$.R(26933, 'extra', extra, false), 'errors'))) {
                                                            J$.M(26953, J$.G(26945, J$.R(26941, 'extra', extra, false), 'errors'), 'push', false)(J$.R(26949, 'lexError', lexError, false));
                                                            break;
                                                        } else {
                                                            throw J$.R(26957, 'lexError', lexError, false);
                                                        }
                                                    }
                                                }
                                                J$.F(26965, J$.R(26961, 'filterTokenLocation', filterTokenLocation, false), false)();
                                                tokens = J$.W(26977, 'tokens', J$.G(26973, J$.R(26969, 'extra', extra, false), 'tokens'), tokens);
                                                if (J$.C(2688, J$.B(2754, '!==', J$.U(2750, 'typeof', J$.G(26985, J$.R(26981, 'extra', extra, false), 'comments')), J$.T(26989, 'undefined', 21)))) {
                                                    J$.P(27005, J$.R(26993, 'tokens', tokens, false), 'comments', J$.G(27001, J$.R(26997, 'extra', extra, false), 'comments'));
                                                }
                                                if (J$.C(2692, J$.B(2762, '!==', J$.U(2758, 'typeof', J$.G(27013, J$.R(27009, 'extra', extra, false), 'errors')), J$.T(27017, 'undefined', 21)))) {
                                                    J$.P(27033, J$.R(27021, 'tokens', tokens, false), 'errors', J$.G(27029, J$.R(27025, 'extra', extra, false), 'errors'));
                                                }
                                            } catch (e) {
                                                throw J$.R(27037, 'e', e, false);
                                            } finally {
                                                extra = J$.W(27045, 'extra', J$.T(27041, {}, 11), extra);
                                            }
                                            return J$.Rt(27053, J$.R(27049, 'tokens', tokens, false));
                                        } catch (J$e) {
                                            J$.Ex(30093, J$e);
                                        } finally {
                                            if (J$.Fr(30097))
                                                continue jalangiLabel149;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            function parse(code, options) {
                                jalangiLabel150:
                                    while (true) {
                                        try {
                                            J$.Fe(27717, arguments.callee, this);
                                            arguments = J$.N(27721, 'arguments', arguments, true);
                                            code = J$.N(27725, 'code', code, true);
                                            options = J$.N(27729, 'options', options, true);
                                            J$.N(27733, 'program', program, false);
                                            J$.N(27737, 'toString', toString, false);
                                            var program, toString;
                                            toString = J$.W(27089, 'toString', J$.I(typeof String === 'undefined' ? String = J$.R(27085, 'String', undefined, true) : String = J$.R(27085, 'String', String, true)), toString);
                                            if (J$.C(2700, J$.C(2696, J$.B(2770, '!==', J$.U(2766, 'typeof', J$.R(27093, 'code', code, false)), J$.T(27097, 'string', 21))) ? J$.U(2778, '!', J$.B(2774, 'instanceof', J$.R(27101, 'code', code, false), J$.I(typeof String === 'undefined' ? String = J$.R(27105, 'String', undefined, true) : String = J$.R(27105, 'String', String, true)))) : J$._())) {
                                                code = J$.W(27121, 'code', J$.F(27117, J$.R(27109, 'toString', toString, false), false)(J$.R(27113, 'code', code, false)), code);
                                            }
                                            delegate = J$.W(27129, 'delegate', J$.R(27125, 'SyntaxTreeDelegate', SyntaxTreeDelegate, false), delegate);
                                            source = J$.W(27137, 'source', J$.R(27133, 'code', code, false), source);
                                            index = J$.W(27145, 'index', J$.T(27141, 0, 22), index);
                                            lineNumber = J$.W(27169, 'lineNumber', J$.C(2704, J$.B(2782, '>', J$.G(27153, J$.R(27149, 'source', source, false), 'length'), J$.T(27157, 0, 22))) ? J$.T(27161, 1, 22) : J$.T(27165, 0, 22), lineNumber);
                                            lineStart = J$.W(27177, 'lineStart', J$.T(27173, 0, 22), lineStart);
                                            length = J$.W(27189, 'length', J$.G(27185, J$.R(27181, 'source', source, false), 'length'), length);
                                            lookahead = J$.W(27197, 'lookahead', J$.T(27193, null, 25), lookahead);
                                            state = J$.W(27233, 'state', J$.T(27229, {
                                                allowIn: J$.T(27201, true, 23),
                                                labelSet: J$.T(27205, {}, 11),
                                                inFunctionBody: J$.T(27209, false, 23),
                                                inIteration: J$.T(27213, false, 23),
                                                inSwitch: J$.T(27217, false, 23),
                                                lastCommentStart: J$.U(2786, '-', J$.T(27221, 1, 22)),
                                                markerStack: J$.T(27225, [], 10)
                                            }, 11), state);
                                            extra = J$.W(27241, 'extra', J$.T(27237, {}, 11), extra);
                                            if (J$.C(2760, J$.B(2794, '!==', J$.U(2790, 'typeof', J$.R(27245, 'options', options, false)), J$.T(27249, 'undefined', 21)))) {
                                                J$.P(27277, J$.R(27253, 'extra', extra, false), 'range', J$.C(2708, J$.B(2802, '===', J$.U(2798, 'typeof', J$.G(27261, J$.R(27257, 'options', options, false), 'range')), J$.T(27265, 'boolean', 21))) ? J$.G(27273, J$.R(27269, 'options', options, false), 'range') : J$._());
                                                J$.P(27305, J$.R(27281, 'extra', extra, false), 'loc', J$.C(2712, J$.B(2810, '===', J$.U(2806, 'typeof', J$.G(27289, J$.R(27285, 'options', options, false), 'loc')), J$.T(27293, 'boolean', 21))) ? J$.G(27301, J$.R(27297, 'options', options, false), 'loc') : J$._());
                                                J$.P(27333, J$.R(27309, 'extra', extra, false), 'attachComment', J$.C(2716, J$.B(2818, '===', J$.U(2814, 'typeof', J$.G(27317, J$.R(27313, 'options', options, false), 'attachComment')), J$.T(27321, 'boolean', 21))) ? J$.G(27329, J$.R(27325, 'options', options, false), 'attachComment') : J$._());
                                                if (J$.C(2728, J$.C(2724, J$.C(2720, J$.G(27341, J$.R(27337, 'extra', extra, false), 'loc')) ? J$.B(2822, '!==', J$.G(27349, J$.R(27345, 'options', options, false), 'source'), J$.T(27353, null, 25)) : J$._()) ? J$.B(2826, '!==', J$.G(27361, J$.R(27357, 'options', options, false), 'source'), J$.T(27365, undefined, 24)) : J$._())) {
                                                    J$.P(27389, J$.R(27369, 'extra', extra, false), 'source', J$.F(27385, J$.R(27373, 'toString', toString, false), false)(J$.G(27381, J$.R(27377, 'options', options, false), 'source')));
                                                }
                                                if (J$.C(2736, J$.C(2732, J$.B(2834, '===', J$.U(2830, 'typeof', J$.G(27397, J$.R(27393, 'options', options, false), 'tokens')), J$.T(27401, 'boolean', 21))) ? J$.G(27409, J$.R(27405, 'options', options, false), 'tokens') : J$._())) {
                                                    J$.P(27421, J$.R(27413, 'extra', extra, false), 'tokens', J$.T(27417, [], 10));
                                                }
                                                if (J$.C(2744, J$.C(2740, J$.B(2842, '===', J$.U(2838, 'typeof', J$.G(27429, J$.R(27425, 'options', options, false), 'comment')), J$.T(27433, 'boolean', 21))) ? J$.G(27441, J$.R(27437, 'options', options, false), 'comment') : J$._())) {
                                                    J$.P(27453, J$.R(27445, 'extra', extra, false), 'comments', J$.T(27449, [], 10));
                                                }
                                                if (J$.C(2752, J$.C(2748, J$.B(2850, '===', J$.U(2846, 'typeof', J$.G(27461, J$.R(27457, 'options', options, false), 'tolerant')), J$.T(27465, 'boolean', 21))) ? J$.G(27473, J$.R(27469, 'options', options, false), 'tolerant') : J$._())) {
                                                    J$.P(27485, J$.R(27477, 'extra', extra, false), 'errors', J$.T(27481, [], 10));
                                                }
                                                if (J$.C(2756, J$.G(27493, J$.R(27489, 'extra', extra, false), 'attachComment'))) {
                                                    J$.P(27505, J$.R(27497, 'extra', extra, false), 'range', J$.T(27501, true, 23));
                                                    J$.P(27517, J$.R(27509, 'extra', extra, false), 'pendingComments', J$.T(27513, [], 10));
                                                    J$.P(27529, J$.R(27521, 'extra', extra, false), 'comments', J$.T(27525, [], 10));
                                                }
                                            }
                                            if (J$.C(2772, J$.B(2854, '>', J$.R(27533, 'length', length, false), J$.T(27537, 0, 22)))) {
                                                if (J$.C(2768, J$.B(2862, '===', J$.U(2858, 'typeof', J$.G(27549, J$.R(27541, 'source', source, false), J$.T(27545, 0, 22))), J$.T(27553, 'undefined', 21)))) {
                                                    if (J$.C(2764, J$.B(2866, 'instanceof', J$.R(27557, 'code', code, false), J$.I(typeof String === 'undefined' ? String = J$.R(27561, 'String', undefined, true) : String = J$.R(27561, 'String', String, true))))) {
                                                        source = J$.W(27573, 'source', J$.M(27569, J$.R(27565, 'code', code, false), 'valueOf', false)(), source);
                                                    }
                                                }
                                            }
                                            try {
                                                program = J$.W(27585, 'program', J$.F(27581, J$.R(27577, 'parseProgram', parseProgram, false), false)(), program);
                                                if (J$.C(2776, J$.B(2874, '!==', J$.U(2870, 'typeof', J$.G(27593, J$.R(27589, 'extra', extra, false), 'comments')), J$.T(27597, 'undefined', 21)))) {
                                                    J$.P(27613, J$.R(27601, 'program', program, false), 'comments', J$.G(27609, J$.R(27605, 'extra', extra, false), 'comments'));
                                                }
                                                if (J$.C(2780, J$.B(2882, '!==', J$.U(2878, 'typeof', J$.G(27621, J$.R(27617, 'extra', extra, false), 'tokens')), J$.T(27625, 'undefined', 21)))) {
                                                    J$.F(27633, J$.R(27629, 'filterTokenLocation', filterTokenLocation, false), false)();
                                                    J$.P(27649, J$.R(27637, 'program', program, false), 'tokens', J$.G(27645, J$.R(27641, 'extra', extra, false), 'tokens'));
                                                }
                                                if (J$.C(2784, J$.B(2890, '!==', J$.U(2886, 'typeof', J$.G(27657, J$.R(27653, 'extra', extra, false), 'errors')), J$.T(27661, 'undefined', 21)))) {
                                                    J$.P(27677, J$.R(27665, 'program', program, false), 'errors', J$.G(27673, J$.R(27669, 'extra', extra, false), 'errors'));
                                                }
                                                if (J$.C(2788, J$.G(27685, J$.R(27681, 'extra', extra, false), 'attachComment'))) {
                                                    J$.F(27693, J$.R(27689, 'attachComments', attachComments, false), false)();
                                                }
                                            } catch (e) {
                                                throw J$.R(27697, 'e', e, false);
                                            } finally {
                                                extra = J$.W(27705, 'extra', J$.T(27701, {}, 11), extra);
                                            }
                                            return J$.Rt(27713, J$.R(27709, 'program', program, false));
                                        } catch (J$e) {
                                            J$.Ex(30101, J$e);
                                        } finally {
                                            if (J$.Fr(30105))
                                                continue jalangiLabel150;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }
                            J$.P(27749, J$.R(27741, 'exports', exports, false), 'version', J$.T(27745, '1.1.0-dev', 21));
                            J$.P(27761, J$.R(27753, 'exports', exports, false), 'tokenize', J$.R(27757, 'tokenize', tokenize, false));
                            J$.P(27773, J$.R(27765, 'exports', exports, false), 'parse', J$.R(27769, 'parse', parse, false));
                            J$.P(27921, J$.R(27777, 'exports', exports, false), 'Syntax', J$.F(27917, J$.T(27913, function () {
                                jalangiLabel151:
                                    while (true) {
                                        try {
                                            J$.Fe(27897, arguments.callee, this);
                                            arguments = J$.N(27901, 'arguments', arguments, true);
                                            J$.N(27905, 'name', name, false);
                                            J$.N(27909, 'types', types, false);
                                            var name, types = J$.W(27785, 'types', J$.T(27781, {}, 11), types);
                                            if (J$.C(2792, J$.B(2898, '===', J$.U(2894, 'typeof', J$.G(27793, J$.I(typeof Object === 'undefined' ? Object = J$.R(27789, 'Object', undefined, true) : Object = J$.R(27789, 'Object', Object, true)), 'create')), J$.T(27797, 'function', 21)))) {
                                                types = J$.W(27813, 'types', J$.M(27809, J$.I(typeof Object === 'undefined' ? Object = J$.R(27801, 'Object', undefined, true) : Object = J$.R(27801, 'Object', Object, true)), 'create', false)(J$.T(27805, null, 25)), types);
                                            }
                                            for (name in J$.H(27857, J$.R(27817, 'Syntax', Syntax, false))) {
                                                J$.N(27861, 'name', name, false);
                                                {
                                                    {
                                                        if (J$.C(2796, J$.M(27829, J$.R(27821, 'Syntax', Syntax, false), 'hasOwnProperty', false)(J$.R(27825, 'name', name, false)))) {
                                                            J$.P(27853, J$.R(27833, 'types', types, false), J$.R(27837, 'name', name, false), J$.G(27849, J$.R(27841, 'Syntax', Syntax, false), J$.R(27845, 'name', name, false)));
                                                        }
                                                    }
                                                }
                                            }
                                            if (J$.C(2800, J$.B(2906, '===', J$.U(2902, 'typeof', J$.G(27869, J$.I(typeof Object === 'undefined' ? Object = J$.R(27865, 'Object', undefined, true) : Object = J$.R(27865, 'Object', Object, true)), 'freeze')), J$.T(27873, 'function', 21)))) {
                                                J$.M(27885, J$.I(typeof Object === 'undefined' ? Object = J$.R(27877, 'Object', undefined, true) : Object = J$.R(27877, 'Object', Object, true)), 'freeze', false)(J$.R(27881, 'types', types, false));
                                            }
                                            return J$.Rt(27893, J$.R(27889, 'types', types, false));
                                        } catch (J$e) {
                                            J$.Ex(30109, J$e);
                                        } finally {
                                            if (J$.Fr(30113))
                                                continue jalangiLabel151;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12), false)());
                        } catch (J$e) {
                            J$.Ex(30117, J$e);
                        } finally {
                            if (J$.Fr(30121))
                                continue jalangiLabel152;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            var code = J$.W(28849, 'code', J$.M(28845, J$, 'readInput', false)(J$.T(28841, 'var a = b;', 21)), code);
            var result = J$.W(28861, 'result', J$.M(28857, J$.R(28853, 'esprima', esprima, false), 'parse', false)(), result);
            J$.M(28881, J$.I(typeof console === 'undefined' ? console = J$.R(28865, 'console', undefined, true) : console = J$.R(28865, 'console', console, true)), 'log', false)(J$.M(28877, J$.I(typeof JSON === 'undefined' ? JSON = J$.R(28869, 'JSON', undefined, true) : JSON = J$.R(28869, 'JSON', JSON, true)), 'stringify', false)(J$.R(28873, 'result', result, false)));
        } catch (J$e) {
            J$.Ex(30125, J$e);
        } finally {
            if (J$.Sr(30129))
                continue jalangiLabel153;
            else
                break jalangiLabel153;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=esprima_jalangi_.js.map