function f(a, b) {
    if(a > 0) {
        // then branch
    } else {
        if (b > 0){
            // else branch
        }
    }
}
