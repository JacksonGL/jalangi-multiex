jalangiLabel4:
    while (true) {
        try {
            J$.Se(557, '../tests/multiex/datastructures/math-cordic_jalangi_.js');
            J$.N(561, 'AG_CONST', AG_CONST, false);
            J$.N(565, 'Target', Target, false);
            J$.N(573, 'FIXED', J$.T(569, FIXED, 12), false);
            J$.N(581, 'FLOAT', J$.T(577, FLOAT, 12), false);
            J$.N(589, 'DEG2RAD', J$.T(585, DEG2RAD, 12), false);
            J$.N(593, 'Angles', Angles, false);
            J$.N(601, 'cordicsincos', J$.T(597, cordicsincos, 12), false);
            J$.N(605, 'total', total, false);
            var AG_CONST = J$.W(9, 'AG_CONST', J$.T(5, 0.607252935, 22), AG_CONST);
            var Target;
            function FIXED(X) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(25, arguments.callee, this);
                            arguments = J$.N(29, 'arguments', arguments, true);
                            X = J$.N(33, 'X', X, true);
                            return J$.Rt(21, J$.B(6, '*', J$.R(13, 'X', X, false), J$.T(17, 65536, 22)));
                        } catch (J$e) {
                            J$.Ex(609, J$e);
                        } finally {
                            if (J$.Fr(613))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function FLOAT(X) {
                jalangiLabel1:
                    while (true) {
                        try {
                            J$.Fe(49, arguments.callee, this);
                            arguments = J$.N(53, 'arguments', arguments, true);
                            X = J$.N(57, 'X', X, true);
                            return J$.Rt(45, J$.B(10, '/', J$.R(37, 'X', X, false), J$.T(41, 65536, 22)));
                        } catch (J$e) {
                            J$.Ex(617, J$e);
                        } finally {
                            if (J$.Fr(621))
                                continue jalangiLabel1;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function DEG2RAD(X) {
                jalangiLabel2:
                    while (true) {
                        try {
                            J$.Fe(73, arguments.callee, this);
                            arguments = J$.N(77, 'arguments', arguments, true);
                            X = J$.N(81, 'X', X, true);
                            return J$.Rt(69, J$.B(14, '*', J$.T(61, 0.017453, 22), J$.R(65, 'X', X, false)));
                        } catch (J$e) {
                            J$.Ex(625, J$e);
                        } finally {
                            if (J$.Fr(629))
                                continue jalangiLabel2;
                            else
                                return J$.Ra();
                        }
                    }
            }
            var Angles = J$.W(233, 'Angles', J$.T(229, [
                    J$.F(93, J$.R(85, 'FIXED', FIXED, false), false)(J$.T(89, 45, 22)),
                    J$.F(105, J$.R(97, 'FIXED', FIXED, false), false)(J$.T(101, 26.565, 22)),
                    J$.F(117, J$.R(109, 'FIXED', FIXED, false), false)(J$.T(113, 14.0362, 22)),
                    J$.F(129, J$.R(121, 'FIXED', FIXED, false), false)(J$.T(125, 7.12502, 22)),
                    J$.F(141, J$.R(133, 'FIXED', FIXED, false), false)(J$.T(137, 3.57633, 22)),
                    J$.F(153, J$.R(145, 'FIXED', FIXED, false), false)(J$.T(149, 1.78991, 22)),
                    J$.F(165, J$.R(157, 'FIXED', FIXED, false), false)(J$.T(161, 0.895174, 22)),
                    J$.F(177, J$.R(169, 'FIXED', FIXED, false), false)(J$.T(173, 0.447614, 22)),
                    J$.F(189, J$.R(181, 'FIXED', FIXED, false), false)(J$.T(185, 0.223811, 22)),
                    J$.F(201, J$.R(193, 'FIXED', FIXED, false), false)(J$.T(197, 0.111906, 22)),
                    J$.F(213, J$.R(205, 'FIXED', FIXED, false), false)(J$.T(209, 0.055953, 22)),
                    J$.F(225, J$.R(217, 'FIXED', FIXED, false), false)(J$.T(221, 0.027977, 22))
                ], 10), Angles);
            function cordicsincos(Target) {
                jalangiLabel3:
                    while (true) {
                        try {
                            J$.Fe(465, arguments.callee, this);
                            arguments = J$.N(469, 'arguments', arguments, true);
                            Target = J$.N(473, 'Target', Target, true);
                            J$.N(477, 'X', X, false);
                            J$.N(481, 'Y', Y, false);
                            J$.N(485, 'TargetAngle', TargetAngle, false);
                            J$.N(489, 'CurrAngle', CurrAngle, false);
                            J$.N(493, 'Step', Step, false);
                            J$.N(497, 'NewX', NewX, false);
                            var X;
                            var Y;
                            var TargetAngle;
                            var CurrAngle;
                            var Step;
                            X = J$.W(249, 'X', J$.F(245, J$.R(237, 'FIXED', FIXED, false), false)(J$.R(241, 'AG_CONST', AG_CONST, false)), X);
                            Y = J$.W(257, 'Y', J$.T(253, 0, 22), Y);
                            TargetAngle = J$.W(273, 'TargetAngle', J$.F(269, J$.R(261, 'FIXED', FIXED, false), false)(J$.R(265, 'Target', Target, false)), TargetAngle);
                            CurrAngle = J$.W(281, 'CurrAngle', J$.T(277, 0, 22), CurrAngle);
                            for (Step = J$.W(289, 'Step', J$.T(285, 0, 22), Step); J$.C(8, J$.B(18, '<', J$.R(293, 'Step', Step, false), J$.T(297, 12, 22))); J$.B(30, '-', Step = J$.W(305, 'Step', J$.B(26, '+', J$.U(22, '+', J$.R(301, 'Step', Step, false)), 1), Step), 1)) {
                                var NewX;
                                if (J$.C(4, J$.B(34, '>', J$.R(309, 'TargetAngle', TargetAngle, false), J$.R(313, 'CurrAngle', CurrAngle, false)))) {
                                    NewX = J$.W(329, 'NewX', J$.B(42, '-', J$.R(317, 'X', X, false), J$.B(38, '>>', J$.R(321, 'Y', Y, false), J$.R(325, 'Step', Step, false))), NewX);
                                    Y = J$.W(345, 'Y', J$.B(50, '+', J$.B(46, '>>', J$.R(333, 'X', X, false), J$.R(337, 'Step', Step, false)), J$.R(341, 'Y', Y, false)), Y);
                                    X = J$.W(353, 'X', J$.R(349, 'NewX', NewX, false), X);
                                    CurrAngle = J$.W(373, 'CurrAngle', J$.B(54, '+', J$.R(369, 'CurrAngle', CurrAngle, false), J$.G(365, J$.R(357, 'Angles', Angles, false), J$.R(361, 'Step', Step, false))), CurrAngle);
                                } else {
                                    NewX = J$.W(389, 'NewX', J$.B(62, '+', J$.R(377, 'X', X, false), J$.B(58, '>>', J$.R(381, 'Y', Y, false), J$.R(385, 'Step', Step, false))), NewX);
                                    Y = J$.W(405, 'Y', J$.B(74, '+', J$.U(70, '-', J$.B(66, '>>', J$.R(393, 'X', X, false), J$.R(397, 'Step', Step, false))), J$.R(401, 'Y', Y, false)), Y);
                                    X = J$.W(413, 'X', J$.R(409, 'NewX', NewX, false), X);
                                    CurrAngle = J$.W(433, 'CurrAngle', J$.B(78, '-', J$.R(429, 'CurrAngle', CurrAngle, false), J$.G(425, J$.R(417, 'Angles', Angles, false), J$.R(421, 'Step', Step, false))), CurrAngle);
                                }
                            }
                            return J$.Rt(461, J$.B(82, '*', J$.F(445, J$.R(437, 'FLOAT', FLOAT, false), false)(J$.R(441, 'X', X, false)), J$.F(457, J$.R(449, 'FLOAT', FLOAT, false), false)(J$.R(453, 'Y', Y, false))));
                        } catch (J$e) {
                            J$.Ex(633, J$e);
                        } finally {
                            if (J$.Fr(637))
                                continue jalangiLabel3;
                            else
                                return J$.Ra();
                        }
                    }
            }
            var total = J$.W(505, 'total', J$.T(501, 0, 22), total);
            J$.F(521, J$.R(509, 'cordicsincos', cordicsincos, false), false)(J$.M(517, J$, 'readInput', false)(J$.T(513, 1, 22)));
            J$.F(537, J$.R(525, 'cordicsincos', cordicsincos, false), false)(J$.M(533, J$, 'readInput', false)(J$.T(529, 2.2, 22)));
            J$.F(553, J$.R(541, 'cordicsincos', cordicsincos, false), false)(J$.M(549, J$, 'readInput', false)(J$.T(545, 300, 22)));
        } catch (J$e) {
            J$.Ex(641, J$e);
        } finally {
            if (J$.Sr(645))
                continue jalangiLabel4;
            else
                break jalangiLabel4;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=math-cordic_jalangi_.js.map