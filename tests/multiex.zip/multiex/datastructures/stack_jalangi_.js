J$.noInstrEval = false;
jalangiLabel7:
    while (true) {
        try {
            J$.Se(1001, '../tests/multiex/datastructures/stack_jalangi_.js');
            function Stack() {
                jalangiLabel5:
                    while (true) {
                        try {
                            J$.Fe(777, arguments.callee, this, arguments);
                            arguments = J$.N(785, 'arguments', arguments, true, false);
                            J$.N(793, 'top', top, false, false);
                            J$.N(801, 'count', count, false, false);
                            var top = J$.W(17, 'top', J$.T(9, null, 25, false), top, false, false);
                            var count = J$.W(33, 'count', J$.T(25, 0, 22, false), count, false, false);
                            J$.P(89, J$.R(41, 'this', this, false, false), 'GetCount', J$.T(81, function () {
                                jalangiLabel0:
                                    while (true) {
                                        try {
                                            J$.Fe(65, arguments.callee, this, arguments);
                                            arguments = J$.N(73, 'arguments', arguments, true, false);
                                            return J$.Rt(57, J$.R(49, 'count', count, false, false));
                                        } catch (J$e) {
                                            J$.Ex(1049, J$e);
                                        } finally {
                                            if (J$.Fr(1057))
                                                continue jalangiLabel0;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(233, J$.R(97, 'this', this, false, false), 'Push', J$.T(225, function (data) {
                                jalangiLabel1:
                                    while (true) {
                                        try {
                                            J$.Fe(193, arguments.callee, this, arguments);
                                            arguments = J$.N(201, 'arguments', arguments, true, false);
                                            data = J$.N(209, 'data', data, true, false);
                                            J$.N(217, 'node', node, false, false);
                                            var node = J$.W(129, 'node', J$.T(121, {
                                                    data: J$.R(105, 'data', data, false, false),
                                                    next: J$.T(113, null, 25, false)
                                                }, 11, false), node, false, false);
                                            J$.P(153, J$.R(137, 'node', node, false, false), 'next', J$.R(145, 'top', top, false, false));
                                            top = J$.W(169, 'top', J$.R(161, 'node', node, false, false), top, false, false);
                                            J$.B(26, '-', count = J$.W(185, 'count', J$.B(18, '+', J$.U(10, '+', J$.R(177, 'count', count, false, false)), 1), count, false, false), 1);
                                        } catch (J$e) {
                                            J$.Ex(1065, J$e);
                                        } finally {
                                            if (J$.Fr(1073))
                                                continue jalangiLabel1;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(409, J$.R(241, 'this', this, false, false), 'Pop', J$.T(401, function () {
                                jalangiLabel2:
                                    while (true) {
                                        try {
                                            J$.Fe(377, arguments.callee, this, arguments);
                                            arguments = J$.N(385, 'arguments', arguments, true, false);
                                            J$.N(393, 'out', out, false, false);
                                            if (J$.C(16, J$.B(34, '===', J$.R(249, 'top', top, false, false), J$.T(257, null, 25, false)))) {
                                                return J$.Rt(273, J$.T(265, null, 25, false));
                                            } else {
                                                var out = J$.W(289, 'out', J$.R(281, 'top', top, false, false), out, false, false);
                                                top = J$.W(313, 'top', J$.G(305, J$.R(297, 'top', top, false, false), 'next'), top, false, false);
                                                if (J$.C(8, J$.B(42, '>', J$.R(321, 'count', count, false, false), J$.T(329, 0, 22, false)))) {
                                                    J$.B(66, '+', count = J$.W(345, 'count', J$.B(58, '-', J$.U(50, '+', J$.R(337, 'count', count, false, false)), 1), count, false, false), 1);
                                                }
                                                return J$.Rt(369, J$.G(361, J$.R(353, 'out', out, false, false), 'data'));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(1081, J$e);
                                        } finally {
                                            if (J$.Fr(1089))
                                                continue jalangiLabel2;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(505, J$.R(417, 'this', this, false, false), 'Peek', J$.T(497, function () {
                                jalangiLabel3:
                                    while (true) {
                                        try {
                                            J$.Fe(481, arguments.callee, this, arguments);
                                            arguments = J$.N(489, 'arguments', arguments, true, false);
                                            if (J$.C(24, J$.B(74, '===', J$.R(425, 'top', top, false, false), J$.T(433, null, 25, false)))) {
                                                return J$.Rt(449, J$.T(441, null, 25, false));
                                            } else {
                                                return J$.Rt(473, J$.G(465, J$.R(457, 'top', top, false, false), 'data'));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(1097, J$e);
                                        } finally {
                                            if (J$.Fr(1105))
                                                continue jalangiLabel3;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(769, J$.R(513, 'this', this, false, false), 'DisplayAll', J$.T(761, function () {
                                jalangiLabel4:
                                    while (true) {
                                        try {
                                            J$.Fe(721, arguments.callee, this, arguments);
                                            arguments = J$.N(729, 'arguments', arguments, true, false);
                                            J$.N(737, 'arr', arr, false, false);
                                            J$.N(745, 'current', current, false, false);
                                            J$.N(753, 'i', i, false, false);
                                            if (J$.C(40, J$.B(82, '===', J$.R(521, 'top', top, false, false), J$.T(529, null, 25, false)))) {
                                                return J$.Rt(545, J$.T(537, null, 25, false));
                                            } else {
                                                var arr = J$.W(569, 'arr', J$.F(561, J$.I(typeof Array === 'undefined' ? Array = J$.R(553, 'Array', undefined, true, true) : Array = J$.R(553, 'Array', Array, true, true)), true)(), arr, false, false);
                                                var current = J$.W(585, 'current', J$.R(577, 'top', top, false, false), current, false, false);
                                                for (var i = J$.W(601, 'i', J$.T(593, 0, 22, false), i, false, false); J$.C(32, J$.B(90, '<', J$.R(609, 'i', i, false, false), J$.R(617, 'count', count, false, false))); J$.B(114, '-', i = J$.W(633, 'i', J$.B(106, '+', J$.U(98, '+', J$.R(625, 'i', i, false, false)), 1), i, false, false), 1)) {
                                                    J$.P(673, J$.R(641, 'arr', arr, false, false), J$.R(649, 'i', i, false, false), J$.G(665, J$.R(657, 'current', current, false, false), 'data'));
                                                    current = J$.W(697, 'current', J$.G(689, J$.R(681, 'current', current, false, false), 'next'), current, false, false);
                                                }
                                                return J$.Rt(713, J$.R(705, 'arr', arr, false, false));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(1113, J$e);
                                        } finally {
                                            if (J$.Fr(1121))
                                                continue jalangiLabel4;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                        } catch (J$e) {
                            J$.Ex(1129, J$e);
                        } finally {
                            if (J$.Fr(1137))
                                continue jalangiLabel5;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function testRound() {
                jalangiLabel6:
                    while (true) {
                        try {
                            J$.Fe(905, arguments.callee, this, arguments);
                            arguments = J$.N(913, 'arguments', arguments, true, false);
                            if (J$.C(48, J$.B(122, '>', J$.M(841, J$, 'readInput', false)(J$.T(833, 1, 22, false)), J$.T(849, 10, 22, false)))) {
                                J$.M(881, J$.R(857, 'stack', stack, false, true), 'Push', false)(J$.M(873, J$, 'readInput', false)(J$.T(865, 2, 22, false)));
                            } else {
                                J$.M(897, J$.R(889, 'stack', stack, false, true), 'Pop', false)();
                            }
                        } catch (J$e) {
                            J$.Ex(1145, J$e);
                        } finally {
                            if (J$.Fr(1153))
                                continue jalangiLabel6;
                            else
                                return J$.Ra();
                        }
                    }
            }
            Stack = J$.N(1017, 'Stack', J$.T(1009, Stack, 12, false), true, false);
            J$.N(1025, 'stack', stack, false, false);
            testRound = J$.N(1041, 'testRound', J$.T(1033, testRound, 12, false), true, false);
            var stack = J$.W(825, 'stack', J$.F(817, J$.R(809, 'Stack', Stack, false, true), true)(), stack, false, true);
            J$.F(929, J$.R(921, 'testRound', testRound, false, true), false)();
            J$.F(945, J$.R(937, 'testRound', testRound, false, true), false)();
            J$.F(961, J$.R(953, 'testRound', testRound, false, true), false)();
            J$.F(977, J$.R(969, 'testRound', testRound, false, true), false)();
            J$.F(993, J$.R(985, 'testRound', testRound, false, true), false)();
        } catch (J$e) {
            J$.Ex(1161, J$e);
        } finally {
            if (J$.Sr(1169))
                continue jalangiLabel7;
            else
                break jalangiLabel7;
        }
    }
// JALANGI DO NOT INSTRUMENT

