J$.noInstrEval = false;
jalangiLabel12:
    while (true) {
        try {
            J$.Se(2353, '../tests/multiex/datastructures/PriorityQueue_jalangi_.js');
            function PriorityQueue(comparator) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(73, arguments.callee, this, arguments);
                            arguments = J$.N(81, 'arguments', arguments, true, false);
                            comparator = J$.N(89, 'comparator', comparator, true, false);
                            J$.P(41, J$.R(9, 'this', this, false, false), '_comparator', J$.C(8, J$.R(17, 'comparator', comparator, false, false)) ? J$._() : J$.G(33, J$.R(25, 'PriorityQueue', PriorityQueue, false, true), 'DEFAULT_COMPARATOR'));
                            J$.P(65, J$.R(49, 'this', this, false, false), '_elements', J$.T(57, [], 10, false));
                        } catch (J$e) {
                            J$.Ex(2393, J$e);
                        } finally {
                            if (J$.Fr(2401))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function testRound() {
                jalangiLabel11:
                    while (true) {
                        try {
                            J$.Fe(2241, arguments.callee, this, arguments);
                            arguments = J$.N(2249, 'arguments', arguments, true, false);
                            J$.N(2257, 'queue', queue, false, false);
                            J$.N(2265, 'flag', flag, false, false);
                            var queue = J$.W(2081, 'queue', J$.F(2073, J$.R(1985, 'PriorityQueue', PriorityQueue, false, true), true)(J$.T(2065, function (a, b) {
                                    jalangiLabel10:
                                        while (true) {
                                            try {
                                                J$.Fe(2033, arguments.callee, this, arguments);
                                                arguments = J$.N(2041, 'arguments', arguments, true, false);
                                                a = J$.N(2049, 'a', a, true, false);
                                                b = J$.N(2057, 'b', b, true, false);
                                                return J$.Rt(2025, J$.B(194, '-', J$.G(2001, J$.R(1993, 'a', a, false, false), 'cash'), J$.G(2017, J$.R(2009, 'b', b, false, false), 'cash')));
                                            } catch (J$e) {
                                                J$.Ex(2553, J$e);
                                            } finally {
                                                if (J$.Fr(2561))
                                                    continue jalangiLabel10;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12, false)), queue, false, false);
                            var flag = J$.W(2105, 'flag', J$.M(2097, J$, 'readInput', false)(J$.T(2089, 1, 22, false)), flag, false, false);
                            if (J$.C(144, J$.B(202, '>', J$.R(2113, 'flag', flag, false, false), J$.T(2121, 100, 22, false)))) {
                                J$.M(2153, J$.R(2129, 'queue', queue, false, false), 'enq', false)(J$.M(2145, J$, 'readInput', false)(J$.T(2137, 2, 22, false)));
                            } else if (J$.C(136, J$.B(210, '>', J$.R(2161, 'flag', flag, false, false), J$.T(2169, 90, 22, false)))) {
                                J$.M(2185, J$.R(2177, 'queue', queue, false, false), 'deq', false)();
                            } else if (J$.C(128, J$.B(218, '>', J$.R(2193, 'flag', flag, false, false), J$.T(2201, 80, 22, false)))) {
                                J$.M(2217, J$.R(2209, 'queue', queue, false, false), 'size', false)();
                            } else {
                                J$.M(2233, J$.R(2225, 'queue', queue, false, false), 'peek', false)();
                            }
                        } catch (J$e) {
                            J$.Ex(2569, J$e);
                        } finally {
                            if (J$.Fr(2577))
                                continue jalangiLabel11;
                            else
                                return J$.Ra();
                        }
                    }
            }
            PriorityQueue = J$.N(2369, 'PriorityQueue', J$.T(2361, PriorityQueue, 12, false), true, false);
            testRound = J$.N(2385, 'testRound', J$.T(2377, testRound, 12, false), true, false);
            J$.P(321, J$.R(97, 'PriorityQueue', PriorityQueue, false, true), 'DEFAULT_COMPARATOR', J$.T(313, function (a, b) {
                jalangiLabel1:
                    while (true) {
                        try {
                            J$.Fe(281, arguments.callee, this, arguments);
                            arguments = J$.N(289, 'arguments', arguments, true, false);
                            a = J$.N(297, 'a', a, true, false);
                            b = J$.N(305, 'b', b, true, false);
                            if (J$.C(40, J$.C(16, J$.B(10, 'instanceof', J$.R(105, 'a', a, false, false), J$.I(typeof Number === 'undefined' ? Number = J$.R(113, 'Number', undefined, true, true) : Number = J$.R(113, 'Number', Number, true, true)))) ? J$.B(18, 'instanceof', J$.R(121, 'b', b, false, false), J$.I(typeof Number === 'undefined' ? Number = J$.R(129, 'Number', undefined, true, true) : Number = J$.R(129, 'Number', Number, true, true))) : J$._())) {
                                return J$.Rt(153, J$.B(26, '-', J$.R(137, 'a', a, false, false), J$.R(145, 'b', b, false, false)));
                            } else {
                                a = J$.W(177, 'a', J$.M(169, J$.R(161, 'a', a, false, false), 'toString', false)(), a, false, false);
                                b = J$.W(201, 'b', J$.M(193, J$.R(185, 'b', b, false, false), 'toString', false)(), b, false, false);
                                if (J$.C(24, J$.B(34, '==', J$.R(209, 'a', a, false, false), J$.R(217, 'b', b, false, false))))
                                    return J$.Rt(233, J$.T(225, 0, 22, false));
                                return J$.Rt(273, J$.C(32, J$.B(42, '>', J$.R(241, 'a', a, false, false), J$.R(249, 'b', b, false, false))) ? J$.T(257, 1, 22, false) : J$.U(50, '-', J$.T(265, 1, 22, false)));
                            }
                        } catch (J$e) {
                            J$.Ex(2409, J$e);
                        } finally {
                            if (J$.Fr(2417))
                                continue jalangiLabel1;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false));
            J$.P(401, J$.G(337, J$.R(329, 'PriorityQueue', PriorityQueue, false, true), 'prototype'), 'isEmpty', J$.T(393, function () {
                jalangiLabel2:
                    while (true) {
                        try {
                            J$.Fe(377, arguments.callee, this, arguments);
                            arguments = J$.N(385, 'arguments', arguments, true, false);
                            return J$.Rt(369, J$.B(58, '===', J$.M(353, J$.R(345, 'this', this, false, false), 'size', false)(), J$.T(361, 0, 22, false)));
                        } catch (J$e) {
                            J$.Ex(2425, J$e);
                        } finally {
                            if (J$.Fr(2433))
                                continue jalangiLabel2;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false));
            J$.P(529, J$.G(417, J$.R(409, 'PriorityQueue', PriorityQueue, false, true), 'prototype'), 'peek', J$.T(521, function () {
                jalangiLabel3:
                    while (true) {
                        try {
                            J$.Fe(505, arguments.callee, this, arguments);
                            arguments = J$.N(513, 'arguments', arguments, true, false);
                            if (J$.C(48, J$.M(433, J$.R(425, 'this', this, false, false), 'isEmpty', false)()))
                                throw J$.F(457, J$.I(typeof Error === 'undefined' ? Error = J$.R(441, 'Error', undefined, true, true) : Error = J$.R(441, 'Error', Error, true, true)), true)(J$.T(449, 'PriorityQueue is empty', 21, false));
                            return J$.Rt(497, J$.G(489, J$.G(473, J$.R(465, 'this', this, false, false), '_elements'), J$.T(481, 0, 22, false)));
                        } catch (J$e) {
                            J$.Ex(2441, J$e);
                        } finally {
                            if (J$.Fr(2449))
                                continue jalangiLabel3;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false));
            J$.P(1121, J$.G(545, J$.R(537, 'PriorityQueue', PriorityQueue, false, true), 'prototype'), 'deq', J$.T(1113, function () {
                jalangiLabel4:
                    while (true) {
                        try {
                            J$.Fe(1041, arguments.callee, this, arguments);
                            arguments = J$.N(1049, 'arguments', arguments, true, false);
                            J$.N(1057, 'first', first, false, false);
                            J$.N(1065, 'last', last, false, false);
                            J$.N(1073, 'size', size, false, false);
                            J$.N(1081, 'current', current, false, false);
                            J$.N(1089, 'largest', largest, false, false);
                            J$.N(1097, 'left', left, false, false);
                            J$.N(1105, 'right', right, false, false);
                            var first = J$.W(569, 'first', J$.M(561, J$.R(553, 'this', this, false, false), 'peek', false)(), first, false, false);
                            var last = J$.W(601, 'last', J$.M(593, J$.G(585, J$.R(577, 'this', this, false, false), '_elements'), 'pop', false)(), last, false, false);
                            var size = J$.W(625, 'size', J$.M(617, J$.R(609, 'this', this, false, false), 'size', false)(), size, false, false);
                            if (J$.C(56, J$.B(66, '===', J$.R(633, 'size', size, false, false), J$.T(641, 0, 22, false))))
                                return J$.Rt(657, J$.R(649, 'first', first, false, false));
                            J$.P(697, J$.G(673, J$.R(665, 'this', this, false, false), '_elements'), J$.T(681, 0, 22, false), J$.R(689, 'last', last, false, false));
                            var current = J$.W(713, 'current', J$.T(705, 0, 22, false), current, false, false);
                            while (J$.C(104, J$.B(74, '<', J$.R(721, 'current', current, false, false), J$.R(729, 'size', size, false, false)))) {
                                var largest = J$.W(745, 'largest', J$.R(737, 'current', current, false, false), largest, false, false);
                                var left = J$.W(777, 'left', J$.B(90, '+', J$.B(82, '*', J$.T(753, 2, 22, false), J$.R(761, 'current', current, false, false)), J$.T(769, 1, 22, false)), left, false, false);
                                var right = J$.W(809, 'right', J$.B(106, '+', J$.B(98, '*', J$.T(785, 2, 22, false), J$.R(793, 'current', current, false, false)), J$.T(801, 2, 22, false)), right, false, false);
                                if (J$.C(72, J$.C(64, J$.B(114, '<', J$.R(817, 'left', left, false, false), J$.R(825, 'size', size, false, false))) ? J$.B(122, '>', J$.M(857, J$.R(833, 'this', this, false, false), '_compare', false)(J$.R(841, 'left', left, false, false), J$.R(849, 'largest', largest, false, false)), J$.T(865, 0, 22, false)) : J$._())) {
                                    largest = J$.W(881, 'largest', J$.R(873, 'left', left, false, false), largest, false, false);
                                }
                                if (J$.C(88, J$.C(80, J$.B(130, '<', J$.R(889, 'right', right, false, false), J$.R(897, 'size', size, false, false))) ? J$.B(138, '>', J$.M(929, J$.R(905, 'this', this, false, false), '_compare', false)(J$.R(913, 'right', right, false, false), J$.R(921, 'largest', largest, false, false)), J$.T(937, 0, 22, false)) : J$._())) {
                                    largest = J$.W(953, 'largest', J$.R(945, 'right', right, false, false), largest, false, false);
                                }
                                if (J$.C(96, J$.B(146, '===', J$.R(961, 'largest', largest, false, false), J$.R(969, 'current', current, false, false))))
                                    break;
                                J$.M(1001, J$.R(977, 'this', this, false, false), '_swap', false)(J$.R(985, 'largest', largest, false, false), J$.R(993, 'current', current, false, false));
                                current = J$.W(1017, 'current', J$.R(1009, 'largest', largest, false, false), current, false, false);
                            }
                            return J$.Rt(1033, J$.R(1025, 'first', first, false, false));
                        } catch (J$e) {
                            J$.Ex(2457, J$e);
                        } finally {
                            if (J$.Fr(2465))
                                continue jalangiLabel4;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false));
            J$.P(1433, J$.G(1137, J$.R(1129, 'PriorityQueue', PriorityQueue, false, true), 'prototype'), 'enq', J$.T(1425, function (element) {
                jalangiLabel5:
                    while (true) {
                        try {
                            J$.Fe(1377, arguments.callee, this, arguments);
                            arguments = J$.N(1385, 'arguments', arguments, true, false);
                            element = J$.N(1393, 'element', element, true, false);
                            J$.N(1401, 'size', size, false, false);
                            J$.N(1409, 'current', current, false, false);
                            J$.N(1417, 'parent', parent, false, false);
                            var size = J$.W(1177, 'size', J$.M(1169, J$.G(1153, J$.R(1145, 'this', this, false, false), '_elements'), 'push', false)(J$.R(1161, 'element', element, false, false)), size, false, false);
                            var current = J$.W(1201, 'current', J$.B(154, '-', J$.R(1185, 'size', size, false, false), J$.T(1193, 1, 22, false)), current, false, false);
                            while (J$.C(120, J$.B(162, '>', J$.R(1209, 'current', current, false, false), J$.T(1217, 0, 22, false)))) {
                                var parent = J$.W(1265, 'parent', J$.M(1257, J$.I(typeof Math === 'undefined' ? Math = J$.R(1225, 'Math', undefined, true, true) : Math = J$.R(1225, 'Math', Math, true, true)), 'floor', false)(J$.B(178, '/', J$.B(170, '-', J$.R(1233, 'current', current, false, false), J$.T(1241, 1, 22, false)), J$.T(1249, 2, 22, false))), parent, false, false);
                                if (J$.C(112, J$.B(186, '<', J$.M(1297, J$.R(1273, 'this', this, false, false), '_compare', false)(J$.R(1281, 'current', current, false, false), J$.R(1289, 'parent', parent, false, false)), J$.T(1305, 0, 22, false))))
                                    break;
                                J$.M(1337, J$.R(1313, 'this', this, false, false), '_swap', false)(J$.R(1321, 'parent', parent, false, false), J$.R(1329, 'current', current, false, false));
                                current = J$.W(1353, 'current', J$.R(1345, 'parent', parent, false, false), current, false, false);
                            }
                            return J$.Rt(1369, J$.R(1361, 'size', size, false, false));
                        } catch (J$e) {
                            J$.Ex(2473, J$e);
                        } finally {
                            if (J$.Fr(2481))
                                continue jalangiLabel5;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false));
            J$.P(1513, J$.G(1449, J$.R(1441, 'PriorityQueue', PriorityQueue, false, true), 'prototype'), 'size', J$.T(1505, function () {
                jalangiLabel6:
                    while (true) {
                        try {
                            J$.Fe(1489, arguments.callee, this, arguments);
                            arguments = J$.N(1497, 'arguments', arguments, true, false);
                            return J$.Rt(1481, J$.G(1473, J$.G(1465, J$.R(1457, 'this', this, false, false), '_elements'), 'length'));
                        } catch (J$e) {
                            J$.Ex(2489, J$e);
                        } finally {
                            if (J$.Fr(2497))
                                continue jalangiLabel6;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false));
            J$.P(1609, J$.G(1529, J$.R(1521, 'PriorityQueue', PriorityQueue, false, true), 'prototype'), 'forEach', J$.T(1601, function (fn) {
                jalangiLabel7:
                    while (true) {
                        try {
                            J$.Fe(1577, arguments.callee, this, arguments);
                            arguments = J$.N(1585, 'arguments', arguments, true, false);
                            fn = J$.N(1593, 'fn', fn, true, false);
                            return J$.Rt(1569, J$.M(1561, J$.G(1545, J$.R(1537, 'this', this, false, false), '_elements'), 'forEach', false)(J$.R(1553, 'fn', fn, false, false)));
                        } catch (J$e) {
                            J$.Ex(2505, J$e);
                        } finally {
                            if (J$.Fr(2513))
                                continue jalangiLabel7;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false));
            J$.P(1761, J$.G(1625, J$.R(1617, 'PriorityQueue', PriorityQueue, false, true), 'prototype'), '_compare', J$.T(1753, function (a, b) {
                jalangiLabel8:
                    while (true) {
                        try {
                            J$.Fe(1721, arguments.callee, this, arguments);
                            arguments = J$.N(1729, 'arguments', arguments, true, false);
                            a = J$.N(1737, 'a', a, true, false);
                            b = J$.N(1745, 'b', b, true, false);
                            return J$.Rt(1713, J$.M(1705, J$.R(1633, 'this', this, false, false), '_comparator', false)(J$.G(1665, J$.G(1649, J$.R(1641, 'this', this, false, false), '_elements'), J$.R(1657, 'a', a, false, false)), J$.G(1697, J$.G(1681, J$.R(1673, 'this', this, false, false), '_elements'), J$.R(1689, 'b', b, false, false))));
                        } catch (J$e) {
                            J$.Ex(2521, J$e);
                        } finally {
                            if (J$.Fr(2529))
                                continue jalangiLabel8;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false));
            J$.P(1977, J$.G(1777, J$.R(1769, 'PriorityQueue', PriorityQueue, false, true), 'prototype'), '_swap', J$.T(1969, function (a, b) {
                jalangiLabel9:
                    while (true) {
                        try {
                            J$.Fe(1929, arguments.callee, this, arguments);
                            arguments = J$.N(1937, 'arguments', arguments, true, false);
                            a = J$.N(1945, 'a', a, true, false);
                            b = J$.N(1953, 'b', b, true, false);
                            J$.N(1961, 'aux', aux, false, false);
                            var aux = J$.W(1817, 'aux', J$.G(1809, J$.G(1793, J$.R(1785, 'this', this, false, false), '_elements'), J$.R(1801, 'a', a, false, false)), aux, false, false);
                            J$.P(1881, J$.G(1833, J$.R(1825, 'this', this, false, false), '_elements'), J$.R(1841, 'a', a, false, false), J$.G(1873, J$.G(1857, J$.R(1849, 'this', this, false, false), '_elements'), J$.R(1865, 'b', b, false, false)));
                            J$.P(1921, J$.G(1897, J$.R(1889, 'this', this, false, false), '_elements'), J$.R(1905, 'b', b, false, false), J$.R(1913, 'aux', aux, false, false));
                        } catch (J$e) {
                            J$.Ex(2537, J$e);
                        } finally {
                            if (J$.Fr(2545))
                                continue jalangiLabel9;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12, false));
            J$.F(2281, J$.R(2273, 'testRound', testRound, false, true), false)();
            J$.F(2297, J$.R(2289, 'testRound', testRound, false, true), false)();
            J$.F(2313, J$.R(2305, 'testRound', testRound, false, true), false)();
            J$.F(2329, J$.R(2321, 'testRound', testRound, false, true), false)();
            J$.F(2345, J$.R(2337, 'testRound', testRound, false, true), false)();
        } catch (J$e) {
            J$.Ex(2585, J$e);
        } finally {
            if (J$.Sr(2593))
                continue jalangiLabel12;
            else
                break jalangiLabel12;
        }
    }
// JALANGI DO NOT INSTRUMENT

