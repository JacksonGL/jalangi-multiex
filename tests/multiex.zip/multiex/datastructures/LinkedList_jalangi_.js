jalangiLabel8:
    while (true) {
        try {
            J$.Se(953, '../tests/multiex/datastructures/LinkedList_jalangi_.js');
            J$.N(961, 'LinkedList', J$.T(957, LinkedList, 12), false);
            J$.N(965, 'list', list, false);
            J$.N(969, 'i', i, false);
            function LinkedList() {
                jalangiLabel7:
                    while (true) {
                        try {
                            J$.Fe(797, arguments.callee, this);
                            arguments = J$.N(801, 'arguments', arguments, true);
                            J$.N(805, 'count', count, false);
                            J$.N(809, 'head', head, false);
                            var count = J$.W(9, 'count', J$.T(5, 0, 22), count);
                            var head = J$.W(17, 'head', J$.T(13, null, 25), head);
                            J$.P(45, J$.R(21, 'this', this, false), 'GetCount', J$.T(41, function () {
                                jalangiLabel0:
                                    while (true) {
                                        try {
                                            J$.Fe(33, arguments.callee, this);
                                            arguments = J$.N(37, 'arguments', arguments, true);
                                            return J$.Rt(29, J$.R(25, 'count', count, false));
                                        } catch (J$e) {
                                            J$.Ex(973, J$e);
                                        } finally {
                                            if (J$.Fr(977))
                                                continue jalangiLabel0;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12));
                            J$.P(181, J$.R(49, 'this', this, false), 'DisplayAll', J$.T(177, function () {
                                jalangiLabel1:
                                    while (true) {
                                        try {
                                            J$.Fe(157, arguments.callee, this);
                                            arguments = J$.N(161, 'arguments', arguments, true);
                                            J$.N(165, 'arr', arr, false);
                                            J$.N(169, 'current', current, false);
                                            J$.N(173, 'i', i, false);
                                            if (J$.C(8, J$.B(6, '===', J$.R(53, 'head', head, false), J$.T(57, null, 25)))) {
                                                return J$.Rt(65, J$.T(61, null, 25));
                                            } else {
                                                var arr = J$.W(81, 'arr', J$.T(77, J$.F(73, J$.I(typeof Array === 'undefined' ? Array = J$.R(69, 'Array', undefined, true) : Array = J$.R(69, 'Array', Array, true)), true)(), 11), arr);
                                                var current = J$.W(89, 'current', J$.R(85, 'head', head, false), current);
                                                for (var i = J$.W(97, 'i', J$.T(93, 0, 22), i); J$.C(4, J$.B(10, '<', J$.R(101, 'i', i, false), J$.R(105, 'count', count, false))); J$.B(22, '-', i = J$.W(113, 'i', J$.B(18, '+', J$.U(14, '+', J$.R(109, 'i', i, false)), 1), i), 1)) {
                                                    J$.P(133, J$.R(117, 'arr', arr, false), J$.R(121, 'i', i, false), J$.G(129, J$.R(125, 'current', current, false), 'data'));
                                                    current = J$.W(145, 'current', J$.G(141, J$.R(137, 'current', current, false), 'next'), current);
                                                }
                                                return J$.Rt(153, J$.R(149, 'arr', arr, false));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(981, J$e);
                                        } finally {
                                            if (J$.Fr(985))
                                                continue jalangiLabel1;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12));
                            J$.P(289, J$.R(185, 'this', this, false), 'DisplayAt', J$.T(285, function (index) {
                                jalangiLabel2:
                                    while (true) {
                                        try {
                                            J$.Fe(265, arguments.callee, this);
                                            arguments = J$.N(269, 'arguments', arguments, true);
                                            index = J$.N(273, 'index', index, true);
                                            J$.N(277, 'current', current, false);
                                            J$.N(281, 'i', i, false);
                                            if (J$.C(20, J$.C(12, J$.B(30, '>', J$.R(189, 'index', index, false), J$.U(26, '-', J$.T(193, 1, 22)))) ? J$.B(34, '<', J$.R(197, 'index', index, false), J$.R(201, 'count', count, false)) : J$._())) {
                                                var current = J$.W(209, 'current', J$.R(205, 'head', head, false), current);
                                                var i = J$.W(217, 'i', J$.T(213, 0, 22), i);
                                                while (J$.C(16, J$.B(50, '<', J$.B(46, '-', i = J$.W(225, 'i', J$.B(42, '+', J$.U(38, '+', J$.R(221, 'i', i, false)), 1), i), 1), J$.R(229, 'index', index, false)))) {
                                                    current = J$.W(241, 'current', J$.G(237, J$.R(233, 'current', current, false), 'next'), current);
                                                }
                                                return J$.Rt(253, J$.G(249, J$.R(245, 'current', current, false), 'data'));
                                            } else {
                                                return J$.Rt(261, J$.T(257, null, 25));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(989, J$e);
                                        } finally {
                                            if (J$.Fr(993))
                                                continue jalangiLabel2;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12));
                            J$.P(349, J$.R(293, 'this', this, false), 'AddFirst', J$.T(345, function (data) {
                                jalangiLabel3:
                                    while (true) {
                                        try {
                                            J$.Fe(329, arguments.callee, this);
                                            arguments = J$.N(333, 'arguments', arguments, true);
                                            data = J$.N(337, 'data', data, true);
                                            J$.N(341, 'node', node, false);
                                            var node = J$.W(309, 'node', J$.T(305, {
                                                    data: J$.R(297, 'data', data, false),
                                                    next: J$.R(301, 'head', head, false)
                                                }, 11), node);
                                            head = J$.W(317, 'head', J$.R(313, 'node', node, false), head);
                                            J$.B(62, '-', count = J$.W(325, 'count', J$.B(58, '+', J$.U(54, '+', J$.R(321, 'count', count, false)), 1), count), 1);
                                        } catch (J$e) {
                                            J$.Ex(997, J$e);
                                        } finally {
                                            if (J$.Fr(1001))
                                                continue jalangiLabel3;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12));
                            J$.P(537, J$.R(353, 'this', this, false), 'Add', J$.T(533, function (data, index) {
                                jalangiLabel4:
                                    while (true) {
                                        try {
                                            J$.Fe(501, arguments.callee, this);
                                            arguments = J$.N(505, 'arguments', arguments, true);
                                            data = J$.N(509, 'data', data, true);
                                            index = J$.N(513, 'index', index, true);
                                            J$.N(517, 'node', node, false);
                                            J$.N(521, 'previous', previous, false);
                                            J$.N(525, 'current', current, false);
                                            J$.N(529, 'i', i, false);
                                            if (J$.C(36, J$.B(66, '===', J$.R(357, 'index', index, false), J$.T(361, 0, 22)))) {
                                                J$.M(373, J$.R(365, 'this', this, false), 'AddFirst', false)(J$.R(369, 'data', data, false));
                                            } else if (J$.C(32, J$.C(24, J$.B(74, '>', J$.R(377, 'index', index, false), J$.U(70, '-', J$.T(381, 1, 22)))) ? J$.B(78, '<', J$.R(385, 'index', index, false), J$.R(389, 'count', count, false)) : J$._())) {
                                                var node = J$.W(405, 'node', J$.T(401, {
                                                        data: J$.R(393, 'data', data, false),
                                                        next: J$.T(397, null, 25)
                                                    }, 11), node);
                                                var previous;
                                                var current = J$.W(413, 'current', J$.R(409, 'head', head, false), current);
                                                var i = J$.W(421, 'i', J$.T(417, 0, 22), i);
                                                while (J$.C(28, J$.B(94, '<', J$.B(90, '-', i = J$.W(429, 'i', J$.B(86, '+', J$.U(82, '+', J$.R(425, 'i', i, false)), 1), i), 1), J$.R(433, 'index', index, false)))) {
                                                    previous = J$.W(441, 'previous', J$.R(437, 'current', current, false), previous);
                                                    current = J$.W(453, 'current', J$.G(449, J$.R(445, 'current', current, false), 'next'), current);
                                                }
                                                J$.P(465, J$.R(457, 'previous', previous, false), 'next', J$.R(461, 'node', node, false));
                                                J$.P(477, J$.R(469, 'node', node, false), 'next', J$.R(473, 'current', current, false));
                                                J$.B(106, '-', count = J$.W(485, 'count', J$.B(102, '+', J$.U(98, '+', J$.R(481, 'count', count, false)), 1), count), 1);
                                            } else {
                                                J$.F(497, J$.I(typeof alert === 'undefined' ? alert = J$.R(489, 'alert', undefined, true) : alert = J$.R(489, 'alert', alert, true)), false)(J$.T(493, 'out of range', 21));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(1005, J$e);
                                        } finally {
                                            if (J$.Fr(1009))
                                                continue jalangiLabel4;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12));
                            J$.P(625, J$.R(541, 'this', this, false), 'RemoveFirst', J$.T(621, function () {
                                jalangiLabel5:
                                    while (true) {
                                        try {
                                            J$.Fe(609, arguments.callee, this);
                                            arguments = J$.N(613, 'arguments', arguments, true);
                                            J$.N(617, 'out', out, false);
                                            if (J$.C(44, J$.B(110, '===', J$.R(545, 'head', head, false), J$.T(549, null, 25)))) {
                                                return J$.Rt(557, J$.T(553, null, 25));
                                            } else {
                                                var out = J$.W(565, 'out', J$.R(561, 'head', head, false), out);
                                                head = J$.W(577, 'head', J$.G(573, J$.R(569, 'head', head, false), 'next'), head);
                                                if (J$.C(40, J$.B(114, '>', J$.R(581, 'count', count, false), J$.T(585, 0, 22)))) {
                                                    J$.B(126, '+', count = J$.W(593, 'count', J$.B(122, '-', J$.U(118, '+', J$.R(589, 'count', count, false)), 1), count), 1);
                                                }
                                                return J$.Rt(605, J$.G(601, J$.R(597, 'out', out, false), 'data'));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(1013, J$e);
                                        } finally {
                                            if (J$.Fr(1017))
                                                continue jalangiLabel5;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12));
                            J$.P(793, J$.R(629, 'this', this, false), 'RemoveAt', J$.T(789, function (index) {
                                jalangiLabel6:
                                    while (true) {
                                        try {
                                            J$.Fe(765, arguments.callee, this);
                                            arguments = J$.N(769, 'arguments', arguments, true);
                                            index = J$.N(773, 'index', index, true);
                                            J$.N(777, 'current', current, false);
                                            J$.N(781, 'previous', previous, false);
                                            J$.N(785, 'i', i, false);
                                            if (J$.C(60, J$.B(130, '===', J$.R(633, 'index', index, false), J$.T(637, 0, 22)))) {
                                                return J$.Rt(653, J$.M(649, J$.R(641, 'this', this, false), 'RemoveFirst', false)(J$.R(645, 'index', index, false)));
                                            } else if (J$.C(56, J$.C(48, J$.B(138, '>', J$.R(657, 'index', index, false), J$.U(134, '-', J$.T(661, 1, 22)))) ? J$.B(142, '<', J$.R(665, 'index', index, false), J$.R(669, 'count', count, false)) : J$._())) {
                                                var current = J$.W(677, 'current', J$.R(673, 'head', head, false), current);
                                                var previous;
                                                var i = J$.W(685, 'i', J$.T(681, 0, 22), i);
                                                while (J$.C(52, J$.B(158, '<', J$.B(154, '-', i = J$.W(693, 'i', J$.B(150, '+', J$.U(146, '+', J$.R(689, 'i', i, false)), 1), i), 1), J$.R(697, 'index', index, false)))) {
                                                    previous = J$.W(705, 'previous', J$.R(701, 'current', current, false), previous);
                                                    current = J$.W(717, 'current', J$.G(713, J$.R(709, 'current', current, false), 'next'), current);
                                                }
                                                J$.P(733, J$.R(721, 'previous', previous, false), 'next', J$.G(729, J$.R(725, 'current', current, false), 'next'));
                                                J$.B(170, '+', count = J$.W(741, 'count', J$.B(166, '-', J$.U(162, '+', J$.R(737, 'count', count, false)), 1), count), 1);
                                            } else {
                                                return J$.Rt(749, J$.T(745, null, 25));
                                            }
                                            return J$.Rt(761, J$.G(757, J$.R(753, 'current', current, false), 'data'));
                                        } catch (J$e) {
                                            J$.Ex(1021, J$e);
                                        } finally {
                                            if (J$.Fr(1025))
                                                continue jalangiLabel6;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12));
                        } catch (J$e) {
                            J$.Ex(1029, J$e);
                        } finally {
                            if (J$.Fr(1033))
                                continue jalangiLabel7;
                            else
                                return J$.Ra();
                        }
                    }
            }
            var list = J$.W(825, 'list', J$.T(821, J$.F(817, J$.R(813, 'LinkedList', LinkedList, false), true)(), 11), list);
            J$.M(837, J$.R(829, 'list', list, false), 'AddFirst', false)(J$.T(833, 'data1', 21));
            J$.M(849, J$.R(841, 'list', list, false), 'AddFirst', false)(J$.T(845, 'data2', 21));
            J$.M(861, J$.R(853, 'list', list, false), 'AddFirst', false)(J$.T(857, 'data3', 21));
            J$.M(873, J$.R(865, 'list', list, false), 'AddFirst', false)(J$.T(869, 'data4', 21));
            J$.M(885, J$.R(877, 'list', list, false), 'AddFirst', false)(J$.T(881, 'data5', 21));
            J$.M(897, J$.R(889, 'list', list, false), 'AddFirst', false)(J$.T(893, 'data6', 21));
            J$.M(909, J$.R(901, 'list', list, false), 'AddFirst', false)(J$.T(905, 'data7', 21));
            for (var i = J$.W(917, 'i', J$.T(913, 0, 22), i); J$.C(64, J$.B(174, '<', J$.R(921, 'i', i, false), J$.T(925, 3, 22))); J$.B(186, '-', i = J$.W(933, 'i', J$.B(182, '+', J$.U(178, '+', J$.R(929, 'i', i, false)), 1), i), 1)) {
                J$.M(949, J$.R(937, 'list', list, false), 'RemoveAt', false)(J$.M(945, J$, 'readInput', false)(J$.T(941, 1, 22)));
            }
        } catch (J$e) {
            J$.Ex(1037, J$e);
        } finally {
            if (J$.Sr(1041))
                continue jalangiLabel8;
            else
                break jalangiLabel8;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=LinkedList_jalangi_.js.map