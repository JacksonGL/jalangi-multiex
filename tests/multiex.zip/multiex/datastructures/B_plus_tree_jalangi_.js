jalangiLabel24:
    while (true) {
        try {
            J$.Se(8945, '../tests/multiex/datastructures/B_plus_tree_jalangi_.js');
            J$.N(8949, 't', t, false);
            J$.N(8953, 'i', i, false);
            leaf = J$.W(65, 'leaf', J$.T(61, function () {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(53, arguments.callee, this);
                            arguments = J$.N(57, 'arguments', arguments, true);
                            J$.P(13, J$.R(5, 'this', this, false), 'keyval', J$.T(9, [], 10));
                            J$.P(25, J$.R(17, 'this', this, false), 'recnum', J$.T(21, [], 10));
                            J$.P(37, J$.R(29, 'this', this, false), 'prevLf', J$.T(33, null, 25));
                            J$.P(49, J$.R(41, 'this', this, false), 'nextLf', J$.T(45, null, 25));
                        } catch (J$e) {
                            J$.Ex(8957, J$e);
                        } finally {
                            if (J$.Fr(8961))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12), J$.I(typeof leaf === 'undefined' ? undefined : leaf));
            node = J$.W(105, 'node', J$.T(101, function () {
                jalangiLabel1:
                    while (true) {
                        try {
                            J$.Fe(93, arguments.callee, this);
                            arguments = J$.N(97, 'arguments', arguments, true);
                            J$.P(77, J$.R(69, 'this', this, false), 'keyval', J$.T(73, [], 10));
                            J$.P(89, J$.R(81, 'this', this, false), 'nodptr', J$.T(85, [], 10));
                        } catch (J$e) {
                            J$.Ex(8965, J$e);
                        } finally {
                            if (J$.Fr(8969))
                                continue jalangiLabel1;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12), J$.I(typeof node === 'undefined' ? undefined : node));
            tree = J$.W(297, 'tree', J$.T(293, function (order) {
                jalangiLabel2:
                    while (true) {
                        try {
                            J$.Fe(281, arguments.callee, this);
                            arguments = J$.N(285, 'arguments', arguments, true);
                            order = J$.N(289, 'order', order, true);
                            J$.P(125, J$.R(109, 'this', this, false), 'root', J$.T(121, J$.F(117, J$.I(typeof leaf === 'undefined' ? leaf = J$.R(113, 'leaf', undefined, true) : leaf = J$.R(113, 'leaf', leaf, true)), true)(), 11));
                            J$.P(141, J$.R(129, 'this', this, false), 'maxkey', J$.B(6, '-', J$.R(133, 'order', order, false), J$.T(137, 1, 22)));
                            J$.P(165, J$.R(145, 'this', this, false), 'minkyl', J$.M(161, J$.I(typeof Math === 'undefined' ? Math = J$.R(149, 'Math', undefined, true) : Math = J$.R(149, 'Math', Math, true)), 'floor', false)(J$.B(10, '/', J$.R(153, 'order', order, false), J$.T(157, 2, 22))));
                            J$.P(193, J$.R(169, 'this', this, false), 'minkyn', J$.M(189, J$.I(typeof Math === 'undefined' ? Math = J$.R(173, 'Math', undefined, true) : Math = J$.R(173, 'Math', Math, true)), 'floor', false)(J$.B(14, '/', J$.G(181, J$.R(177, 'this', this, false), 'maxkey'), J$.T(185, 2, 22))));
                            J$.P(205, J$.R(197, 'this', this, false), 'leaf', J$.T(201, null, 25));
                            J$.P(217, J$.R(209, 'this', this, false), 'item', J$.U(18, '-', J$.T(213, 1, 22)));
                            J$.P(229, J$.R(221, 'this', this, false), 'keyval', J$.T(225, '', 21));
                            J$.P(241, J$.R(233, 'this', this, false), 'recnum', J$.U(22, '-', J$.T(237, 1, 22)));
                            J$.P(253, J$.R(245, 'this', this, false), 'length', J$.T(249, 0, 22));
                            J$.P(265, J$.R(257, 'this', this, false), 'eof', J$.T(261, true, 23));
                            J$.P(277, J$.R(269, 'this', this, false), 'found', J$.T(273, false, 23));
                        } catch (J$e) {
                            J$.Ex(8973, J$e);
                        } finally {
                            if (J$.Fr(8977))
                                continue jalangiLabel2;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12), J$.I(typeof tree === 'undefined' ? undefined : tree));
            J$.P(329, J$.G(305, J$.I(typeof leaf === 'undefined' ? leaf = J$.R(301, 'leaf', undefined, true) : leaf = J$.R(301, 'leaf', leaf, true)), 'prototype'), 'isLeaf', J$.T(325, function () {
                jalangiLabel3:
                    while (true) {
                        try {
                            J$.Fe(317, arguments.callee, this);
                            arguments = J$.N(321, 'arguments', arguments, true);
                            return J$.Rt(313, J$.T(309, true, 23));
                        } catch (J$e) {
                            J$.Ex(8981, J$e);
                        } finally {
                            if (J$.Fr(8985))
                                continue jalangiLabel3;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(517, J$.G(337, J$.I(typeof leaf === 'undefined' ? leaf = J$.R(333, 'leaf', undefined, true) : leaf = J$.R(333, 'leaf', leaf, true)), 'prototype'), 'getItem', J$.T(513, function (key, near) {
                jalangiLabel4:
                    while (true) {
                        try {
                            J$.Fe(485, arguments.callee, this);
                            arguments = J$.N(489, 'arguments', arguments, true);
                            key = J$.N(493, 'key', key, true);
                            near = J$.N(497, 'near', near, true);
                            J$.N(501, 'vals', vals, false);
                            J$.N(505, 'i', i, false);
                            J$.N(509, 'len', len, false);
                            var vals = J$.W(349, 'vals', J$.G(345, J$.R(341, 'this', this, false), 'keyval'), vals);
                            if (J$.C(20, J$.R(353, 'near', near, false))) {
                                for (var i = J$.W(369, 'i', J$.T(357, 0, 22), i), len = J$.W(373, 'len', J$.G(365, J$.R(361, 'vals', vals, false), 'length'), len); J$.C(8, J$.B(26, '<', J$.R(377, 'i', i, false), J$.R(381, 'len', len, false))); J$.B(38, '-', i = J$.W(389, 'i', J$.B(34, '+', J$.U(30, '+', J$.R(385, 'i', i, false)), 1), i), 1)) {
                                    if (J$.C(4, J$.B(42, '<=', J$.R(393, 'key', key, false), J$.G(405, J$.R(397, 'vals', vals, false), J$.R(401, 'i', i, false)))))
                                        return J$.Rt(413, J$.R(409, 'i', i, false));
                                }
                            } else {
                                for (var i = J$.W(429, 'i', J$.T(417, 0, 22), i), len = J$.W(433, 'len', J$.G(425, J$.R(421, 'vals', vals, false), 'length'), len); J$.C(16, J$.B(46, '<', J$.R(437, 'i', i, false), J$.R(441, 'len', len, false))); J$.B(58, '-', i = J$.W(449, 'i', J$.B(54, '+', J$.U(50, '+', J$.R(445, 'i', i, false)), 1), i), 1)) {
                                    if (J$.C(12, J$.B(62, '===', J$.R(453, 'key', key, false), J$.G(465, J$.R(457, 'vals', vals, false), J$.R(461, 'i', i, false)))))
                                        return J$.Rt(473, J$.R(469, 'i', i, false));
                                }
                            }
                            return J$.Rt(481, J$.U(66, '-', J$.T(477, 1, 22)));
                        } catch (J$e) {
                            J$.Ex(8989, J$e);
                        } finally {
                            if (J$.Fr(8993))
                                continue jalangiLabel4;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(813, J$.G(525, J$.I(typeof leaf === 'undefined' ? leaf = J$.R(521, 'leaf', undefined, true) : leaf = J$.R(521, 'leaf', leaf, true)), 'prototype'), 'addKey', J$.T(809, function (key, rec) {
                jalangiLabel5:
                    while (true) {
                        try {
                            J$.Fe(777, arguments.callee, this);
                            arguments = J$.N(781, 'arguments', arguments, true);
                            key = J$.N(785, 'key', key, true);
                            rec = J$.N(789, 'rec', rec, true);
                            J$.N(793, 'vals', vals, false);
                            J$.N(797, 'itm', itm, false);
                            J$.N(801, 'i', i, false);
                            J$.N(805, 'len', len, false);
                            var vals = J$.W(537, 'vals', J$.G(533, J$.R(529, 'this', this, false), 'keyval'), vals);
                            var itm = J$.W(549, 'itm', J$.G(545, J$.R(541, 'vals', vals, false), 'length'), itm);
                            for (var i = J$.W(561, 'i', J$.T(553, 0, 22), i), len = J$.W(565, 'len', J$.R(557, 'itm', itm, false), len); J$.C(32, J$.B(70, '<', J$.R(569, 'i', i, false), J$.R(573, 'len', len, false))); J$.B(82, '-', i = J$.W(581, 'i', J$.B(78, '+', J$.U(74, '+', J$.R(577, 'i', i, false)), 1), i), 1)) {
                                if (J$.C(24, J$.B(86, '===', J$.R(585, 'key', key, false), J$.G(597, J$.R(589, 'vals', vals, false), J$.R(593, 'i', i, false))))) {
                                    itm = J$.W(605, 'itm', J$.U(90, '-', J$.T(601, 1, 22)), itm);
                                    break;
                                }
                                if (J$.C(28, J$.B(94, '<=', J$.R(609, 'key', key, false), J$.G(621, J$.R(613, 'vals', vals, false), J$.R(617, 'i', i, false))))) {
                                    itm = J$.W(629, 'itm', J$.R(625, 'i', i, false), itm);
                                    break;
                                }
                            }
                            if (J$.C(40, J$.B(102, '!=', J$.R(633, 'itm', itm, false), J$.U(98, '-', J$.T(637, 1, 22))))) {
                                for (var i = J$.W(649, 'i', J$.G(645, J$.R(641, 'vals', vals, false), 'length'), i); J$.C(36, J$.B(106, '>', J$.R(653, 'i', i, false), J$.R(657, 'itm', itm, false))); J$.B(118, '+', i = J$.W(665, 'i', J$.B(114, '-', J$.U(110, '+', J$.R(661, 'i', i, false)), 1), i), 1)) {
                                    J$.P(693, J$.R(669, 'vals', vals, false), J$.R(673, 'i', i, false), J$.G(689, J$.R(677, 'vals', vals, false), J$.B(122, '-', J$.R(681, 'i', i, false), J$.T(685, 1, 22))));
                                    J$.P(729, J$.G(701, J$.R(697, 'this', this, false), 'recnum'), J$.R(705, 'i', i, false), J$.G(725, J$.G(713, J$.R(709, 'this', this, false), 'recnum'), J$.B(126, '-', J$.R(717, 'i', i, false), J$.T(721, 1, 22))));
                                }
                                J$.P(745, J$.R(733, 'vals', vals, false), J$.R(737, 'itm', itm, false), J$.R(741, 'key', key, false));
                                J$.P(765, J$.G(753, J$.R(749, 'this', this, false), 'recnum'), J$.R(757, 'itm', itm, false), J$.R(761, 'rec', rec, false));
                            }
                            return J$.Rt(773, J$.R(769, 'itm', itm, false));
                        } catch (J$e) {
                            J$.Ex(8997, J$e);
                        } finally {
                            if (J$.Fr(9001))
                                continue jalangiLabel5;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1053, J$.G(821, J$.I(typeof leaf === 'undefined' ? leaf = J$.R(817, 'leaf', undefined, true) : leaf = J$.R(817, 'leaf', leaf, true)), 'prototype'), 'split', J$.T(1049, function () {
                jalangiLabel6:
                    while (true) {
                        try {
                            J$.Fe(1029, arguments.callee, this);
                            arguments = J$.N(1033, 'arguments', arguments, true);
                            J$.N(1037, 'mov', mov, false);
                            J$.N(1041, 'newL', newL, false);
                            J$.N(1045, 'i', i, false);
                            var mov = J$.W(849, 'mov', J$.M(845, J$.I(typeof Math === 'undefined' ? Math = J$.R(825, 'Math', undefined, true) : Math = J$.R(825, 'Math', Math, true)), 'floor', false)(J$.B(130, '/', J$.G(837, J$.G(833, J$.R(829, 'this', this, false), 'keyval'), 'length'), J$.T(841, 2, 22))), mov);
                            var newL = J$.W(865, 'newL', J$.T(861, J$.F(857, J$.I(typeof leaf === 'undefined' ? leaf = J$.R(853, 'leaf', undefined, true) : leaf = J$.R(853, 'leaf', leaf, true)), true)(), 11), newL);
                            for (var i = J$.W(877, 'i', J$.B(134, '-', J$.R(869, 'mov', mov, false), J$.T(873, 1, 22)), i); J$.C(44, J$.B(138, '>=', J$.R(881, 'i', i, false), J$.T(885, 0, 22))); J$.B(150, '+', i = J$.W(893, 'i', J$.B(146, '-', J$.U(142, '+', J$.R(889, 'i', i, false)), 1), i), 1)) {
                                J$.P(921, J$.G(901, J$.R(897, 'newL', newL, false), 'keyval'), J$.R(905, 'i', i, false), J$.M(917, J$.G(913, J$.R(909, 'this', this, false), 'keyval'), 'pop', false)());
                                J$.P(949, J$.G(929, J$.R(925, 'newL', newL, false), 'recnum'), J$.R(933, 'i', i, false), J$.M(945, J$.G(941, J$.R(937, 'this', this, false), 'recnum'), 'pop', false)());
                            }
                            J$.P(961, J$.R(953, 'newL', newL, false), 'prevLf', J$.R(957, 'this', this, false));
                            J$.P(977, J$.R(965, 'newL', newL, false), 'nextLf', J$.G(973, J$.R(969, 'this', this, false), 'nextLf'));
                            if (J$.C(48, J$.B(154, '!==', J$.G(985, J$.R(981, 'this', this, false), 'nextLf'), J$.T(989, null, 25))))
                                J$.P(1005, J$.G(997, J$.R(993, 'this', this, false), 'nextLf'), 'prevLf', J$.R(1001, 'newL', newL, false));
                            J$.P(1017, J$.R(1009, 'this', this, false), 'nextLf', J$.R(1013, 'newL', newL, false));
                            return J$.Rt(1025, J$.R(1021, 'newL', newL, false));
                        } catch (J$e) {
                            J$.Ex(9005, J$e);
                        } finally {
                            if (J$.Fr(9009))
                                continue jalangiLabel6;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1505, J$.G(1061, J$.I(typeof leaf === 'undefined' ? leaf = J$.R(1057, 'leaf', undefined, true) : leaf = J$.R(1057, 'leaf', leaf, true)), 'prototype'), 'merge', J$.T(1501, function (frNod, paNod, frKey) {
                jalangiLabel7:
                    while (true) {
                        try {
                            J$.Fe(1469, arguments.callee, this);
                            arguments = J$.N(1473, 'arguments', arguments, true);
                            frNod = J$.N(1477, 'frNod', frNod, true);
                            paNod = J$.N(1481, 'paNod', paNod, true);
                            frKey = J$.N(1485, 'frKey', frKey, true);
                            J$.N(1489, 'i', i, false);
                            J$.N(1493, 'len', len, false);
                            J$.N(1497, 'itm', itm, false);
                            for (var i = J$.W(1081, 'i', J$.T(1065, 0, 22), i), len = J$.W(1085, 'len', J$.G(1077, J$.G(1073, J$.R(1069, 'frNod', frNod, false), 'keyval'), 'length'), len); J$.C(52, J$.B(158, '<', J$.R(1089, 'i', i, false), J$.R(1093, 'len', len, false))); J$.B(170, '-', i = J$.W(1101, 'i', J$.B(166, '+', J$.U(162, '+', J$.R(1097, 'i', i, false)), 1), i), 1)) {
                                J$.P(1141, J$.G(1109, J$.R(1105, 'this', this, false), 'keyval'), J$.G(1121, J$.G(1117, J$.R(1113, 'this', this, false), 'keyval'), 'length'), J$.G(1137, J$.G(1129, J$.R(1125, 'frNod', frNod, false), 'keyval'), J$.R(1133, 'i', i, false)));
                                J$.P(1181, J$.G(1149, J$.R(1145, 'this', this, false), 'recnum'), J$.G(1161, J$.G(1157, J$.R(1153, 'this', this, false), 'recnum'), 'length'), J$.G(1177, J$.G(1169, J$.R(1165, 'frNod', frNod, false), 'recnum'), J$.R(1173, 'i', i, false)));
                            }
                            J$.P(1197, J$.R(1185, 'this', this, false), 'nextLf', J$.G(1193, J$.R(1189, 'frNod', frNod, false), 'nextLf'));
                            if (J$.C(56, J$.B(174, '!==', J$.G(1205, J$.R(1201, 'frNod', frNod, false), 'nextLf'), J$.T(1209, null, 25))))
                                J$.P(1225, J$.G(1217, J$.R(1213, 'frNod', frNod, false), 'nextLf'), 'prevLf', J$.R(1221, 'this', this, false));
                            J$.P(1237, J$.R(1229, 'frNod', frNod, false), 'prevLf', J$.T(1233, null, 25));
                            J$.P(1249, J$.R(1241, 'frNod', frNod, false), 'nextLf', J$.T(1245, null, 25));
                            var itm = J$.W(1269, 'itm', J$.B(178, '-', J$.G(1261, J$.G(1257, J$.R(1253, 'paNod', paNod, false), 'keyval'), 'length'), J$.T(1265, 1, 22)), itm);
                            for (var i = J$.W(1277, 'i', J$.R(1273, 'itm', itm, false), i); J$.C(64, J$.B(182, '>=', J$.R(1281, 'i', i, false), J$.T(1285, 0, 22))); J$.B(194, '+', i = J$.W(1293, 'i', J$.B(190, '-', J$.U(186, '+', J$.R(1289, 'i', i, false)), 1), i), 1)) {
                                if (J$.C(60, J$.B(198, '==', J$.G(1309, J$.G(1301, J$.R(1297, 'paNod', paNod, false), 'keyval'), J$.R(1305, 'i', i, false)), J$.R(1313, 'frKey', frKey, false)))) {
                                    itm = J$.W(1321, 'itm', J$.R(1317, 'i', i, false), itm);
                                    break;
                                }
                            }
                            for (var i = J$.W(1345, 'i', J$.R(1325, 'itm', itm, false), i), len = J$.W(1349, 'len', J$.B(202, '-', J$.G(1337, J$.G(1333, J$.R(1329, 'paNod', paNod, false), 'keyval'), 'length'), J$.T(1341, 1, 22)), len); J$.C(68, J$.B(206, '<', J$.R(1353, 'i', i, false), J$.R(1357, 'len', len, false))); J$.B(218, '-', i = J$.W(1365, 'i', J$.B(214, '+', J$.U(210, '+', J$.R(1361, 'i', i, false)), 1), i), 1)) {
                                J$.P(1401, J$.G(1373, J$.R(1369, 'paNod', paNod, false), 'keyval'), J$.R(1377, 'i', i, false), J$.G(1397, J$.G(1385, J$.R(1381, 'paNod', paNod, false), 'keyval'), J$.B(222, '+', J$.R(1389, 'i', i, false), J$.T(1393, 1, 22))));
                                J$.P(1441, J$.G(1409, J$.R(1405, 'paNod', paNod, false), 'nodptr'), J$.B(226, '+', J$.R(1413, 'i', i, false), J$.T(1417, 1, 22)), J$.G(1437, J$.G(1425, J$.R(1421, 'paNod', paNod, false), 'nodptr'), J$.B(230, '+', J$.R(1429, 'i', i, false), J$.T(1433, 2, 22))));
                            }
                            J$.M(1453, J$.G(1449, J$.R(1445, 'paNod', paNod, false), 'keyval'), 'pop', false)();
                            J$.M(1465, J$.G(1461, J$.R(1457, 'paNod', paNod, false), 'nodptr'), 'pop', false)();
                        } catch (J$e) {
                            J$.Ex(9013, J$e);
                        } finally {
                            if (J$.Fr(9017))
                                continue jalangiLabel7;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1537, J$.G(1513, J$.I(typeof node === 'undefined' ? node = J$.R(1509, 'node', undefined, true) : node = J$.R(1509, 'node', node, true)), 'prototype'), 'isLeaf', J$.T(1533, function () {
                jalangiLabel8:
                    while (true) {
                        try {
                            J$.Fe(1525, arguments.callee, this);
                            arguments = J$.N(1529, 'arguments', arguments, true);
                            return J$.Rt(1521, J$.T(1517, false, 23));
                        } catch (J$e) {
                            J$.Ex(9021, J$e);
                        } finally {
                            if (J$.Fr(9025))
                                continue jalangiLabel8;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1661, J$.G(1545, J$.I(typeof node === 'undefined' ? node = J$.R(1541, 'node', undefined, true) : node = J$.R(1541, 'node', node, true)), 'prototype'), 'getItem', J$.T(1657, function (key) {
                jalangiLabel9:
                    while (true) {
                        try {
                            J$.Fe(1633, arguments.callee, this);
                            arguments = J$.N(1637, 'arguments', arguments, true);
                            key = J$.N(1641, 'key', key, true);
                            J$.N(1645, 'vals', vals, false);
                            J$.N(1649, 'i', i, false);
                            J$.N(1653, 'len', len, false);
                            var vals = J$.W(1557, 'vals', J$.G(1553, J$.R(1549, 'this', this, false), 'keyval'), vals);
                            for (var i = J$.W(1573, 'i', J$.T(1561, 0, 22), i), len = J$.W(1577, 'len', J$.G(1569, J$.R(1565, 'vals', vals, false), 'length'), len); J$.C(76, J$.B(234, '<', J$.R(1581, 'i', i, false), J$.R(1585, 'len', len, false))); J$.B(246, '-', i = J$.W(1593, 'i', J$.B(242, '+', J$.U(238, '+', J$.R(1589, 'i', i, false)), 1), i), 1)) {
                                if (J$.C(72, J$.B(250, '<', J$.R(1597, 'key', key, false), J$.G(1609, J$.R(1601, 'vals', vals, false), J$.R(1605, 'i', i, false)))))
                                    return J$.Rt(1617, J$.R(1613, 'i', i, false));
                            }
                            return J$.Rt(1629, J$.G(1625, J$.R(1621, 'vals', vals, false), 'length'));
                        } catch (J$e) {
                            J$.Ex(9029, J$e);
                        } finally {
                            if (J$.Fr(9033))
                                continue jalangiLabel9;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1949, J$.G(1669, J$.I(typeof node === 'undefined' ? node = J$.R(1665, 'node', undefined, true) : node = J$.R(1665, 'node', node, true)), 'prototype'), 'addKey', J$.T(1945, function (key, ptrL, ptrR) {
                jalangiLabel10:
                    while (true) {
                        try {
                            J$.Fe(1909, arguments.callee, this);
                            arguments = J$.N(1913, 'arguments', arguments, true);
                            key = J$.N(1917, 'key', key, true);
                            ptrL = J$.N(1921, 'ptrL', ptrL, true);
                            ptrR = J$.N(1925, 'ptrR', ptrR, true);
                            J$.N(1929, 'vals', vals, false);
                            J$.N(1933, 'itm', itm, false);
                            J$.N(1937, 'i', i, false);
                            J$.N(1941, 'len', len, false);
                            var vals = J$.W(1681, 'vals', J$.G(1677, J$.R(1673, 'this', this, false), 'keyval'), vals);
                            var itm = J$.W(1693, 'itm', J$.G(1689, J$.R(1685, 'vals', vals, false), 'length'), itm);
                            for (var i = J$.W(1709, 'i', J$.T(1697, 0, 22), i), len = J$.W(1713, 'len', J$.G(1705, J$.R(1701, 'vals', vals, false), 'length'), len); J$.C(84, J$.B(254, '<', J$.R(1717, 'i', i, false), J$.R(1721, 'len', len, false))); J$.B(266, '-', i = J$.W(1729, 'i', J$.B(262, '+', J$.U(258, '+', J$.R(1725, 'i', i, false)), 1), i), 1)) {
                                if (J$.C(80, J$.B(270, '<=', J$.R(1733, 'key', key, false), J$.G(1745, J$.R(1737, 'vals', vals, false), J$.R(1741, 'i', i, false))))) {
                                    itm = J$.W(1753, 'itm', J$.R(1749, 'i', i, false), itm);
                                    break;
                                }
                            }
                            for (var i = J$.W(1765, 'i', J$.G(1761, J$.R(1757, 'vals', vals, false), 'length'), i); J$.C(88, J$.B(274, '>', J$.R(1769, 'i', i, false), J$.R(1773, 'itm', itm, false))); J$.B(286, '+', i = J$.W(1781, 'i', J$.B(282, '-', J$.U(278, '+', J$.R(1777, 'i', i, false)), 1), i), 1)) {
                                J$.P(1809, J$.R(1785, 'vals', vals, false), J$.R(1789, 'i', i, false), J$.G(1805, J$.R(1793, 'vals', vals, false), J$.B(290, '-', J$.R(1797, 'i', i, false), J$.T(1801, 1, 22))));
                                J$.P(1845, J$.G(1817, J$.R(1813, 'this', this, false), 'nodptr'), J$.B(294, '+', J$.R(1821, 'i', i, false), J$.T(1825, 1, 22)), J$.G(1841, J$.G(1833, J$.R(1829, 'this', this, false), 'nodptr'), J$.R(1837, 'i', i, false)));
                            }
                            J$.P(1861, J$.R(1849, 'vals', vals, false), J$.R(1853, 'itm', itm, false), J$.R(1857, 'key', key, false));
                            J$.P(1881, J$.G(1869, J$.R(1865, 'this', this, false), 'nodptr'), J$.R(1873, 'itm', itm, false), J$.R(1877, 'ptrL', ptrL, false));
                            J$.P(1905, J$.G(1889, J$.R(1885, 'this', this, false), 'nodptr'), J$.B(298, '+', J$.R(1893, 'itm', itm, false), J$.T(1897, 1, 22)), J$.R(1901, 'ptrR', ptrR, false));
                        } catch (J$e) {
                            J$.Ex(9037, J$e);
                        } finally {
                            if (J$.Fr(9041))
                                continue jalangiLabel10;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(2153, J$.G(1957, J$.I(typeof node === 'undefined' ? node = J$.R(1953, 'node', undefined, true) : node = J$.R(1953, 'node', node, true)), 'prototype'), 'split', J$.T(2149, function () {
                jalangiLabel11:
                    while (true) {
                        try {
                            J$.Fe(2129, arguments.callee, this);
                            arguments = J$.N(2133, 'arguments', arguments, true);
                            J$.N(2137, 'mov', mov, false);
                            J$.N(2141, 'newN', newN, false);
                            J$.N(2145, 'i', i, false);
                            var mov = J$.W(1989, 'mov', J$.B(306, '-', J$.M(1981, J$.I(typeof Math === 'undefined' ? Math = J$.R(1961, 'Math', undefined, true) : Math = J$.R(1961, 'Math', Math, true)), 'ceil', false)(J$.B(302, '/', J$.G(1973, J$.G(1969, J$.R(1965, 'this', this, false), 'keyval'), 'length'), J$.T(1977, 2, 22))), J$.T(1985, 1, 22)), mov);
                            var newN = J$.W(2005, 'newN', J$.T(2001, J$.F(1997, J$.I(typeof node === 'undefined' ? node = J$.R(1993, 'node', undefined, true) : node = J$.R(1993, 'node', node, true)), true)(), 11), newN);
                            J$.P(2033, J$.G(2013, J$.R(2009, 'newN', newN, false), 'nodptr'), J$.R(2017, 'mov', mov, false), J$.M(2029, J$.G(2025, J$.R(2021, 'this', this, false), 'nodptr'), 'pop', false)());
                            for (var i = J$.W(2045, 'i', J$.B(310, '-', J$.R(2037, 'mov', mov, false), J$.T(2041, 1, 22)), i); J$.C(92, J$.B(314, '>=', J$.R(2049, 'i', i, false), J$.T(2053, 0, 22))); J$.B(326, '+', i = J$.W(2061, 'i', J$.B(322, '-', J$.U(318, '+', J$.R(2057, 'i', i, false)), 1), i), 1)) {
                                J$.P(2089, J$.G(2069, J$.R(2065, 'newN', newN, false), 'keyval'), J$.R(2073, 'i', i, false), J$.M(2085, J$.G(2081, J$.R(2077, 'this', this, false), 'keyval'), 'pop', false)());
                                J$.P(2117, J$.G(2097, J$.R(2093, 'newN', newN, false), 'nodptr'), J$.R(2101, 'i', i, false), J$.M(2113, J$.G(2109, J$.R(2105, 'this', this, false), 'nodptr'), 'pop', false)());
                            }
                            return J$.Rt(2125, J$.R(2121, 'newN', newN, false));
                        } catch (J$e) {
                            J$.Ex(9045, J$e);
                        } finally {
                            if (J$.Fr(9049))
                                continue jalangiLabel11;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(2573, J$.G(2161, J$.I(typeof node === 'undefined' ? node = J$.R(2157, 'node', undefined, true) : node = J$.R(2157, 'node', node, true)), 'prototype'), 'merge', J$.T(2569, function (frNod, paNod, paItm) {
                jalangiLabel12:
                    while (true) {
                        try {
                            J$.Fe(2537, arguments.callee, this);
                            arguments = J$.N(2541, 'arguments', arguments, true);
                            frNod = J$.N(2545, 'frNod', frNod, true);
                            paNod = J$.N(2549, 'paNod', paNod, true);
                            paItm = J$.N(2553, 'paItm', paItm, true);
                            J$.N(2557, 'del', del, false);
                            J$.N(2561, 'i', i, false);
                            J$.N(2565, 'len', len, false);
                            var del = J$.W(2181, 'del', J$.G(2177, J$.G(2169, J$.R(2165, 'paNod', paNod, false), 'keyval'), J$.R(2173, 'paItm', paItm, false)), del);
                            J$.P(2209, J$.G(2189, J$.R(2185, 'this', this, false), 'keyval'), J$.G(2201, J$.G(2197, J$.R(2193, 'this', this, false), 'keyval'), 'length'), J$.R(2205, 'del', del, false));
                            for (var i = J$.W(2229, 'i', J$.T(2213, 0, 22), i), len = J$.W(2233, 'len', J$.G(2225, J$.G(2221, J$.R(2217, 'frNod', frNod, false), 'keyval'), 'length'), len); J$.C(96, J$.B(330, '<', J$.R(2237, 'i', i, false), J$.R(2241, 'len', len, false))); J$.B(342, '-', i = J$.W(2249, 'i', J$.B(338, '+', J$.U(334, '+', J$.R(2245, 'i', i, false)), 1), i), 1)) {
                                J$.P(2289, J$.G(2257, J$.R(2253, 'this', this, false), 'keyval'), J$.G(2269, J$.G(2265, J$.R(2261, 'this', this, false), 'keyval'), 'length'), J$.G(2285, J$.G(2277, J$.R(2273, 'frNod', frNod, false), 'keyval'), J$.R(2281, 'i', i, false)));
                                J$.P(2329, J$.G(2297, J$.R(2293, 'this', this, false), 'nodptr'), J$.G(2309, J$.G(2305, J$.R(2301, 'this', this, false), 'nodptr'), 'length'), J$.G(2325, J$.G(2317, J$.R(2313, 'frNod', frNod, false), 'nodptr'), J$.R(2321, 'i', i, false)));
                            }
                            J$.P(2381, J$.G(2337, J$.R(2333, 'this', this, false), 'nodptr'), J$.G(2349, J$.G(2345, J$.R(2341, 'this', this, false), 'nodptr'), 'length'), J$.G(2377, J$.G(2357, J$.R(2353, 'frNod', frNod, false), 'nodptr'), J$.B(346, '-', J$.G(2369, J$.G(2365, J$.R(2361, 'frNod', frNod, false), 'nodptr'), 'length'), J$.T(2373, 1, 22))));
                            for (var i = J$.W(2405, 'i', J$.R(2385, 'paItm', paItm, false), i), len = J$.W(2409, 'len', J$.B(350, '-', J$.G(2397, J$.G(2393, J$.R(2389, 'paNod', paNod, false), 'keyval'), 'length'), J$.T(2401, 1, 22)), len); J$.C(100, J$.B(354, '<', J$.R(2413, 'i', i, false), J$.R(2417, 'len', len, false))); J$.B(366, '-', i = J$.W(2425, 'i', J$.B(362, '+', J$.U(358, '+', J$.R(2421, 'i', i, false)), 1), i), 1)) {
                                J$.P(2461, J$.G(2433, J$.R(2429, 'paNod', paNod, false), 'keyval'), J$.R(2437, 'i', i, false), J$.G(2457, J$.G(2445, J$.R(2441, 'paNod', paNod, false), 'keyval'), J$.B(370, '+', J$.R(2449, 'i', i, false), J$.T(2453, 1, 22))));
                                J$.P(2501, J$.G(2469, J$.R(2465, 'paNod', paNod, false), 'nodptr'), J$.B(374, '+', J$.R(2473, 'i', i, false), J$.T(2477, 1, 22)), J$.G(2497, J$.G(2485, J$.R(2481, 'paNod', paNod, false), 'nodptr'), J$.B(378, '+', J$.R(2489, 'i', i, false), J$.T(2493, 2, 22))));
                            }
                            J$.M(2513, J$.G(2509, J$.R(2505, 'paNod', paNod, false), 'keyval'), 'pop', false)();
                            J$.M(2525, J$.G(2521, J$.R(2517, 'paNod', paNod, false), 'nodptr'), 'pop', false)();
                            return J$.Rt(2533, J$.R(2529, 'del', del, false));
                        } catch (J$e) {
                            J$.Ex(9053, J$e);
                        } finally {
                            if (J$.Fr(9057))
                                continue jalangiLabel12;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(3277, J$.G(2581, J$.I(typeof tree === 'undefined' ? tree = J$.R(2577, 'tree', undefined, true) : tree = J$.R(2577, 'tree', tree, true)), 'prototype'), 'insert', J$.T(3273, function (key, rec) {
                jalangiLabel13:
                    while (true) {
                        try {
                            J$.Fe(3233, arguments.callee, this);
                            arguments = J$.N(3237, 'arguments', arguments, true);
                            key = J$.N(3241, 'key', key, true);
                            rec = J$.N(3245, 'rec', rec, true);
                            J$.N(3249, 'stack', stack, false);
                            J$.N(3253, 'pL', pL, false);
                            J$.N(3257, 'pR', pR, false);
                            J$.N(3261, 'ky', ky, false);
                            J$.N(3265, 'newN', newN, false);
                            J$.N(3269, 'nod', nod, false);
                            var stack = J$.W(2589, 'stack', J$.T(2585, [], 10), stack);
                            J$.P(2605, J$.R(2593, 'this', this, false), 'leaf', J$.G(2601, J$.R(2597, 'this', this, false), 'root'));
                            while (J$.C(104, J$.U(382, '!', J$.M(2617, J$.G(2613, J$.R(2609, 'this', this, false), 'leaf'), 'isLeaf', false)()))) {
                                J$.P(2641, J$.R(2621, 'stack', stack, false), J$.G(2629, J$.R(2625, 'stack', stack, false), 'length'), J$.G(2637, J$.R(2633, 'this', this, false), 'leaf'));
                                J$.P(2665, J$.R(2645, 'this', this, false), 'item', J$.M(2661, J$.G(2653, J$.R(2649, 'this', this, false), 'leaf'), 'getItem', false)(J$.R(2657, 'key', key, false)));
                                J$.P(2697, J$.R(2669, 'this', this, false), 'leaf', J$.G(2693, J$.G(2681, J$.G(2677, J$.R(2673, 'this', this, false), 'leaf'), 'nodptr'), J$.G(2689, J$.R(2685, 'this', this, false), 'item')));
                            }
                            J$.P(2725, J$.R(2701, 'this', this, false), 'item', J$.M(2721, J$.G(2709, J$.R(2705, 'this', this, false), 'leaf'), 'addKey', false)(J$.R(2713, 'key', key, false), J$.R(2717, 'rec', rec, false)));
                            J$.P(2737, J$.R(2729, 'this', this, false), 'keyval', J$.R(2733, 'key', key, false));
                            J$.P(2749, J$.R(2741, 'this', this, false), 'eof', J$.T(2745, false, 23));
                            if (J$.C(128, J$.B(390, '==', J$.G(2757, J$.R(2753, 'this', this, false), 'item'), J$.U(386, '-', J$.T(2761, 1, 22))))) {
                                J$.P(2773, J$.R(2765, 'this', this, false), 'found', J$.T(2769, true, 23));
                                J$.P(2801, J$.R(2777, 'this', this, false), 'item', J$.M(2797, J$.G(2785, J$.R(2781, 'this', this, false), 'leaf'), 'getItem', false)(J$.R(2789, 'key', key, false), J$.T(2793, false, 23)));
                                J$.P(2833, J$.R(2805, 'this', this, false), 'recnum', J$.G(2829, J$.G(2817, J$.G(2813, J$.R(2809, 'this', this, false), 'leaf'), 'recnum'), J$.G(2825, J$.R(2821, 'this', this, false), 'item')));
                            } else {
                                J$.P(2845, J$.R(2837, 'this', this, false), 'found', J$.T(2841, false, 23));
                                J$.P(2857, J$.R(2849, 'this', this, false), 'recnum', J$.R(2853, 'rec', rec, false));
                                J$.B(394, '-', J$.A(2865, J$.R(2861, 'this', this, false), 'length', '+')(1), 1);
                                if (J$.C(124, J$.B(398, '>', J$.G(2881, J$.G(2877, J$.G(2873, J$.R(2869, 'this', this, false), 'leaf'), 'keyval'), 'length'), J$.G(2889, J$.R(2885, 'this', this, false), 'maxkey')))) {
                                    var pL = J$.W(2901, 'pL', J$.G(2897, J$.R(2893, 'this', this, false), 'leaf'), pL);
                                    var pR = J$.W(2917, 'pR', J$.M(2913, J$.G(2909, J$.R(2905, 'this', this, false), 'leaf'), 'split', false)(), pR);
                                    var ky = J$.W(2937, 'ky', J$.G(2933, J$.G(2925, J$.R(2921, 'pR', pR, false), 'keyval'), J$.T(2929, 0, 22)), ky);
                                    J$.P(2965, J$.R(2941, 'this', this, false), 'item', J$.M(2961, J$.G(2949, J$.R(2945, 'this', this, false), 'leaf'), 'getItem', false)(J$.R(2953, 'key', key, false), J$.T(2957, false, 23)));
                                    if (J$.C(108, J$.B(406, '==', J$.G(2973, J$.R(2969, 'this', this, false), 'item'), J$.U(402, '-', J$.T(2977, 1, 22))))) {
                                        J$.P(2997, J$.R(2981, 'this', this, false), 'leaf', J$.G(2993, J$.G(2989, J$.R(2985, 'this', this, false), 'leaf'), 'nextLf'));
                                        J$.P(3025, J$.R(3001, 'this', this, false), 'item', J$.M(3021, J$.G(3009, J$.R(3005, 'this', this, false), 'leaf'), 'getItem', false)(J$.R(3013, 'key', key, false), J$.T(3017, false, 23)));
                                    }
                                    while (J$.C(120, J$.T(3029, true, 23))) {
                                        if (J$.C(112, J$.B(410, '==', J$.G(3037, J$.R(3033, 'stack', stack, false), 'length'), J$.T(3041, 0, 22)))) {
                                            var newN = J$.W(3057, 'newN', J$.T(3053, J$.F(3049, J$.I(typeof node === 'undefined' ? node = J$.R(3045, 'node', undefined, true) : node = J$.R(3045, 'node', node, true)), true)(), 11), newN);
                                            J$.P(3077, J$.G(3065, J$.R(3061, 'newN', newN, false), 'keyval'), J$.T(3069, 0, 22), J$.R(3073, 'ky', ky, false));
                                            J$.P(3097, J$.G(3085, J$.R(3081, 'newN', newN, false), 'nodptr'), J$.T(3089, 0, 22), J$.R(3093, 'pL', pL, false));
                                            J$.P(3117, J$.G(3105, J$.R(3101, 'newN', newN, false), 'nodptr'), J$.T(3109, 1, 22), J$.R(3113, 'pR', pR, false));
                                            J$.P(3129, J$.R(3121, 'this', this, false), 'root', J$.R(3125, 'newN', newN, false));
                                            break;
                                        }
                                        var nod = J$.W(3141, 'nod', J$.M(3137, J$.R(3133, 'stack', stack, false), 'pop', false)(), nod);
                                        J$.M(3161, J$.R(3145, 'nod', nod, false), 'addKey', false)(J$.R(3149, 'ky', ky, false), J$.R(3153, 'pL', pL, false), J$.R(3157, 'pR', pR, false));
                                        if (J$.C(116, J$.B(414, '<=', J$.G(3173, J$.G(3169, J$.R(3165, 'nod', nod, false), 'keyval'), 'length'), J$.G(3181, J$.R(3177, 'this', this, false), 'maxkey'))))
                                            break;
                                        pL = J$.W(3189, 'pL', J$.R(3185, 'nod', nod, false), pL);
                                        pR = J$.W(3201, 'pR', J$.M(3197, J$.R(3193, 'nod', nod, false), 'split', false)(), pR);
                                        ky = J$.W(3217, 'ky', J$.M(3213, J$.G(3209, J$.R(3205, 'nod', nod, false), 'keyval'), 'pop', false)(), ky);
                                    }
                                }
                            }
                            return J$.Rt(3229, J$.U(418, '!', J$.G(3225, J$.R(3221, 'this', this, false), 'found')));
                        } catch (J$e) {
                            J$.Ex(9061, J$e);
                        } finally {
                            if (J$.Fr(9065))
                                continue jalangiLabel13;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(3493, J$.G(3285, J$.I(typeof tree === 'undefined' ? tree = J$.R(3281, 'tree', undefined, true) : tree = J$.R(3281, 'tree', tree, true)), 'prototype'), 'remove', J$.T(3489, function (key) {
                jalangiLabel14:
                    while (true) {
                        try {
                            J$.Fe(3477, arguments.callee, this);
                            arguments = J$.N(3481, 'arguments', arguments, true);
                            key = J$.N(3485, 'key', key, true);
                            if (J$.C(136, J$.B(426, '==', J$.U(422, 'typeof', J$.R(3289, 'key', key, false)), J$.T(3293, 'undefined', 21)))) {
                                if (J$.C(132, J$.B(434, '==', J$.G(3301, J$.R(3297, 'this', this, false), 'item'), J$.U(430, '-', J$.T(3305, 1, 22))))) {
                                    J$.P(3317, J$.R(3309, 'this', this, false), 'eof', J$.T(3313, true, 23));
                                    J$.P(3329, J$.R(3321, 'this', this, false), 'found', J$.T(3325, false, 23));
                                    return J$.Rt(3337, J$.T(3333, false, 23));
                                }
                                key = J$.W(3365, 'key', J$.G(3361, J$.G(3349, J$.G(3345, J$.R(3341, 'this', this, false), 'leaf'), 'keyval'), J$.G(3357, J$.R(3353, 'this', this, false), 'item')), key);
                            }
                            J$.M(3377, J$.R(3369, 'this', this, false), '_del', false)(J$.R(3373, 'key', key, false));
                            if (J$.C(140, J$.U(438, '!', J$.G(3385, J$.R(3381, 'this', this, false), 'found')))) {
                                J$.P(3397, J$.R(3389, 'this', this, false), 'item', J$.U(442, '-', J$.T(3393, 1, 22)));
                                J$.P(3409, J$.R(3401, 'this', this, false), 'eof', J$.T(3405, true, 23));
                                J$.P(3421, J$.R(3413, 'this', this, false), 'keyval', J$.T(3417, '', 21));
                                J$.P(3433, J$.R(3425, 'this', this, false), 'recnum', J$.U(446, '-', J$.T(3429, 1, 22)));
                            } else {
                                J$.M(3449, J$.R(3437, 'this', this, false), 'seek', false)(J$.R(3441, 'key', key, false), J$.T(3445, true, 23));
                                J$.P(3461, J$.R(3453, 'this', this, false), 'found', J$.T(3457, true, 23));
                            }
                            return J$.Rt(3473, J$.G(3469, J$.R(3465, 'this', this, false), 'found'));
                        } catch (J$e) {
                            J$.Ex(9069, J$e);
                        } finally {
                            if (J$.Fr(9073))
                                continue jalangiLabel14;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(3901, J$.G(3501, J$.I(typeof tree === 'undefined' ? tree = J$.R(3497, 'tree', undefined, true) : tree = J$.R(3497, 'tree', tree, true)), 'prototype'), 'seek', J$.T(3897, function (key, near) {
                jalangiLabel15:
                    while (true) {
                        try {
                            J$.Fe(3881, arguments.callee, this);
                            arguments = J$.N(3885, 'arguments', arguments, true);
                            key = J$.N(3889, 'key', key, true);
                            near = J$.N(3893, 'near', near, true);
                            if (J$.C(144, J$.B(454, '!=', J$.U(450, 'typeof', J$.R(3505, 'near', near, false)), J$.T(3509, 'boolean', 21))))
                                near = J$.W(3517, 'near', J$.T(3513, false, 23), near);
                            J$.P(3533, J$.R(3521, 'this', this, false), 'leaf', J$.G(3529, J$.R(3525, 'this', this, false), 'root'));
                            while (J$.C(148, J$.U(458, '!', J$.M(3545, J$.G(3541, J$.R(3537, 'this', this, false), 'leaf'), 'isLeaf', false)()))) {
                                J$.P(3569, J$.R(3549, 'this', this, false), 'item', J$.M(3565, J$.G(3557, J$.R(3553, 'this', this, false), 'leaf'), 'getItem', false)(J$.R(3561, 'key', key, false)));
                                J$.P(3601, J$.R(3573, 'this', this, false), 'leaf', J$.G(3597, J$.G(3585, J$.G(3581, J$.R(3577, 'this', this, false), 'leaf'), 'nodptr'), J$.G(3593, J$.R(3589, 'this', this, false), 'item')));
                            }
                            J$.P(3629, J$.R(3605, 'this', this, false), 'item', J$.M(3625, J$.G(3613, J$.R(3609, 'this', this, false), 'leaf'), 'getItem', false)(J$.R(3617, 'key', key, false), J$.R(3621, 'near', near, false)));
                            if (J$.C(160, J$.C(156, J$.C(152, J$.R(3633, 'near', near, false)) ? J$.B(466, '==', J$.G(3641, J$.R(3637, 'this', this, false), 'item'), J$.U(462, '-', J$.T(3645, 1, 22))) : J$._()) ? J$.B(470, '!==', J$.G(3657, J$.G(3653, J$.R(3649, 'this', this, false), 'leaf'), 'nextLf'), J$.T(3661, null, 25)) : J$._())) {
                                J$.P(3681, J$.R(3665, 'this', this, false), 'leaf', J$.G(3677, J$.G(3673, J$.R(3669, 'this', this, false), 'leaf'), 'nextLf'));
                                J$.P(3693, J$.R(3685, 'this', this, false), 'item', J$.T(3689, 0, 22));
                            }
                            if (J$.C(164, J$.B(478, '==', J$.G(3701, J$.R(3697, 'this', this, false), 'item'), J$.U(474, '-', J$.T(3705, 1, 22))))) {
                                J$.P(3717, J$.R(3709, 'this', this, false), 'eof', J$.T(3713, true, 23));
                                J$.P(3729, J$.R(3721, 'this', this, false), 'keyval', J$.T(3725, '', 21));
                                J$.P(3741, J$.R(3733, 'this', this, false), 'found', J$.T(3737, false, 23));
                                J$.P(3753, J$.R(3745, 'this', this, false), 'recnum', J$.U(482, '-', J$.T(3749, 1, 22)));
                            } else {
                                J$.P(3765, J$.R(3757, 'this', this, false), 'eof', J$.T(3761, false, 23));
                                J$.P(3801, J$.R(3769, 'this', this, false), 'found', J$.B(486, '===', J$.G(3793, J$.G(3781, J$.G(3777, J$.R(3773, 'this', this, false), 'leaf'), 'keyval'), J$.G(3789, J$.R(3785, 'this', this, false), 'item')), J$.R(3797, 'key', key, false)));
                                J$.P(3833, J$.R(3805, 'this', this, false), 'keyval', J$.G(3829, J$.G(3817, J$.G(3813, J$.R(3809, 'this', this, false), 'leaf'), 'keyval'), J$.G(3825, J$.R(3821, 'this', this, false), 'item')));
                                J$.P(3865, J$.R(3837, 'this', this, false), 'recnum', J$.G(3861, J$.G(3849, J$.G(3845, J$.R(3841, 'this', this, false), 'leaf'), 'recnum'), J$.G(3857, J$.R(3853, 'this', this, false), 'item')));
                            }
                            return J$.Rt(3877, J$.U(490, '!', J$.G(3873, J$.R(3869, 'this', this, false), 'eof')));
                        } catch (J$e) {
                            J$.Ex(9077, J$e);
                        } finally {
                            if (J$.Fr(9081))
                                continue jalangiLabel15;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(4437, J$.G(3909, J$.I(typeof tree === 'undefined' ? tree = J$.R(3905, 'tree', undefined, true) : tree = J$.R(3905, 'tree', tree, true)), 'prototype'), 'skip', J$.T(4433, function (cnt) {
                jalangiLabel16:
                    while (true) {
                        try {
                            J$.Fe(4421, arguments.callee, this);
                            arguments = J$.N(4425, 'arguments', arguments, true);
                            cnt = J$.N(4429, 'cnt', cnt, true);
                            if (J$.C(168, J$.B(498, '!=', J$.U(494, 'typeof', J$.R(3913, 'cnt', cnt, false)), J$.T(3917, 'number', 21))))
                                cnt = J$.W(3925, 'cnt', J$.T(3921, 1, 22), cnt);
                            if (J$.C(176, J$.C(172, J$.B(506, '==', J$.G(3933, J$.R(3929, 'this', this, false), 'item'), J$.U(502, '-', J$.T(3937, 1, 22)))) ? J$._() : J$.B(510, '===', J$.G(3945, J$.R(3941, 'this', this, false), 'leaf'), J$.T(3949, null, 25))))
                                J$.P(3961, J$.R(3953, 'this', this, false), 'eof', J$.T(3957, true, 23));
                            if (J$.C(212, J$.B(514, '>', J$.R(3965, 'cnt', cnt, false), J$.T(3969, 0, 22)))) {
                                while (J$.C(188, J$.C(180, J$.U(518, '!', J$.G(3977, J$.R(3973, 'this', this, false), 'eof'))) ? J$.B(530, '<', J$.B(526, '-', J$.B(522, '-', J$.G(3993, J$.G(3989, J$.G(3985, J$.R(3981, 'this', this, false), 'leaf'), 'keyval'), 'length'), J$.G(4001, J$.R(3997, 'this', this, false), 'item')), J$.T(4005, 1, 22)), J$.R(4009, 'cnt', cnt, false)) : J$._())) {
                                    cnt = J$.W(4041, 'cnt', J$.B(538, '+', J$.B(534, '-', J$.R(4013, 'cnt', cnt, false), J$.G(4029, J$.G(4025, J$.G(4021, J$.R(4017, 'this', this, false), 'leaf'), 'keyval'), 'length')), J$.G(4037, J$.R(4033, 'this', this, false), 'item')), cnt);
                                    J$.P(4061, J$.R(4045, 'this', this, false), 'leaf', J$.G(4057, J$.G(4053, J$.R(4049, 'this', this, false), 'leaf'), 'nextLf'));
                                    if (J$.C(184, J$.B(542, '===', J$.G(4069, J$.R(4065, 'this', this, false), 'leaf'), J$.T(4073, null, 25))))
                                        J$.P(4085, J$.R(4077, 'this', this, false), 'eof', J$.T(4081, true, 23));
                                    else
                                        J$.P(4097, J$.R(4089, 'this', this, false), 'item', J$.T(4093, 0, 22));
                                }
                                if (J$.C(192, J$.U(546, '!', J$.G(4105, J$.R(4101, 'this', this, false), 'eof'))))
                                    J$.P(4125, J$.R(4109, 'this', this, false), 'item', J$.B(550, '+', J$.G(4117, J$.R(4113, 'this', this, false), 'item'), J$.R(4121, 'cnt', cnt, false)));
                            } else {
                                cnt = J$.W(4133, 'cnt', J$.U(554, '-', J$.R(4129, 'cnt', cnt, false)), cnt);
                                while (J$.C(204, J$.C(196, J$.U(558, '!', J$.G(4141, J$.R(4137, 'this', this, false), 'eof'))) ? J$.B(562, '<', J$.G(4149, J$.R(4145, 'this', this, false), 'item'), J$.R(4153, 'cnt', cnt, false)) : J$._())) {
                                    cnt = J$.W(4173, 'cnt', J$.B(570, '-', J$.B(566, '-', J$.R(4157, 'cnt', cnt, false), J$.G(4165, J$.R(4161, 'this', this, false), 'item')), J$.T(4169, 1, 22)), cnt);
                                    J$.P(4193, J$.R(4177, 'this', this, false), 'leaf', J$.G(4189, J$.G(4185, J$.R(4181, 'this', this, false), 'leaf'), 'prevLf'));
                                    if (J$.C(200, J$.B(574, '===', J$.G(4201, J$.R(4197, 'this', this, false), 'leaf'), J$.T(4205, null, 25))))
                                        J$.P(4217, J$.R(4209, 'this', this, false), 'eof', J$.T(4213, true, 23));
                                    else
                                        J$.P(4245, J$.R(4221, 'this', this, false), 'item', J$.B(578, '-', J$.G(4237, J$.G(4233, J$.G(4229, J$.R(4225, 'this', this, false), 'leaf'), 'keyval'), 'length'), J$.T(4241, 1, 22)));
                                }
                                if (J$.C(208, J$.U(582, '!', J$.G(4253, J$.R(4249, 'this', this, false), 'eof'))))
                                    J$.P(4273, J$.R(4257, 'this', this, false), 'item', J$.B(586, '-', J$.G(4265, J$.R(4261, 'this', this, false), 'item'), J$.R(4269, 'cnt', cnt, false)));
                            }
                            if (J$.C(216, J$.G(4281, J$.R(4277, 'this', this, false), 'eof'))) {
                                J$.P(4293, J$.R(4285, 'this', this, false), 'item', J$.U(590, '-', J$.T(4289, 1, 22)));
                                J$.P(4305, J$.R(4297, 'this', this, false), 'found', J$.T(4301, false, 23));
                                J$.P(4317, J$.R(4309, 'this', this, false), 'keyval', J$.T(4313, '', 21));
                                J$.P(4329, J$.R(4321, 'this', this, false), 'recnum', J$.U(594, '-', J$.T(4325, 1, 22)));
                            } else {
                                J$.P(4341, J$.R(4333, 'this', this, false), 'found', J$.T(4337, true, 23));
                                J$.P(4373, J$.R(4345, 'this', this, false), 'keyval', J$.G(4369, J$.G(4357, J$.G(4353, J$.R(4349, 'this', this, false), 'leaf'), 'keyval'), J$.G(4365, J$.R(4361, 'this', this, false), 'item')));
                                J$.P(4405, J$.R(4377, 'this', this, false), 'recnum', J$.G(4401, J$.G(4389, J$.G(4385, J$.R(4381, 'this', this, false), 'leaf'), 'recnum'), J$.G(4397, J$.R(4393, 'this', this, false), 'item')));
                            }
                            return J$.Rt(4417, J$.G(4413, J$.R(4409, 'this', this, false), 'found'));
                        } catch (J$e) {
                            J$.Ex(9085, J$e);
                        } finally {
                            if (J$.Fr(9089))
                                continue jalangiLabel16;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(4549, J$.G(4445, J$.I(typeof tree === 'undefined' ? tree = J$.R(4441, 'tree', undefined, true) : tree = J$.R(4441, 'tree', tree, true)), 'prototype'), 'goto', J$.T(4545, function (cnt) {
                jalangiLabel17:
                    while (true) {
                        try {
                            J$.Fe(4533, arguments.callee, this);
                            arguments = J$.N(4537, 'arguments', arguments, true);
                            cnt = J$.N(4541, 'cnt', cnt, true);
                            if (J$.C(228, J$.B(598, '<', J$.R(4449, 'cnt', cnt, false), J$.T(4453, 0, 22)))) {
                                J$.M(4461, J$.R(4457, 'this', this, false), 'goBottom', false)();
                                if (J$.C(220, J$.U(602, '!', J$.G(4469, J$.R(4465, 'this', this, false), 'eof'))))
                                    J$.M(4485, J$.R(4473, 'this', this, false), 'skip', false)(J$.B(606, '+', J$.R(4477, 'cnt', cnt, false), J$.T(4481, 1, 22)));
                            } else {
                                J$.M(4493, J$.R(4489, 'this', this, false), 'goTop', false)();
                                if (J$.C(224, J$.U(610, '!', J$.G(4501, J$.R(4497, 'this', this, false), 'eof'))))
                                    J$.M(4517, J$.R(4505, 'this', this, false), 'skip', false)(J$.B(614, '-', J$.R(4509, 'cnt', cnt, false), J$.T(4513, 1, 22)));
                            }
                            return J$.Rt(4529, J$.G(4525, J$.R(4521, 'this', this, false), 'found'));
                        } catch (J$e) {
                            J$.Ex(9093, J$e);
                        } finally {
                            if (J$.Fr(9097))
                                continue jalangiLabel17;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(4693, J$.G(4557, J$.I(typeof tree === 'undefined' ? tree = J$.R(4553, 'tree', undefined, true) : tree = J$.R(4553, 'tree', tree, true)), 'prototype'), 'keynum', J$.T(4689, function () {
                jalangiLabel18:
                    while (true) {
                        try {
                            J$.Fe(4673, arguments.callee, this);
                            arguments = J$.N(4677, 'arguments', arguments, true);
                            J$.N(4681, 'cnt', cnt, false);
                            J$.N(4685, 'ptr', ptr, false);
                            if (J$.C(236, J$.C(232, J$.B(618, '===', J$.G(4565, J$.R(4561, 'this', this, false), 'leaf'), J$.T(4569, null, 25))) ? J$._() : J$.B(626, '==', J$.G(4577, J$.R(4573, 'this', this, false), 'item'), J$.U(622, '-', J$.T(4581, 1, 22)))))
                                return J$.Rt(4589, J$.U(630, '-', J$.T(4585, 1, 22)));
                            var cnt = J$.W(4605, 'cnt', J$.B(634, '+', J$.G(4597, J$.R(4593, 'this', this, false), 'item'), J$.T(4601, 1, 22)), cnt);
                            var ptr = J$.W(4617, 'ptr', J$.G(4613, J$.R(4609, 'this', this, false), 'leaf'), ptr);
                            while (J$.C(240, J$.B(638, '!==', J$.G(4625, J$.R(4621, 'ptr', ptr, false), 'prevLf'), J$.T(4629, null, 25)))) {
                                ptr = J$.W(4641, 'ptr', J$.G(4637, J$.R(4633, 'ptr', ptr, false), 'prevLf'), ptr);
                                cnt = J$.W(4661, 'cnt', J$.B(642, '+', J$.R(4657, 'cnt', cnt, false), J$.G(4653, J$.G(4649, J$.R(4645, 'ptr', ptr, false), 'keyval'), 'length')), cnt);
                            }
                            return J$.Rt(4669, J$.R(4665, 'cnt', cnt, false));
                        } catch (J$e) {
                            J$.Ex(9101, J$e);
                        } finally {
                            if (J$.Fr(9105))
                                continue jalangiLabel18;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(4957, J$.G(4701, J$.I(typeof tree === 'undefined' ? tree = J$.R(4697, 'tree', undefined, true) : tree = J$.R(4697, 'tree', tree, true)), 'prototype'), 'goTop', J$.T(4953, function () {
                jalangiLabel19:
                    while (true) {
                        try {
                            J$.Fe(4945, arguments.callee, this);
                            arguments = J$.N(4949, 'arguments', arguments, true);
                            J$.P(4717, J$.R(4705, 'this', this, false), 'leaf', J$.G(4713, J$.R(4709, 'this', this, false), 'root'));
                            while (J$.C(244, J$.U(646, '!', J$.M(4729, J$.G(4725, J$.R(4721, 'this', this, false), 'leaf'), 'isLeaf', false)()))) {
                                J$.P(4757, J$.R(4733, 'this', this, false), 'leaf', J$.G(4753, J$.G(4745, J$.G(4741, J$.R(4737, 'this', this, false), 'leaf'), 'nodptr'), J$.T(4749, 0, 22)));
                            }
                            if (J$.C(248, J$.B(650, '==', J$.G(4773, J$.G(4769, J$.G(4765, J$.R(4761, 'this', this, false), 'leaf'), 'keyval'), 'length'), J$.T(4777, 0, 22)))) {
                                J$.P(4789, J$.R(4781, 'this', this, false), 'item', J$.U(654, '-', J$.T(4785, 1, 22)));
                                J$.P(4801, J$.R(4793, 'this', this, false), 'eof', J$.T(4797, true, 23));
                                J$.P(4813, J$.R(4805, 'this', this, false), 'found', J$.T(4809, false, 23));
                                J$.P(4825, J$.R(4817, 'this', this, false), 'keyval', J$.T(4821, '', 21));
                                J$.P(4837, J$.R(4829, 'this', this, false), 'recnum', J$.U(658, '-', J$.T(4833, 1, 22)));
                            } else {
                                J$.P(4849, J$.R(4841, 'this', this, false), 'item', J$.T(4845, 0, 22));
                                J$.P(4861, J$.R(4853, 'this', this, false), 'eof', J$.T(4857, false, 23));
                                J$.P(4873, J$.R(4865, 'this', this, false), 'found', J$.T(4869, true, 23));
                                J$.P(4901, J$.R(4877, 'this', this, false), 'keyval', J$.G(4897, J$.G(4889, J$.G(4885, J$.R(4881, 'this', this, false), 'leaf'), 'keyval'), J$.T(4893, 0, 22)));
                                J$.P(4929, J$.R(4905, 'this', this, false), 'recnum', J$.G(4925, J$.G(4917, J$.G(4913, J$.R(4909, 'this', this, false), 'leaf'), 'recnum'), J$.T(4921, 0, 22)));
                            }
                            return J$.Rt(4941, J$.G(4937, J$.R(4933, 'this', this, false), 'found'));
                        } catch (J$e) {
                            J$.Ex(9109, J$e);
                        } finally {
                            if (J$.Fr(9113))
                                continue jalangiLabel19;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(5261, J$.G(4965, J$.I(typeof tree === 'undefined' ? tree = J$.R(4961, 'tree', undefined, true) : tree = J$.R(4961, 'tree', tree, true)), 'prototype'), 'goBottom', J$.T(5257, function () {
                jalangiLabel20:
                    while (true) {
                        try {
                            J$.Fe(5249, arguments.callee, this);
                            arguments = J$.N(5253, 'arguments', arguments, true);
                            J$.P(4981, J$.R(4969, 'this', this, false), 'leaf', J$.G(4977, J$.R(4973, 'this', this, false), 'root'));
                            while (J$.C(252, J$.U(662, '!', J$.M(4993, J$.G(4989, J$.R(4985, 'this', this, false), 'leaf'), 'isLeaf', false)()))) {
                                J$.P(5037, J$.R(4997, 'this', this, false), 'leaf', J$.G(5033, J$.G(5009, J$.G(5005, J$.R(5001, 'this', this, false), 'leaf'), 'nodptr'), J$.B(666, '-', J$.G(5025, J$.G(5021, J$.G(5017, J$.R(5013, 'this', this, false), 'leaf'), 'nodptr'), 'length'), J$.T(5029, 1, 22))));
                            }
                            if (J$.C(256, J$.B(670, '==', J$.G(5053, J$.G(5049, J$.G(5045, J$.R(5041, 'this', this, false), 'leaf'), 'keyval'), 'length'), J$.T(5057, 0, 22)))) {
                                J$.P(5069, J$.R(5061, 'this', this, false), 'item', J$.U(674, '-', J$.T(5065, 1, 22)));
                                J$.P(5081, J$.R(5073, 'this', this, false), 'eof', J$.T(5077, true, 23));
                                J$.P(5093, J$.R(5085, 'this', this, false), 'found', J$.T(5089, false, 23));
                                J$.P(5105, J$.R(5097, 'this', this, false), 'keyval', J$.T(5101, '', 21));
                                J$.P(5117, J$.R(5109, 'this', this, false), 'recnum', J$.U(678, '-', J$.T(5113, 1, 22)));
                            } else {
                                J$.P(5145, J$.R(5121, 'this', this, false), 'item', J$.B(682, '-', J$.G(5137, J$.G(5133, J$.G(5129, J$.R(5125, 'this', this, false), 'leaf'), 'keyval'), 'length'), J$.T(5141, 1, 22)));
                                J$.P(5157, J$.R(5149, 'this', this, false), 'eof', J$.T(5153, false, 23));
                                J$.P(5169, J$.R(5161, 'this', this, false), 'found', J$.T(5165, true, 23));
                                J$.P(5201, J$.R(5173, 'this', this, false), 'keyval', J$.G(5197, J$.G(5185, J$.G(5181, J$.R(5177, 'this', this, false), 'leaf'), 'keyval'), J$.G(5193, J$.R(5189, 'this', this, false), 'item')));
                                J$.P(5233, J$.R(5205, 'this', this, false), 'recnum', J$.G(5229, J$.G(5217, J$.G(5213, J$.R(5209, 'this', this, false), 'leaf'), 'recnum'), J$.G(5225, J$.R(5221, 'this', this, false), 'item')));
                            }
                            return J$.Rt(5245, J$.G(5241, J$.R(5237, 'this', this, false), 'found'));
                        } catch (J$e) {
                            J$.Ex(9117, J$e);
                        } finally {
                            if (J$.Fr(9121))
                                continue jalangiLabel20;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(6589, J$.G(5269, J$.I(typeof tree === 'undefined' ? tree = J$.R(5265, 'tree', undefined, true) : tree = J$.R(5265, 'tree', tree, true)), 'prototype'), 'pack', J$.T(6585, function () {
                jalangiLabel21:
                    while (true) {
                        try {
                            J$.Fe(6537, arguments.callee, this);
                            arguments = J$.N(6541, 'arguments', arguments, true);
                            J$.N(6545, 'toN', toN, false);
                            J$.N(6549, 'toI', toI, false);
                            J$.N(6553, 'frN', frN, false);
                            J$.N(6557, 'frI', frI, false);
                            J$.N(6561, 'parKey', parKey, false);
                            J$.N(6565, 'parNod', parNod, false);
                            J$.N(6569, 'tmp', tmp, false);
                            J$.N(6573, 'mov', mov, false);
                            J$.N(6577, 'i', i, false);
                            J$.N(6581, 'len', len, false);
                            J$.M(5281, J$.R(5273, 'this', this, false), 'goTop', false)(J$.T(5277, 0, 22));
                            if (J$.C(260, J$.B(686, '==', J$.G(5289, J$.R(5285, 'this', this, false), 'leaf'), J$.G(5297, J$.R(5293, 'this', this, false), 'root'))))
                                return J$.Rt(5301, undefined);
                            var toN = J$.W(5317, 'toN', J$.T(5313, J$.F(5309, J$.I(typeof leaf === 'undefined' ? leaf = J$.R(5305, 'leaf', undefined, true) : leaf = J$.R(5305, 'leaf', leaf, true)), true)(), 11), toN);
                            var toI = J$.W(5325, 'toI', J$.T(5321, 0, 22), toI);
                            var frN = J$.W(5337, 'frN', J$.G(5333, J$.R(5329, 'this', this, false), 'leaf'), frN);
                            var frI = J$.W(5345, 'frI', J$.T(5341, 0, 22), frI);
                            var parKey = J$.W(5353, 'parKey', J$.T(5349, [], 10), parKey);
                            var parNod = J$.W(5361, 'parNod', J$.T(5357, [], 10), parNod);
                            while (J$.C(280, J$.T(5365, true, 23))) {
                                J$.P(5397, J$.G(5373, J$.R(5369, 'toN', toN, false), 'keyval'), J$.R(5377, 'toI', toI, false), J$.G(5393, J$.G(5385, J$.R(5381, 'frN', frN, false), 'keyval'), J$.R(5389, 'frI', frI, false)));
                                J$.P(5429, J$.G(5405, J$.R(5401, 'toN', toN, false), 'recnum'), J$.R(5409, 'toI', toI, false), J$.G(5425, J$.G(5417, J$.R(5413, 'frN', frN, false), 'recnum'), J$.R(5421, 'frI', frI, false)));
                                if (J$.C(264, J$.B(690, '==', J$.R(5433, 'toI', toI, false), J$.T(5437, 0, 22))))
                                    J$.P(5457, J$.R(5441, 'parNod', parNod, false), J$.G(5449, J$.R(5445, 'parNod', parNod, false), 'length'), J$.R(5453, 'toN', toN, false));
                                if (J$.C(272, J$.B(698, '==', J$.R(5461, 'frI', frI, false), J$.B(694, '-', J$.G(5473, J$.G(5469, J$.R(5465, 'frN', frN, false), 'keyval'), 'length'), J$.T(5477, 1, 22))))) {
                                    if (J$.C(268, J$.B(702, '===', J$.G(5485, J$.R(5481, 'frN', frN, false), 'nextLf'), J$.T(5489, null, 25))))
                                        break;
                                    frN = J$.W(5501, 'frN', J$.G(5497, J$.R(5493, 'frN', frN, false), 'nextLf'), frN);
                                    frI = J$.W(5509, 'frI', J$.T(5505, 0, 22), frI);
                                } else {
                                    J$.B(714, '-', frI = J$.W(5517, 'frI', J$.B(710, '+', J$.U(706, '+', J$.R(5513, 'frI', frI, false)), 1), frI), 1);
                                }
                                if (J$.C(276, J$.B(722, '==', J$.R(5521, 'toI', toI, false), J$.B(718, '-', J$.G(5529, J$.R(5525, 'this', this, false), 'maxkey'), J$.T(5533, 1, 22))))) {
                                    var tmp = J$.W(5549, 'tmp', J$.T(5545, J$.F(5541, J$.I(typeof leaf === 'undefined' ? leaf = J$.R(5537, 'leaf', undefined, true) : leaf = J$.R(5537, 'leaf', leaf, true)), true)(), 11), tmp);
                                    J$.P(5561, J$.R(5553, 'toN', toN, false), 'nextLf', J$.R(5557, 'tmp', tmp, false));
                                    J$.P(5573, J$.R(5565, 'tmp', tmp, false), 'prevLf', J$.R(5569, 'toN', toN, false));
                                    toN = J$.W(5581, 'toN', J$.R(5577, 'tmp', tmp, false), toN);
                                    toI = J$.W(5589, 'toI', J$.T(5585, 0, 22), toI);
                                } else {
                                    J$.B(734, '-', toI = J$.W(5597, 'toI', J$.B(730, '+', J$.U(726, '+', J$.R(5593, 'toI', toI, false)), 1), toI), 1);
                                }
                            }
                            var mov = J$.W(5621, 'mov', J$.B(738, '-', J$.G(5605, J$.R(5601, 'this', this, false), 'minkyl'), J$.G(5617, J$.G(5613, J$.R(5609, 'toN', toN, false), 'keyval'), 'length')), mov);
                            frN = J$.W(5633, 'frN', J$.G(5629, J$.R(5625, 'toN', toN, false), 'prevLf'), frN);
                            if (J$.C(296, J$.C(284, J$.B(742, '>', J$.R(5637, 'mov', mov, false), J$.T(5641, 0, 22))) ? J$.B(746, '!==', J$.R(5645, 'frN', frN, false), J$.T(5649, null, 25)) : J$._())) {
                                for (var i = J$.W(5669, 'i', J$.B(750, '-', J$.G(5661, J$.G(5657, J$.R(5653, 'toN', toN, false), 'keyval'), 'length'), J$.T(5665, 1, 22)), i); J$.C(288, J$.B(754, '>=', J$.R(5673, 'i', i, false), J$.T(5677, 0, 22))); J$.B(766, '+', i = J$.W(5685, 'i', J$.B(762, '-', J$.U(758, '+', J$.R(5681, 'i', i, false)), 1), i), 1)) {
                                    J$.P(5721, J$.G(5693, J$.R(5689, 'toN', toN, false), 'keyval'), J$.B(770, '+', J$.R(5697, 'i', i, false), J$.R(5701, 'mov', mov, false)), J$.G(5717, J$.G(5709, J$.R(5705, 'toN', toN, false), 'keyval'), J$.R(5713, 'i', i, false)));
                                    J$.P(5757, J$.G(5729, J$.R(5725, 'toN', toN, false), 'recnum'), J$.B(774, '+', J$.R(5733, 'i', i, false), J$.R(5737, 'mov', mov, false)), J$.G(5753, J$.G(5745, J$.R(5741, 'toN', toN, false), 'recnum'), J$.R(5749, 'i', i, false)));
                                }
                                for (var i = J$.W(5769, 'i', J$.B(778, '-', J$.R(5761, 'mov', mov, false), J$.T(5765, 1, 22)), i); J$.C(292, J$.B(782, '>=', J$.R(5773, 'i', i, false), J$.T(5777, 0, 22))); J$.B(794, '+', i = J$.W(5785, 'i', J$.B(790, '-', J$.U(786, '+', J$.R(5781, 'i', i, false)), 1), i), 1)) {
                                    J$.P(5813, J$.G(5793, J$.R(5789, 'toN', toN, false), 'keyval'), J$.R(5797, 'i', i, false), J$.M(5809, J$.G(5805, J$.R(5801, 'frN', frN, false), 'keyval'), 'pop', false)());
                                    J$.P(5841, J$.G(5821, J$.R(5817, 'toN', toN, false), 'recnum'), J$.R(5825, 'i', i, false), J$.M(5837, J$.G(5833, J$.R(5829, 'frN', frN, false), 'recnum'), 'pop', false)());
                                }
                            }
                            for (i = J$.W(5849, 'i', J$.T(5845, 1, 22), i), len = J$.W(5861, 'len', J$.G(5857, J$.R(5853, 'parNod', parNod, false), 'length'), len); J$.C(300, J$.B(798, '<', J$.R(5865, 'i', i, false), J$.R(5869, 'len', len, false))); J$.B(810, '-', i = J$.W(5877, 'i', J$.B(806, '+', J$.U(802, '+', J$.R(5873, 'i', i, false)), 1), i), 1)) {
                                J$.P(5917, J$.R(5881, 'parKey', parKey, false), J$.G(5889, J$.R(5885, 'parKey', parKey, false), 'length'), J$.G(5913, J$.G(5905, J$.G(5901, J$.R(5893, 'parNod', parNod, false), J$.R(5897, 'i', i, false)), 'keyval'), J$.T(5909, 0, 22)));
                            }
                            J$.P(5937, J$.R(5921, 'parKey', parKey, false), J$.G(5929, J$.R(5925, 'parKey', parKey, false), 'length'), J$.T(5933, null, 25));
                            while (J$.C(332, J$.B(814, '!==', J$.G(5949, J$.R(5941, 'parKey', parKey, false), J$.T(5945, 0, 22)), J$.T(5953, null, 25)))) {
                                kidKey = J$.W(5961, 'kidKey', J$.R(5957, 'parKey', parKey, false), J$.I(typeof kidKey === 'undefined' ? undefined : kidKey));
                                kidNod = J$.W(5969, 'kidNod', J$.R(5965, 'parNod', parNod, false), J$.I(typeof kidNod === 'undefined' ? undefined : kidNod));
                                parKey = J$.W(5977, 'parKey', J$.T(5973, [], 10), parKey);
                                parNod = J$.W(5985, 'parNod', J$.T(5981, [], 10), parNod);
                                var toI = J$.W(6001, 'toI', J$.B(818, '+', J$.G(5993, J$.R(5989, 'this', this, false), 'maxkey'), J$.T(5997, 1, 22)), toI);
                                for (var i = J$.W(6017, 'i', J$.T(6005, 0, 22), i), len = J$.W(6021, 'len', J$.G(6013, J$.I(typeof kidKey === 'undefined' ? kidKey = J$.R(6009, 'kidKey', undefined, true) : kidKey = J$.R(6009, 'kidKey', kidKey, true)), 'length'), len); J$.C(308, J$.B(822, '<', J$.R(6025, 'i', i, false), J$.R(6029, 'len', len, false))); J$.B(834, '-', i = J$.W(6037, 'i', J$.B(830, '+', J$.U(826, '+', J$.R(6033, 'i', i, false)), 1), i), 1)) {
                                    if (J$.C(304, J$.B(838, '>', J$.R(6041, 'toI', toI, false), J$.G(6049, J$.R(6045, 'this', this, false), 'maxkey')))) {
                                        toN = J$.W(6065, 'toN', J$.T(6061, J$.F(6057, J$.I(typeof node === 'undefined' ? node = J$.R(6053, 'node', undefined, true) : node = J$.R(6053, 'node', node, true)), true)(), 11), toN);
                                        toI = J$.W(6073, 'toI', J$.T(6069, 0, 22), toI);
                                        J$.P(6093, J$.R(6077, 'parNod', parNod, false), J$.G(6085, J$.R(6081, 'parNod', parNod, false), 'length'), J$.R(6089, 'toN', toN, false));
                                    }
                                    J$.P(6121, J$.G(6101, J$.R(6097, 'toN', toN, false), 'keyval'), J$.R(6105, 'toI', toI, false), J$.G(6117, J$.I(typeof kidKey === 'undefined' ? kidKey = J$.R(6109, 'kidKey', undefined, true) : kidKey = J$.R(6109, 'kidKey', kidKey, true)), J$.R(6113, 'i', i, false)));
                                    J$.P(6149, J$.G(6129, J$.R(6125, 'toN', toN, false), 'nodptr'), J$.R(6133, 'toI', toI, false), J$.G(6145, J$.I(typeof kidNod === 'undefined' ? kidNod = J$.R(6137, 'kidNod', undefined, true) : kidNod = J$.R(6137, 'kidNod', kidNod, true)), J$.R(6141, 'i', i, false)));
                                    J$.B(850, '-', toI = J$.W(6157, 'toI', J$.B(846, '+', J$.U(842, '+', J$.R(6153, 'toI', toI, false)), 1), toI), 1);
                                }
                                mov = J$.W(6185, 'mov', J$.B(858, '+', J$.B(854, '-', J$.G(6165, J$.R(6161, 'this', this, false), 'minkyn'), J$.G(6177, J$.G(6173, J$.R(6169, 'toN', toN, false), 'keyval'), 'length')), J$.T(6181, 1, 22)), mov);
                                if (J$.C(324, J$.C(312, J$.B(862, '>', J$.R(6189, 'mov', mov, false), J$.T(6193, 0, 22))) ? J$.B(866, '>', J$.G(6201, J$.R(6197, 'parNod', parNod, false), 'length'), J$.T(6205, 1, 22)) : J$._())) {
                                    for (var i = J$.W(6225, 'i', J$.B(870, '-', J$.G(6217, J$.G(6213, J$.R(6209, 'toN', toN, false), 'keyval'), 'length'), J$.T(6221, 1, 22)), i); J$.C(316, J$.B(874, '>=', J$.R(6229, 'i', i, false), J$.T(6233, 0, 22))); J$.B(886, '+', i = J$.W(6241, 'i', J$.B(882, '-', J$.U(878, '+', J$.R(6237, 'i', i, false)), 1), i), 1)) {
                                        J$.P(6277, J$.G(6249, J$.R(6245, 'toN', toN, false), 'keyval'), J$.B(890, '+', J$.R(6253, 'i', i, false), J$.R(6257, 'mov', mov, false)), J$.G(6273, J$.G(6265, J$.R(6261, 'toN', toN, false), 'keyval'), J$.R(6269, 'i', i, false)));
                                        J$.P(6313, J$.G(6285, J$.R(6281, 'toN', toN, false), 'nodptr'), J$.B(894, '+', J$.R(6289, 'i', i, false), J$.R(6293, 'mov', mov, false)), J$.G(6309, J$.G(6301, J$.R(6297, 'toN', toN, false), 'nodptr'), J$.R(6305, 'i', i, false)));
                                    }
                                    frN = J$.W(6337, 'frN', J$.G(6333, J$.R(6317, 'parNod', parNod, false), J$.B(898, '-', J$.G(6325, J$.R(6321, 'parNod', parNod, false), 'length'), J$.T(6329, 2, 22))), frN);
                                    for (var i = J$.W(6349, 'i', J$.B(902, '-', J$.R(6341, 'mov', mov, false), J$.T(6345, 1, 22)), i); J$.C(320, J$.B(906, '>=', J$.R(6353, 'i', i, false), J$.T(6357, 0, 22))); J$.B(918, '+', i = J$.W(6365, 'i', J$.B(914, '-', J$.U(910, '+', J$.R(6361, 'i', i, false)), 1), i), 1)) {
                                        J$.P(6393, J$.G(6373, J$.R(6369, 'toN', toN, false), 'keyval'), J$.R(6377, 'i', i, false), J$.M(6389, J$.G(6385, J$.R(6381, 'frN', frN, false), 'keyval'), 'pop', false)());
                                        J$.P(6421, J$.G(6401, J$.R(6397, 'toN', toN, false), 'nodptr'), J$.R(6405, 'i', i, false), J$.M(6417, J$.G(6413, J$.R(6409, 'frN', frN, false), 'nodptr'), 'pop', false)());
                                    }
                                }
                                for (var i = J$.W(6437, 'i', J$.T(6425, 0, 22), i), len = J$.W(6441, 'len', J$.G(6433, J$.R(6429, 'parNod', parNod, false), 'length'), len); J$.C(328, J$.B(922, '<', J$.R(6445, 'i', i, false), J$.R(6449, 'len', len, false))); J$.B(934, '-', i = J$.W(6457, 'i', J$.B(930, '+', J$.U(926, '+', J$.R(6453, 'i', i, false)), 1), i), 1)) {
                                    J$.P(6493, J$.R(6461, 'parKey', parKey, false), J$.G(6469, J$.R(6465, 'parKey', parKey, false), 'length'), J$.M(6489, J$.G(6485, J$.G(6481, J$.R(6473, 'parNod', parNod, false), J$.R(6477, 'i', i, false)), 'keyval'), 'pop', false)());
                                }
                            }
                            J$.P(6513, J$.R(6497, 'this', this, false), 'root', J$.G(6509, J$.R(6501, 'parNod', parNod, false), J$.T(6505, 0, 22)));
                            J$.M(6521, J$.R(6517, 'this', this, false), 'goTop', false)();
                            return J$.Rt(6533, J$.G(6529, J$.R(6525, 'this', this, false), 'found'));
                        } catch (J$e) {
                            J$.Ex(9125, J$e);
                        } finally {
                            if (J$.Fr(9129))
                                continue jalangiLabel21;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(8637, J$.G(6597, J$.I(typeof tree === 'undefined' ? tree = J$.R(6593, 'tree', undefined, true) : tree = J$.R(6593, 'tree', tree, true)), 'prototype'), '_del', J$.T(8633, function (key) {
                jalangiLabel22:
                    while (true) {
                        try {
                            J$.Fe(8581, arguments.callee, this);
                            arguments = J$.N(8585, 'arguments', arguments, true);
                            key = J$.N(8589, 'key', key, true);
                            J$.N(8593, 'stack', stack, false);
                            J$.N(8597, 'parNod', parNod, false);
                            J$.N(8601, 'parPtr', parPtr, false);
                            J$.N(8605, 'i', i, false);
                            J$.N(8609, 'len', len, false);
                            J$.N(8613, 'delKey', delKey, false);
                            J$.N(8617, 'sibL', sibL, false);
                            J$.N(8621, 'sibR', sibR, false);
                            J$.N(8625, 'curNod', curNod, false);
                            J$.N(8629, 'parItm', parItm, false);
                            var stack = J$.W(6605, 'stack', J$.T(6601, [], 10), stack);
                            var parNod = J$.W(6613, 'parNod', J$.T(6609, null, 25), parNod);
                            var parPtr = J$.W(6621, 'parPtr', J$.U(938, '-', J$.T(6617, 1, 22)), parPtr);
                            J$.P(6637, J$.R(6625, 'this', this, false), 'leaf', J$.G(6633, J$.R(6629, 'this', this, false), 'root'));
                            while (J$.C(336, J$.U(942, '!', J$.M(6649, J$.G(6645, J$.R(6641, 'this', this, false), 'leaf'), 'isLeaf', false)()))) {
                                J$.P(6673, J$.R(6653, 'stack', stack, false), J$.G(6661, J$.R(6657, 'stack', stack, false), 'length'), J$.G(6669, J$.R(6665, 'this', this, false), 'leaf'));
                                parNod = J$.W(6685, 'parNod', J$.G(6681, J$.R(6677, 'this', this, false), 'leaf'), parNod);
                                parPtr = J$.W(6705, 'parPtr', J$.M(6701, J$.G(6693, J$.R(6689, 'this', this, false), 'leaf'), 'getItem', false)(J$.R(6697, 'key', key, false)), parPtr);
                                J$.P(6733, J$.R(6709, 'this', this, false), 'leaf', J$.G(6729, J$.G(6721, J$.G(6717, J$.R(6713, 'this', this, false), 'leaf'), 'nodptr'), J$.R(6725, 'parPtr', parPtr, false)));
                            }
                            J$.P(6761, J$.R(6737, 'this', this, false), 'item', J$.M(6757, J$.G(6745, J$.R(6741, 'this', this, false), 'leaf'), 'getItem', false)(J$.R(6749, 'key', key, false), J$.T(6753, false, 23)));
                            if (J$.C(340, J$.B(950, '==', J$.G(6769, J$.R(6765, 'this', this, false), 'item'), J$.U(946, '-', J$.T(6773, 1, 22))))) {
                                J$.P(6785, J$.R(6777, 'this', this, false), 'found', J$.T(6781, false, 23));
                                return J$.Rt(6789, undefined);
                            }
                            J$.P(6801, J$.R(6793, 'this', this, false), 'found', J$.T(6797, true, 23));
                            for (var i = J$.W(6833, 'i', J$.G(6809, J$.R(6805, 'this', this, false), 'item'), i), len = J$.W(6837, 'len', J$.B(954, '-', J$.G(6825, J$.G(6821, J$.G(6817, J$.R(6813, 'this', this, false), 'leaf'), 'keyval'), 'length'), J$.T(6829, 1, 22)), len); J$.C(344, J$.B(958, '<', J$.R(6841, 'i', i, false), J$.R(6845, 'len', len, false))); J$.B(970, '-', i = J$.W(6853, 'i', J$.B(966, '+', J$.U(962, '+', J$.R(6849, 'i', i, false)), 1), i), 1)) {
                                J$.P(6897, J$.G(6865, J$.G(6861, J$.R(6857, 'this', this, false), 'leaf'), 'keyval'), J$.R(6869, 'i', i, false), J$.G(6893, J$.G(6881, J$.G(6877, J$.R(6873, 'this', this, false), 'leaf'), 'keyval'), J$.B(974, '+', J$.R(6885, 'i', i, false), J$.T(6889, 1, 22))));
                                J$.P(6941, J$.G(6909, J$.G(6905, J$.R(6901, 'this', this, false), 'leaf'), 'recnum'), J$.R(6913, 'i', i, false), J$.G(6937, J$.G(6925, J$.G(6921, J$.R(6917, 'this', this, false), 'leaf'), 'recnum'), J$.B(978, '+', J$.R(6929, 'i', i, false), J$.T(6933, 1, 22))));
                            }
                            J$.M(6957, J$.G(6953, J$.G(6949, J$.R(6945, 'this', this, false), 'leaf'), 'keyval'), 'pop', false)();
                            J$.M(6973, J$.G(6969, J$.G(6965, J$.R(6961, 'this', this, false), 'leaf'), 'recnum'), 'pop', false)();
                            J$.B(982, '+', J$.A(6981, J$.R(6977, 'this', this, false), 'length', '-')(1), 1);
                            if (J$.C(348, J$.B(986, '==', J$.G(6989, J$.R(6985, 'this', this, false), 'leaf'), J$.G(6997, J$.R(6993, 'this', this, false), 'root'))))
                                return J$.Rt(7001, undefined);
                            if (J$.C(356, J$.B(990, '>=', J$.G(7017, J$.G(7013, J$.G(7009, J$.R(7005, 'this', this, false), 'leaf'), 'keyval'), 'length'), J$.G(7025, J$.R(7021, 'this', this, false), 'minkyl')))) {
                                if (J$.C(352, J$.B(994, '==', J$.G(7033, J$.R(7029, 'this', this, false), 'item'), J$.T(7037, 0, 22))))
                                    J$.M(7073, J$.R(7041, 'this', this, false), '_fixNodes', false)(J$.R(7045, 'stack', stack, false), J$.R(7049, 'key', key, false), J$.G(7069, J$.G(7061, J$.G(7057, J$.R(7053, 'this', this, false), 'leaf'), 'keyval'), J$.T(7065, 0, 22)));
                                return J$.Rt(7077, undefined);
                            }
                            var delKey;
                            var sibL = J$.W(7113, 'sibL', J$.C(360, J$.B(998, '==', J$.R(7081, 'parPtr', parPtr, false), J$.T(7085, 0, 22))) ? J$.T(7089, null, 25) : J$.G(7109, J$.G(7097, J$.R(7093, 'parNod', parNod, false), 'nodptr'), J$.B(1002, '-', J$.R(7101, 'parPtr', parPtr, false), J$.T(7105, 1, 22))), sibL);
                            if (J$.C(376, J$.C(364, J$.B(1006, '!==', J$.R(7117, 'sibL', sibL, false), J$.T(7121, null, 25))) ? J$.B(1010, '>', J$.G(7133, J$.G(7129, J$.R(7125, 'sibL', sibL, false), 'keyval'), 'length'), J$.G(7141, J$.R(7137, 'this', this, false), 'minkyl')) : J$._())) {
                                delKey = J$.W(7181, 'delKey', J$.C(368, J$.B(1014, '==', J$.G(7149, J$.R(7145, 'this', this, false), 'item'), J$.T(7153, 0, 22))) ? J$.R(7157, 'key', key, false) : J$.G(7177, J$.G(7169, J$.G(7165, J$.R(7161, 'this', this, false), 'leaf'), 'keyval'), J$.T(7173, 0, 22)), delKey);
                                for (var i = J$.W(7201, 'i', J$.G(7197, J$.G(7193, J$.G(7189, J$.R(7185, 'this', this, false), 'leaf'), 'keyval'), 'length'), i); J$.C(372, J$.B(1018, '>', J$.R(7205, 'i', i, false), J$.T(7209, 0, 22))); J$.B(1030, '+', i = J$.W(7217, 'i', J$.B(1026, '-', J$.U(1022, '+', J$.R(7213, 'i', i, false)), 1), i), 1)) {
                                    J$.P(7261, J$.G(7229, J$.G(7225, J$.R(7221, 'this', this, false), 'leaf'), 'keyval'), J$.R(7233, 'i', i, false), J$.G(7257, J$.G(7245, J$.G(7241, J$.R(7237, 'this', this, false), 'leaf'), 'keyval'), J$.B(1034, '-', J$.R(7249, 'i', i, false), J$.T(7253, 1, 22))));
                                    J$.P(7305, J$.G(7273, J$.G(7269, J$.R(7265, 'this', this, false), 'leaf'), 'recnum'), J$.R(7277, 'i', i, false), J$.G(7301, J$.G(7289, J$.G(7285, J$.R(7281, 'this', this, false), 'leaf'), 'recnum'), J$.B(1038, '-', J$.R(7293, 'i', i, false), J$.T(7297, 1, 22))));
                                }
                                J$.P(7337, J$.G(7317, J$.G(7313, J$.R(7309, 'this', this, false), 'leaf'), 'keyval'), J$.T(7321, 0, 22), J$.M(7333, J$.G(7329, J$.R(7325, 'sibL', sibL, false), 'keyval'), 'pop', false)());
                                J$.P(7369, J$.G(7349, J$.G(7345, J$.R(7341, 'this', this, false), 'leaf'), 'recnum'), J$.T(7353, 0, 22), J$.M(7365, J$.G(7361, J$.R(7357, 'sibL', sibL, false), 'recnum'), 'pop', false)());
                                J$.M(7405, J$.R(7373, 'this', this, false), '_fixNodes', false)(J$.R(7377, 'stack', stack, false), J$.R(7381, 'delKey', delKey, false), J$.G(7401, J$.G(7393, J$.G(7389, J$.R(7385, 'this', this, false), 'leaf'), 'keyval'), J$.T(7397, 0, 22)));
                                return J$.Rt(7409, undefined);
                            }
                            var sibR = J$.W(7453, 'sibR', J$.C(380, J$.B(1042, '==', J$.R(7413, 'parPtr', parPtr, false), J$.G(7425, J$.G(7421, J$.R(7417, 'parNod', parNod, false), 'keyval'), 'length'))) ? J$.T(7429, null, 25) : J$.G(7449, J$.G(7437, J$.R(7433, 'parNod', parNod, false), 'nodptr'), J$.B(1046, '+', J$.R(7441, 'parPtr', parPtr, false), J$.T(7445, 1, 22))), sibR);
                            if (J$.C(392, J$.C(384, J$.B(1050, '!==', J$.R(7457, 'sibR', sibR, false), J$.T(7461, null, 25))) ? J$.B(1054, '>', J$.G(7473, J$.G(7469, J$.R(7465, 'sibR', sibR, false), 'keyval'), 'length'), J$.G(7481, J$.R(7477, 'this', this, false), 'minkyl')) : J$._())) {
                                J$.P(7525, J$.G(7493, J$.G(7489, J$.R(7485, 'this', this, false), 'leaf'), 'keyval'), J$.G(7509, J$.G(7505, J$.G(7501, J$.R(7497, 'this', this, false), 'leaf'), 'keyval'), 'length'), J$.M(7521, J$.G(7517, J$.R(7513, 'sibR', sibR, false), 'keyval'), 'shift', false)());
                                J$.P(7569, J$.G(7537, J$.G(7533, J$.R(7529, 'this', this, false), 'leaf'), 'recnum'), J$.G(7553, J$.G(7549, J$.G(7545, J$.R(7541, 'this', this, false), 'leaf'), 'recnum'), 'length'), J$.M(7565, J$.G(7561, J$.R(7557, 'sibR', sibR, false), 'recnum'), 'shift', false)());
                                if (J$.C(388, J$.B(1058, '==', J$.G(7577, J$.R(7573, 'this', this, false), 'item'), J$.T(7581, 0, 22))))
                                    J$.M(7617, J$.R(7585, 'this', this, false), '_fixNodes', false)(J$.R(7589, 'stack', stack, false), J$.R(7593, 'key', key, false), J$.G(7613, J$.G(7605, J$.G(7601, J$.R(7597, 'this', this, false), 'leaf'), 'keyval'), J$.T(7609, 0, 22)));
                                J$.M(7681, J$.R(7621, 'this', this, false), '_fixNodes', false)(J$.R(7625, 'stack', stack, false), J$.G(7661, J$.G(7637, J$.G(7633, J$.R(7629, 'this', this, false), 'leaf'), 'keyval'), J$.B(1062, '-', J$.G(7653, J$.G(7649, J$.G(7645, J$.R(7641, 'this', this, false), 'leaf'), 'keyval'), 'length'), J$.T(7657, 1, 22))), J$.G(7677, J$.G(7669, J$.R(7665, 'sibR', sibR, false), 'keyval'), J$.T(7673, 0, 22)));
                                return J$.Rt(7685, undefined);
                            }
                            if (J$.C(404, J$.B(1066, '!==', J$.R(7689, 'sibL', sibL, false), J$.T(7693, null, 25)))) {
                                delKey = J$.W(7733, 'delKey', J$.C(396, J$.B(1070, '==', J$.G(7701, J$.R(7697, 'this', this, false), 'item'), J$.T(7705, 0, 22))) ? J$.R(7709, 'key', key, false) : J$.G(7729, J$.G(7721, J$.G(7717, J$.R(7713, 'this', this, false), 'leaf'), 'keyval'), J$.T(7725, 0, 22)), delKey);
                                J$.M(7757, J$.R(7737, 'sibL', sibL, false), 'merge', false)(J$.G(7745, J$.R(7741, 'this', this, false), 'leaf'), J$.R(7749, 'parNod', parNod, false), J$.R(7753, 'delKey', delKey, false));
                                J$.P(7769, J$.R(7761, 'this', this, false), 'leaf', J$.R(7765, 'sibL', sibL, false));
                            } else {
                                delKey = J$.W(7789, 'delKey', J$.G(7785, J$.G(7777, J$.R(7773, 'sibR', sibR, false), 'keyval'), J$.T(7781, 0, 22)), delKey);
                                J$.M(7813, J$.G(7797, J$.R(7793, 'this', this, false), 'leaf'), 'merge', false)(J$.R(7801, 'sibR', sibR, false), J$.R(7805, 'parNod', parNod, false), J$.R(7809, 'delKey', delKey, false));
                                if (J$.C(400, J$.B(1074, '==', J$.G(7821, J$.R(7817, 'this', this, false), 'item'), J$.T(7825, 0, 22))))
                                    J$.M(7861, J$.R(7829, 'this', this, false), '_fixNodes', false)(J$.R(7833, 'stack', stack, false), J$.R(7837, 'key', key, false), J$.G(7857, J$.G(7849, J$.G(7845, J$.R(7841, 'this', this, false), 'leaf'), 'keyval'), J$.T(7853, 0, 22)));
                            }
                            if (J$.C(412, J$.C(408, J$.B(1078, '==', J$.G(7869, J$.R(7865, 'stack', stack, false), 'length'), J$.T(7873, 1, 22))) ? J$.B(1082, '==', J$.G(7885, J$.G(7881, J$.R(7877, 'parNod', parNod, false), 'keyval'), 'length'), J$.T(7889, 0, 22)) : J$._())) {
                                J$.P(7905, J$.R(7893, 'this', this, false), 'root', J$.G(7901, J$.R(7897, 'this', this, false), 'leaf'));
                                return J$.Rt(7909, undefined);
                            }
                            var curNod = J$.W(7921, 'curNod', J$.M(7917, J$.R(7913, 'stack', stack, false), 'pop', false)(), curNod);
                            var parItm;
                            while (J$.C(468, J$.C(416, J$.B(1086, '<', J$.G(7933, J$.G(7929, J$.R(7925, 'curNod', curNod, false), 'keyval'), 'length'), J$.G(7941, J$.R(7937, 'this', this, false), 'minkyn'))) ? J$.B(1090, '>', J$.G(7949, J$.R(7945, 'stack', stack, false), 'length'), J$.T(7953, 0, 22)) : J$._())) {
                                parNod = J$.W(7965, 'parNod', J$.M(7961, J$.R(7957, 'stack', stack, false), 'pop', false)(), parNod);
                                parItm = J$.W(7981, 'parItm', J$.M(7977, J$.R(7969, 'parNod', parNod, false), 'getItem', false)(J$.R(7973, 'delKey', delKey, false)), parItm);
                                sibR = J$.W(8025, 'sibR', J$.C(420, J$.B(1094, '==', J$.R(7985, 'parItm', parItm, false), J$.G(7997, J$.G(7993, J$.R(7989, 'parNod', parNod, false), 'keyval'), 'length'))) ? J$.T(8001, null, 25) : J$.G(8021, J$.G(8009, J$.R(8005, 'parNod', parNod, false), 'nodptr'), J$.B(1098, '+', J$.R(8013, 'parItm', parItm, false), J$.T(8017, 1, 22))), sibR);
                                if (J$.C(428, J$.C(424, J$.B(1102, '!==', J$.R(8029, 'sibR', sibR, false), J$.T(8033, null, 25))) ? J$.B(1106, '>', J$.G(8045, J$.G(8041, J$.R(8037, 'sibR', sibR, false), 'keyval'), 'length'), J$.G(8053, J$.R(8049, 'this', this, false), 'minkyn')) : J$._())) {
                                    J$.P(8093, J$.G(8061, J$.R(8057, 'curNod', curNod, false), 'keyval'), J$.G(8073, J$.G(8069, J$.R(8065, 'curNod', curNod, false), 'keyval'), 'length'), J$.G(8089, J$.G(8081, J$.R(8077, 'parNod', parNod, false), 'keyval'), J$.R(8085, 'parItm', parItm, false)));
                                    J$.P(8121, J$.G(8101, J$.R(8097, 'parNod', parNod, false), 'keyval'), J$.R(8105, 'parItm', parItm, false), J$.M(8117, J$.G(8113, J$.R(8109, 'sibR', sibR, false), 'keyval'), 'shift', false)());
                                    J$.P(8157, J$.G(8129, J$.R(8125, 'curNod', curNod, false), 'nodptr'), J$.G(8141, J$.G(8137, J$.R(8133, 'curNod', curNod, false), 'nodptr'), 'length'), J$.M(8153, J$.G(8149, J$.R(8145, 'sibR', sibR, false), 'nodptr'), 'shift', false)());
                                    break;
                                }
                                sibL = J$.W(8193, 'sibL', J$.C(432, J$.B(1110, '==', J$.R(8161, 'parItm', parItm, false), J$.T(8165, 0, 22))) ? J$.T(8169, null, 25) : J$.G(8189, J$.G(8177, J$.R(8173, 'parNod', parNod, false), 'nodptr'), J$.B(1114, '-', J$.R(8181, 'parItm', parItm, false), J$.T(8185, 1, 22))), sibL);
                                if (J$.C(448, J$.C(436, J$.B(1118, '!==', J$.R(8197, 'sibL', sibL, false), J$.T(8201, null, 25))) ? J$.B(1122, '>', J$.G(8213, J$.G(8209, J$.R(8205, 'sibL', sibL, false), 'keyval'), 'length'), J$.G(8221, J$.R(8217, 'this', this, false), 'minkyn')) : J$._())) {
                                    for (var i = J$.W(8237, 'i', J$.G(8233, J$.G(8229, J$.R(8225, 'curNod', curNod, false), 'keyval'), 'length'), i); J$.C(440, J$.B(1126, '>', J$.R(8241, 'i', i, false), J$.T(8245, 0, 22))); J$.B(1138, '+', i = J$.W(8253, 'i', J$.B(1134, '-', J$.U(1130, '+', J$.R(8249, 'i', i, false)), 1), i), 1)) {
                                        J$.P(8289, J$.G(8261, J$.R(8257, 'curNod', curNod, false), 'keyval'), J$.R(8265, 'i', i, false), J$.G(8285, J$.G(8273, J$.R(8269, 'curNod', curNod, false), 'keyval'), J$.B(1142, '-', J$.R(8277, 'i', i, false), J$.T(8281, 1, 22))));
                                    }
                                    for (var i = J$.W(8305, 'i', J$.G(8301, J$.G(8297, J$.R(8293, 'curNod', curNod, false), 'nodptr'), 'length'), i); J$.C(444, J$.B(1146, '>', J$.R(8309, 'i', i, false), J$.T(8313, 0, 22))); J$.B(1158, '+', i = J$.W(8321, 'i', J$.B(1154, '-', J$.U(1150, '+', J$.R(8317, 'i', i, false)), 1), i), 1)) {
                                        J$.P(8357, J$.G(8329, J$.R(8325, 'curNod', curNod, false), 'nodptr'), J$.R(8333, 'i', i, false), J$.G(8353, J$.G(8341, J$.R(8337, 'curNod', curNod, false), 'nodptr'), J$.B(1162, '-', J$.R(8345, 'i', i, false), J$.T(8349, 1, 22))));
                                    }
                                    J$.P(8393, J$.G(8365, J$.R(8361, 'curNod', curNod, false), 'keyval'), J$.T(8369, 0, 22), J$.G(8389, J$.G(8377, J$.R(8373, 'parNod', parNod, false), 'keyval'), J$.B(1166, '-', J$.R(8381, 'parItm', parItm, false), J$.T(8385, 1, 22))));
                                    J$.P(8425, J$.G(8401, J$.R(8397, 'parNod', parNod, false), 'keyval'), J$.B(1170, '-', J$.R(8405, 'parItm', parItm, false), J$.T(8409, 1, 22)), J$.M(8421, J$.G(8417, J$.R(8413, 'sibL', sibL, false), 'keyval'), 'pop', false)());
                                    J$.P(8453, J$.G(8433, J$.R(8429, 'curNod', curNod, false), 'nodptr'), J$.T(8437, 0, 22), J$.M(8449, J$.G(8445, J$.R(8441, 'sibL', sibL, false), 'nodptr'), 'pop', false)());
                                    break;
                                }
                                if (J$.C(456, J$.B(1174, '!==', J$.R(8457, 'sibL', sibL, false), J$.T(8461, null, 25)))) {
                                    delKey = J$.W(8489, 'delKey', J$.M(8485, J$.R(8465, 'sibL', sibL, false), 'merge', false)(J$.R(8469, 'curNod', curNod, false), J$.R(8473, 'parNod', parNod, false), J$.B(1178, '-', J$.R(8477, 'parItm', parItm, false), J$.T(8481, 1, 22))), delKey);
                                    curNod = J$.W(8497, 'curNod', J$.R(8493, 'sibL', sibL, false), curNod);
                                } else if (J$.C(452, J$.B(1182, '!==', J$.R(8501, 'sibR', sibR, false), J$.T(8505, null, 25)))) {
                                    delKey = J$.W(8529, 'delKey', J$.M(8525, J$.R(8509, 'curNod', curNod, false), 'merge', false)(J$.R(8513, 'sibR', sibR, false), J$.R(8517, 'parNod', parNod, false), J$.R(8521, 'parItm', parItm, false)), delKey);
                                }
                                if (J$.C(464, J$.C(460, J$.B(1186, '==', J$.G(8537, J$.R(8533, 'stack', stack, false), 'length'), J$.T(8541, 0, 22))) ? J$.B(1190, '==', J$.G(8553, J$.G(8549, J$.R(8545, 'parNod', parNod, false), 'keyval'), 'length'), J$.T(8557, 0, 22)) : J$._())) {
                                    J$.P(8569, J$.R(8561, 'this', this, false), 'root', J$.R(8565, 'curNod', curNod, false));
                                    break;
                                }
                                curNod = J$.W(8577, 'curNod', J$.R(8573, 'parNod', parNod, false), curNod);
                            }
                        } catch (J$e) {
                            J$.Ex(9133, J$e);
                        } finally {
                            if (J$.Fr(9137))
                                continue jalangiLabel22;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(8821, J$.G(8645, J$.I(typeof tree === 'undefined' ? tree = J$.R(8641, 'tree', undefined, true) : tree = J$.R(8641, 'tree', tree, true)), 'prototype'), '_fixNodes', J$.T(8817, function (stk, frKey, toKey) {
                jalangiLabel23:
                    while (true) {
                        try {
                            J$.Fe(8781, arguments.callee, this);
                            arguments = J$.N(8785, 'arguments', arguments, true);
                            stk = J$.N(8789, 'stk', stk, true);
                            frKey = J$.N(8793, 'frKey', frKey, true);
                            toKey = J$.N(8797, 'toKey', toKey, true);
                            J$.N(8801, 'nod', nod, false);
                            J$.N(8805, 'lvl', lvl, false);
                            J$.N(8809, 'mor', mor, false);
                            J$.N(8813, 'i', i, false);
                            var nod, lvl = J$.W(8661, 'lvl', J$.G(8653, J$.R(8649, 'stk', stk, false), 'length'), lvl), mor = J$.W(8665, 'mor', J$.T(8657, true, 23), mor);
                            do {
                                J$.B(1202, '+', lvl = J$.W(8673, 'lvl', J$.B(1198, '-', J$.U(1194, '+', J$.R(8669, 'lvl', lvl, false)), 1), lvl), 1);
                                vals = J$.W(8693, 'vals', J$.G(8689, J$.G(8685, J$.R(8677, 'stk', stk, false), J$.R(8681, 'lvl', lvl, false)), 'keyval'), J$.I(typeof vals === 'undefined' ? undefined : vals));
                                for (var i = J$.W(8709, 'i', J$.B(1206, '-', J$.G(8701, J$.I(typeof vals === 'undefined' ? vals = J$.R(8697, 'vals', undefined, true) : vals = J$.R(8697, 'vals', vals, true)), 'length'), J$.T(8705, 1, 22)), i); J$.C(476, J$.B(1210, '>=', J$.R(8713, 'i', i, false), J$.T(8717, 0, 22))); J$.B(1222, '+', i = J$.W(8725, 'i', J$.B(1218, '-', J$.U(1214, '+', J$.R(8721, 'i', i, false)), 1), i), 1)) {
                                    if (J$.C(472, J$.B(1226, '==', J$.G(8737, J$.I(typeof vals === 'undefined' ? vals = J$.R(8729, 'vals', undefined, true) : vals = J$.R(8729, 'vals', vals, true)), J$.R(8733, 'i', i, false)), J$.R(8741, 'frKey', frKey, false)))) {
                                        J$.P(8757, J$.I(typeof vals === 'undefined' ? vals = J$.R(8745, 'vals', undefined, true) : vals = J$.R(8745, 'vals', vals, true)), J$.R(8749, 'i', i, false), J$.R(8753, 'toKey', toKey, false));
                                        mor = J$.W(8765, 'mor', J$.T(8761, false, 23), mor);
                                        break;
                                    }
                                }
                            } while (J$.C(484, J$.C(480, J$.R(8769, 'mor', mor, false)) ? J$.B(1230, '>', J$.R(8773, 'lvl', lvl, false), J$.T(8777, 0, 22)) : J$._()));
                        } catch (J$e) {
                            J$.Ex(9141, J$e);
                        } finally {
                            if (J$.Fr(9145))
                                continue jalangiLabel23;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            var t = J$.W(8845, 't', J$.T(8841, J$.F(8837, J$.I(typeof tree === 'undefined' ? tree = J$.R(8825, 'tree', undefined, true) : tree = J$.R(8825, 'tree', tree, true)), true)(J$.M(8833, J$, 'readInput', false)(J$.T(8829, 1, 22))), 11), t);
            for (var i = J$.W(8853, 'i', J$.T(8849, 0, 22), i); J$.C(488, J$.B(1234, '<', J$.R(8857, 'i', i, false), J$.T(8861, 4, 22))); J$.B(1246, '-', i = J$.W(8869, 'i', J$.B(1242, '+', J$.U(1238, '+', J$.R(8865, 'i', i, false)), 1), i), 1)) {
                J$.M(8893, J$.R(8873, 't', t, false), 'addKey', false)(J$.M(8881, J$, 'readInput', false)(J$.T(8877, 1, 22)), J$.M(8889, J$, 'readInput', false)(J$.T(8885, 1, 22)));
            }
            for (var i = J$.W(8901, 'i', J$.T(8897, 0, 22), i); J$.C(492, J$.B(1250, '<', J$.R(8905, 'i', i, false), J$.T(8909, 4, 22))); J$.B(1262, '-', i = J$.W(8917, 'i', J$.B(1258, '+', J$.U(1254, '+', J$.R(8913, 'i', i, false)), 1), i), 1)) {
                J$.M(8941, J$.R(8921, 't', t, false), 'seek', false)(J$.M(8929, J$, 'readInput', false)(J$.T(8925, 1, 22)), J$.M(8937, J$, 'readInput', false)(J$.T(8933, 1, 22)));
            }
        } catch (J$e) {
            J$.Ex(9149, J$e);
        } finally {
            if (J$.Sr(9153))
                continue jalangiLabel24;
            else
                break jalangiLabel24;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=B_plus_tree_jalangi_.js.map