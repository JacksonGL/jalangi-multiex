jalangiLabel1:
    while (true) {
        try {
            J$.Se(233, '../tests/multiex/datastructures/numeric_same_jalangi_.js');
            J$.N(237, 'numeric', numeric, false);
            var numeric = J$.W(9, 'numeric', J$.T(5, {}, 11), numeric);
            J$.P(221, J$.R(13, 'numeric', numeric, false), 'same', J$.T(217, function same(x, y) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(193, arguments.callee, this);
                            arguments = J$.N(197, 'arguments', arguments, true);
                            x = J$.N(201, 'x', x, true);
                            y = J$.N(205, 'y', y, true);
                            J$.N(209, 'i', i, false);
                            J$.N(213, 'n', n, false);
                            var i, n;
                            if (J$.C(8, J$.C(4, J$.U(10, '!', J$.B(6, 'instanceof', J$.R(17, 'x', x, false), J$.I(typeof Array === 'undefined' ? Array = J$.R(21, 'Array', undefined, true) : Array = J$.R(21, 'Array', Array, true))))) ? J$._() : J$.U(18, '!', J$.B(14, 'instanceof', J$.R(25, 'y', y, false), J$.I(typeof Array === 'undefined' ? Array = J$.R(29, 'Array', undefined, true) : Array = J$.R(29, 'Array', Array, true)))))) {
                                return J$.Rt(37, J$.T(33, false, 23));
                            }
                            n = J$.W(49, 'n', J$.G(45, J$.R(41, 'x', x, false), 'length'), n);
                            if (J$.C(12, J$.B(22, '!==', J$.R(53, 'n', n, false), J$.G(61, J$.R(57, 'y', y, false), 'length')))) {
                                return J$.Rt(69, J$.T(65, false, 23));
                            }
                            for (i = J$.W(77, 'i', J$.T(73, 0, 22), i); J$.C(28, J$.B(26, '<', J$.R(81, 'i', i, false), J$.R(85, 'n', n, false))); J$.B(38, '-', i = J$.W(93, 'i', J$.B(34, '+', J$.U(30, '+', J$.R(89, 'i', i, false)), 1), i), 1)) {
                                if (J$.C(16, J$.B(42, '===', J$.G(105, J$.R(97, 'x', x, false), J$.R(101, 'i', i, false)), J$.G(117, J$.R(109, 'y', y, false), J$.R(113, 'i', i, false))))) {
                                    continue;
                                }
                                if (J$.C(24, J$.B(50, '===', J$.U(46, 'typeof', J$.G(129, J$.R(121, 'x', x, false), J$.R(125, 'i', i, false))), J$.T(133, 'object', 21)))) {
                                    if (J$.C(20, J$.U(54, '!', J$.F(165, J$.R(137, 'same', same, false), false)(J$.G(149, J$.R(141, 'x', x, false), J$.R(145, 'i', i, false)), J$.G(161, J$.R(153, 'y', y, false), J$.R(157, 'i', i, false))))))
                                        return J$.Rt(173, J$.T(169, false, 23));
                                } else {
                                    return J$.Rt(181, J$.T(177, false, 23));
                                }
                            }
                            return J$.Rt(189, J$.T(185, true, 23));
                        } catch (J$e) {
                            J$.Ex(241, J$e);
                        } finally {
                            if (J$.Fr(245))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.M(229, J$.R(225, 'numeric', numeric, false), 'same', false)();
        } catch (J$e) {
            J$.Ex(249, J$e);
        } finally {
            if (J$.Sr(253))
                continue jalangiLabel1;
            else
                break jalangiLabel1;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=numeric_same_jalangi_.js.map