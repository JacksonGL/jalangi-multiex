jalangiLabel18:
    while (true) {
        try {
            J$.Se(2205, '../tests/multiex/datastructures/splay_jalangi_.js');
            J$.N(2209, 'kSplayTreeSize', kSplayTreeSize, false);
            J$.N(2213, 'kSplayTreeModifications', kSplayTreeModifications, false);
            J$.N(2217, 'kSplayTreePayloadDepth', kSplayTreePayloadDepth, false);
            J$.N(2221, 'splayTree', splayTree, false);
            J$.N(2229, 'GeneratePayloadTree', J$.T(2225, GeneratePayloadTree, 12), false);
            J$.N(2237, 'GenerateKey', J$.T(2233, GenerateKey, 12), false);
            J$.N(2245, 'InsertNewNode', J$.T(2241, InsertNewNode, 12), false);
            J$.N(2253, 'SplaySetup', J$.T(2249, SplaySetup, 12), false);
            J$.N(2261, 'SplayTearDown', J$.T(2257, SplayTearDown, 12), false);
            J$.N(2269, 'SplayRun', J$.T(2265, SplayRun, 12), false);
            J$.N(2277, 'SplayTree', J$.T(2273, SplayTree, 12), false);
            var kSplayTreeSize = J$.W(9, 'kSplayTreeSize', J$.T(5, 80, 22), kSplayTreeSize);
            var kSplayTreeModifications = J$.W(17, 'kSplayTreeModifications', J$.T(13, 8, 22), kSplayTreeModifications);
            var kSplayTreePayloadDepth = J$.W(25, 'kSplayTreePayloadDepth', J$.T(21, 5, 22), kSplayTreePayloadDepth);
            var splayTree = J$.W(33, 'splayTree', J$.T(29, null, 25), splayTree);
            function GeneratePayloadTree(depth, tag) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(157, arguments.callee, this);
                            arguments = J$.N(161, 'arguments', arguments, true);
                            depth = J$.N(165, 'depth', depth, true);
                            tag = J$.N(169, 'tag', tag, true);
                            if (J$.C(4, J$.B(6, '==', J$.R(37, 'depth', depth, false), J$.T(41, 0, 22)))) {
                                return J$.Rt(105, J$.T(101, {
                                    array: J$.T(85, [
                                        J$.T(45, 0, 22),
                                        J$.T(49, 1, 22),
                                        J$.T(53, 2, 22),
                                        J$.T(57, 3, 22),
                                        J$.T(61, 4, 22),
                                        J$.T(65, 5, 22),
                                        J$.T(69, 6, 22),
                                        J$.T(73, 7, 22),
                                        J$.T(77, 8, 22),
                                        J$.T(81, 9, 22)
                                    ], 10),
                                    string: J$.B(14, '+', J$.B(10, '+', J$.T(89, 'String for key ', 21), J$.R(93, 'tag', tag, false)), J$.T(97, ' in leaf node', 21))
                                }, 11));
                            } else {
                                return J$.Rt(153, J$.T(149, {
                                    left: J$.F(125, J$.R(109, 'GeneratePayloadTree', GeneratePayloadTree, false), false)(J$.B(18, '-', J$.R(113, 'depth', depth, false), J$.T(117, 1, 22)), J$.R(121, 'tag', tag, false)),
                                    right: J$.F(145, J$.R(129, 'GeneratePayloadTree', GeneratePayloadTree, false), false)(J$.B(22, '-', J$.R(133, 'depth', depth, false), J$.T(137, 1, 22)), J$.R(141, 'tag', tag, false))
                                }, 11));
                            }
                        } catch (J$e) {
                            J$.Ex(2281, J$e);
                        } finally {
                            if (J$.Fr(2285))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function GenerateKey() {
                jalangiLabel1:
                    while (true) {
                        try {
                            J$.Fe(185, arguments.callee, this);
                            arguments = J$.N(189, 'arguments', arguments, true);
                            return J$.Rt(181, J$.M(177, J$, 'readInput', false)(J$.T(173, 1, 22)));
                        } catch (J$e) {
                            J$.Ex(2289, J$e);
                        } finally {
                            if (J$.Fr(2293))
                                continue jalangiLabel1;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function InsertNewNode() {
                jalangiLabel2:
                    while (true) {
                        try {
                            J$.Fe(273, arguments.callee, this);
                            arguments = J$.N(277, 'arguments', arguments, true);
                            J$.N(281, 'key', key, false);
                            J$.N(285, 'payload', payload, false);
                            var key;
                            do {
                                key = J$.W(201, 'key', J$.F(197, J$.R(193, 'GenerateKey', GenerateKey, false), false)(), key);
                            } while (J$.C(8, J$.B(26, '!=', J$.M(213, J$.R(205, 'splayTree', splayTree, false), 'find', false)(J$.R(209, 'key', key, false)), J$.T(217, null, 25))));
                            var payload = J$.W(245, 'payload', J$.F(241, J$.R(221, 'GeneratePayloadTree', GeneratePayloadTree, false), false)(J$.R(225, 'kSplayTreePayloadDepth', kSplayTreePayloadDepth, false), J$.F(237, J$.I(typeof String === 'undefined' ? String = J$.R(229, 'String', undefined, true) : String = J$.R(229, 'String', String, true)), false)(J$.R(233, 'key', key, false))), payload);
                            J$.M(261, J$.R(249, 'splayTree', splayTree, false), 'insert', false)(J$.R(253, 'key', key, false), J$.R(257, 'payload', payload, false));
                            return J$.Rt(269, J$.R(265, 'key', key, false));
                        } catch (J$e) {
                            J$.Ex(2297, J$e);
                        } finally {
                            if (J$.Fr(2301))
                                continue jalangiLabel2;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function SplaySetup() {
                jalangiLabel3:
                    while (true) {
                        try {
                            J$.Fe(337, arguments.callee, this);
                            arguments = J$.N(341, 'arguments', arguments, true);
                            J$.N(345, 'i', i, false);
                            splayTree = J$.W(301, 'splayTree', J$.T(297, J$.F(293, J$.R(289, 'SplayTree', SplayTree, false), true)(), 11), splayTree);
                            for (var i = J$.W(309, 'i', J$.T(305, 0, 22), i); J$.C(12, J$.B(30, '<', J$.R(313, 'i', i, false), J$.R(317, 'kSplayTreeSize', kSplayTreeSize, false))); J$.B(42, '-', i = J$.W(325, 'i', J$.B(38, '+', J$.U(34, '+', J$.R(321, 'i', i, false)), 1), i), 1))
                                J$.F(333, J$.R(329, 'InsertNewNode', InsertNewNode, false), false)();
                        } catch (J$e) {
                            J$.Ex(2305, J$e);
                        } finally {
                            if (J$.Fr(2309))
                                continue jalangiLabel3;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function SplayTearDown() {
                jalangiLabel4:
                    while (true) {
                        try {
                            J$.Fe(477, arguments.callee, this);
                            arguments = J$.N(481, 'arguments', arguments, true);
                            J$.N(485, 'keys', keys, false);
                            J$.N(489, 'length', length, false);
                            J$.N(493, 'i', i, false);
                            var keys = J$.W(357, 'keys', J$.M(353, J$.R(349, 'splayTree', splayTree, false), 'exportKeys', false)(), keys);
                            splayTree = J$.W(365, 'splayTree', J$.T(361, null, 25), splayTree);
                            var length = J$.W(377, 'length', J$.G(373, J$.R(369, 'keys', keys, false), 'length'), length);
                            if (J$.C(16, J$.B(46, '!=', J$.R(381, 'length', length, false), J$.R(385, 'kSplayTreeSize', kSplayTreeSize, false)))) {
                                throw J$.T(401, J$.F(397, J$.I(typeof Error === 'undefined' ? Error = J$.R(389, 'Error', undefined, true) : Error = J$.R(389, 'Error', Error, true)), true)(J$.T(393, 'Splay tree has wrong size', 21)), 11);
                            }
                            for (var i = J$.W(409, 'i', J$.T(405, 0, 22), i); J$.C(24, J$.B(54, '<', J$.R(413, 'i', i, false), J$.B(50, '-', J$.R(417, 'length', length, false), J$.T(421, 1, 22)))); J$.B(66, '-', i = J$.W(429, 'i', J$.B(62, '+', J$.U(58, '+', J$.R(425, 'i', i, false)), 1), i), 1)) {
                                if (J$.C(20, J$.B(74, '>=', J$.G(441, J$.R(433, 'keys', keys, false), J$.R(437, 'i', i, false)), J$.G(457, J$.R(445, 'keys', keys, false), J$.B(70, '+', J$.R(449, 'i', i, false), J$.T(453, 1, 22)))))) {
                                    throw J$.T(473, J$.F(469, J$.I(typeof Error === 'undefined' ? Error = J$.R(461, 'Error', undefined, true) : Error = J$.R(461, 'Error', Error, true)), true)(J$.T(465, 'Splay tree not sorted', 21)), 11);
                                }
                            }
                        } catch (J$e) {
                            J$.Ex(2313, J$e);
                        } finally {
                            if (J$.Fr(2317))
                                continue jalangiLabel4;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function SplayRun() {
                jalangiLabel5:
                    while (true) {
                        try {
                            J$.Fe(585, arguments.callee, this);
                            arguments = J$.N(589, 'arguments', arguments, true);
                            J$.N(593, 'i', i, false);
                            J$.N(597, 'key', key, false);
                            J$.N(601, 'greatest', greatest, false);
                            for (var i = J$.W(501, 'i', J$.T(497, 0, 22), i); J$.C(32, J$.B(78, '<', J$.R(505, 'i', i, false), J$.R(509, 'kSplayTreeModifications', kSplayTreeModifications, false))); J$.B(90, '-', i = J$.W(517, 'i', J$.B(86, '+', J$.U(82, '+', J$.R(513, 'i', i, false)), 1), i), 1)) {
                                var key = J$.W(529, 'key', J$.F(525, J$.R(521, 'InsertNewNode', InsertNewNode, false), false)(), key);
                                var greatest = J$.W(545, 'greatest', J$.M(541, J$.R(533, 'splayTree', splayTree, false), 'findGreatestLessThan', false)(J$.R(537, 'key', key, false)), greatest);
                                if (J$.C(28, J$.B(94, '==', J$.R(549, 'greatest', greatest, false), J$.T(553, null, 25))))
                                    J$.M(565, J$.R(557, 'splayTree', splayTree, false), 'remove', false)(J$.R(561, 'key', key, false));
                                else
                                    J$.M(581, J$.R(569, 'splayTree', splayTree, false), 'remove', false)(J$.G(577, J$.R(573, 'greatest', greatest, false), 'key'));
                            }
                        } catch (J$e) {
                            J$.Ex(2321, J$e);
                        } finally {
                            if (J$.Fr(2325))
                                continue jalangiLabel5;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function SplayTree() {
                jalangiLabel6:
                    while (true) {
                        try {
                            J$.Fe(605, arguments.callee, this);
                            arguments = J$.N(609, 'arguments', arguments, true);
                        } catch (J$e) {
                            J$.Ex(2329, J$e);
                        } finally {
                            if (J$.Fr(2333))
                                continue jalangiLabel6;
                            else
                                return J$.Ra();
                        }
                    }
            }
            ;
            J$.P(625, J$.G(617, J$.R(613, 'SplayTree', SplayTree, false), 'prototype'), 'root_', J$.T(621, null, 25));
            J$.P(661, J$.G(633, J$.R(629, 'SplayTree', SplayTree, false), 'prototype'), 'isEmpty', J$.T(657, function () {
                jalangiLabel7:
                    while (true) {
                        try {
                            J$.Fe(649, arguments.callee, this);
                            arguments = J$.N(653, 'arguments', arguments, true);
                            return J$.Rt(645, J$.U(98, '!', J$.G(641, J$.R(637, 'this', this, false), 'root_')));
                        } catch (J$e) {
                            J$.Ex(2337, J$e);
                        } finally {
                            if (J$.Fr(2341))
                                continue jalangiLabel7;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(925, J$.G(669, J$.R(665, 'SplayTree', SplayTree, false), 'prototype'), 'insert', J$.T(921, function (key, value) {
                jalangiLabel8:
                    while (true) {
                        try {
                            J$.Fe(901, arguments.callee, this);
                            arguments = J$.N(905, 'arguments', arguments, true);
                            key = J$.N(909, 'key', key, true);
                            value = J$.N(913, 'value', value, true);
                            J$.N(917, 'node', node, false);
                            if (J$.C(36, J$.M(677, J$.R(673, 'this', this, false), 'isEmpty', false)())) {
                                J$.P(705, J$.R(681, 'this', this, false), 'root_', J$.T(701, J$.M(697, J$.R(685, 'SplayTree', SplayTree, false), 'Node', true)(J$.R(689, 'key', key, false), J$.R(693, 'value', value, false)), 11));
                                return J$.Rt(709, undefined);
                            }
                            J$.M(721, J$.R(713, 'this', this, false), 'splay_', false)(J$.R(717, 'key', key, false));
                            if (J$.C(40, J$.B(102, '==', J$.G(733, J$.G(729, J$.R(725, 'this', this, false), 'root_'), 'key'), J$.R(737, 'key', key, false)))) {
                                return J$.Rt(741, undefined);
                            }
                            var node = J$.W(765, 'node', J$.T(761, J$.M(757, J$.R(745, 'SplayTree', SplayTree, false), 'Node', true)(J$.R(749, 'key', key, false), J$.R(753, 'value', value, false)), 11), node);
                            if (J$.C(44, J$.B(106, '>', J$.R(769, 'key', key, false), J$.G(781, J$.G(777, J$.R(773, 'this', this, false), 'root_'), 'key')))) {
                                J$.P(797, J$.R(785, 'node', node, false), 'left', J$.G(793, J$.R(789, 'this', this, false), 'root_'));
                                J$.P(817, J$.R(801, 'node', node, false), 'right', J$.G(813, J$.G(809, J$.R(805, 'this', this, false), 'root_'), 'right'));
                                J$.P(833, J$.G(825, J$.R(821, 'this', this, false), 'root_'), 'right', J$.T(829, null, 25));
                            } else {
                                J$.P(849, J$.R(837, 'node', node, false), 'right', J$.G(845, J$.R(841, 'this', this, false), 'root_'));
                                J$.P(869, J$.R(853, 'node', node, false), 'left', J$.G(865, J$.G(861, J$.R(857, 'this', this, false), 'root_'), 'left'));
                                J$.P(885, J$.G(877, J$.R(873, 'this', this, false), 'root_'), 'left', J$.T(881, null, 25));
                            }
                            J$.P(897, J$.R(889, 'this', this, false), 'root_', J$.R(893, 'node', node, false));
                        } catch (J$e) {
                            J$.Ex(2345, J$e);
                        } finally {
                            if (J$.Fr(2349))
                                continue jalangiLabel8;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1145, J$.G(933, J$.R(929, 'SplayTree', SplayTree, false), 'prototype'), 'remove', J$.T(1141, function (key) {
                jalangiLabel9:
                    while (true) {
                        try {
                            J$.Fe(1121, arguments.callee, this);
                            arguments = J$.N(1125, 'arguments', arguments, true);
                            key = J$.N(1129, 'key', key, true);
                            J$.N(1133, 'removed', removed, false);
                            J$.N(1137, 'right', right, false);
                            if (J$.C(48, J$.M(941, J$.R(937, 'this', this, false), 'isEmpty', false)())) {
                                throw J$.F(957, J$.I(typeof Error === 'undefined' ? Error = J$.R(945, 'Error', undefined, true) : Error = J$.R(945, 'Error', Error, true)), false)(J$.B(110, '+', J$.T(949, 'Key not found: ', 21), J$.R(953, 'key', key, false)));
                            }
                            J$.M(969, J$.R(961, 'this', this, false), 'splay_', false)(J$.R(965, 'key', key, false));
                            if (J$.C(52, J$.B(114, '!=', J$.G(981, J$.G(977, J$.R(973, 'this', this, false), 'root_'), 'key'), J$.R(985, 'key', key, false)))) {
                                throw J$.F(1001, J$.I(typeof Error === 'undefined' ? Error = J$.R(989, 'Error', undefined, true) : Error = J$.R(989, 'Error', Error, true)), false)(J$.B(118, '+', J$.T(993, 'Key not found: ', 21), J$.R(997, 'key', key, false)));
                            }
                            var removed = J$.W(1013, 'removed', J$.G(1009, J$.R(1005, 'this', this, false), 'root_'), removed);
                            if (J$.C(56, J$.U(122, '!', J$.G(1025, J$.G(1021, J$.R(1017, 'this', this, false), 'root_'), 'left')))) {
                                J$.P(1045, J$.R(1029, 'this', this, false), 'root_', J$.G(1041, J$.G(1037, J$.R(1033, 'this', this, false), 'root_'), 'right'));
                            } else {
                                var right = J$.W(1061, 'right', J$.G(1057, J$.G(1053, J$.R(1049, 'this', this, false), 'root_'), 'right'), right);
                                J$.P(1081, J$.R(1065, 'this', this, false), 'root_', J$.G(1077, J$.G(1073, J$.R(1069, 'this', this, false), 'root_'), 'left'));
                                J$.M(1093, J$.R(1085, 'this', this, false), 'splay_', false)(J$.R(1089, 'key', key, false));
                                J$.P(1109, J$.G(1101, J$.R(1097, 'this', this, false), 'root_'), 'right', J$.R(1105, 'right', right, false));
                            }
                            return J$.Rt(1117, J$.R(1113, 'removed', removed, false));
                        } catch (J$e) {
                            J$.Ex(2353, J$e);
                        } finally {
                            if (J$.Fr(2357))
                                continue jalangiLabel9;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1233, J$.G(1153, J$.R(1149, 'SplayTree', SplayTree, false), 'prototype'), 'find', J$.T(1229, function (key) {
                jalangiLabel10:
                    while (true) {
                        try {
                            J$.Fe(1217, arguments.callee, this);
                            arguments = J$.N(1221, 'arguments', arguments, true);
                            key = J$.N(1225, 'key', key, true);
                            if (J$.C(60, J$.M(1161, J$.R(1157, 'this', this, false), 'isEmpty', false)())) {
                                return J$.Rt(1169, J$.T(1165, null, 25));
                            }
                            J$.M(1181, J$.R(1173, 'this', this, false), 'splay_', false)(J$.R(1177, 'key', key, false));
                            return J$.Rt(1213, J$.C(64, J$.B(126, '==', J$.G(1193, J$.G(1189, J$.R(1185, 'this', this, false), 'root_'), 'key'), J$.R(1197, 'key', key, false))) ? J$.G(1205, J$.R(1201, 'this', this, false), 'root_') : J$.T(1209, null, 25));
                        } catch (J$e) {
                            J$.Ex(2361, J$e);
                        } finally {
                            if (J$.Fr(2365))
                                continue jalangiLabel10;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1325, J$.G(1241, J$.R(1237, 'SplayTree', SplayTree, false), 'prototype'), 'findMax', J$.T(1321, function (opt_startNode) {
                jalangiLabel11:
                    while (true) {
                        try {
                            J$.Fe(1305, arguments.callee, this);
                            arguments = J$.N(1309, 'arguments', arguments, true);
                            opt_startNode = J$.N(1313, 'opt_startNode', opt_startNode, true);
                            J$.N(1317, 'current', current, false);
                            if (J$.C(68, J$.M(1249, J$.R(1245, 'this', this, false), 'isEmpty', false)())) {
                                return J$.Rt(1257, J$.T(1253, null, 25));
                            }
                            var current = J$.W(1273, 'current', J$.C(72, J$.R(1261, 'opt_startNode', opt_startNode, false)) ? J$._() : J$.G(1269, J$.R(1265, 'this', this, false), 'root_'), current);
                            while (J$.C(76, J$.G(1281, J$.R(1277, 'current', current, false), 'right'))) {
                                current = J$.W(1293, 'current', J$.G(1289, J$.R(1285, 'current', current, false), 'right'), current);
                            }
                            return J$.Rt(1301, J$.R(1297, 'current', current, false));
                        } catch (J$e) {
                            J$.Ex(2369, J$e);
                        } finally {
                            if (J$.Fr(2373))
                                continue jalangiLabel11;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1453, J$.G(1333, J$.R(1329, 'SplayTree', SplayTree, false), 'prototype'), 'findGreatestLessThan', J$.T(1449, function (key) {
                jalangiLabel12:
                    while (true) {
                        try {
                            J$.Fe(1437, arguments.callee, this);
                            arguments = J$.N(1441, 'arguments', arguments, true);
                            key = J$.N(1445, 'key', key, true);
                            if (J$.C(80, J$.M(1341, J$.R(1337, 'this', this, false), 'isEmpty', false)())) {
                                return J$.Rt(1349, J$.T(1345, null, 25));
                            }
                            J$.M(1361, J$.R(1353, 'this', this, false), 'splay_', false)(J$.R(1357, 'key', key, false));
                            if (J$.C(88, J$.B(130, '<', J$.G(1373, J$.G(1369, J$.R(1365, 'this', this, false), 'root_'), 'key'), J$.R(1377, 'key', key, false)))) {
                                return J$.Rt(1389, J$.G(1385, J$.R(1381, 'this', this, false), 'root_'));
                            } else if (J$.C(84, J$.G(1401, J$.G(1397, J$.R(1393, 'this', this, false), 'root_'), 'left'))) {
                                return J$.Rt(1425, J$.M(1421, J$.R(1405, 'this', this, false), 'findMax', false)(J$.G(1417, J$.G(1413, J$.R(1409, 'this', this, false), 'root_'), 'left')));
                            } else {
                                return J$.Rt(1433, J$.T(1429, null, 25));
                            }
                        } catch (J$e) {
                            J$.Ex(2377, J$e);
                        } finally {
                            if (J$.Fr(2381))
                                continue jalangiLabel12;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1549, J$.G(1461, J$.R(1457, 'SplayTree', SplayTree, false), 'prototype'), 'exportKeys', J$.T(1545, function () {
                jalangiLabel14:
                    while (true) {
                        try {
                            J$.Fe(1533, arguments.callee, this);
                            arguments = J$.N(1537, 'arguments', arguments, true);
                            J$.N(1541, 'result', result, false);
                            var result = J$.W(1469, 'result', J$.T(1465, [], 10), result);
                            if (J$.C(92, J$.U(134, '!', J$.M(1477, J$.R(1473, 'this', this, false), 'isEmpty', false)()))) {
                                J$.M(1521, J$.G(1485, J$.R(1481, 'this', this, false), 'root_'), 'traverse_', false)(J$.T(1517, function (node) {
                                    jalangiLabel13:
                                        while (true) {
                                            try {
                                                J$.Fe(1505, arguments.callee, this);
                                                arguments = J$.N(1509, 'arguments', arguments, true);
                                                node = J$.N(1513, 'node', node, true);
                                                J$.M(1501, J$.R(1489, 'result', result, false), 'push', false)(J$.G(1497, J$.R(1493, 'node', node, false), 'key'));
                                            } catch (J$e) {
                                                J$.Ex(2385, J$e);
                                            } finally {
                                                if (J$.Fr(2389))
                                                    continue jalangiLabel13;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12));
                            }
                            return J$.Rt(1529, J$.R(1525, 'result', result, false));
                        } catch (J$e) {
                            J$.Ex(2393, J$e);
                        } finally {
                            if (J$.Fr(2397))
                                continue jalangiLabel14;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(1981, J$.G(1557, J$.R(1553, 'SplayTree', SplayTree, false), 'prototype'), 'splay_', J$.T(1977, function (key) {
                jalangiLabel15:
                    while (true) {
                        try {
                            J$.Fe(1945, arguments.callee, this);
                            arguments = J$.N(1949, 'arguments', arguments, true);
                            key = J$.N(1953, 'key', key, true);
                            J$.N(1957, 'dummy', dummy, false);
                            J$.N(1961, 'left', left, false);
                            J$.N(1965, 'right', right, false);
                            J$.N(1969, 'current', current, false);
                            J$.N(1973, 'tmp', tmp, false);
                            if (J$.C(96, J$.M(1565, J$.R(1561, 'this', this, false), 'isEmpty', false)())) {
                                return J$.Rt(1569, undefined);
                            }
                            var dummy, left, right;
                            dummy = J$.W(1601, 'dummy', left = J$.W(1597, 'left', right = J$.W(1593, 'right', J$.T(1589, J$.M(1585, J$.R(1573, 'SplayTree', SplayTree, false), 'Node', true)(J$.T(1577, null, 25), J$.T(1581, null, 25)), 11), right), left), dummy);
                            var current = J$.W(1613, 'current', J$.G(1609, J$.R(1605, 'this', this, false), 'root_'), current);
                            while (J$.C(132, J$.T(1617, true, 23))) {
                                if (J$.C(128, J$.B(138, '<', J$.R(1621, 'key', key, false), J$.G(1629, J$.R(1625, 'current', current, false), 'key')))) {
                                    if (J$.C(100, J$.U(142, '!', J$.G(1637, J$.R(1633, 'current', current, false), 'left')))) {
                                        break;
                                    }
                                    if (J$.C(108, J$.B(146, '<', J$.R(1641, 'key', key, false), J$.G(1653, J$.G(1649, J$.R(1645, 'current', current, false), 'left'), 'key')))) {
                                        var tmp = J$.W(1665, 'tmp', J$.G(1661, J$.R(1657, 'current', current, false), 'left'), tmp);
                                        J$.P(1681, J$.R(1669, 'current', current, false), 'left', J$.G(1677, J$.R(1673, 'tmp', tmp, false), 'right'));
                                        J$.P(1693, J$.R(1685, 'tmp', tmp, false), 'right', J$.R(1689, 'current', current, false));
                                        current = J$.W(1701, 'current', J$.R(1697, 'tmp', tmp, false), current);
                                        if (J$.C(104, J$.U(150, '!', J$.G(1709, J$.R(1705, 'current', current, false), 'left')))) {
                                            break;
                                        }
                                    }
                                    J$.P(1721, J$.R(1713, 'right', right, false), 'left', J$.R(1717, 'current', current, false));
                                    right = J$.W(1729, 'right', J$.R(1725, 'current', current, false), right);
                                    current = J$.W(1741, 'current', J$.G(1737, J$.R(1733, 'current', current, false), 'left'), current);
                                } else if (J$.C(124, J$.B(154, '>', J$.R(1745, 'key', key, false), J$.G(1753, J$.R(1749, 'current', current, false), 'key')))) {
                                    if (J$.C(112, J$.U(158, '!', J$.G(1761, J$.R(1757, 'current', current, false), 'right')))) {
                                        break;
                                    }
                                    if (J$.C(120, J$.B(162, '>', J$.R(1765, 'key', key, false), J$.G(1777, J$.G(1773, J$.R(1769, 'current', current, false), 'right'), 'key')))) {
                                        var tmp = J$.W(1789, 'tmp', J$.G(1785, J$.R(1781, 'current', current, false), 'right'), tmp);
                                        J$.P(1805, J$.R(1793, 'current', current, false), 'right', J$.G(1801, J$.R(1797, 'tmp', tmp, false), 'left'));
                                        J$.P(1817, J$.R(1809, 'tmp', tmp, false), 'left', J$.R(1813, 'current', current, false));
                                        current = J$.W(1825, 'current', J$.R(1821, 'tmp', tmp, false), current);
                                        if (J$.C(116, J$.U(166, '!', J$.G(1833, J$.R(1829, 'current', current, false), 'right')))) {
                                            break;
                                        }
                                    }
                                    J$.P(1845, J$.R(1837, 'left', left, false), 'right', J$.R(1841, 'current', current, false));
                                    left = J$.W(1853, 'left', J$.R(1849, 'current', current, false), left);
                                    current = J$.W(1865, 'current', J$.G(1861, J$.R(1857, 'current', current, false), 'right'), current);
                                } else {
                                    break;
                                }
                            }
                            J$.P(1881, J$.R(1869, 'left', left, false), 'right', J$.G(1877, J$.R(1873, 'current', current, false), 'left'));
                            J$.P(1897, J$.R(1885, 'right', right, false), 'left', J$.G(1893, J$.R(1889, 'current', current, false), 'right'));
                            J$.P(1913, J$.R(1901, 'current', current, false), 'left', J$.G(1909, J$.R(1905, 'dummy', dummy, false), 'right'));
                            J$.P(1929, J$.R(1917, 'current', current, false), 'right', J$.G(1925, J$.R(1921, 'dummy', dummy, false), 'left'));
                            J$.P(1941, J$.R(1933, 'this', this, false), 'root_', J$.R(1937, 'current', current, false));
                        } catch (J$e) {
                            J$.Ex(2401, J$e);
                        } finally {
                            if (J$.Fr(2405))
                                continue jalangiLabel15;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(2033, J$.R(1985, 'SplayTree', SplayTree, false), 'Node', J$.T(2029, function (key, value) {
                jalangiLabel16:
                    while (true) {
                        try {
                            J$.Fe(2013, arguments.callee, this);
                            arguments = J$.N(2017, 'arguments', arguments, true);
                            key = J$.N(2021, 'key', key, true);
                            value = J$.N(2025, 'value', value, true);
                            J$.P(1997, J$.R(1989, 'this', this, false), 'key', J$.R(1993, 'key', key, false));
                            J$.P(2009, J$.R(2001, 'this', this, false), 'value', J$.R(2005, 'value', value, false));
                        } catch (J$e) {
                            J$.Ex(2409, J$e);
                        } finally {
                            if (J$.Fr(2413))
                                continue jalangiLabel16;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.P(2053, J$.G(2045, J$.G(2041, J$.R(2037, 'SplayTree', SplayTree, false), 'Node'), 'prototype'), 'left', J$.T(2049, null, 25));
            J$.P(2073, J$.G(2065, J$.G(2061, J$.R(2057, 'SplayTree', SplayTree, false), 'Node'), 'prototype'), 'right', J$.T(2069, null, 25));
            J$.P(2177, J$.G(2085, J$.G(2081, J$.R(2077, 'SplayTree', SplayTree, false), 'Node'), 'prototype'), 'traverse_', J$.T(2173, function (f) {
                jalangiLabel17:
                    while (true) {
                        try {
                            J$.Fe(2153, arguments.callee, this);
                            arguments = J$.N(2157, 'arguments', arguments, true);
                            f = J$.N(2161, 'f', f, true);
                            J$.N(2165, 'current', current, false);
                            J$.N(2169, 'left', left, false);
                            var current = J$.W(2093, 'current', J$.R(2089, 'this', this, false), current);
                            while (J$.C(140, J$.R(2097, 'current', current, false))) {
                                var left = J$.W(2109, 'left', J$.G(2105, J$.R(2101, 'current', current, false), 'left'), left);
                                if (J$.C(136, J$.R(2113, 'left', left, false)))
                                    J$.M(2125, J$.R(2117, 'left', left, false), 'traverse_', false)(J$.R(2121, 'f', f, false));
                                J$.F(2137, J$.R(2129, 'f', f, false), false)(J$.R(2133, 'current', current, false));
                                current = J$.W(2149, 'current', J$.G(2145, J$.R(2141, 'current', current, false), 'right'), current);
                            }
                        } catch (J$e) {
                            J$.Ex(2417, J$e);
                        } finally {
                            if (J$.Fr(2421))
                                continue jalangiLabel17;
                            else
                                return J$.Ra();
                        }
                    }
            }, 12));
            J$.F(2185, J$.R(2181, 'SplaySetup', SplaySetup, false), false)();
            J$.F(2193, J$.R(2189, 'SplayRun', SplayRun, false), false)();
            J$.F(2201, J$.R(2197, 'SplayTearDown', SplayTearDown, false), false)();
        } catch (J$e) {
            J$.Ex(2425, J$e);
        } finally {
            if (J$.Sr(2429))
                continue jalangiLabel18;
            else
                break jalangiLabel18;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=splay_jalangi_.js.map