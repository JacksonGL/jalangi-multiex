jalangiLabel8:
    while (true) {
        try {
            J$.Se(1077, '../tests/multiex/datastructures/binaryHeap_jalangi_.js');
            J$.N(1085, 'BinaryHeap', J$.T(1081, BinaryHeap, 12), false);
            J$.N(1089, 'heap', heap, false);
            J$.N(1093, 'i', i, false);
            function BinaryHeap(scoreFunction) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(29, arguments.callee, this);
                            arguments = J$.N(33, 'arguments', arguments, true);
                            scoreFunction = J$.N(37, 'scoreFunction', scoreFunction, true);
                            J$.P(13, J$.R(5, 'this', this, false), 'content', J$.T(9, [], 10));
                            J$.P(25, J$.R(17, 'this', this, false), 'scoreFunction', J$.R(21, 'scoreFunction', scoreFunction, false));
                        } catch (J$e) {
                            J$.Ex(1097, J$e);
                        } finally {
                            if (J$.Fr(1101))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.P(953, J$.R(41, 'BinaryHeap', BinaryHeap, false), 'prototype', J$.T(949, {
                push: J$.T(109, function (element) {
                    jalangiLabel1:
                        while (true) {
                            try {
                                J$.Fe(97, arguments.callee, this);
                                arguments = J$.N(101, 'arguments', arguments, true);
                                element = J$.N(105, 'element', element, true);
                                J$.P(69, J$.G(49, J$.R(45, 'this', this, false), 'content'), J$.G(61, J$.G(57, J$.R(53, 'this', this, false), 'content'), 'length'), J$.R(65, 'element', element, false));
                                J$.M(93, J$.R(73, 'this', this, false), 'bubbleUp', false)(J$.B(6, '-', J$.G(85, J$.G(81, J$.R(77, 'this', this, false), 'content'), 'length'), J$.T(89, 1, 22)));
                            } catch (J$e) {
                                J$.Ex(1105, J$e);
                            } finally {
                                if (J$.Fr(1109))
                                    continue jalangiLabel1;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12),
                pop: J$.T(221, function () {
                    jalangiLabel2:
                        while (true) {
                            try {
                                J$.Fe(205, arguments.callee, this);
                                arguments = J$.N(209, 'arguments', arguments, true);
                                J$.N(213, 'result', result, false);
                                J$.N(217, 'end', end, false);
                                var result = J$.W(129, 'result', J$.G(125, J$.G(117, J$.R(113, 'this', this, false), 'content'), J$.T(121, 0, 22)), result);
                                var end = J$.W(145, 'end', J$.M(141, J$.G(137, J$.R(133, 'this', this, false), 'content'), 'pop', false)(), end);
                                if (J$.C(4, J$.B(10, '>', J$.G(157, J$.G(153, J$.R(149, 'this', this, false), 'content'), 'length'), J$.T(161, 0, 22)))) {
                                    J$.P(181, J$.G(169, J$.R(165, 'this', this, false), 'content'), J$.T(173, 0, 22), J$.R(177, 'end', end, false));
                                    J$.M(193, J$.R(185, 'this', this, false), 'sinkDown', false)(J$.T(189, 0, 22));
                                }
                                return J$.Rt(201, J$.R(197, 'result', result, false));
                            } catch (J$e) {
                                J$.Ex(1113, J$e);
                            } finally {
                                if (J$.Fr(1117))
                                    continue jalangiLabel2;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12),
                remove: J$.T(381, function (node) {
                    jalangiLabel3:
                        while (true) {
                            try {
                                J$.Fe(357, arguments.callee, this);
                                arguments = J$.N(361, 'arguments', arguments, true);
                                node = J$.N(365, 'node', node, true);
                                J$.N(369, 'length', length, false);
                                J$.N(373, 'i', i, false);
                                J$.N(377, 'end', end, false);
                                var length = J$.W(237, 'length', J$.G(233, J$.G(229, J$.R(225, 'this', this, false), 'content'), 'length'), length);
                                for (var i = J$.W(245, 'i', J$.T(241, 0, 22), i); J$.C(16, J$.B(14, '<', J$.R(249, 'i', i, false), J$.R(253, 'length', length, false))); J$.B(26, '-', i = J$.W(261, 'i', J$.B(22, '+', J$.U(18, '+', J$.R(257, 'i', i, false)), 1), i), 1)) {
                                    if (J$.C(8, J$.B(30, '!=', J$.G(277, J$.G(269, J$.R(265, 'this', this, false), 'content'), J$.R(273, 'i', i, false)), J$.R(281, 'node', node, false))))
                                        continue;
                                    var end = J$.W(297, 'end', J$.M(293, J$.G(289, J$.R(285, 'this', this, false), 'content'), 'pop', false)(), end);
                                    if (J$.C(12, J$.B(38, '==', J$.R(301, 'i', i, false), J$.B(34, '-', J$.R(305, 'length', length, false), J$.T(309, 1, 22)))))
                                        break;
                                    J$.P(329, J$.G(317, J$.R(313, 'this', this, false), 'content'), J$.R(321, 'i', i, false), J$.R(325, 'end', end, false));
                                    J$.M(341, J$.R(333, 'this', this, false), 'bubbleUp', false)(J$.R(337, 'i', i, false));
                                    J$.M(353, J$.R(345, 'this', this, false), 'sinkDown', false)(J$.R(349, 'i', i, false));
                                    break;
                                }
                            } catch (J$e) {
                                J$.Ex(1121, J$e);
                            } finally {
                                if (J$.Fr(1125))
                                    continue jalangiLabel3;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12),
                size: J$.T(409, function () {
                    jalangiLabel4:
                        while (true) {
                            try {
                                J$.Fe(401, arguments.callee, this);
                                arguments = J$.N(405, 'arguments', arguments, true);
                                return J$.Rt(397, J$.G(393, J$.G(389, J$.R(385, 'this', this, false), 'content'), 'length'));
                            } catch (J$e) {
                                J$.Ex(1129, J$e);
                            } finally {
                                if (J$.Fr(1133))
                                    continue jalangiLabel4;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12),
                bubbleUp: J$.T(597, function (n) {
                    jalangiLabel5:
                        while (true) {
                            try {
                                J$.Fe(569, arguments.callee, this);
                                arguments = J$.N(573, 'arguments', arguments, true);
                                n = J$.N(577, 'n', n, true);
                                J$.N(581, 'element', element, false);
                                J$.N(585, 'score', score, false);
                                J$.N(589, 'parentN', parentN, false);
                                J$.N(593, 'parent', parent, false);
                                var element = J$.W(441, 'element', J$.G(425, J$.G(417, J$.R(413, 'this', this, false), 'content'), J$.R(421, 'n', n, false)), element), score = J$.W(445, 'score', J$.M(437, J$.R(429, 'this', this, false), 'scoreFunction', false)(J$.R(433, 'element', element, false)), score);
                                while (J$.C(24, J$.B(42, '>', J$.R(449, 'n', n, false), J$.T(453, 0, 22)))) {
                                    var parentN = J$.W(497, 'parentN', J$.B(54, '-', J$.M(473, J$.I(typeof Math === 'undefined' ? Math = J$.R(457, 'Math', undefined, true) : Math = J$.R(457, 'Math', Math, true)), 'floor', false)(J$.B(50, '/', J$.B(46, '+', J$.R(461, 'n', n, false), J$.T(465, 1, 22)), J$.T(469, 2, 22))), J$.T(477, 1, 22)), parentN), parent = J$.W(501, 'parent', J$.G(493, J$.G(485, J$.R(481, 'this', this, false), 'content'), J$.R(489, 'parentN', parentN, false)), parent);
                                    if (J$.C(20, J$.B(58, '>=', J$.R(505, 'score', score, false), J$.M(517, J$.R(509, 'this', this, false), 'scoreFunction', false)(J$.R(513, 'parent', parent, false)))))
                                        break;
                                    J$.P(537, J$.G(525, J$.R(521, 'this', this, false), 'content'), J$.R(529, 'parentN', parentN, false), J$.R(533, 'element', element, false));
                                    J$.P(557, J$.G(545, J$.R(541, 'this', this, false), 'content'), J$.R(549, 'n', n, false), J$.R(553, 'parent', parent, false));
                                    n = J$.W(565, 'n', J$.R(561, 'parentN', parentN, false), n);
                                }
                            } catch (J$e) {
                                J$.Ex(1137, J$e);
                            } finally {
                                if (J$.Fr(1141))
                                    continue jalangiLabel5;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12),
                sinkDown: J$.T(945, function (n) {
                    jalangiLabel6:
                        while (true) {
                            try {
                                J$.Fe(893, arguments.callee, this);
                                arguments = J$.N(897, 'arguments', arguments, true);
                                n = J$.N(901, 'n', n, true);
                                J$.N(905, 'length', length, false);
                                J$.N(909, 'element', element, false);
                                J$.N(913, 'elemScore', elemScore, false);
                                J$.N(917, 'child2N', child2N, false);
                                J$.N(921, 'child1N', child1N, false);
                                J$.N(925, 'swap', swap, false);
                                J$.N(929, 'child1', child1, false);
                                J$.N(933, 'child1Score', child1Score, false);
                                J$.N(937, 'child2', child2, false);
                                J$.N(941, 'child2Score', child2Score, false);
                                var length = J$.W(641, 'length', J$.G(609, J$.G(605, J$.R(601, 'this', this, false), 'content'), 'length'), length), element = J$.W(645, 'element', J$.G(625, J$.G(617, J$.R(613, 'this', this, false), 'content'), J$.R(621, 'n', n, false)), element), elemScore = J$.W(649, 'elemScore', J$.M(637, J$.R(629, 'this', this, false), 'scoreFunction', false)(J$.R(633, 'element', element, false)), elemScore);
                                while (J$.C(52, J$.T(653, true, 23))) {
                                    var child2N = J$.W(677, 'child2N', J$.B(66, '*', J$.B(62, '+', J$.R(657, 'n', n, false), J$.T(661, 1, 22)), J$.T(665, 2, 22)), child2N), child1N = J$.W(681, 'child1N', J$.B(70, '-', J$.R(669, 'child2N', child2N, false), J$.T(673, 1, 22)), child1N);
                                    var swap = J$.W(689, 'swap', J$.T(685, null, 25), swap);
                                    if (J$.C(32, J$.B(74, '<', J$.R(693, 'child1N', child1N, false), J$.R(697, 'length', length, false)))) {
                                        var child1 = J$.W(729, 'child1', J$.G(713, J$.G(705, J$.R(701, 'this', this, false), 'content'), J$.R(709, 'child1N', child1N, false)), child1), child1Score = J$.W(733, 'child1Score', J$.M(725, J$.R(717, 'this', this, false), 'scoreFunction', false)(J$.R(721, 'child1', child1, false)), child1Score);
                                        if (J$.C(28, J$.B(78, '<', J$.R(737, 'child1Score', child1Score, false), J$.R(741, 'elemScore', elemScore, false))))
                                            swap = J$.W(749, 'swap', J$.R(745, 'child1N', child1N, false), swap);
                                    }
                                    if (J$.C(44, J$.B(82, '<', J$.R(753, 'child2N', child2N, false), J$.R(757, 'length', length, false)))) {
                                        var child2 = J$.W(789, 'child2', J$.G(773, J$.G(765, J$.R(761, 'this', this, false), 'content'), J$.R(769, 'child2N', child2N, false)), child2), child2Score = J$.W(793, 'child2Score', J$.M(785, J$.R(777, 'this', this, false), 'scoreFunction', false)(J$.R(781, 'child2', child2, false)), child2Score);
                                        if (J$.C(40, J$.B(90, '<', J$.R(797, 'child2Score', child2Score, false), J$.C(36, J$.B(86, '==', J$.R(801, 'swap', swap, false), J$.T(805, null, 25))) ? J$.R(809, 'elemScore', elemScore, false) : J$.R(813, 'child1Score', child1Score, false))))
                                            swap = J$.W(821, 'swap', J$.R(817, 'child2N', child2N, false), swap);
                                    }
                                    if (J$.C(48, J$.B(94, '==', J$.R(825, 'swap', swap, false), J$.T(829, null, 25))))
                                        break;
                                    J$.P(861, J$.G(837, J$.R(833, 'this', this, false), 'content'), J$.R(841, 'n', n, false), J$.G(857, J$.G(849, J$.R(845, 'this', this, false), 'content'), J$.R(853, 'swap', swap, false)));
                                    J$.P(881, J$.G(869, J$.R(865, 'this', this, false), 'content'), J$.R(873, 'swap', swap, false), J$.R(877, 'element', element, false));
                                    n = J$.W(889, 'n', J$.R(885, 'swap', swap, false), n);
                                }
                            } catch (J$e) {
                                J$.Ex(1145, J$e);
                            } finally {
                                if (J$.Fr(1149))
                                    continue jalangiLabel6;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12)
            }, 11));
            var heap = J$.W(993, 'heap', J$.T(989, J$.F(985, J$.R(957, 'BinaryHeap', BinaryHeap, false), true)(J$.T(981, function (x) {
                    jalangiLabel7:
                        while (true) {
                            try {
                                J$.Fe(969, arguments.callee, this);
                                arguments = J$.N(973, 'arguments', arguments, true);
                                x = J$.N(977, 'x', x, true);
                                return J$.Rt(965, J$.R(961, 'x', x, false));
                            } catch (J$e) {
                                J$.Ex(1153, J$e);
                            } finally {
                                if (J$.Fr(1157))
                                    continue jalangiLabel7;
                                else
                                    return J$.Ra();
                            }
                        }
                }, 12)), 11), heap);
            for (var i = J$.W(1001, 'i', J$.T(997, 0, 22), i); J$.C(56, J$.B(98, '<', J$.R(1005, 'i', i, false), J$.T(1009, 4, 22))); J$.B(110, '-', i = J$.W(1017, 'i', J$.B(106, '+', J$.U(102, '+', J$.R(1013, 'i', i, false)), 1), i), 1)) {
                J$.M(1033, J$.R(1021, 'heap', heap, false), 'push', false)(J$.M(1029, J$, 'readInput', false)(J$.T(1025, 1, 22)));
            }
            J$.M(1045, J$.R(1037, 'heap', heap, false), 'remove', false)(J$.T(1041, 2, 22));
            while (J$.C(60, J$.B(114, '>', J$.M(1053, J$.R(1049, 'heap', heap, false), 'size', false)(), J$.T(1057, 0, 22))))
                J$.F(1073, J$.I(typeof print === 'undefined' ? print = J$.R(1061, 'print', undefined, true) : print = J$.R(1061, 'print', print, true)), false)(J$.M(1069, J$.R(1065, 'heap', heap, false), 'pop', false)());
        } catch (J$e) {
            J$.Ex(1161, J$e);
        } finally {
            if (J$.Sr(1165))
                continue jalangiLabel8;
            else
                break jalangiLabel8;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=binaryHeap_jalangi_.js.map