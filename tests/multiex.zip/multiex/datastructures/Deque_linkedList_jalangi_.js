J$.noInstrEval = false;
jalangiLabel12:
    while (true) {
        try {
            J$.Se(1665, '../tests/multiex/datastructures/Deque_linkedList_jalangi_.js');
            function Deque() {
                jalangiLabel10:
                    while (true) {
                        try {
                            J$.Fe(1409, arguments.callee, this, arguments);
                            arguments = J$.N(1417, 'arguments', arguments, true, false);
                            J$.N(1425, 'count', count, false, false);
                            J$.N(1433, 'head', head, false, false);
                            J$.N(1441, 'tail', tail, false, false);
                            J$.N(1449, 'Node', Node, false, false);
                            var count = J$.W(17, 'count', J$.T(9, 0, 22, false), count, false, false);
                            var head = J$.W(33, 'head', J$.T(25, null, 25, false), head, false, false);
                            var tail = J$.W(49, 'tail', J$.T(41, null, 25, false), tail, false, false);
                            J$.P(137, J$.R(57, 'this', this, false, false), 'getHead', J$.T(129, function () {
                                jalangiLabel0:
                                    while (true) {
                                        try {
                                            J$.Fe(113, arguments.callee, this, arguments);
                                            arguments = J$.N(121, 'arguments', arguments, true, false);
                                            if (J$.C(8, J$.R(65, 'head', head, false, false))) {
                                                return J$.Rt(89, J$.G(81, J$.R(73, 'head', head, false, false), 'data'));
                                            }
                                            return J$.Rt(105, J$.T(97, null, 25, false));
                                        } catch (J$e) {
                                            J$.Ex(1713, J$e);
                                        } finally {
                                            if (J$.Fr(1721))
                                                continue jalangiLabel0;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(225, J$.R(145, 'this', this, false, false), 'getTail', J$.T(217, function () {
                                jalangiLabel1:
                                    while (true) {
                                        try {
                                            J$.Fe(201, arguments.callee, this, arguments);
                                            arguments = J$.N(209, 'arguments', arguments, true, false);
                                            if (J$.C(16, J$.R(153, 'tail', tail, false, false))) {
                                                return J$.Rt(177, J$.G(169, J$.R(161, 'tail', tail, false, false), 'data'));
                                            }
                                            return J$.Rt(193, J$.T(185, null, 25, false));
                                        } catch (J$e) {
                                            J$.Ex(1729, J$e);
                                        } finally {
                                            if (J$.Fr(1737))
                                                continue jalangiLabel1;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(281, J$.R(233, 'this', this, false, false), 'GetCount', J$.T(273, function () {
                                jalangiLabel2:
                                    while (true) {
                                        try {
                                            J$.Fe(257, arguments.callee, this, arguments);
                                            arguments = J$.N(265, 'arguments', arguments, true, false);
                                            return J$.Rt(249, J$.R(241, 'count', count, false, false));
                                        } catch (J$e) {
                                            J$.Ex(1745, J$e);
                                        } finally {
                                            if (J$.Fr(1753))
                                                continue jalangiLabel2;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            var Node = J$.W(369, 'Node', J$.T(361, function (data) {
                                    jalangiLabel3:
                                        while (true) {
                                            try {
                                                J$.Fe(337, arguments.callee, this, arguments);
                                                arguments = J$.N(345, 'arguments', arguments, true, false);
                                                data = J$.N(353, 'data', data, true, false);
                                                J$.P(305, J$.R(289, 'this', this, false, false), 'data', J$.R(297, 'data', data, false, false));
                                                J$.P(329, J$.R(313, 'this', this, false, false), 'next', J$.T(321, null, 25, false));
                                            } catch (J$e) {
                                                J$.Ex(1761, J$e);
                                            } finally {
                                                if (J$.Fr(1769))
                                                    continue jalangiLabel3;
                                                else
                                                    return J$.Ra();
                                            }
                                        }
                                }, 12, false), Node, false, false);
                            J$.P(577, J$.R(377, 'this', this, false, false), 'DisplayHeadToTail', J$.T(569, function () {
                                jalangiLabel4:
                                    while (true) {
                                        try {
                                            J$.Fe(537, arguments.callee, this, arguments);
                                            arguments = J$.N(545, 'arguments', arguments, true, false);
                                            J$.N(553, 'arr', arr, false, false);
                                            J$.N(561, 'current', current, false, false);
                                            if (J$.C(32, J$.B(10, '!=', J$.R(385, 'head', head, false, false), J$.T(393, null, 25, false)))) {
                                                var arr = J$.W(417, 'arr', J$.F(409, J$.I(typeof Array === 'undefined' ? Array = J$.R(401, 'Array', undefined, true, true) : Array = J$.R(401, 'Array', Array, true, true)), true)(), arr, false, false);
                                                var current = J$.W(433, 'current', J$.R(425, 'head', head, false, false), current, false, false);
                                                while (J$.C(24, J$.R(441, 'current', current, false, false))) {
                                                    J$.M(473, J$.R(449, 'arr', arr, false, false), 'push', false)(J$.G(465, J$.R(457, 'current', current, false, false), 'data'));
                                                    current = J$.W(497, 'current', J$.G(489, J$.R(481, 'current', current, false, false), 'next'), current, false, false);
                                                }
                                                return J$.Rt(513, J$.R(505, 'arr', arr, false, false));
                                            } else {
                                                return J$.Rt(529, J$.T(521, null, 25, false));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(1777, J$e);
                                        } finally {
                                            if (J$.Fr(1785))
                                                continue jalangiLabel4;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(705, J$.R(585, 'this', this, false, false), 'DisplayTailToHead', J$.T(697, function () {
                                jalangiLabel5:
                                    while (true) {
                                        try {
                                            J$.Fe(673, arguments.callee, this, arguments);
                                            arguments = J$.N(681, 'arguments', arguments, true, false);
                                            J$.N(689, 'arr', arr, false, false);
                                            if (J$.C(40, J$.B(18, '!=', J$.R(593, 'head', head, false, false), J$.T(601, null, 25, false)))) {
                                                var arr = J$.W(625, 'arr', J$.M(617, J$.R(609, 'this', this, false, false), 'DisplayHeadToTail', false)(), arr, false, false);
                                                return J$.Rt(649, J$.M(641, J$.R(633, 'arr', arr, false, false), 'reverse', false)());
                                            } else {
                                                return J$.Rt(665, J$.T(657, null, 25, false));
                                            }
                                        } catch (J$e) {
                                            J$.Ex(1793, J$e);
                                        } finally {
                                            if (J$.Fr(1801))
                                                continue jalangiLabel5;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(873, J$.R(713, 'this', this, false, false), 'AddHead', J$.T(865, function (data) {
                                jalangiLabel6:
                                    while (true) {
                                        try {
                                            J$.Fe(833, arguments.callee, this, arguments);
                                            arguments = J$.N(841, 'arguments', arguments, true, false);
                                            data = J$.N(849, 'data', data, true, false);
                                            J$.N(857, 'node', node, false, false);
                                            var node = J$.W(745, 'node', J$.F(737, J$.R(721, 'Node', Node, false, false), true)(J$.R(729, 'data', data, false, false)), node, false, false);
                                            J$.P(769, J$.R(753, 'node', node, false, false), 'next', J$.R(761, 'head', head, false, false));
                                            head = J$.W(785, 'head', J$.R(777, 'node', node, false, false), head, false, false);
                                            if (J$.C(48, J$.U(26, '!', J$.R(793, 'tail', tail, false, false)))) {
                                                tail = J$.W(809, 'tail', J$.R(801, 'head', head, false, false), tail, false, false);
                                            }
                                            J$.B(50, '-', count = J$.W(825, 'count', J$.B(42, '+', J$.U(34, '+', J$.R(817, 'count', count, false, false)), 1), count, false, false), 1);
                                        } catch (J$e) {
                                            J$.Ex(1809, J$e);
                                        } finally {
                                            if (J$.Fr(1817))
                                                continue jalangiLabel6;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(1041, J$.R(881, 'this', this, false, false), 'AddTail', J$.T(1033, function (data) {
                                jalangiLabel7:
                                    while (true) {
                                        try {
                                            J$.Fe(1001, arguments.callee, this, arguments);
                                            arguments = J$.N(1009, 'arguments', arguments, true, false);
                                            data = J$.N(1017, 'data', data, true, false);
                                            J$.N(1025, 'node', node, false, false);
                                            var node = J$.W(913, 'node', J$.F(905, J$.R(889, 'Node', Node, false, false), true)(J$.R(897, 'data', data, false, false)), node, false, false);
                                            if (J$.C(56, J$.U(58, '!', J$.R(921, 'head', head, false, false)))) {
                                                head = J$.W(937, 'head', J$.R(929, 'node', node, false, false), head, false, false);
                                            } else {
                                                J$.P(961, J$.R(945, 'tail', tail, false, false), 'next', J$.R(953, 'node', node, false, false));
                                            }
                                            tail = J$.W(977, 'tail', J$.R(969, 'node', node, false, false), tail, false, false);
                                            J$.B(82, '-', count = J$.W(993, 'count', J$.B(74, '+', J$.U(66, '+', J$.R(985, 'count', count, false, false)), 1), count, false, false), 1);
                                        } catch (J$e) {
                                            J$.Ex(1825, J$e);
                                        } finally {
                                            if (J$.Fr(1833))
                                                continue jalangiLabel7;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(1177, J$.R(1049, 'this', this, false, false), 'RemoveHead', J$.T(1169, function () {
                                jalangiLabel8:
                                    while (true) {
                                        try {
                                            J$.Fe(1153, arguments.callee, this, arguments);
                                            arguments = J$.N(1161, 'arguments', arguments, true, false);
                                            if (J$.C(72, J$.R(1057, 'head', head, false, false))) {
                                                if (J$.C(64, J$.B(90, '===', J$.R(1065, 'count', count, false, false), J$.T(1073, 1, 22, false)))) {
                                                    head = J$.W(1089, 'head', J$.T(1081, null, 25, false), head, false, false);
                                                    tail = J$.W(1105, 'tail', J$.T(1097, null, 25, false), tail, false, false);
                                                } else {
                                                    head = J$.W(1129, 'head', J$.G(1121, J$.R(1113, 'head', head, false, false), 'next'), head, false, false);
                                                }
                                                J$.B(114, '+', count = J$.W(1145, 'count', J$.B(106, '-', J$.U(98, '+', J$.R(1137, 'count', count, false, false)), 1), count, false, false), 1);
                                            }
                                        } catch (J$e) {
                                            J$.Ex(1841, J$e);
                                        } finally {
                                            if (J$.Fr(1849))
                                                continue jalangiLabel8;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(1401, J$.R(1185, 'this', this, false, false), 'RemoveTail', J$.T(1393, function () {
                                jalangiLabel9:
                                    while (true) {
                                        try {
                                            J$.Fe(1369, arguments.callee, this, arguments);
                                            arguments = J$.N(1377, 'arguments', arguments, true, false);
                                            J$.N(1385, 'current', current, false, false);
                                            if (J$.C(96, J$.R(1193, 'head', head, false, false))) {
                                                if (J$.C(88, J$.B(122, '===', J$.R(1201, 'count', count, false, false), J$.T(1209, 1, 22, false)))) {
                                                    head = J$.W(1225, 'head', J$.T(1217, null, 25, false), head, false, false);
                                                    tail = J$.W(1241, 'tail', J$.T(1233, null, 25, false), tail, false, false);
                                                } else {
                                                    var current = J$.W(1257, 'current', J$.R(1249, 'head', head, false, false), current, false, false);
                                                    while (J$.C(80, J$.G(1281, J$.G(1273, J$.R(1265, 'current', current, false, false), 'next'), 'next'))) {
                                                        current = J$.W(1305, 'current', J$.G(1297, J$.R(1289, 'current', current, false, false), 'next'), current, false, false);
                                                    }
                                                    tail = J$.W(1321, 'tail', J$.R(1313, 'current', current, false, false), tail, false, false);
                                                    J$.P(1345, J$.R(1329, 'tail', tail, false, false), 'next', J$.T(1337, null, 25, false));
                                                }
                                                J$.B(146, '+', count = J$.W(1361, 'count', J$.B(138, '-', J$.U(130, '+', J$.R(1353, 'count', count, false, false)), 1), count, false, false), 1);
                                            }
                                        } catch (J$e) {
                                            J$.Ex(1857, J$e);
                                        } finally {
                                            if (J$.Fr(1865))
                                                continue jalangiLabel9;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                        } catch (J$e) {
                            J$.Ex(1873, J$e);
                        } finally {
                            if (J$.Fr(1881))
                                continue jalangiLabel10;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function f() {
                jalangiLabel11:
                    while (true) {
                        try {
                            J$.Fe(1577, arguments.callee, this, arguments);
                            arguments = J$.N(1585, 'arguments', arguments, true, false);
                            J$.N(1593, 'flag', flag, false, false);
                            var flag = J$.W(1497, 'flag', J$.M(1489, J$, 'readInput', false)(J$.T(1481, 1, 22, false)), flag, false, false);
                            if (J$.C(112, J$.B(154, '===', J$.R(1505, 'flag', flag, false, false), J$.T(1513, 1, 22, false)))) {
                                J$.M(1537, J$.R(1521, 'list', list, false, true), 'AddHead', false)(J$.T(1529, 'data', 21, false));
                            } else if (J$.C(104, J$.B(162, '===', J$.R(1545, 'flag', flag, false, false), J$.T(1553, 3, 22, false)))) {
                                J$.M(1569, J$.R(1561, 'list', list, false, true), 'RemoveHead', false)();
                            }
                        } catch (J$e) {
                            J$.Ex(1889, J$e);
                        } finally {
                            if (J$.Fr(1897))
                                continue jalangiLabel11;
                            else
                                return J$.Ra();
                        }
                    }
            }
            Deque = J$.N(1681, 'Deque', J$.T(1673, Deque, 12, false), true, false);
            J$.N(1689, 'list', list, false, false);
            f = J$.N(1705, 'f', J$.T(1697, f, 12, false), true, false);
            var list = J$.W(1473, 'list', J$.F(1465, J$.R(1457, 'Deque', Deque, false, true), true)(), list, false, true);
            J$.F(1609, J$.R(1601, 'f', f, false, true), false)();
            J$.F(1625, J$.R(1617, 'f', f, false, true), false)();
            J$.F(1641, J$.R(1633, 'f', f, false, true), false)();
            J$.F(1657, J$.R(1649, 'f', f, false, true), false)();
        } catch (J$e) {
            J$.Ex(1905, J$e);
        } finally {
            if (J$.Sr(1913))
                continue jalangiLabel12;
            else
                break jalangiLabel12;
        }
    }
// JALANGI DO NOT INSTRUMENT

