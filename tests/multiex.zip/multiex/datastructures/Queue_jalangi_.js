J$.noInstrEval = false;
jalangiLabel7:
    while (true) {
        try {
            J$.Se(841, '../tests/multiex/datastructures/Queue_jalangi_.js');
            function Queue() {
                jalangiLabel5:
                    while (true) {
                        try {
                            J$.Fe(585, arguments.callee, this, arguments);
                            arguments = J$.N(593, 'arguments', arguments, true, false);
                            J$.N(601, 'queue', queue, false, false);
                            J$.N(609, 'offset', offset, false, false);
                            var queue = J$.W(17, 'queue', J$.T(9, [], 10, false), queue, false, false);
                            var offset = J$.W(33, 'offset', J$.T(25, 0, 22, false), offset, false, false);
                            J$.P(105, J$.R(41, 'this', this, false, false), 'getLength', J$.T(97, function () {
                                jalangiLabel0:
                                    while (true) {
                                        try {
                                            J$.Fe(81, arguments.callee, this, arguments);
                                            arguments = J$.N(89, 'arguments', arguments, true, false);
                                            return J$.Rt(73, J$.B(10, '-', J$.G(57, J$.R(49, 'queue', queue, false, false), 'length'), J$.R(65, 'offset', offset, false, false)));
                                        } catch (J$e) {
                                            J$.Ex(881, J$e);
                                        } finally {
                                            if (J$.Fr(889))
                                                continue jalangiLabel0;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(177, J$.R(113, 'this', this, false, false), 'isEmpty', J$.T(169, function () {
                                jalangiLabel1:
                                    while (true) {
                                        try {
                                            J$.Fe(153, arguments.callee, this, arguments);
                                            arguments = J$.N(161, 'arguments', arguments, true, false);
                                            return J$.Rt(145, J$.B(18, '==', J$.G(129, J$.R(121, 'queue', queue, false, false), 'length'), J$.T(137, 0, 22, false)));
                                        } catch (J$e) {
                                            J$.Ex(897, J$e);
                                        } finally {
                                            if (J$.Fr(905))
                                                continue jalangiLabel1;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(249, J$.R(185, 'this', this, false, false), 'enqueue', J$.T(241, function (item) {
                                jalangiLabel2:
                                    while (true) {
                                        try {
                                            J$.Fe(217, arguments.callee, this, arguments);
                                            arguments = J$.N(225, 'arguments', arguments, true, false);
                                            item = J$.N(233, 'item', item, true, false);
                                            J$.M(209, J$.R(193, 'queue', queue, false, false), 'push', false)(J$.R(201, 'item', item, false, false));
                                        } catch (J$e) {
                                            J$.Ex(913, J$e);
                                        } finally {
                                            if (J$.Fr(921))
                                                continue jalangiLabel2;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(473, J$.R(257, 'this', this, false, false), 'dequeue', J$.T(465, function () {
                                jalangiLabel3:
                                    while (true) {
                                        try {
                                            J$.Fe(441, arguments.callee, this, arguments);
                                            arguments = J$.N(449, 'arguments', arguments, true, false);
                                            J$.N(457, 'item', item, false, false);
                                            if (J$.C(8, J$.B(26, '==', J$.G(273, J$.R(265, 'queue', queue, false, false), 'length'), J$.T(281, 0, 22, false))))
                                                return J$.Rt(297, J$.T(289, undefined, 24, false));
                                            var item = J$.W(329, 'item', J$.G(321, J$.R(305, 'queue', queue, false, false), J$.R(313, 'offset', offset, false, false)), item, false, false);
                                            if (J$.C(16, J$.B(58, '>=', J$.B(50, '*', offset = J$.W(345, 'offset', J$.B(42, '+', J$.U(34, '+', J$.R(337, 'offset', offset, false, false)), 1), offset, false, false), J$.T(353, 2, 22, false)), J$.G(369, J$.R(361, 'queue', queue, false, false), 'length')))) {
                                                queue = J$.W(401, 'queue', J$.M(393, J$.R(377, 'queue', queue, false, false), 'slice', false)(J$.R(385, 'offset', offset, false, false)), queue, false, false);
                                                offset = J$.W(417, 'offset', J$.T(409, 0, 22, false), offset, false, false);
                                            }
                                            return J$.Rt(433, J$.R(425, 'item', item, false, false));
                                        } catch (J$e) {
                                            J$.Ex(929, J$e);
                                        } finally {
                                            if (J$.Fr(937))
                                                continue jalangiLabel3;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                            J$.P(577, J$.R(481, 'this', this, false, false), 'peek', J$.T(569, function () {
                                jalangiLabel4:
                                    while (true) {
                                        try {
                                            J$.Fe(553, arguments.callee, this, arguments);
                                            arguments = J$.N(561, 'arguments', arguments, true, false);
                                            return J$.Rt(545, J$.C(24, J$.B(66, '>', J$.G(497, J$.R(489, 'queue', queue, false, false), 'length'), J$.T(505, 0, 22, false))) ? J$.G(529, J$.R(513, 'queue', queue, false, false), J$.R(521, 'offset', offset, false, false)) : J$.T(537, undefined, 24, false));
                                        } catch (J$e) {
                                            J$.Ex(945, J$e);
                                        } finally {
                                            if (J$.Fr(953))
                                                continue jalangiLabel4;
                                            else
                                                return J$.Ra();
                                        }
                                    }
                            }, 12, false));
                        } catch (J$e) {
                            J$.Ex(961, J$e);
                        } finally {
                            if (J$.Fr(969))
                                continue jalangiLabel5;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function testRound() {
                jalangiLabel6:
                    while (true) {
                        try {
                            J$.Fe(729, arguments.callee, this, arguments);
                            arguments = J$.N(737, 'arguments', arguments, true, false);
                            J$.N(745, 'queue', queue, false, false);
                            J$.N(753, 'flag', flag, false, false);
                            var queue = J$.W(633, 'queue', J$.F(625, J$.R(617, 'Queue', Queue, false, true), true)(), queue, false, false);
                            var flag = J$.W(657, 'flag', J$.M(649, J$, 'readInput', false)(J$.T(641, 1, 22, false)), flag, false, false);
                            if (J$.C(32, J$.B(74, '>', J$.R(665, 'flag', flag, false, false), J$.T(673, 100, 22, false)))) {
                                J$.M(705, J$.R(681, 'queue', queue, false, false), 'enqueue', false)(J$.M(697, J$, 'readInput', false)(J$.T(689, 2, 22, false)));
                            } else {
                                J$.M(721, J$.R(713, 'queue', queue, false, false), 'dequeue', false)();
                            }
                        } catch (J$e) {
                            J$.Ex(977, J$e);
                        } finally {
                            if (J$.Fr(985))
                                continue jalangiLabel6;
                            else
                                return J$.Ra();
                        }
                    }
            }
            Queue = J$.N(857, 'Queue', J$.T(849, Queue, 12, false), true, false);
            testRound = J$.N(873, 'testRound', J$.T(865, testRound, 12, false), true, false);
            J$.F(769, J$.R(761, 'testRound', testRound, false, true), false)();
            J$.F(785, J$.R(777, 'testRound', testRound, false, true), false)();
            J$.F(801, J$.R(793, 'testRound', testRound, false, true), false)();
            J$.F(817, J$.R(809, 'testRound', testRound, false, true), false)();
            J$.F(833, J$.R(825, 'testRound', testRound, false, true), false)();
        } catch (J$e) {
            J$.Ex(993, J$e);
        } finally {
            if (J$.Sr(1001))
                continue jalangiLabel7;
            else
                break jalangiLabel7;
        }
    }
// JALANGI DO NOT INSTRUMENT

