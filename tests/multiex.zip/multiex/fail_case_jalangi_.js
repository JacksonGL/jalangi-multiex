jalangiLabel2:
    while (true) {
        try {
            J$.Se(121, '../tests/multiex/fail_case_jalangi_.js');
            J$.N(129, '_push', J$.T(125, _push, 12), false);
            J$.N(137, 'foo', J$.T(133, foo, 12), false);
            function _push(array, val) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(25, arguments.callee, this);
                            arguments = J$.N(29, 'arguments', arguments, true);
                            array = J$.N(33, 'array', array, true);
                            val = J$.N(37, 'val', val, true);
                            J$.P(21, J$.R(5, 'array', array, false), J$.G(13, J$.R(9, 'array', array, false), 'length'), J$.R(17, 'val', val, false));
                        } catch (J$e) {
                            J$.Ex(141, J$e);
                        } finally {
                            if (J$.Fr(145))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            function foo(a) {
                jalangiLabel1:
                    while (true) {
                        try {
                            J$.Fe(97, arguments.callee, this);
                            arguments = J$.N(101, 'arguments', arguments, true);
                            a = J$.N(105, 'a', a, true);
                            J$.N(109, 'array', array, false);
                            var array = J$.W(45, 'array', J$.T(41, [], 10), array);
                            J$.F(61, J$.R(49, '_push', _push, false), false)(J$.R(53, 'array', array, false), J$.R(57, 'a', a, false));
                            if (J$.C(4, J$.B(6, '>', J$.G(73, J$.R(65, 'array', array, false), J$.T(69, 0, 22)), J$.T(77, 0, 22)))) {
                                return J$.Rt(85, J$.T(81, 1, 22));
                            } else {
                                return J$.Rt(93, J$.T(89, 2, 22));
                            }
                        } catch (J$e) {
                            J$.Ex(149, J$e);
                        } finally {
                            if (J$.Fr(153))
                                continue jalangiLabel1;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.F(117, J$.R(113, 'foo', foo, false), false)();
        } catch (J$e) {
            J$.Ex(157, J$e);
        } finally {
            if (J$.Sr(161))
                continue jalangiLabel2;
            else
                break jalangiLabel2;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=fail_case_jalangi_.js.map