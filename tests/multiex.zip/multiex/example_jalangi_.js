jalangiLabel1:
    while (true) {
        try {
            J$.Se(113, '../tests/multiex/example_jalangi_.js');
            J$.N(121, 'foo', J$.T(117, foo, 12), false);
            function foo(a, b, c) {
                jalangiLabel0:
                    while (true) {
                        try {
                            J$.Fe(61, arguments.callee, this);
                            arguments = J$.N(65, 'arguments', arguments, true);
                            a = J$.N(69, 'a', a, true);
                            b = J$.N(73, 'b', b, true);
                            c = J$.N(77, 'c', c, true);
                            if (J$.C(12, J$.B(6, '>', J$.R(5, 'a', a, false), J$.R(9, 'b', b, false)))) {
                                if (J$.C(4, J$.B(10, '>', J$.R(13, 'a', a, false), J$.R(17, 'c', c, false)))) {
                                    return J$.Rt(25, J$.R(21, 'a', a, false));
                                } else {
                                    return J$.Rt(33, J$.R(29, 'c', c, false));
                                }
                            } else {
                                if (J$.C(8, J$.B(14, '>', J$.R(37, 'b', b, false), J$.R(41, 'c', c, false)))) {
                                    return J$.Rt(49, J$.R(45, 'b', b, false));
                                } else {
                                    return J$.Rt(57, J$.R(53, 'c', c, false));
                                }
                            }
                        } catch (J$e) {
                            J$.Ex(125, J$e);
                        } finally {
                            if (J$.Fr(129))
                                continue jalangiLabel0;
                            else
                                return J$.Ra();
                        }
                    }
            }
            J$.F(109, J$.R(81, 'foo', foo, false), false)(J$.M(89, J$, 'readInput', false)(J$.T(85, 1, 22)), J$.M(97, J$, 'readInput', false)(J$.T(93, 1, 22)), J$.M(105, J$, 'readInput', false)(J$.T(101, 1, 22)));
        } catch (J$e) {
            J$.Ex(133, J$e);
        } finally {
            if (J$.Sr(137))
                continue jalangiLabel1;
            else
                break jalangiLabel1;
        }
    }
// JALANGI DO NOT INSTRUMENT

//@ sourceMappingURL=example_jalangi_.js.map