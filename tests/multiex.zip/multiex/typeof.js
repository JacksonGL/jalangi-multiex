

var input = J$.readInput(true);
if(typeof input === 'object') {
    1;
} else {
    2;
}